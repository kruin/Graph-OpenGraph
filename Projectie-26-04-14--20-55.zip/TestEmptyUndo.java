import graphStructure.Graph;

public class TestEmptyUndo {
  public static void main(String[] args) {
    Graph g = new Graph();
    g.newMemento("empty");
    g.undoMemento();
    g.abortMemento();
    System.out.println("empty-undo-ok");
  }
}
