package userInterface;

import javax.swing.*;
import java.io.*;
import graphStructure.*;
import userInterface.fileUtils.*;

public class GraphFileActions
{
  private static boolean lastStartInGraphDir = true;
  private static boolean lastGraphOnly = true;

  public void loadGraph(GraphWindow graphWindow, GraphController controller)
  {
    File baseDir = new File(System.getProperty("user.dir"));
    File graphDir = getPreferredGraphDirectory(controller);

    lastStartInGraphDir = controller.getLoadGraphFromGraphDir();
    JFileChooser fc = createGraphLoadChooser(lastStartInGraphDir ? graphDir : baseDir, lastGraphOnly);
    fc.setDialogTitle("Load GRAPH File");
    fc.setApproveButtonText("Load GRAPH");

    JPanel accessory = new JPanel();
    accessory.setLayout(new BoxLayout(accessory, BoxLayout.Y_AXIS));

    JCheckBox startInGraphDir = new JCheckBox("Start in Graph dir", lastStartInGraphDir);
    JCheckBox graphOnly = new JCheckBox("Only .graph", lastGraphOnly);
    JLabel currentDirLabel = new JLabel(shortDirectoryLabel(graphDir));

    startInGraphDir.addActionListener(e ->
    {
      lastStartInGraphDir = startInGraphDir.isSelected();
      controller.setLoadGraphFromGraphDir(lastStartInGraphDir);
      fc.setCurrentDirectory(lastStartInGraphDir ? getPreferredGraphDirectory(controller) : baseDir);
      currentDirLabel.setText(shortDirectoryLabel(getPreferredGraphDirectory(controller)));
    });

    graphOnly.addActionListener(e ->
    {
      lastGraphOnly = graphOnly.isSelected();
      fc.setAcceptAllFileFilterUsed(!lastGraphOnly);
    });

    accessory.add(startInGraphDir);
    accessory.add(graphOnly);
    accessory.add(Box.createVerticalStrut(8));
    accessory.add(new JLabel("Default Graph dir:"));
    accessory.add(currentDirLabel);
    fc.setAccessory(accessory);

    loadGraphFromChooser(fc, graphWindow, controller, "Load GRAPH File");
  }

  public void chooseDefaultGraphDirectory(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = new JFileChooser(getPreferredGraphDirectory(controller));
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setDialogTitle("Set Default Graph Directory");
    fc.setApproveButtonText("Set Graph Dir");

    int returnVal = fc.showDialog(graphWindow, "Set Graph Dir");
    if ( returnVal == JFileChooser.APPROVE_OPTION && fc.getSelectedFile() != null )
    {
      try
      {
        File selected = fc.getSelectedFile().getCanonicalFile();
        controller.setPreferredGraphDirectoryPath(selected.getPath());
        controller.setLoadGraphFromGraphDir(true);
      }
      catch ( IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to use the selected directory as the default Graph directory.",
                                      "Unable to Set Graph Directory",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void loadGraphFromDir(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = createGraphLoadChooser(getPreferredGraphDirectory(controller), true);
    fc.setDialogTitle("Load GRAPH from Graph directory");
    fc.setApproveButtonText("Load GRAPH");
    loadGraphFromChooser(fc, graphWindow, controller, "Load GRAPH File");
  }

  public void saveGraph(GraphWindow graphWindow, GraphEditorWindow editorWindow)
  {
    JFileChooser fc = createSaveChooser();
    GraphFilter graphFilter = getGraphFilter(fc);
    ImageFilter imageFilter = getImageFilter(fc);

    int returnVal = fc.showDialog(graphWindow, "Save Current Graph to File");

    if ( returnVal == JFileChooser.APPROVE_OPTION )
    {
      String savePath = "";
      try
      {
        savePath = fc.getSelectedFile().getCanonicalPath();
        String fileExt = Utils.getExtension(fc.getSelectedFile());
        if ( fc.getFileFilter() == graphFilter )
        {
          saveGraphFile(graphWindow, editorWindow, savePath, fileExt);
        }
        else if ( fc.getFileFilter() == imageFilter )
        {
          saveImageFile(graphWindow, editorWindow, savePath, fileExt);
        }
      }
      catch ( java.io.IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to write to the selected file.",
                                      "Unable to Save Graph",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  private void loadGraphFromChooser(JFileChooser fc,
                                    GraphWindow graphWindow,
                                    GraphController controller,
                                    String approveText)
  {
    int returnVal = fc.showDialog(graphWindow, approveText);

    if ( returnVal == JFileChooser.APPROVE_OPTION )
    {
      String loadGraphPath = "";
      Graph graph = null;
      try
      {
        loadGraphPath = fc.getSelectedFile().getCanonicalPath();
        BufferedReader aReader = new BufferedReader(new FileReader(loadGraphPath));
        try
        {
          graph = Graph.loadFrom(aReader);
        }
        finally
        {
          aReader.close();
        }
        graph.setFilePath(loadGraphPath);
      }
      catch ( java.io.IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "The selected file could not be parsed as a GRAPH file.\n\n" +
                                      "Path: " + loadGraphPath + "\n" +
                                      "Reason: " + ioe.getMessage(),
                                      "Unable to load graph file",
                                      JOptionPane.ERROR_MESSAGE);
        return;
      }
      catch ( Exception ex )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "The selected file could not be loaded as a GRAPH file.\n\n" +
                                      "Path: " + loadGraphPath + "\n" +
                                      "Reason: " + ex.getClass().getName() +
                                      (ex.getMessage() != null ? ": " + ex.getMessage() : ""),
                                      "Unable to load graph file",
                                      JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
        return;
      }

      try
      {
        graphWindow.addGraphEditorWindow(controller, graph);
      }
      catch ( Exception ex )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "The GRAPH file was parsed, but the editor window could not be opened.\n\n" +
                                      "Path: " + loadGraphPath + "\n" +
                                      "Reason: " + ex.getClass().getName() +
                                      (ex.getMessage() != null ? ": " + ex.getMessage() : ""),
                                      "Unable to open loaded graph",
                                      JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
      }
    }
  }

  private JFileChooser createGraphLoadChooser(File currentDirectory, boolean graphOnly)
  {
    JFileChooser fc = new JFileChooser();
    GraphFilter graphFilter = new GraphFilter();
    fc.addChoosableFileFilter(graphFilter);
    fc.setFileFilter(graphFilter);
    fc.setAcceptAllFileFilterUsed(!graphOnly);
    fc.setFileView(new GraphFileView());
    fc.setCurrentDirectory(currentDirectory);
    return fc;
  }

  private File getPreferredGraphDirectory(GraphController controller)
  {
    if ( controller != null )
    {
      String preferredPath = controller.getPreferredGraphDirectoryPath();
      if ( preferredPath != null && preferredPath.trim().length() > 0 )
      {
        File preferredDir = new File(preferredPath.trim());
        if ( preferredDir.exists() && preferredDir.isDirectory() )
        {
          return preferredDir;
        }
      }
    }

    File graphDir = new File(System.getProperty("user.dir"), "GRAPH");
    if ( graphDir.exists() && graphDir.isDirectory() )
    {
      return graphDir;
    }
    return new File(System.getProperty("user.dir"));
  }

  private String shortDirectoryLabel(File dir)
  {
    String path = dir.getPath();
    if ( path.length() > 36 )
    {
      return "..." + path.substring(path.length() - 33);
    }
    return path;
  }

  private JFileChooser createSaveChooser()
  {
    JFileChooser fc = new JFileChooser();
    GraphFilter graphFilter = new GraphFilter();
    ImageFilter imageFilter = new ImageFilter();
    fc.addChoosableFileFilter(graphFilter);
    fc.addChoosableFileFilter(imageFilter);
    fc.setFileFilter(graphFilter);
    fc.setFileView(new GraphFileView());
    fc.setCurrentDirectory(new File(System.getProperty("user.dir")));
    return fc;
  }

  private GraphFilter getGraphFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter filters[] = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof GraphFilter )
      {
        return (GraphFilter)filters[i];
      }
    }
    return null;
  }

  private ImageFilter getImageFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter filters[] = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof ImageFilter )
      {
        return (ImageFilter)filters[i];
      }
    }
    return null;
  }

  private void saveGraphFile(GraphWindow graphWindow, GraphEditorWindow editorWindow, String savePath, String fileExt) throws IOException
  {
    String targetPath = savePath;
    String targetExtension = fileExt;

    if ( targetExtension == null )
    {
      targetPath = targetPath + ".graph";
      targetExtension = Utils.graph;
    }

    if ( targetExtension != null && targetExtension.equalsIgnoreCase(Utils.graph) )
    {
      File aFile = new File(targetPath);
      if ( !aFile.exists() || confirmOverwrite(graphWindow, targetPath) )
      {
        PrintWriter aWriter = new PrintWriter(new FileWriter(targetPath));
        editorWindow.getGraphEditor().getGraph().saveTo(aWriter);
        aWriter.close();
      }
    }
    else
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Graphs may only be saved as .graph files.",
                                    "Unable to Save Graph",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private void saveImageFile(GraphWindow graphWindow, GraphEditorWindow editorWindow, String savePath, String fileExt)
  {
    if ( fileExt != null &&
         ( fileExt.equalsIgnoreCase(Utils.gif) ||
           fileExt.equalsIgnoreCase(Utils.jpg) ||
           fileExt.equalsIgnoreCase(Utils.jpeg) ) )
    {
      File aFile = new File(savePath);
      if ( !aFile.exists() || confirmOverwrite(graphWindow, savePath) )
      {
        editorWindow.getGraphEditor().saveImage(savePath);
      }
    }
    else
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Images may only be saved as .gif, .jpg, or .jpeg files.",
                                    "Unable to Save Graph Image",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private boolean confirmOverwrite(GraphWindow graphWindow, String targetPath)
  {
    int option = JOptionPane.showConfirmDialog(graphWindow,
                                               "Overwrite existing file?\n\n" + targetPath,
                                               "Confirm overwrite",
                                               JOptionPane.YES_NO_OPTION,
                                               JOptionPane.WARNING_MESSAGE);
    return option == JOptionPane.YES_OPTION;
  }
}
