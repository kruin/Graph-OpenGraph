package userInterface.menuAndToolBar;

import java.lang.reflect.Method;
import javax.swing.*;
import userInterface.GraphController;

public class MenuAndToolBarWindowSupport
{
  private MenuAndToolBar owner;
  private GraphController controller;

  public MenuAndToolBarWindowSupport(MenuAndToolBar owner, GraphController controller)
  {
    this.owner = owner;
    this.controller = controller;
  }

  public void removeWindow(JMenuItem menuItem)
  {
    JMenu windowMenu = owner.getWindowMenu();
    windowMenu.remove(menuItem);
    if ( windowMenu.getItemCount() == 0 )
    {
      windowMenu.add(owner.getNoWindowItem());
    }
  }

  public void addWindow(JMenuItem menuItem)
  {
    JMenu windowMenu = owner.getWindowMenu();
    if ( !windowContainsMenuItem(menuItem) )
    {
      if ( windowMenu.getItemCount() > 0 &&
           windowMenu.getItem(0) == owner.getNoWindowItem() )
      {
        windowMenu.remove(owner.getNoWindowItem());
      }
      windowMenu.add(menuItem);
    }
  }

  private boolean windowContainsMenuItem(JMenuItem item)
  {
    boolean found = false;
    JMenu windowMenu = owner.getWindowMenu();
    if ( item == null )
    {
      return true;
    }
    for ( int i=0; i<windowMenu.getItemCount(); i++ )
    {
      if ( windowMenu.getItem(i) == item )
      {
        found = true;
        break;
      }
    }
    return found;
  }

  public void createSaveOTSAction()
  {
    Method method = null;
    try
    {
      method = GraphController.class.getDeclaredMethod("saveOTS");
    }
    catch (NoSuchMethodException nsme)
    {
      // error
    }
    MenuAndToolBarAction saveOTSAction = new MenuAndToolBarAction(
      "Save OTS",
      new ImageIcon(MenuAndToolBar.class.getResource("/images/Save.gif")),
      "Save the current Open Tree Structure result",
      Integer.valueOf((int)'O'),
      false,
      1,
      method,
      false,
      controller
    );
    owner.setSaveOTSAction(saveOTSAction);
    owner.addAction(saveOTSAction);
    saveOTSAction.setEnabled(false);
  }

  private boolean fileContainsMenuItem(JMenuItem item)
  {
    JMenu fileMenu = owner.getFileMenu();
    if ( fileMenu == null || item == null )
    {
      return false;
    }
    for ( int i=0; i<fileMenu.getItemCount(); i++ )
    {
      if ( fileMenu.getItem(i) == item )
      {
        return true;
      }
    }
    return false;
  }

  private int getFileMenuIndexAfterSaveGraph()
  {
    JMenu fileMenu = owner.getFileMenu();
    if ( fileMenu == null )
    {
      return -1;
    }
    for ( int i=0; i<fileMenu.getItemCount(); i++ )
    {
      JMenuItem item = fileMenu.getItem(i);
      if ( item != null && "Save Graph".equals(item.getText()) )
      {
        return i + 1;
      }
    }
    return fileMenu.getItemCount();
  }

  public void showSaveOTS()
  {
    JMenu fileMenu = owner.getFileMenu();
    MenuAndToolBarAction saveOTSAction = owner.getSaveOTSAction();
    if ( fileMenu == null || saveOTSAction == null )
    {
      return;
    }
    JMenuItem item = saveOTSAction.getMenuItem();
    if ( !fileContainsMenuItem(item) )
    {
      int index = getFileMenuIndexAfterSaveGraph();
      if ( index < 0 || index > fileMenu.getItemCount() )
      {
        fileMenu.add(item);
      }
      else
      {
        fileMenu.insert(item, index);
      }
    }
  }

  public void hideSaveOTS()
  {
    JMenu fileMenu = owner.getFileMenu();
    MenuAndToolBarAction saveOTSAction = owner.getSaveOTSAction();
    if ( fileMenu == null || saveOTSAction == null )
    {
      return;
    }
    JMenuItem item = saveOTSAction.getMenuItem();
    if ( fileContainsMenuItem(item) )
    {
      fileMenu.remove(item);
      fileMenu.revalidate();
      fileMenu.repaint();
    }
  }

  public void setSaveOTSEnabled(boolean enabled)
  {
    MenuAndToolBarAction saveOTSAction = owner.getSaveOTSAction();
    if ( saveOTSAction != null )
    {
      saveOTSAction.setEnabled(enabled);
      if ( saveOTSAction.getMenuItem() != null )
      {
        saveOTSAction.getMenuItem().setEnabled(enabled);
      }
      if ( saveOTSAction.getButton() != null )
      {
        saveOTSAction.getButton().setEnabled(enabled);
      }
    }
  }
}
