package userInterface;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.geom.Rectangle2D;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.JOptionPane;
import graphStructure.Graph;
import graphStructure.Node;

/**
 * Shared layout, grid and viewport calculations for {@link GraphEditor}.
 * This keeps the editor focused on interaction and painting while preserving
 * existing behaviour.
 */
public class GraphEditorLayoutSupport
{
  private final GraphEditor editor;

  public GraphEditorLayoutSupport(GraphEditor editor)
  {
    this.editor = editor;
  }

  public void changeToKruinGridMode(int rows, int rowHeight, int cols, int colWidth)
  {
    rowHeight = Math.max(2, rowHeight);
    colWidth = Math.max(2, colWidth);
    rows = Math.max(2, rows);
    cols = Math.max(2, cols);

    editor.getGraph().setGrid(rows, rowHeight, cols, colWidth, true);

    if ( !editor.isInGridMode() )
    {
      editor.ensureGridListener();
      editor.updateShapes();
      editor.repaint();
    }
    refreshPreferredSize();
  }

  public void changeToKruinGridMode(KruinGridSettings settings)
  {
    KruinGridSettings normalized = settings == null ? new KruinGridSettings() : settings.copy();
    normalized.normalize();
    editor.setKruinGridSettings(normalized);

    int rowHeight = normalized.getCellHeight();
    int colWidth = normalized.getCellWidth();

    if ( normalized.getGridMode() == KruinGridSettings.MODE_FULL_WINDOW )
    {
      int editorWidth = Math.max(1, getDrawWidth());
      int editorHeight = Math.max(1, getDrawHeight());
      int cols = Math.max(2, (int)Math.ceil((double)editorWidth / (double)colWidth) + 1);
      int rows = Math.max(2, (int)Math.ceil((double)editorHeight / (double)rowHeight) + 1);
      changeToKruinGridMode(rows, rowHeight, cols, colWidth);
      editor.getGraph().resetGridDisplayWindow();
    }
    else
    {
      Rectangle2D.Double fitBounds = getKruinFitBounds(normalized);
      int minX = floorToGrid((int)Math.floor(fitBounds.getMinX()), colWidth)
                 - normalized.getMarginLeftLines()*colWidth;
      int minY = floorToGrid((int)Math.floor(fitBounds.getMinY()), rowHeight)
                 - normalized.getMarginTopLines()*rowHeight;
      int maxX = ceilToGrid((int)Math.ceil(fitBounds.getMaxX()), colWidth)
                 + normalized.getMarginRightLines()*colWidth;
      int maxY = ceilToGrid((int)Math.ceil(fitBounds.getMaxY()), rowHeight)
                 + normalized.getMarginBottomLines()*rowHeight;

      if ( maxX <= minX )
      {
        maxX = minX + colWidth;
      }
      if ( maxY <= minY )
      {
        maxY = minY + rowHeight;
      }

      int cols = Math.max(2, ((maxX - minX) / colWidth) + 1);
      int rows = Math.max(2, ((maxY - minY) / rowHeight) + 1);

      changeToKruinGridMode(rows, rowHeight, cols, colWidth);
      editor.getGraph().setGridDisplayWindow(minX, minY, rows, cols);
    }

    if ( !editor.isInGridMode() )
    {
      editor.ensureGridListener();
    }
    editor.updateShapes();
    refreshPreferredSize();
    editor.repaint();
  }

  public void changeToDynamicKruinGridMode(int rowHeight, int colWidth)
  {
    KruinGridSettings settings = editor.getKruinGridSettings();
    settings.setGridMode(KruinGridSettings.MODE_FIT_CONTENT);
    settings.setCellHeight(rowHeight);
    settings.setCellWidth(colWidth);
    changeToKruinGridMode(settings);
  }

  public void changeToGridMode()
  {
    String gridString = null;
    if ( editor.getGraph().getGridRows() > 0 )
    {
      gridString = (String)JOptionPane.showInputDialog(
                             editor.getGraphController().getGraphWindow(),
                             "Use commas to separate the number of rows and columns",
                             "Set Grid Size",
                             JOptionPane.PLAIN_MESSAGE,
                             null, null,
                             String.valueOf(editor.getGraph().getGridRows() +
                                            "," + editor.getGraph().getGridCols()));
    }
    else
    {
      gridString = (String)JOptionPane.showInputDialog(
                             editor.getGraphController().getGraphWindow(),
                             "Use commas to separate the number of rows and columns",
                             "Set Grid Size",
                             JOptionPane.PLAIN_MESSAGE,
                             null, null,
                             String.valueOf((editor.getGraph().getNumNodes()-1) +
                                            "," + (editor.getGraph().getNumNodes()-1)));
    }
    int rows = 0;
    int cols = 0;
    if ( gridString != null )
    {
      try
      {
        StringTokenizer tok = new StringTokenizer(gridString, ",");
        if ( tok.countTokens() != 2 )
        {
          throw new NumberFormatException("Rows and Columns must be separated by a comma");
        }
        rows = Integer.parseInt(tok.nextToken());
        cols = Integer.parseInt(tok.nextToken());
        if ( rows < 2 || cols < 2 )
        {
          throw new NumberFormatException("Rows and Columns must both be greater than 1");
        }
        String sizeString = (String)JOptionPane.showInputDialog(
                              editor.getGraphController().getGraphWindow(),
                              "Use commas to separate the height and width of the rows and columns",
                              "Set Grid Size",
                              JOptionPane.PLAIN_MESSAGE,
                              null, null,
                              String.valueOf(getDrawWidth()/(cols-1) + "," +
                                             getDrawHeight()/(rows-1)) );
        int rowHeight = 0;
        int colWidth = 0;
        if ( sizeString != null )
        {
          try
          {
            tok = new StringTokenizer(sizeString, ",");
            if ( tok.countTokens() != 2 )
            {
              throw new NumberFormatException("Row and Column width must be separated by a comma");
            }
            colWidth = Integer.parseInt(tok.nextToken());
            rowHeight = Integer.parseInt(tok.nextToken());
            if ( rowHeight < 2 || colWidth < 2 )
            {
              throw new NumberFormatException("Rows and Column width must both be greater than 1");
            }
            editor.getGraph().setGrid(rows, rowHeight, cols, colWidth, true);
            if ( !editor.isInGridMode() )
            {
              editor.ensureGridListener();
              editor.updateShapes();
              editor.repaint();
            }
            refreshPreferredSize();
          }
          catch ( NumberFormatException nfe )
          {
            JOptionPane.showMessageDialog(editor.getGraphController().getGraphWindow(),
                                          "The width of the rows and columns for the grid must be integers greater than 1 separated by a comma",
                                          "Unable to switch to grid mode", JOptionPane.ERROR_MESSAGE);
          }
        }

      }
      catch ( NumberFormatException nfe )
      {
        JOptionPane.showMessageDialog(editor.getGraphController().getGraphWindow(),
                                      "The number of rows and columns for the grid must be integers greater than 1 separated by a comma",
                                      "Unable to switch to grid mode", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void refreshPreferredSize()
  {
    Rectangle2D.Double visibleBounds = getVisibleContentBounds();
    int contentWidth = (int)Math.ceil(visibleBounds.getMaxX() + 2*GraphEditor.DRAW_BUFFER);
    int contentHeight = (int)Math.ceil(visibleBounds.getMaxY() + 2*GraphEditor.DRAW_BUFFER);
    int gridWidth = editor.getGraph().getGridDisplayMaxX() + 2*GraphEditor.DRAW_BUFFER;
    int gridHeight = editor.getGraph().getGridDisplayMaxY() + 2*GraphEditor.DRAW_BUFFER;
    int preferredWidth = Math.max(contentWidth, gridWidth);
    int preferredHeight = Math.max(contentHeight, gridHeight);
    preferredWidth = Math.max(preferredWidth, editor.getWidth());
    preferredHeight = Math.max(preferredHeight, editor.getHeight());
    preferredWidth = Math.max(preferredWidth, 2*GraphEditor.DRAW_BUFFER + 1);
    preferredHeight = Math.max(preferredHeight, 2*GraphEditor.DRAW_BUFFER + 1);

    Dimension dim = editor.getPreferredSize();
    if ( preferredWidth != dim.width || preferredHeight != dim.height )
    {
      editor.setPreferredSize(new Dimension(preferredWidth, preferredHeight));
    }
  }

  public Rectangle2D.Double getVisibleContentBounds()
  {
    Rectangle2D.Double bounds = editor.getGraph().getBounds();
    if ( editor.getGraph().getShowLabels() || editor.getGraph().getShowCoords() )
    {
      bounds = expandBoundsForNodeLabels(bounds);
    }
    return KruinProjectionSupport.expandBoundsForReservedProjectionLabels(editor, bounds);
  }

  public void centerVisibleContentInWindow()
  {
    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !editor.isInGridMode() )
    {
      return;
    }

    KruinGridSettings gridSettings = editor.getKruinGridSettings();
    int cellWidth = Math.max(2, gridSettings.getCellWidth());
    int cellHeight = Math.max(2, gridSettings.getCellHeight());
    int drawWidth = Math.max(cellWidth * 2, getDrawWidth());
    int drawHeight = Math.max(cellHeight * 2, getDrawHeight());
    int paddingX = Math.max(0, gridSettings.getMarginLeftLines()) * cellWidth;
    int paddingY = Math.max(0, gridSettings.getMarginTopLines()) * cellHeight;
    paddingX = Math.max(paddingX, 2 * cellWidth);
    paddingY = Math.max(paddingY, 2 * cellHeight);

    Rectangle2D.Double visibleBounds = getVisibleContentBounds();
    double visibleWidth = visibleBounds.getWidth();
    double visibleHeight = visibleBounds.getHeight();

    double desiredMinX = visibleWidth + (2 * paddingX) <= drawWidth
                         ? (drawWidth - visibleWidth) / 2.0
                         : paddingX;
    double desiredMinY = visibleHeight + (2 * paddingY) <= drawHeight
                         ? (drawHeight - visibleHeight) / 2.0
                         : paddingY;

    int dx = snapToGrid((int)Math.round(desiredMinX - visibleBounds.getMinX()), cellWidth);
    int dy = snapToGrid((int)Math.round(desiredMinY - visibleBounds.getMinY()), cellHeight);
    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    changeToKruinGridMode(gridSettings);
  }

  public int getDrawWidth()
  {
    return editor.getWidth() - 2*GraphEditor.DRAW_BUFFER;
  }

  public int getDrawHeight()
  {
    return editor.getHeight() - 2*GraphEditor.DRAW_BUFFER;
  }

  private int snapToGrid(int value, int step)
  {
    if ( step <= 1 )
    {
      return value;
    }
    return (int)Math.round((double)value / (double)step) * step;
  }

  private int floorToGrid(int value, int step)
  {
    return (int)Math.floor((double)value / (double)step) * step;
  }

  private int ceilToGrid(int value, int step)
  {
    return (int)Math.ceil((double)value / (double)step) * step;
  }

  private Rectangle2D.Double getKruinFitBounds(KruinGridSettings settings)
  {
    Graph graph = editor.getGraph();

    if ( graph.getNumNodes() == 0 )
    {
      return new Rectangle2D.Double(0, 0, settings.getCellWidth(), settings.getCellHeight());
    }

    Rectangle2D.Double bounds = graph.getBounds();

    if ( settings.getFitScope() >= KruinGridSettings.SCOPE_STRUCTURE_AND_PROJECTIONS )
    {
      bounds = KruinProjectionSupport.expandStructureBoundsForProjectionBands(editor, bounds, settings);
    }

    if ( settings.getFitScope() == KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
    {
      if ( editor.getGraph().getShowLabels() || editor.getGraph().getShowCoords() )
      {
        bounds = expandBoundsForNodeLabels(bounds);
      }
      bounds = KruinProjectionSupport.expandBoundsForProjectionLabelsForFit(editor, bounds, settings);
    }

    return bounds;
  }

  private Rectangle2D.Double expandBoundsForNodeLabels(Rectangle2D.Double bounds)
  {
    Rectangle2D.Double expanded = new Rectangle2D.Double(bounds.getX(), bounds.getY(),
                                                         bounds.getWidth(), bounds.getHeight());
    if ( !editor.getGraph().getShowLabels() && !editor.getGraph().getShowCoords() )
    {
      return expanded;
    }

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    Vector nodes = editor.getGraph().getNodes();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      String text = null;
      if ( editor.getGraph().getShowLabels() )
      {
        text = node.getLabel();
      }
      else if ( editor.getGraph().getShowCoords() )
      {
        text = String.valueOf(node.getLocation().intX()) + ", " +
               String.valueOf(node.getLocation().intY());
      }
      if ( text != null && text.length() > 0 )
      {
        double textX = node.getLocation().intX() + Node.RADIUS + 3;
        double textY = node.getLocation().intY() + Node.RADIUS + 2 - fm.getAscent();
        Rectangle2D.Double textBounds = new Rectangle2D.Double(textX, textY,
                                                               fm.stringWidth(text) + 2,
                                                               fm.getHeight());
        Rectangle2D union = expanded.createUnion(textBounds);
        expanded = new Rectangle2D.Double(union.getX(), union.getY(), union.getWidth(), union.getHeight());
      }
    }
    return expanded;
  }
}
