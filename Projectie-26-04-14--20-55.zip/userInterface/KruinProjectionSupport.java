package userInterface;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.util.Collections;
import java.util.Comparator;
import java.util.Properties;
import java.util.Vector;
import graphStructure.Graph;
import graphStructure.Node;

/**
 * Computes and renders the currently implemented Kruin projections.
 *
 * <p>At the moment only the lexical projection is drawn, and only for leaf
 * nodes (end nodes / non-branching nodes). The projections land on the edge
 * of the fitted visible KruinGrid, while the projection labels are drawn
 * outside that visible grid.</p>
 */
public final class KruinProjectionSupport
{
  private static final int PROJECTION_BAND_CELLS = 1;
  private static final int LABEL_GAP = 6;
  private static final float PROJECTION_LINE_WIDTH = 2.0f;
  private static final int PROJECTION_AXIS_NODE_RADIUS = Node.RADIUS;
  private static final Color PROJECTION_AXIS_NODE_FILL_COLOR = Color.white;
  private static final Color PROJECTION_AXIS_NODE_BORDER_COLOR = GraphEditor.borderColor.darker();
  private static final String LEFT_PROJECTION_NAME = "Lexical Form";
  private static final String RIGHT_PROJECTION_NAME = "Syntactical Form";
  private static final String BOTTOM_PROJECTION_NAME = "Logical Form (LF)";

  private KruinProjectionSupport()
  {
  }

  public static KruinProjectionSettings loadBestAvailable()
  {
    KruinProjectionSettings settings = loadFromPath(KruinGridSettingsIO.USER_SETTINGS_PATH);
    if ( settings != null )
    {
      return settings;
    }
    settings = loadFromPath(KruinGridSettingsIO.DEFAULTS_PATH);
    if ( settings != null )
    {
      return settings;
    }
    return new KruinProjectionSettings();
  }

  public static KruinProjectionSettings fromDialog(KruinDialog dialog)
  {
    KruinProjectionSettings settings = new KruinProjectionSettings();
    if ( dialog == null )
    {
      return settings;
    }

    settings.setStructureType(dialog.getStructureType());
    settings.setShowProjections(dialog.getShowProjections());
    settings.setLeftProjectionEnabled(dialog.getLeftProjectionEnabled());
    settings.setRightProjectionEnabled(dialog.getRightProjectionEnabled());
    settings.setTopProjectionEnabled(dialog.getTopProjectionEnabled());
    settings.setBottomProjectionEnabled(dialog.getBottomProjectionEnabled());
    settings.setLeftProjectionPosition(dialog.getLeftProjectionPosition());
    settings.setRightProjectionPosition(dialog.getRightProjectionPosition());
    settings.setTopProjectionPosition(dialog.getTopProjectionPosition());
    settings.setBottomProjectionPosition(dialog.getBottomProjectionPosition());
    settings.normalize();
    return settings;
  }

  public static boolean hasReservedLexicalProjection(KruinProjectionSettings settings)
  {
    return hasProjectionFootprint(settings);
  }

  public static boolean hasRenderableProjectionContext(GraphEditor editor)
  {
    return editor != null && editor.isKruinProjectionContextActive();
  }

  public static Rectangle2D.Double expandStructureBoundsForProjectionBands(GraphEditor editor,
                                                                           Rectangle2D.Double structureBounds,
                                                                           KruinGridSettings gridSettings)
  {
    Rectangle2D.Double expanded = copyBounds(structureBounds);
    if ( editor == null || structureBounds == null )
    {
      return expanded;
    }

    KruinProjectionSettings projectionSettings = editor.getKruinProjectionSettings();
    if ( !hasRenderableProjectionContext(editor) ||
         !hasProjectionFootprint(projectionSettings) )
    {
      return expanded;
    }

    double minX = expanded.getMinX();
    double minY = expanded.getMinY();
    double maxX = expanded.getMaxX();
    double maxY = expanded.getMaxY();

    int cellWidth = safeCellWidth(gridSettings, editor.getGraph());
    int cellHeight = safeCellHeight(gridSettings, editor.getGraph());

    if ( projectionSettings.getLeftProjectionEnabled() )
    {
      minX -= PROJECTION_BAND_CELLS * cellWidth;
    }
    if ( projectionSettings.getRightProjectionEnabled() )
    {
      maxX += PROJECTION_BAND_CELLS * cellWidth;
    }
    if ( projectionSettings.getTopProjectionEnabled() )
    {
      minY -= PROJECTION_BAND_CELLS * cellHeight;
    }
    if ( projectionSettings.getBottomProjectionEnabled() )
    {
      maxY += PROJECTION_BAND_CELLS * cellHeight;
    }

    return createBounds(minX, minY, maxX, maxY);
  }

  public static Rectangle2D.Double expandBoundsForProjectionLabels(GraphEditor editor,
                                                                   Rectangle2D.Double currentBounds)
  {
    return expandBoundsForProjectionLabels(editor, currentBounds, false);
  }

  public static Rectangle2D.Double expandBoundsForReservedProjectionLabels(GraphEditor editor,
                                                                           Rectangle2D.Double currentBounds)
  {
    return expandBoundsForProjectionLabels(editor, currentBounds, true);
  }

  private static Rectangle2D.Double expandBoundsForProjectionLabels(GraphEditor editor,
                                                                    Rectangle2D.Double currentBounds,
                                                                    boolean reserveSpaceEvenWhenHidden)
  {
    Rectangle2D.Double expanded = copyBounds(currentBounds);
    ProjectionGeometry geometry = getProjectionGeometry(editor, reserveSpaceEvenWhenHidden);
    if ( geometry == null )
    {
      return expanded;
    }

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        expanded = union(expanded, labelBounds);
      }
      Rectangle2D.Double lineBounds = item.getLineBounds();
      if ( lineBounds != null )
      {
        expanded = union(expanded, lineBounds);
      }
      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        expanded = union(expanded, markerBounds);
      }
    }
    return expanded;
  }

  public static Rectangle2D.Double expandBoundsForProjectionLabelsForFit(GraphEditor editor,
                                                                         Rectangle2D.Double currentBounds,
                                                                         KruinGridSettings gridSettings)
  {
    Rectangle2D.Double expanded = copyBounds(currentBounds);
    if ( editor == null || currentBounds == null )
    {
      return expanded;
    }

    KruinProjectionSettings settings = editor.getKruinProjectionSettings();
    if ( !hasRenderableProjectionContext(editor) ||
         !hasProjectionFootprint(settings) )
    {
      return expanded;
    }

    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 )
    {
      return expanded;
    }

    Vector leaves = getLeafNodes(graph);
    if ( leaves.isEmpty() )
    {
      return expanded;
    }

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    ProjectionGeometry geometry = new ProjectionGeometry(fm);

    int gridMinX = (int)Math.floor(currentBounds.getMinX());
    int gridMaxX = (int)Math.ceil(currentBounds.getMaxX());
    int gridMinY = (int)Math.floor(currentBounds.getMinY());
    int gridMaxY = (int)Math.ceil(currentBounds.getMaxY());

    int leftLabelRightX = gridMinX - LABEL_GAP;
    int rightLabelLeftX = gridMaxX + LABEL_GAP;

    for ( int i=0; i<leaves.size(); i++ )
    {
      Node leaf = (Node)leaves.elementAt(i);
      int nodeX = leaf.getLocation().intX();
      int nodeY = leaf.getLocation().intY();

      if ( settings.getLeftProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_LEFT, nodeX, nodeY, gridMinX, nodeY));
      }
      if ( settings.getRightProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_RIGHT, nodeX, nodeY, gridMaxX, nodeY));
      }
      if ( settings.getTopProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_TOP, nodeX, nodeY, nodeX, gridMinY));
      }
      if ( settings.getBottomProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_BOTTOM, nodeX, nodeY, nodeX, gridMaxY));
      }
    }

    addSideCaptionItems(geometry, fm, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        expanded = union(expanded, labelBounds);
      }
      Rectangle2D.Double lineBounds = item.getLineBounds();
      if ( lineBounds != null )
      {
        expanded = union(expanded, lineBounds);
      }
      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        expanded = union(expanded, markerBounds);
      }
    }

    return expanded;
  }

  public static void draw(Graphics2D g2, GraphEditor editor)
  {
    ProjectionGeometry geometry = getProjectionGeometry(editor, false);
    if ( geometry == null )
    {
      return;
    }

    Stroke oldStroke = g2.getStroke();
    Color oldColor = g2.getColor();
    g2.setStroke(new BasicStroke(PROJECTION_LINE_WIDTH));

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.drawLine )
      {
        g2.setColor(GraphEditor.borderColor.darker());
        g2.drawLine(item.fromX + GraphEditor.DRAW_BUFFER,
                    item.fromY + GraphEditor.DRAW_BUFFER,
                    item.toX + GraphEditor.DRAW_BUFFER,
                    item.toY + GraphEditor.DRAW_BUFFER);
      }
      if ( item.drawMarker )
      {
        int diameter = item.markerRadius * 2;
        int markerX = item.markerX - item.markerRadius + GraphEditor.DRAW_BUFFER;
        int markerY = item.markerY - item.markerRadius + GraphEditor.DRAW_BUFFER;
        g2.setColor(PROJECTION_AXIS_NODE_FILL_COLOR);
        g2.fillOval(markerX, markerY, diameter, diameter);
        g2.setColor(PROJECTION_AXIS_NODE_BORDER_COLOR);
        g2.drawOval(markerX, markerY, diameter, diameter);
      }
      if ( item.text != null && item.text.length() > 0 )
      {
        g2.setColor(Color.black);
        g2.drawString(item.text,
                      item.labelX + GraphEditor.DRAW_BUFFER,
                      item.labelBaselineY + GraphEditor.DRAW_BUFFER);
      }
    }

    g2.setStroke(oldStroke);
    g2.setColor(oldColor);
  }

  private static ProjectionGeometry getProjectionGeometry(GraphEditor editor, boolean reserveSpaceEvenWhenHidden)
  {
    if ( editor == null )
    {
      return null;
    }

    KruinProjectionSettings settings = editor.getKruinProjectionSettings();
    if ( settings == null )
    {
      return null;
    }

    if ( !hasRenderableProjectionContext(editor) )
    {
      return null;
    }

    if ( reserveSpaceEvenWhenHidden )
    {
      if ( !hasProjectionFootprint(settings) )
      {
        return null;
      }
    }
    else if ( !settings.isLexicalProjectionActive() )
    {
      return null;
    }

    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graph.getDrawGrid() )
    {
      return null;
    }

    Vector leaves = getLeafNodes(graph);
    if ( leaves.isEmpty() )
    {
      return null;
    }

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    ProjectionGeometry geometry = new ProjectionGeometry(fm);

    int gridMinX = graph.getGridDisplayMinX();
    int gridMaxX = graph.getGridDisplayMaxX();
    int gridMinY = graph.getGridDisplayMinY();
    int gridMaxY = graph.getGridDisplayMaxY();

    for ( int i=0; i<leaves.size(); i++ )
    {
      Node leaf = (Node)leaves.elementAt(i);
      int nodeX = leaf.getLocation().intX();
      int nodeY = leaf.getLocation().intY();

      if ( settings.getLeftProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_LEFT, nodeX, nodeY, gridMinX, nodeY));
      }
      if ( settings.getRightProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_RIGHT, nodeX, nodeY, gridMaxX, nodeY));
      }
      if ( settings.getTopProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_TOP, nodeX, nodeY, nodeX, gridMinY));
      }
      if ( settings.getBottomProjectionEnabled() )
      {
        geometry.items.addElement(ProjectionItem.createLineWithAxisNode(SIDE_BOTTOM, nodeX, nodeY, nodeX, gridMaxY));
      }
    }

    addSideCaptionItems(geometry, fm, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);

    return geometry;
  }

  private static void addSideCaptionItems(ProjectionGeometry geometry,
                                          FontMetrics fm,
                                          KruinProjectionSettings settings,
                                          int gridMinX,
                                          int gridMinY,
                                          int gridMaxX,
                                          int gridMaxY)
  {
    if ( geometry == null || fm == null || settings == null )
    {
      return;
    }

    int centerYBaseline = gridMinY + ((gridMaxY - gridMinY) / 2) + (fm.getAscent() / 2);

    if ( settings.getLeftProjectionEnabled() )
    {
      addCaptionItem(geometry, fm, SIDE_LEFT, LEFT_PROJECTION_NAME, gridMinX, centerYBaseline, true);
    }
    if ( settings.getRightProjectionEnabled() )
    {
      addCaptionItem(geometry, fm, SIDE_RIGHT, RIGHT_PROJECTION_NAME, gridMaxX, centerYBaseline, false);
    }
    if ( settings.getBottomProjectionEnabled() )
    {
      int baselineY = gridMaxY + LABEL_GAP + fm.getAscent();
      int labelX = gridMinX + ((gridMaxX - gridMinX - fm.stringWidth(BOTTOM_PROJECTION_NAME)) / 2);
      geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_BOTTOM, BOTTOM_PROJECTION_NAME, labelX, baselineY));
    }
  }

  private static void addCaptionItem(ProjectionGeometry geometry,
                                     FontMetrics fm,
                                     int side,
                                     String text,
                                     int gridEdgeX,
                                     int baselineY,
                                     boolean left)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelWidth = fm.stringWidth(text);
    int labelX;
    if ( left )
    {
      labelX = gridEdgeX - LABEL_GAP - labelWidth;
    }
    else
    {
      labelX = gridEdgeX + LABEL_GAP;
    }
    geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY));
  }

  private static Vector getLeafNodes(Graph graph)
  {
    Vector leaves = new Vector();
    Vector nodes = graph.getNodes();

    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( isLeafNode(node) )
      {
        leaves.addElement(node);
      }
    }

    Collections.sort(leaves, new Comparator()
    {
      public int compare(Object leftObj, Object rightObj)
      {
        Node left = (Node)leftObj;
        Node right = (Node)rightObj;
        int xCompare = left.getLocation().intX() - right.getLocation().intX();
        if ( xCompare != 0 )
        {
          return xCompare;
        }
        return left.getLocation().intY() - right.getLocation().intY();
      }
    });

    return leaves;
  }

  private static boolean isLeafNode(Node node)
  {
    if ( node == null )
    {
      return false;
    }

    Vector neighbours = node.neighbours();
    if ( neighbours.isEmpty() )
    {
      return true;
    }

    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        return false;
      }
    }
    return true;
  }

  private static int safeCellWidth(KruinGridSettings gridSettings, Graph graph)
  {
    if ( gridSettings != null )
    {
      return Math.max(2, gridSettings.getCellWidth());
    }
    if ( graph != null )
    {
      return Math.max(2, graph.getGridColWidth());
    }
    return 20;
  }

  private static int safeCellHeight(KruinGridSettings gridSettings, Graph graph)
  {
    if ( gridSettings != null )
    {
      return Math.max(2, gridSettings.getCellHeight());
    }
    if ( graph != null )
    {
      return Math.max(2, graph.getGridRowHeight());
    }
    return 20;
  }

  private static boolean hasProjectionFootprint(KruinProjectionSettings settings)
  {
    return settings != null &&
           settings.getStructureType() == KruinDialog.STRUCTURE_LANGUAGE_TREE &&
           (settings.getLeftProjectionEnabled() ||
            settings.getRightProjectionEnabled() ||
            settings.getTopProjectionEnabled() ||
            settings.getBottomProjectionEnabled());
  }

  private static KruinProjectionSettings loadFromPath(String path)
  {
    try
    {
      Properties props = KruinDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( props == null )
      {
        return null;
      }
      KruinDialogSettingsState state = KruinDialogSettingsSupport.fromProperties(props);
      KruinDialogSettingsSupport.applyPostLoadRules(state);
      KruinProjectionSettings settings = new KruinProjectionSettings();
      settings.setStructureType(state.structureType);
      settings.setShowProjections(state.showProjections);
      settings.setLeftProjectionEnabled(state.leftProjectionEnabled);
      settings.setRightProjectionEnabled(state.rightProjectionEnabled);
      settings.setTopProjectionEnabled(state.topProjectionEnabled);
      settings.setBottomProjectionEnabled(state.bottomProjectionEnabled);
      settings.setLeftProjectionPosition(state.leftProjectionPosition);
      settings.setRightProjectionPosition(state.rightProjectionPosition);
      settings.setTopProjectionPosition(state.topProjectionPosition);
      settings.setBottomProjectionPosition(state.bottomProjectionPosition);
      settings.normalize();
      return settings;
    }
    catch (Exception e)
    {
      return null;
    }
  }

  private static Rectangle2D.Double copyBounds(Rectangle2D.Double bounds)
  {
    if ( bounds == null )
    {
      return new Rectangle2D.Double();
    }
    return new Rectangle2D.Double(bounds.getX(), bounds.getY(), bounds.getWidth(), bounds.getHeight());
  }

  private static Rectangle2D.Double createBounds(double minX, double minY, double maxX, double maxY)
  {
    return new Rectangle2D.Double(minX, minY, Math.max(0, maxX - minX), Math.max(0, maxY - minY));
  }

  private static Rectangle2D.Double union(Rectangle2D.Double base, Rectangle2D.Double addition)
  {
    if ( base == null )
    {
      return copyBounds(addition);
    }
    if ( addition == null )
    {
      return copyBounds(base);
    }
    Rectangle2D rect = base.createUnion(addition);
    return new Rectangle2D.Double(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
  }

  private static final class ProjectionGeometry
  {
    private final FontMetrics fontMetrics;
    private final Vector items = new Vector();

    private ProjectionGeometry(FontMetrics fontMetrics)
    {
      this.fontMetrics = fontMetrics;
    }
  }

  private static final int SIDE_LEFT = 1;
  private static final int SIDE_RIGHT = 2;
  private static final int SIDE_TOP = 3;
  private static final int SIDE_BOTTOM = 4;

  private static final class ProjectionItem
  {
    private final int side;
    private final int fromX;
    private final int fromY;
    private final int toX;
    private final int toY;
    private final boolean drawLine;
    private final boolean drawMarker;
    private final int markerX;
    private final int markerY;
    private final int markerRadius;
    private final String text;
    private final int labelX;
    private int labelBaselineY;

    private ProjectionItem(int side, int fromX, int fromY, int toX, int toY,
                           boolean drawLine, boolean drawMarker, int markerX, int markerY, int markerRadius,
                           String text, int labelX, int labelBaselineY)
    {
      this.side = side;
      this.fromX = fromX;
      this.fromY = fromY;
      this.toX = toX;
      this.toY = toY;
      this.drawLine = drawLine;
      this.drawMarker = drawMarker;
      this.markerX = markerX;
      this.markerY = markerY;
      this.markerRadius = markerRadius;
      this.text = text;
      this.labelX = labelX;
      this.labelBaselineY = labelBaselineY;
    }

    private static ProjectionItem createLineOnly(int side, int fromX, int fromY, int toX, int toY)
    {
      return new ProjectionItem(side, fromX, fromY, toX, toY, true, false, 0, 0, 0, null, 0, 0);
    }

    private static ProjectionItem createLineWithAxisNode(int side, int fromX, int fromY, int toX, int toY)
    {
      return new ProjectionItem(side, fromX, fromY, toX, toY, true, true, toX, toY,
                                PROJECTION_AXIS_NODE_RADIUS, null, 0, 0);
    }

    private static ProjectionItem createLabelOnly(int side, String text, int labelX, int labelBaselineY)
    {
      return new ProjectionItem(side, 0, 0, 0, 0, false, false, 0, 0, 0, text, labelX, labelBaselineY);
    }

    private Rectangle2D.Double getLineBounds()
    {
      if ( !drawLine )
      {
        return null;
      }
      int minX = Math.min(fromX, toX);
      int maxX = Math.max(fromX, toX);
      int minY = Math.min(fromY, toY);
      int maxY = Math.max(fromY, toY);
      return new Rectangle2D.Double(minX, minY, Math.max(1, maxX - minX), Math.max(1, maxY - minY));
    }

    private Rectangle2D.Double getMarkerBounds()
    {
      if ( !drawMarker || markerRadius <= 0 )
      {
        return null;
      }
      int diameter = markerRadius * 2;
      return new Rectangle2D.Double(markerX - markerRadius, markerY - markerRadius, diameter, diameter);
    }

    private Rectangle2D.Double getLabelBounds(FontMetrics fm)
    {
      if ( text == null || text.length() == 0 || fm == null )
      {
        return null;
      }
      int width = Math.max(1, fm.stringWidth(text));
      int height = Math.max(1, fm.getHeight());
      int y = labelBaselineY - fm.getAscent();
      return new Rectangle2D.Double(labelX, y, width, height);
    }
  }
}
