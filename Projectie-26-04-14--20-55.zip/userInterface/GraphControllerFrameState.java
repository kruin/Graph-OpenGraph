package userInterface;

import javax.swing.*;
import javax.swing.event.*;
import java.util.Vector;
import userInterface.menuAndToolBar.*;

public class GraphControllerFrameState
{
  private final GraphWindow graphWindow;
  private final MenuAndToolBar menuAndToolBar;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphKruinActions graphKruinActions;

  private GraphEditorWindow activeGraphEditorWindow;
  private GraphEditorDialog activeGraphEditorDialog;
  private JInternalFrame lastWindow;

  public GraphControllerFrameState(GraphWindow graphWindow,
                                   MenuAndToolBar menuAndToolBar,
                                   GraphWindowCoordinator graphWindowCoordinator,
                                   GraphKruinActions graphKruinActions)
  {
    this.graphWindow = graphWindow;
    this.menuAndToolBar = menuAndToolBar;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphKruinActions = graphKruinActions;
    activeGraphEditorWindow = null;
    activeGraphEditorDialog = null;
    lastWindow = null;
  }

  public GraphEditorWindow getActiveGraphEditorWindow()
  {
    return activeGraphEditorWindow;
  }

  public GraphEditorDialog getActiveGraphEditorDialog()
  {
    return activeGraphEditorDialog;
  }

  public void showWindow(OpenGraphEdInternalFrame intFrame)
  {
    graphWindow.activate(intFrame);
  }

  public boolean hasUnsavedGraphs()
  {
    Vector<GraphEditorWindow> graphEditorWindows = graphWindow.getAllGraphEditorWindows();
    for ( int i=0; i<graphEditorWindows.size(); i++ )
    {
      if ( graphEditorWindows.elementAt(i).getGraphEditor().getGraph().hasChangedSinceLastSave() )
      {
        return true;
      }
    }
    return false;
  }

  public void nodesSelectedByEditor(int numNodes, int maxNodes)
  {
    if ( activeGraphEditorWindow != null &&
         activeGraphEditorWindow.getDialog() != null )
    {
      GraphEditorDialog ged = (GraphEditorDialog)activeGraphEditorWindow.getDialog();
      if ( numNodes == maxNodes )
      {
        ged.enableRunButton();
        activeGraphEditorWindow.getGraphEditor().repaint();
        graphWindow.activateDialog(ged);
      }
      else
      {
        ged.disableRunButton();
        activeGraphEditorWindow.getGraphEditor().repaint();
      }
    }
  }

  public void update()
  {
    if ( activeGraphEditorWindow != null )
    {
      activeGraphEditorWindow.getGraphEditor().updateShapes();
    }
    else if ( activeGraphEditorDialog != null )
    {
      activeGraphEditorDialog.getOwner().getGraphEditor().updateShapes();
    }
    graphWindow.repaint();
  }

  public void internalFrameOpened(InternalFrameEvent e)
  {
    menuAndToolBar.addWindow(((OpenGraphEdInternalFrame)e.getSource()).getMenuItem());
  }

  public void internalFrameClosed(InternalFrameEvent e)
  {
    menuAndToolBar.removeWindow(((OpenGraphEdInternalFrame)e.getSource()).getMenuItem());
    lastWindow = null;

    if ( e.getSource() instanceof GraphEditorWindow )
    {
      graphWindowCoordinator.closeOwnedWindows((GraphEditorWindow)e.getSource());
      if ( activeGraphEditorWindow == (GraphEditorWindow)e.getSource() )
      {
        activeGraphEditorWindow = null;
      }
    }
    else if ( e.getSource() instanceof GraphEditorDialog )
    {
      graphWindowCoordinator.releaseDialogAfterClose((GraphEditorDialog)e.getSource());
      if ( activeGraphEditorDialog == (GraphEditorDialog)e.getSource() )
      {
        activeGraphEditorDialog = null;
      }
    }
  }

  public void internalFrameActivated(InternalFrameEvent e)
  {
    if ( e.getSource() instanceof GraphEditorWindow )
    {
      activeGraphEditorWindow = (GraphEditorWindow)e.getSource();
      if ( activeGraphEditorWindow.getDialog() != null &&
           activeGraphEditorWindow.getDialog() != lastWindow )
      {
        lastWindow = activeGraphEditorWindow;
        graphWindow.activateDialog(activeGraphEditorWindow.getDialog());
      }
      else
      {
        menuAndToolBar.showControls(activeGraphEditorWindow.getGraphEditor());
        refreshOTSMenuVisibility();
        lastWindow = activeGraphEditorWindow;
      }
    }
    else
    {
      if ( e.getSource() instanceof GraphEditorDialog )
      {
        activeGraphEditorDialog = (GraphEditorDialog)e.getSource();
        if ( lastWindow != activeGraphEditorDialog.getOwner() )
        {
          graphWindow.activate(activeGraphEditorDialog.getOwner());
          activeGraphEditorDialog = (GraphEditorDialog)e.getSource();
          graphWindow.activateDialog(activeGraphEditorDialog);
        }
        lastWindow = activeGraphEditorDialog;
      }
      menuAndToolBar.hideControls();
      refreshOTSMenuVisibility();
    }
  }

  public void internalFrameDeactivated(InternalFrameEvent e)
  {
    menuAndToolBar.hideControls();
    refreshOTSMenuVisibility();
    if ( e.getSource() instanceof GraphEditorWindow &&
         activeGraphEditorWindow == (GraphEditorWindow)e.getSource() )
    {
      activeGraphEditorWindow = null;
    }
    if ( e.getSource() instanceof GraphEditorDialog &&
         activeGraphEditorDialog == (GraphEditorDialog)e.getSource() )
    {
      activeGraphEditorDialog = null;
    }
  }

  public void internalFrameClosing(InternalFrameEvent e)
  {
    if ( e.getSource() instanceof GraphEditorWindow )
    {
      GraphEditorWindow editorWindow = (GraphEditorWindow)e.getSource();
      if ( editorWindow != null )
      {
        if ( editorWindow.getGraphEditor().getGraph().hasChangedSinceLastSave() )
        {
          int returnInt = JOptionPane.showConfirmDialog(graphWindow,
                          "Are you sure you want to discard all changes to " +
                          editorWindow.getTitle() + "?",
                          "Discard Changes", JOptionPane.YES_NO_OPTION);
          if ( returnInt == JOptionPane.YES_OPTION )
          {
            editorWindow.dispose();
          }
        }
        else
        {
          editorWindow.dispose();
        }
      }
    }
  }

  private void refreshOTSMenuVisibility()
  {
    graphKruinActions.refreshOTSMenuVisibility(activeGraphEditorWindow);
  }
}
