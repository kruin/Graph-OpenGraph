package userInterface;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class KruinDialog extends GraphEditorDialog implements ActionListener
{
  public static int WIDTH = 430;
  public static int HEIGHT = 320;

  public static final int STRUCTURE_SIMPLE_TREE = 1;
  public static final int STRUCTURE_LANGUAGE_TREE = 2;
  public static final int STRUCTURE_ANAPHOR_TREE = 3;
  public static final int STRUCTURE_OTHER = 4;

  private static final String DEFAULTS_PATH = "config/kruin_defaults.properties";
  private static final String USER_SETTINGS_PATH = "config/kruin_user.properties";

  private static final Dimension MAIN_BUTTON_SIZE = new Dimension(340, 28);

  private GraphEditorWindow owner;
  private JButton runButton;
  private JButton kruinDefaultsButton;
  private JButton drawSettingsButton;
  private JButton gridSettingsButton;

  private ButtonGroup structureTypeGroup;
  private JRadioButton simpleTreeButton;
  private JRadioButton languageTreeButton;
  private JRadioButton anaphorTreeButton;
  private JRadioButton otherTreeButton;

  private JCheckBox showProjectionsCheckBox;
  private JCheckBox leftProjectionCheckBox;
  private JCheckBox rightProjectionCheckBox;
  private JCheckBox topProjectionCheckBox;
  private JCheckBox bottomProjectionCheckBox;

  private JSpinner structureLeftOffsetSpinner;
  private JSpinner structureRightOffsetSpinner;
  private JSpinner structureTopOffsetSpinner;
  private JSpinner structureBottomOffsetSpinner;

  private JSpinner leftProjectionPositionSpinner;
  private JSpinner rightProjectionPositionSpinner;
  private JSpinner topProjectionPositionSpinner;
  private JSpinner bottomProjectionPositionSpinner;

  private JSpinner gridColumnWidthSpinner;
  private JSpinner gridRowHeightSpinner;
  private ButtonGroup gridModeGroup;
  private JRadioButton fullWindowGridButton;
  private JRadioButton fitContentGridButton;
  private ButtonGroup fitScopeGroup;
  private JRadioButton fitStructureOnlyButton;
  private JRadioButton fitStructureAndProjectionsButton;
  private JRadioButton fitStructureProjectionsAndLabelsButton;
  private JSpinner gridMarginLeftSpinner;
  private JSpinner gridMarginRightSpinner;
  private JSpinner gridMarginTopSpinner;
  private JSpinner gridMarginBottomSpinner;

  private boolean loadUserSettingsRequested = false;

  public KruinDialog(GraphController controller, GraphEditorWindow owner,
                     String title, String message)
  {
    super(controller, owner.getTitle() + " - " + title,
          true,
          true,
          true,
          false
    );
    this.owner = owner;

    initialiseFields();
    buildUi();
    loadAtStartup();

    addInternalFrameListener(controller);
    setVisible(true);
  }

  public void preloadFromEditor(GraphEditor editor)
  {
    if ( editor == null )
    {
      return;
    }

    KruinDialogSettingsState state = readState();
    KruinProjectionSettings projectionSettings = editor.getKruinProjectionSettings();
    if ( !editor.isKruinProjectionContextActive() )
    {
      KruinProjectionSettings remembered = editor.getRememberedLanguageProjectionSettings();
      if ( remembered != null &&
           remembered.getStructureType() == STRUCTURE_LANGUAGE_TREE )
      {
        projectionSettings = remembered;
      }
    }
    if ( projectionSettings != null )
    {
      state.structureType = projectionSettings.getStructureType();
      state.showProjections = projectionSettings.getShowProjections();
      state.leftProjectionEnabled = projectionSettings.getLeftProjectionEnabled();
      state.rightProjectionEnabled = projectionSettings.getRightProjectionEnabled();
      state.topProjectionEnabled = projectionSettings.getTopProjectionEnabled();
      state.bottomProjectionEnabled = projectionSettings.getBottomProjectionEnabled();
      state.leftProjectionPosition = projectionSettings.getLeftProjectionPosition();
      state.rightProjectionPosition = projectionSettings.getRightProjectionPosition();
      state.topProjectionPosition = projectionSettings.getTopProjectionPosition();
      state.bottomProjectionPosition = projectionSettings.getBottomProjectionPosition();
    }

    KruinGridSettings gridSettings = editor.getKruinGridSettings();
    if ( gridSettings != null )
    {
      state.gridMode = gridSettings.getGridMode();
      state.fitScope = gridSettings.getFitScope();
      state.gridColumnWidth = gridSettings.getCellWidth();
      state.gridRowHeight = gridSettings.getCellHeight();
      state.gridMarginLeft = gridSettings.getMarginLeftLines();
      state.gridMarginRight = gridSettings.getMarginRightLines();
      state.gridMarginTop = gridSettings.getMarginTopLines();
      state.gridMarginBottom = gridSettings.getMarginBottomLines();
    }

    applyState(state);
  }

  private void buildUi()
  {
    getContentPane().setLayout(new BorderLayout(8, 8));
    ((Container)getContentPane()).setBackground(getBackground());

    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
    mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
    getContentPane().add(mainPanel, BorderLayout.CENTER);

    addIntroLabel(mainPanel, "Select structure type, then Run.");
    addIntroLabel(mainPanel, "KruinDraw settings and KruinGrid settings are separated. Language defaults now use left and bottom projections; top stays inactive for now.");

    mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

    runButton = createMainButton("Run", this);
    mainPanel.add(runButton);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 6)));

    kruinDefaultsButton = createMainButton("Reset defaults", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyKruinDefaultsForCurrentType();
      }
    });
    mainPanel.add(kruinDefaultsButton);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 6)));

    drawSettingsButton = createMainButton("KruinDraw settings", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        showDrawSettingsDialog();
      }
    });
    mainPanel.add(drawSettingsButton);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 6)));

    gridSettingsButton = createMainButton("KruinGrid settings", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        showGridSettingsDialog();
      }
    });
    mainPanel.add(gridSettingsButton);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 12)));

    mainPanel.add(createStructurePanel());

    setPreferredSize(new Dimension(WIDTH, HEIGHT));
    pack();
    fitWithinOwner();
  }

  private void addIntroLabel(JPanel panel, String text)
  {
    JLabel label = new JLabel(text);
    label.setAlignmentX(Component.LEFT_ALIGNMENT);
    label.setHorizontalAlignment(SwingConstants.LEFT);
    panel.add(label);
  }

  private JPanel createStructurePanel()
  {
    JPanel structurePanel = new JPanel();
    structurePanel.setLayout(new BoxLayout(structurePanel, BoxLayout.Y_AXIS));
    structurePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
    structurePanel.setBorder(BorderFactory.createTitledBorder("Structure Type"));

    structurePanel.add(simpleTreeButton);
    structurePanel.add(languageTreeButton);
    structurePanel.add(anaphorTreeButton);
    structurePanel.add(otherTreeButton);

    return structurePanel;
  }

  private JButton createMainButton(String text, ActionListener listener)
  {
    JButton button = DialogUiSupport.createActionButton(text, listener);
    button.setAlignmentX(Component.LEFT_ALIGNMENT);
    button.setMaximumSize(MAIN_BUTTON_SIZE);
    button.setPreferredSize(MAIN_BUTTON_SIZE);
    return button;
  }

  private void initialiseFields()
  {
    simpleTreeButton = createStructureTypeButton("Simple");
    languageTreeButton = createStructureTypeButton("Language");
    anaphorTreeButton = createStructureTypeButton("Anaphor");
    otherTreeButton = createStructureTypeButton("Other");

    structureTypeGroup = new ButtonGroup();
    structureTypeGroup.add(simpleTreeButton);
    structureTypeGroup.add(languageTreeButton);
    structureTypeGroup.add(anaphorTreeButton);
    structureTypeGroup.add(otherTreeButton);

    showProjectionsCheckBox = new JCheckBox("Show projections");
    leftProjectionCheckBox = new JCheckBox("Left");
    rightProjectionCheckBox = new JCheckBox("Right");
    topProjectionCheckBox = new JCheckBox("Top");
    bottomProjectionCheckBox = new JCheckBox("Bottom");

    structureLeftOffsetSpinner = createSpinner(2, 0, 999, 1);
    structureRightOffsetSpinner = createSpinner(0, 0, 999, 1);
    structureTopOffsetSpinner = createSpinner(2, 0, 999, 1);
    structureBottomOffsetSpinner = createSpinner(0, 0, 999, 1);

    leftProjectionPositionSpinner = createSpinner(2, 0, 999, 1);
    rightProjectionPositionSpinner = createSpinner(30, 0, 999, 1);
    topProjectionPositionSpinner = createSpinner(0, 0, 999, 1);
    bottomProjectionPositionSpinner = createSpinner(30, 0, 999, 1);

    gridColumnWidthSpinner = createSpinner(20, 1, 999, 1);
    gridRowHeightSpinner = createSpinner(20, 1, 999, 1);
    gridMarginLeftSpinner = createSpinner(1, 0, 999, 1);
    gridMarginRightSpinner = createSpinner(1, 0, 999, 1);
    gridMarginTopSpinner = createSpinner(1, 0, 999, 1);
    gridMarginBottomSpinner = createSpinner(1, 0, 999, 1);

    fullWindowGridButton = createAlignedRadioButton("Full window");
    fitContentGridButton = createAlignedRadioButton("Fit content");
    gridModeGroup = new ButtonGroup();
    gridModeGroup.add(fullWindowGridButton);
    gridModeGroup.add(fitContentGridButton);

    fitStructureOnlyButton = createAlignedRadioButton("Structure only");
    fitStructureAndProjectionsButton = createAlignedRadioButton("Structure + projections");
    fitStructureProjectionsAndLabelsButton = createAlignedRadioButton("Structure + projections + labels");
    fitScopeGroup = new ButtonGroup();
    fitScopeGroup.add(fitStructureOnlyButton);
    fitScopeGroup.add(fitStructureAndProjectionsButton);
    fitScopeGroup.add(fitStructureProjectionsAndLabelsButton);

    fitContentGridButton.setSelected(true);
    fitStructureProjectionsAndLabelsButton.setSelected(true);

    simpleTreeButton.setSelected(true);
    applyKruinDefaultsForCurrentType();
  }

  private JRadioButton createStructureTypeButton(String text)
  {
    JRadioButton button = new JRadioButton(text);
    button.setAlignmentX(Component.LEFT_ALIGNMENT);
    return button;
  }

  private JRadioButton createAlignedRadioButton(String text)
  {
    JRadioButton button = new JRadioButton(text);
    button.setAlignmentX(Component.LEFT_ALIGNMENT);
    return button;
  }

  private JSpinner createSpinner(int value, int min, int max, int step)
  {
    JSpinner spinner = new JSpinner(new SpinnerNumberModel(value, min, max, step));
    spinner.setPreferredSize(new Dimension(70, 24));
    spinner.setMaximumSize(new Dimension(70, 24));
    return spinner;
  }

  private void fitWithinOwner()
  {
    Rectangle bounds = null;
    if ( owner != null )
    {
      bounds = owner.getBounds();
    }

    int x = 40;
    int y = 40;
    if ( bounds != null )
    {
      x = bounds.x + Math.max(15, (bounds.width - getWidth()) / 2);
      y = bounds.y + Math.max(15, (bounds.height - getHeight()) / 2);
    }

    setLocation(x, y);
  }

  private void showDrawSettingsDialog()
  {
    final JDialog dialog = new JDialog((Frame)null, "KruinDraw settings", true);
    dialog.getContentPane().setLayout(new BorderLayout(8, 8));
    dialog.getContentPane().add(createSettingsHeaderPanel(
      KruinDialogSettingsSupport.getSettingsHeader(getStructureType()),
      "Tree/projection settings only. KruinGrid settings are in the separate KruinGrid dialog."), BorderLayout.NORTH);
    dialog.getContentPane().add(createDrawSettingsTabbedPane(), BorderLayout.CENTER);
    dialog.getContentPane().add(createDialogCloseBar(dialog), BorderLayout.SOUTH);
    dialog.pack();
    dialog.setResizable(false);
    dialog.setLocationRelativeTo(null);
    dialog.setVisible(true);
  }

  private void showGridSettingsDialog()
  {
    final JDialog dialog = new JDialog((Frame)null, "KruinGrid settings", true);
    dialog.getContentPane().setLayout(new BorderLayout(8, 8));
    dialog.getContentPane().add(createSettingsHeaderPanel(
      "KruinGrid settings",
      "Grid cell size, fit mode and margins only. KruinDraw settings are in the separate KruinDraw dialog."), BorderLayout.NORTH);
    dialog.getContentPane().add(createGridSettingsTab(), BorderLayout.CENTER);
    dialog.getContentPane().add(createDialogCloseBar(dialog), BorderLayout.SOUTH);
    dialog.pack();
    dialog.setResizable(false);
    dialog.setLocationRelativeTo(null);
    dialog.setVisible(true);
  }

  private JPanel createSettingsHeaderPanel(String headerText, String subHeaderText)
  {
    JPanel top = new JPanel();
    top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
    top.setBorder(new EmptyBorder(10, 10, 0, 10));

    JLabel header1 = new JLabel(headerText);
    header1.setAlignmentX(Component.LEFT_ALIGNMENT);
    JLabel header2 = new JLabel(subHeaderText);
    header2.setAlignmentX(Component.LEFT_ALIGNMENT);

    top.add(header1);
    top.add(header2);
    return top;
  }

  private JTabbedPane createDrawSettingsTabbedPane()
  {
    JTabbedPane tabs = new JTabbedPane();
    if ( getStructureType() == STRUCTURE_LANGUAGE_TREE )
    {
      tabs.addTab("Projections", createProjectionsTab());
      tabs.addTab("Placement", createPositionsTab());
    }
    else if ( getStructureType() == STRUCTURE_ANAPHOR_TREE )
    {
      tabs.addTab("Tree", createSimpleTreeSettingsTab());
      tabs.addTab("Projections", createProjectionsTab());
    }
    else
    {
      tabs.addTab("Tree", createSimpleTreeSettingsTab());
    }
    return tabs;
  }

  private JPanel createDialogCloseBar(final JDialog dialog)
  {
    JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    bottom.add(DialogUiSupport.createActionButton("Close", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        dialog.dispose();
      }
    }));
    return bottom;
  }

  private JPanel createSimpleTreeSettingsTab()
  {
    JPanel panel = createSettingsGridPanel();
    GridBagConstraints c = baseConstraints();
    addRow(panel, c, 0, "Tree left", structureLeftOffsetSpinner);
    addRow(panel, c, 1, "Tree top", structureTopOffsetSpinner);
    return panel;
  }

  private JPanel createProjectionsTab()
  {
    JPanel panel = createSettingsGridPanel();

    GridBagConstraints c = baseConstraints();
    c.gridx = 0;
    c.gridy = 0;
    c.anchor = GridBagConstraints.WEST;
    c.gridwidth = 2;
    panel.add(showProjectionsCheckBox, c);

    c.gridy++;
    c.gridwidth = 1;
    panel.add(leftProjectionCheckBox, c);
    c.gridx = 1;
    panel.add(rightProjectionCheckBox, c);

    c.gridx = 0;
    c.gridy++;
    panel.add(topProjectionCheckBox, c);
    c.gridx = 1;
    panel.add(bottomProjectionCheckBox, c);

    return panel;
  }

  private JPanel createPositionsTab()
  {
    JPanel panel = createSettingsGridPanel();
    GridBagConstraints c = baseConstraints();
    addRow(panel, c, 0, "Tree left", structureLeftOffsetSpinner);
    addRow(panel, c, 1, "Tree top", structureTopOffsetSpinner);
    addRow(panel, c, 4, "Left projection", leftProjectionPositionSpinner);
    addRow(panel, c, 5, "Right projection", rightProjectionPositionSpinner);
    addRow(panel, c, 6, "Top projection", topProjectionPositionSpinner);
    addRow(panel, c, 7, "Bottom projection", bottomProjectionPositionSpinner);
    return panel;
  }

  private JPanel createGridSettingsTab()
  {
    JPanel panel = createSettingsGridPanel();
    GridBagConstraints c = baseConstraints();
    addRow(panel, c, 0, "Cell width", gridColumnWidthSpinner);
    addRow(panel, c, 1, "Cell height", gridRowHeightSpinner);

    c.gridx = 0;
    c.gridy = 2;
    c.gridwidth = 2;
    panel.add(new JLabel("Grid mode"), c);

    c.gridy = 3;
    panel.add(fullWindowGridButton, c);
    c.gridy = 4;
    panel.add(fitContentGridButton, c);

    c.gridy = 5;
    panel.add(new JLabel("Fit scope"), c);
    c.gridy = 6;
    panel.add(fitStructureOnlyButton, c);
    c.gridy = 7;
    panel.add(fitStructureAndProjectionsButton, c);
    c.gridy = 8;
    panel.add(fitStructureProjectionsAndLabelsButton, c);

    c.gridwidth = 1;
    addRow(panel, c, 9, "Left margin", gridMarginLeftSpinner);
    addRow(panel, c, 10, "Right margin", gridMarginRightSpinner);
    addRow(panel, c, 11, "Top margin", gridMarginTopSpinner);
    addRow(panel, c, 12, "Bottom margin", gridMarginBottomSpinner);
    return panel;
  }

  private JPanel createSettingsGridPanel()
  {
    JPanel panel = new JPanel(new GridBagLayout());
    panel.setBorder(new EmptyBorder(10, 10, 10, 10));
    return panel;
  }

  private GridBagConstraints baseConstraints()
  {
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(4, 4, 4, 4);
    c.anchor = GridBagConstraints.WEST;
    return c;
  }

  private void addRow(JPanel panel, GridBagConstraints c, int row, String label, Component field)
  {
    c.gridx = 0;
    c.gridy = row;
    c.weightx = 0.0;
    c.fill = GridBagConstraints.NONE;
    panel.add(new JLabel(label), c);

    c.gridx = 1;
    c.weightx = 1.0;
    panel.add(field, c);
  }

  private void loadAtStartup()
  {
    if ( !loadUserSettingsFromFile() )
    {
      loadDefaultsFromFileOrFallback();
    }
  }

  private void loadDefaultsFromFileOrFallback()
  {
    if ( !loadPropertiesFromPath(DEFAULTS_PATH) )
    {
      applyKruinDefaultsForCurrentType();
    }
  }

  private boolean loadUserSettingsFromFile()
  {
    boolean ok = loadPropertiesFromPath(USER_SETTINGS_PATH);
    if ( ok )
    {
      loadUserSettingsRequested = true;
    }
    return ok;
  }

  private boolean loadPropertiesFromPath(String path)
  {
    try
    {
      Properties props = KruinDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( props == null )
      {
        return false;
      }

      KruinDialogSettingsState state = KruinDialogSettingsSupport.fromProperties(props);
      KruinDialogSettingsSupport.applyPostLoadRules(state);
      applyState(state);
      return true;
    }
    catch ( IOException ioe )
    {
      return false;
    }
  }

  private void applyKruinDefaultsForCurrentType()
  {
    applyState(KruinDialogSettingsSupport.createDefaultsForType(getStructureType()));
  }

  private void applyState(KruinDialogSettingsState state)
  {
    selectStructureType(state.structureType);

    showProjectionsCheckBox.setSelected(state.showProjections);
    leftProjectionCheckBox.setSelected(state.leftProjectionEnabled);
    rightProjectionCheckBox.setSelected(state.rightProjectionEnabled);
    topProjectionCheckBox.setSelected(state.topProjectionEnabled);
    bottomProjectionCheckBox.setSelected(state.bottomProjectionEnabled);

    structureLeftOffsetSpinner.setValue(Integer.valueOf(state.structureOffsetLeft));
    structureRightOffsetSpinner.setValue(Integer.valueOf(state.structureOffsetRight));
    structureTopOffsetSpinner.setValue(Integer.valueOf(state.structureOffsetTop));
    structureBottomOffsetSpinner.setValue(Integer.valueOf(state.structureOffsetBottom));

    leftProjectionPositionSpinner.setValue(Integer.valueOf(state.leftProjectionPosition));
    rightProjectionPositionSpinner.setValue(Integer.valueOf(state.rightProjectionPosition));
    topProjectionPositionSpinner.setValue(Integer.valueOf(state.topProjectionPosition));
    bottomProjectionPositionSpinner.setValue(Integer.valueOf(state.bottomProjectionPosition));

    gridColumnWidthSpinner.setValue(Integer.valueOf(state.gridColumnWidth));
    gridRowHeightSpinner.setValue(Integer.valueOf(state.gridRowHeight));
    gridMarginLeftSpinner.setValue(Integer.valueOf(state.gridMarginLeft));
    gridMarginRightSpinner.setValue(Integer.valueOf(state.gridMarginRight));
    gridMarginTopSpinner.setValue(Integer.valueOf(state.gridMarginTop));
    gridMarginBottomSpinner.setValue(Integer.valueOf(state.gridMarginBottom));

    if ( state.gridMode == KruinGridSettings.MODE_FULL_WINDOW )
    {
      fullWindowGridButton.setSelected(true);
    }
    else
    {
      fitContentGridButton.setSelected(true);
    }

    if ( state.fitScope == KruinGridSettings.SCOPE_STRUCTURE_ONLY )
    {
      fitStructureOnlyButton.setSelected(true);
    }
    else if ( state.fitScope == KruinGridSettings.SCOPE_STRUCTURE_AND_PROJECTIONS )
    {
      fitStructureAndProjectionsButton.setSelected(true);
    }
    else
    {
      fitStructureProjectionsAndLabelsButton.setSelected(true);
    }
  }

  private void selectStructureType(int structureType)
  {
    if ( structureType == STRUCTURE_LANGUAGE_TREE )
    {
      languageTreeButton.setSelected(true);
    }
    else if ( structureType == STRUCTURE_ANAPHOR_TREE )
    {
      anaphorTreeButton.setSelected(true);
    }
    else if ( structureType == STRUCTURE_OTHER )
    {
      otherTreeButton.setSelected(true);
    }
    else
    {
      simpleTreeButton.setSelected(true);
    }
  }

  private KruinDialogSettingsState readState()
  {
    KruinDialogSettingsState state = new KruinDialogSettingsState();
    state.structureType = getStructureType();
    state.showProjections = getShowProjections();
    state.leftProjectionEnabled = getLeftProjectionEnabled();
    state.rightProjectionEnabled = getRightProjectionEnabled();
    state.topProjectionEnabled = getTopProjectionEnabled();
    state.bottomProjectionEnabled = getBottomProjectionEnabled();

    state.structureOffsetLeft = getStructureOffsetFromLeft();
    state.structureOffsetRight = getStructureOffsetFromRight();
    state.structureOffsetTop = getStructureOffsetFromTop();
    state.structureOffsetBottom = getStructureOffsetFromBottom();

    state.leftProjectionPosition = getLeftProjectionPosition();
    state.rightProjectionPosition = getRightProjectionPosition();
    state.topProjectionPosition = getTopProjectionPosition();
    state.bottomProjectionPosition = getBottomProjectionPosition();

    state.gridColumnWidth = getGridColumnWidth();
    state.gridRowHeight = getGridRowHeight();
    state.gridMarginLeft = getGridMarginLeftLines();
    state.gridMarginRight = getGridMarginRightLines();
    state.gridMarginTop = getGridMarginTopLines();
    state.gridMarginBottom = getGridMarginBottomLines();
    state.gridMode = getKruinGridMode();
    state.fitScope = getKruinGridFitScope();
    return state;
  }

  public void saveUserPreferences()
  {
    try
    {
      saveUserPreferencesInternal();
      DialogUiSupport.showInfoMessage(this,
                                      "Kruin",
                                      "User settings saved.");
    }
    catch ( IOException ioe )
    {
      DialogUiSupport.showErrorMessage(this,
                                       "Kruin",
                                       "Unable to save user settings.");
    }
  }

  private void saveUserPreferencesSilently()
  {
    try
    {
      saveUserPreferencesInternal();
    }
    catch ( IOException ioe )
    {
    }
  }

  private void saveUserPreferencesInternal() throws IOException
  {
    Properties existing = KruinDialogSettingsSupport.loadPropertiesIfExists(USER_SETTINGS_PATH);
    Properties props = KruinDialogSettingsSupport.mergeUserProperties(existing, readState());
    KruinDialogSettingsSupport.saveProperties(USER_SETTINGS_PATH, props, "Kruin user settings");
    loadUserSettingsRequested = true;
  }

  public int getSelectedMethodNumber()
  {
    return 1;
  }

  public boolean usePreviousOpenStructureDefaultsSelected()
  {
    return loadUserSettingsRequested;
  }

  public int getStructureType()
  {
    if ( languageTreeButton.isSelected() )
    {
      return STRUCTURE_LANGUAGE_TREE;
    }
    if ( anaphorTreeButton.isSelected() )
    {
      return STRUCTURE_ANAPHOR_TREE;
    }
    if ( otherTreeButton.isSelected() )
    {
      return STRUCTURE_OTHER;
    }
    return STRUCTURE_SIMPLE_TREE;
  }

  public boolean getShowProjections()
  {
    if ( getStructureType() == STRUCTURE_SIMPLE_TREE )
    {
      return false;
    }
    return showProjectionsCheckBox.isSelected();
  }

  public boolean getLeftProjectionEnabled()
  {
    if ( getStructureType() == STRUCTURE_SIMPLE_TREE )
    {
      return false;
    }
    return leftProjectionCheckBox.isSelected();
  }

  public boolean getRightProjectionEnabled()
  {
    if ( getStructureType() == STRUCTURE_SIMPLE_TREE )
    {
      return false;
    }
    return rightProjectionCheckBox.isSelected();
  }

  public boolean getTopProjectionEnabled()
  {
    if ( getStructureType() == STRUCTURE_SIMPLE_TREE )
    {
      return false;
    }
    return topProjectionCheckBox.isSelected();
  }

  public boolean getBottomProjectionEnabled()
  {
    if ( getStructureType() == STRUCTURE_SIMPLE_TREE )
    {
      return false;
    }
    return bottomProjectionCheckBox.isSelected();
  }

  public int getStructureOffsetFromLeft() { return ((Integer)structureLeftOffsetSpinner.getValue()).intValue(); }
  public int getStructureOffsetFromRight() { return 0; }
  public int getStructureOffsetFromTop() { return ((Integer)structureTopOffsetSpinner.getValue()).intValue(); }
  public int getStructureOffsetFromBottom() { return 0; }

  public int getLeftProjectionPosition() { return ((Integer)leftProjectionPositionSpinner.getValue()).intValue(); }
  public int getRightProjectionPosition() { return ((Integer)rightProjectionPositionSpinner.getValue()).intValue(); }
  public int getTopProjectionPosition() { return ((Integer)topProjectionPositionSpinner.getValue()).intValue(); }
  public int getBottomProjectionPosition() { return ((Integer)bottomProjectionPositionSpinner.getValue()).intValue(); }

  public int getGridColumnWidth() { return ((Integer)gridColumnWidthSpinner.getValue()).intValue(); }
  public int getGridRowHeight() { return ((Integer)gridRowHeightSpinner.getValue()).intValue(); }
  public int getGridMarginLeftLines() { return ((Integer)gridMarginLeftSpinner.getValue()).intValue(); }
  public int getGridMarginRightLines() { return ((Integer)gridMarginRightSpinner.getValue()).intValue(); }
  public int getGridMarginTopLines() { return ((Integer)gridMarginTopSpinner.getValue()).intValue(); }
  public int getGridMarginBottomLines() { return ((Integer)gridMarginBottomSpinner.getValue()).intValue(); }

  public int getKruinGridMode()
  {
    if ( fullWindowGridButton.isSelected() )
    {
      return KruinGridSettings.MODE_FULL_WINDOW;
    }
    return KruinGridSettings.MODE_FIT_CONTENT;
  }

  public int getKruinGridFitScope()
  {
    if ( fitStructureOnlyButton.isSelected() )
    {
      return KruinGridSettings.SCOPE_STRUCTURE_ONLY;
    }
    if ( fitStructureAndProjectionsButton.isSelected() )
    {
      return KruinGridSettings.SCOPE_STRUCTURE_AND_PROJECTIONS;
    }
    return KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS;
  }

  public KruinGridSettings getKruinGridSettings()
  {
    KruinGridSettings settings = new KruinGridSettings();
    settings.setGridMode(getKruinGridMode());
    settings.setFitScope(getKruinGridFitScope());
    settings.setMarginLeftLines(getGridMarginLeftLines());
    settings.setMarginRightLines(getGridMarginRightLines());
    settings.setMarginTopLines(getGridMarginTopLines());
    settings.setMarginBottomLines(getGridMarginBottomLines());
    settings.setCellWidth(getGridColumnWidth());
    settings.setCellHeight(getGridRowHeight());
    return settings;
  }

  public void enableRunButton() { runButton.setEnabled(true); }
  public void disableRunButton() { runButton.setEnabled(false); }
  public GraphEditorWindow getOwner() { return owner; }
  public void setOwner(GraphEditorWindow o) { owner = o; }

  public void actionPerformed(ActionEvent e)
  {
    saveUserPreferencesSilently();
    // overridden by anonymous subclass in GraphController
  }
}
