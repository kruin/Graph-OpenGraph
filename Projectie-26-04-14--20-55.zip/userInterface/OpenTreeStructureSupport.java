package userInterface;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import graphStructure.Graph;
import userInterface.fileUtils.Utils;

final class OpenTreeStructureSupport
{
  private boolean resultAvailable;
  private GraphEditorWindow resultWindow;
  private Graph resultGraph;

  public void clear()
  {
    resultAvailable = false;
    resultWindow = null;
    resultGraph = null;
  }

  public boolean isSaveAvailableFor(GraphEditorWindow activeWindow)
  {
    return resultAvailable &&
           activeWindow != null &&
           activeWindow == resultWindow &&
           resultGraph != null;
  }

  public void rememberResult(GraphEditorWindow window, Graph drawnGraph) throws Exception
  {
    resultAvailable = true;
    resultWindow = window;
    resultGraph = cloneGraph(drawnGraph);
  }

  public void saveResult(Component parent, Graph sourceGraph) throws Exception
  {
    String suggestedPath = buildSuggestedPath(sourceGraph);
    JFileChooser chooser = createSaveChooser(suggestedPath);

    int returnVal = chooser.showSaveDialog(parent);
    if ( returnVal != JFileChooser.APPROVE_OPTION )
    {
      return;
    }

    String savePath = chooser.getSelectedFile().getCanonicalPath();
    String fileExt = Utils.getExtension(chooser.getSelectedFile());
    if ( fileExt == null )
    {
      savePath = savePath + ".ots";
      fileExt = "ots";
    }
    if ( fileExt == null || !fileExt.equalsIgnoreCase("ots") )
    {
      JOptionPane.showMessageDialog(parent,
                                    "OTS files may only be saved as .ots files.",
                                    "Unable to Save OTS",
                                    JOptionPane.ERROR_MESSAGE);
      return;
    }
    if ( !confirmOverwriteIfNeeded(parent, savePath) )
    {
      return;
    }

    PrintWriter writer = new PrintWriter(new FileWriter(savePath));
    resultGraph.saveTo(writer);
    writer.close();

    JOptionPane.showMessageDialog(parent,
                                  "Open Tree Structure saved to:\n" + savePath,
                                  "Save OTS",
                                  JOptionPane.INFORMATION_MESSAGE);
  }

  private String buildSuggestedPath(Graph sourceGraph) throws Exception
  {
    String sourcePath = tryGetGraphFilePath(sourceGraph);
    if ( sourcePath != null && sourcePath.length() > 0 )
    {
      return deriveOTSPath(sourcePath);
    }
    return new File(System.getProperty("user.dir"), "OTS_graph.ots").getCanonicalPath();
  }

  private JFileChooser createSaveChooser(String suggestedPath)
  {
    JFileChooser chooser = new JFileChooser();
    File suggestedFile = new File(suggestedPath);
    File parentDir = suggestedFile.getParentFile();
    if ( parentDir != null && parentDir.exists() )
    {
      chooser.setCurrentDirectory(parentDir);
    }
    else
    {
      chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
    }
    chooser.setSelectedFile(new File(suggestedFile.getName()));
    chooser.setDialogTitle("Save OTS");
    chooser.setApproveButtonText("Save OTS");
    chooser.setApproveButtonToolTipText("OTS = Open Tree Structure");

    JPanel accessory = new JPanel(new BorderLayout());
    accessory.add(new JLabel("<html><b>OTS</b> = Open Tree Structure<br>Suggested result name starts with <b>OTS_</b> and ends with <b>.ots</b>.</html>"),
                  BorderLayout.NORTH);
    chooser.setAccessory(accessory);
    return chooser;
  }

  private boolean confirmOverwriteIfNeeded(Component parent, String savePath)
  {
    File aFile = new File(savePath);
    if ( aFile.exists() )
    {
      int returnInt = JOptionPane.showConfirmDialog(parent,
                        "Do you wish to Overwrite the file " + savePath + "?",
                        "File Already Exists",
                        JOptionPane.YES_NO_OPTION);
      return returnInt == JOptionPane.YES_OPTION;
    }
    return true;
  }

  private String deriveOTSPath(String sourcePath)
  {
    File sourceFile = new File(sourcePath);
    String name = sourceFile.getName();
    File parent = sourceFile.getParentFile();

    int dot = name.lastIndexOf('.');
    if ( dot > 0 )
    {
      name = name.substring(0, dot);
    }
    if ( !name.startsWith("OTS_") )
    {
      name = "OTS_" + name;
    }
    name = name + ".ots";

    if ( parent != null )
    {
      return new File(parent, name).getPath();
    }
    return name;
  }

  private String tryGetGraphFilePath(Graph graph)
  {
    try
    {
      java.lang.reflect.Method method = graph.getClass().getMethod("getFilePath", new Class[0]);
      Object value = method.invoke(graph, new Object[0]);
      if ( value instanceof String )
      {
        return (String)value;
      }
    }
    catch ( Exception e )
    {
    }
    return null;
  }

  private Graph cloneGraph(Graph sourceGraph) throws Exception
  {
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    sourceGraph.saveTo(pw);
    pw.close();

    BufferedReader reader = new BufferedReader(new StringReader(sw.toString()));
    Graph cloned = Graph.loadFrom(reader);
    reader.close();
    return cloned;
  }
}
