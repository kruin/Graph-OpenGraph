package userInterface;

import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import graphStructure.*;
import graphException.*;
import operation.*;
import userInterface.menuAndToolBar.*;

public class GraphKruinActions
{
  private static final int DEFAULT_VISIBLE_PADDING_CELLS = 2;
  private final GraphWindow graphWindow;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;
  private final OpenTreeStructureSupport otsSupport;
  private final MenuAndToolBar menuAndToolBar;

  public GraphKruinActions(GraphWindow graphWindow,
                           GraphWindowCoordinator graphWindowCoordinator,
                           GraphEditorActions graphEditorActions,
                           OpenTreeStructureSupport otsSupport,
                           MenuAndToolBar menuAndToolBar)
  {
    this.graphWindow = graphWindow;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphEditorActions = graphEditorActions;
    this.otsSupport = otsSupport;
    this.menuAndToolBar = menuAndToolBar;
  }

  public void refreshOTSMenuVisibility(GraphEditorWindow activeWindow)
  {
    if ( menuAndToolBar == null )
    {
      return;
    }

    if ( otsSupport.isSaveAvailableFor(activeWindow) )
    {
      menuAndToolBar.showSaveOTS();
      menuAndToolBar.setSaveOTSEnabled(true);
    }
    else
    {
      menuAndToolBar.setSaveOTSEnabled(false);
      menuAndToolBar.hideSaveOTS();
    }
  }

  public void toggleLexicalProjection(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      return;
    }

    GraphEditor editor = activeWindow.getGraphEditor();
    KruinProjectionSettings projectionSettings = editor.getKruinProjectionSettings();
    boolean currentlyVisible = editor.isKruinProjectionContextActive() &&
                               projectionSettings.isLexicalProjectionActive();
    boolean enable = !currentlyVisible;

    if ( enable )
    {
      if ( projectionSettings.getStructureType() != KruinDialog.STRUCTURE_LANGUAGE_TREE ||
           (!projectionSettings.getLeftProjectionEnabled() &&
            !projectionSettings.getRightProjectionEnabled() &&
            !projectionSettings.getTopProjectionEnabled() &&
            !projectionSettings.getBottomProjectionEnabled()) )
      {
        projectionSettings = editor.getRememberedLanguageProjectionSettings();
      }

      projectionSettings.setStructureType(KruinDialog.STRUCTURE_LANGUAGE_TREE);
      projectionSettings.setShowProjections(true);
      if ( !projectionSettings.getLeftProjectionEnabled() &&
           !projectionSettings.getRightProjectionEnabled() &&
           !projectionSettings.getTopProjectionEnabled() &&
           !projectionSettings.getBottomProjectionEnabled() )
      {
        projectionSettings.setLeftProjectionEnabled(true);
        projectionSettings.setRightProjectionEnabled(false);
        projectionSettings.setTopProjectionEnabled(false);
        projectionSettings.setBottomProjectionEnabled(true);
      }
    }
    else
    {
      projectionSettings.setShowProjections(false);
    }

    editor.setKruinProjectionSettings(projectionSettings);
    if ( projectionSettings.getStructureType() == KruinDialog.STRUCTURE_LANGUAGE_TREE )
    {
      editor.rememberLanguageProjectionSettings(projectionSettings);
    }

    if ( !editor.isKruinProjectionContextActive() )
    {
      editor.update();
      return;
    }

    KruinGridSettings gridSettings = editor.getKruinGridSettings();
    if ( enable &&
         gridSettings.getFitScope() < KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
    {
      gridSettings.setFitScope(KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
      editor.setKruinGridSettings(gridSettings);
    }

    if ( editor.isInGridMode() )
    {
      gridSettings = editor.getKruinGridSettings();
      editor.changeToKruinGridMode(gridSettings);
      centerVisibleContentInWindow(editor);
    }
    editor.update();
  }
  private void ensureProjectionContentVisible(GraphEditor graphEditor, KruinGridSettings gridSettings)
  {
    centerVisibleContentInWindow(graphEditor);
  }

  private void centerVisibleContentInWindow(GraphEditor graphEditor)
  {
    if ( graphEditor == null )
    {
      return;
    }

    Graph graph = graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graphEditor.isInGridMode() )
    {
      return;
    }

    KruinGridSettings gridSettings = graphEditor.getKruinGridSettings();
    int cellWidth = Math.max(2, gridSettings.getCellWidth());
    int cellHeight = Math.max(2, gridSettings.getCellHeight());
    int drawWidth = Math.max(cellWidth * 2, graphEditor.getDrawWidth());
    int drawHeight = Math.max(cellHeight * 2, graphEditor.getDrawHeight());
    int paddingX = DEFAULT_VISIBLE_PADDING_CELLS * cellWidth;
    int paddingY = DEFAULT_VISIBLE_PADDING_CELLS * cellHeight;

    Rectangle2D.Double visibleBounds = graphEditor.getVisibleContentBounds();
    double visibleWidth = visibleBounds.getWidth();
    double visibleHeight = visibleBounds.getHeight();

    double desiredMinX;
    if ( visibleWidth + (2 * paddingX) <= drawWidth )
    {
      desiredMinX = (drawWidth - visibleWidth) / 2.0;
    }
    else
    {
      desiredMinX = paddingX;
    }

    double desiredMinY;
    if ( visibleHeight + (2 * paddingY) <= drawHeight )
    {
      desiredMinY = (drawHeight - visibleHeight) / 2.0;
    }
    else
    {
      desiredMinY = paddingY;
    }

    int dx = snapToGrid((int)Math.round(desiredMinX - visibleBounds.getMinX()), cellWidth);
    int dy = snapToGrid((int)Math.round(desiredMinY - visibleBounds.getMinY()), cellHeight);

    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    graphEditor.changeToKruinGridMode(gridSettings);
  }

  private int snapToGrid(int value, int step)
  {
    if ( step <= 1 )
    {
      return value;
    }
    return (int)Math.round((double)value / (double)step) * step;
  }


  public void clearOTSState(GraphEditorWindow activeWindow)
  {
    otsSupport.clear();
    refreshOTSMenuVisibility(activeWindow);
  }

  public void saveOTS(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null ||
         !otsSupport.isSaveAvailableFor(activeWindow) )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Save OTS is only available immediately after a Kruin draw.",
                                    "Save OTS",
                                    JOptionPane.INFORMATION_MESSAGE);
      clearOTSState(activeWindow);
      return;
    }
    try
    {
      Graph currentGraph = activeWindow.getGraphEditor().getGraph();
      otsSupport.saveResult(graphWindow, currentGraph);
      clearOTSState(activeWindow);
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                    "Error During Save OTS", JOptionPane.ERROR_MESSAGE);
    }
  }

  public void displayKruinTree(final GraphController controller,
                               final GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      clearOTSState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }
      KruinDialog dialog = new KruinDialog( controller,
        editorWindow,
        "Kruin Tree Drawing Display",
        "<html>Select structure type, then Run.</html>" )
      {
        public void actionPerformed(ActionEvent e)
        {
          displayKruinTreeHelper(getOwner(), this);
        }
      };
      dialog.preloadFromEditor(editorWindow.getGraphEditor());
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
    }
  }

  private void displayKruinTreeHelper(GraphEditorWindow editorWindow, KruinDialog dialog)
  {
    try
    {
      GraphEditor graphEditor = editorWindow.getGraphEditor();
      Graph graph = graphEditor.getGraph();
      int rootIndex = KruinRootSelector.getRootIndex(editorWindow);
      graph.newMemento("Display Kruin Drawing");

      int structureType = dialog.getStructureType();
      if ( structureType != KruinDialog.STRUCTURE_SIMPLE_TREE &&
           structureType != KruinDialog.STRUCTURE_LANGUAGE_TREE )
      {
        throw new GraphException("Only the Simple tree and the lexical projection for Language are implemented reliably at the moment.");
      }

      KruinProjectionSettings projectionSettings = KruinProjectionSupport.fromDialog(dialog);
      graphEditor.setKruinProjectionSettings(projectionSettings);
      boolean languageProjectionContext =
        projectionSettings.getStructureType() == KruinDialog.STRUCTURE_LANGUAGE_TREE;
      graphEditor.setKruinProjectionContextActive(languageProjectionContext);

      KruinGridSettings gridSettings = graphEditor.getKruinGridSettings();
      if ( projectionSettings.getStructureType() == KruinDialog.STRUCTURE_LANGUAGE_TREE &&
           gridSettings.getGridMode() == KruinGridSettings.MODE_FIT_CONTENT &&
           gridSettings.getFitScope() < KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
      {
        gridSettings.setFitScope(KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
        graphEditor.setKruinGridSettings(gridSettings);
      }
      KruinTreeDrawOperation.displayKruinTreeDrawing(
        graph,
        graph.getNodeAt(rootIndex),
        dialog.getSelectedMethodNumber(),
        dialog.getStructureOffsetFromLeft(),
        dialog.getStructureOffsetFromTop(),
        gridSettings.getCellWidth(),
        gridSettings.getCellHeight(),
        graphEditor.getDrawWidth(),
        graphEditor.getDrawHeight() );
      graphEditor.changeToKruinGridMode(gridSettings);
      centerVisibleContentInWindow(graphEditor);
      if ( projectionSettings.getStructureType() == KruinDialog.STRUCTURE_LANGUAGE_TREE )
      {
        graphEditor.rememberLanguageProjectionSettings(projectionSettings);
      }
      graphEditor.setKruinProjectionContextActive(languageProjectionContext);
      graphEditor.update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.closeDialogAndClearOwner(editorWindow);
      graph.doneMemento();
      graphEditorActions.updateUndo(editorWindow);
      otsSupport.rememberResult(editorWindow, graph);
      refreshOTSMenuVisibility(editorWindow);
    }
    catch ( Exception e )
    {
      if ( !(e instanceof GraphException) )
      {
        e.printStackTrace();
      }

      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.undoMemento();
      graph.abortMemento();

      JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                    "Error During Kruin Drawing Display", JOptionPane.ERROR_MESSAGE);
    }
  }
}
