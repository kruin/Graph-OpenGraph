package userInterface;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

/**
 * Dedicated dialog for configuring KruinGrid from Modes -> KruinGrid.
 */
public class KruinGridModeDialog extends JDialog implements ActionListener
{
  private static final String TITLE = "KruinGrid";
  private static final String COMMAND_LOAD_SAVED = "Load saved";
  private static final String COMMAND_DEFAULTS = "Defaults";
  private static final String COMMAND_SAVE = "Save";
  private static final String COMMAND_OK = "OK";
  private static final String COMMAND_CANCEL = "Cancel";

  private JRadioButton fullWindowGridButton;
  private JRadioButton fitContentGridButton;
  private JRadioButton fitStructureOnlyButton;
  private JRadioButton fitStructureAndProjectionsButton;
  private JRadioButton fitStructureProjectionsAndLabelsButton;

  private JSpinner gridColumnWidthSpinner;
  private JSpinner gridRowHeightSpinner;
  private JSpinner gridMarginLeftSpinner;
  private JSpinner gridMarginRightSpinner;
  private JSpinner gridMarginTopSpinner;
  private JSpinner gridMarginBottomSpinner;

  private boolean approved;

  public KruinGridModeDialog(Component owner, KruinGridSettings settings)
  {
    super((Frame)null, TITLE, true);
    approved = false;
    initialiseFields();
    buildUI();
    applySettings(settings);
    pack();
    setResizable(false);
    setLocationRelativeTo(owner);
  }

  private void initialiseFields()
  {
    fullWindowGridButton = new JRadioButton("Full window");
    fitContentGridButton = new JRadioButton("Fit content");
    ButtonGroup gridModeGroup = new ButtonGroup();
    gridModeGroup.add(fullWindowGridButton);
    gridModeGroup.add(fitContentGridButton);

    fitStructureOnlyButton = new JRadioButton("Structure only");
    fitStructureAndProjectionsButton = new JRadioButton("Structure + projections");
    fitStructureProjectionsAndLabelsButton = new JRadioButton("Structure + projections + labels");
    ButtonGroup fitScopeGroup = new ButtonGroup();
    fitScopeGroup.add(fitStructureOnlyButton);
    fitScopeGroup.add(fitStructureAndProjectionsButton);
    fitScopeGroup.add(fitStructureProjectionsAndLabelsButton);

    gridColumnWidthSpinner = createSpinner(20, 2, 999, 1);
    gridRowHeightSpinner = createSpinner(20, 2, 999, 1);
    gridMarginLeftSpinner = createSpinner(1, 0, 999, 1);
    gridMarginRightSpinner = createSpinner(1, 0, 999, 1);
    gridMarginTopSpinner = createSpinner(1, 0, 999, 1);
    gridMarginBottomSpinner = createSpinner(1, 0, 999, 1);
  }

  private void buildUI()
  {
    JPanel content = new JPanel(new BorderLayout(8, 8));
    content.setBorder(new EmptyBorder(10, 10, 10, 10));
    setContentPane(content);

    JLabel header = DialogUiSupport.createMessageLabel("Set the visible KruinGrid for the current drawing.");
    content.add(header, BorderLayout.NORTH);

    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(4, 4, 4, 4);
    c.anchor = GridBagConstraints.WEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 2;
    panel.add(new JLabel("Grid mode"), c);

    c.gridy++;
    panel.add(fullWindowGridButton, c);
    c.gridy++;
    panel.add(fitContentGridButton, c);

    c.gridy++;
    panel.add(Box.createRigidArea(new Dimension(0, 8)), c);
    c.gridy++;
    panel.add(new JLabel("Fit content scope"), c);

    c.gridy++;
    panel.add(fitStructureOnlyButton, c);
    c.gridy++;
    panel.add(fitStructureAndProjectionsButton, c);
    c.gridy++;
    panel.add(fitStructureProjectionsAndLabelsButton, c);

    c.gridwidth = 1;
    addRow(panel, c, 8, "Extra lines left", gridMarginLeftSpinner);
    addRow(panel, c, 9, "Extra lines right", gridMarginRightSpinner);
    addRow(panel, c, 10, "Extra lines top", gridMarginTopSpinner);
    addRow(panel, c, 11, "Extra lines bottom", gridMarginBottomSpinner);
    addRow(panel, c, 12, "Column width", gridColumnWidthSpinner);
    addRow(panel, c, 13, "Row height", gridRowHeightSpinner);

    content.add(panel, BorderLayout.CENTER);

    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    buttons.add(createButton(COMMAND_LOAD_SAVED));
    buttons.add(createButton(COMMAND_DEFAULTS));
    buttons.add(createButton(COMMAND_SAVE));
    buttons.add(createButton(COMMAND_OK));
    buttons.add(createButton(COMMAND_CANCEL));
    content.add(buttons, BorderLayout.SOUTH);
  }

  private JButton createButton(String text)
  {
    return DialogUiSupport.createActionButton(text, this);
  }

  private JSpinner createSpinner(int value, int min, int max, int step)
  {
    JSpinner spinner = new JSpinner(new SpinnerNumberModel(value, min, max, step));
    spinner.setPreferredSize(new Dimension(70, 24));
    spinner.setMaximumSize(new Dimension(70, 24));
    return spinner;
  }

  private void addRow(JPanel panel, GridBagConstraints c, int row, String label, Component field)
  {
    c.gridx = 0;
    c.gridy = row;
    c.weightx = 0.0;
    c.fill = GridBagConstraints.NONE;
    panel.add(new JLabel(label), c);

    c.gridx = 1;
    c.weightx = 1.0;
    panel.add(field, c);
  }

  public void applySettings(KruinGridSettings settings)
  {
    if ( settings == null )
    {
      settings = new KruinGridSettings();
    }
    settings = settings.copy();
    settings.normalize();

    if ( settings.getGridMode() == KruinGridSettings.MODE_FULL_WINDOW )
    {
      fullWindowGridButton.setSelected(true);
    }
    else
    {
      fitContentGridButton.setSelected(true);
    }

    if ( settings.getFitScope() == KruinGridSettings.SCOPE_STRUCTURE_ONLY )
    {
      fitStructureOnlyButton.setSelected(true);
    }
    else if ( settings.getFitScope() == KruinGridSettings.SCOPE_STRUCTURE_AND_PROJECTIONS )
    {
      fitStructureAndProjectionsButton.setSelected(true);
    }
    else
    {
      fitStructureProjectionsAndLabelsButton.setSelected(true);
    }

    gridMarginLeftSpinner.setValue(Integer.valueOf(settings.getMarginLeftLines()));
    gridMarginRightSpinner.setValue(Integer.valueOf(settings.getMarginRightLines()));
    gridMarginTopSpinner.setValue(Integer.valueOf(settings.getMarginTopLines()));
    gridMarginBottomSpinner.setValue(Integer.valueOf(settings.getMarginBottomLines()));
    gridColumnWidthSpinner.setValue(Integer.valueOf(settings.getCellWidth()));
    gridRowHeightSpinner.setValue(Integer.valueOf(settings.getCellHeight()));
  }

  public KruinGridSettings getKruinGridSettings()
  {
    KruinGridSettings settings = new KruinGridSettings();
    settings.setGridMode(fullWindowGridButton.isSelected() ?
      KruinGridSettings.MODE_FULL_WINDOW : KruinGridSettings.MODE_FIT_CONTENT);

    if ( fitStructureOnlyButton.isSelected() )
    {
      settings.setFitScope(KruinGridSettings.SCOPE_STRUCTURE_ONLY);
    }
    else if ( fitStructureAndProjectionsButton.isSelected() )
    {
      settings.setFitScope(KruinGridSettings.SCOPE_STRUCTURE_AND_PROJECTIONS);
    }
    else
    {
      settings.setFitScope(KruinGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
    }

    settings.setMarginLeftLines(((Integer)gridMarginLeftSpinner.getValue()).intValue());
    settings.setMarginRightLines(((Integer)gridMarginRightSpinner.getValue()).intValue());
    settings.setMarginTopLines(((Integer)gridMarginTopSpinner.getValue()).intValue());
    settings.setMarginBottomLines(((Integer)gridMarginBottomSpinner.getValue()).intValue());
    settings.setCellWidth(((Integer)gridColumnWidthSpinner.getValue()).intValue());
    settings.setCellHeight(((Integer)gridRowHeightSpinner.getValue()).intValue());
    settings.normalize();
    return settings;
  }

  public boolean isApproved()
  {
    return approved;
  }

  public void actionPerformed(ActionEvent e)
  {
    String command = ((JButton)e.getSource()).getText();
    if ( COMMAND_LOAD_SAVED.equals(command) )
    {
      KruinGridSettings settings = KruinGridSettingsIO.loadUserSettings();
      if ( settings == null )
      {
        DialogUiSupport.showInfoMessage(this,
          TITLE,
          "No saved KruinGrid settings found.");
      }
      else
      {
        applySettings(settings);
      }
    }
    else if ( COMMAND_DEFAULTS.equals(command) )
    {
      KruinGridSettings settings = KruinGridSettingsIO.loadDefaultSettings();
      if ( settings == null )
      {
        settings = new KruinGridSettings();
      }
      applySettings(settings);
    }
    else if ( COMMAND_SAVE.equals(command) )
    {
      try
      {
        KruinGridSettingsIO.saveUserSettings(getKruinGridSettings());
        DialogUiSupport.showInfoMessage(this,
          TITLE,
          "KruinGrid settings saved.");
      }
      catch (IOException ioe)
      {
        DialogUiSupport.showErrorMessage(this,
          TITLE,
          "Unable to save KruinGrid settings.");
      }
    }
    else if ( COMMAND_OK.equals(command) )
    {
      approved = true;
      dispose();
    }
    else if ( COMMAND_CANCEL.equals(command) )
    {
      approved = false;
      dispose();
    }
  }
}
