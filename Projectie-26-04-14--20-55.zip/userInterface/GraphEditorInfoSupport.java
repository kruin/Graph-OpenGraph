package userInterface;

import javax.swing.*;
import java.awt.*;
import graphStructure.Graph;
import operation.*;

public class GraphEditorInfoSupport
{
  private final JLabel totalNodesLabel;
  private final JLabel totalEdgesLabel;
  private final JLabel generatedEdgesLabel;
  private final JLabel curvedEdgesLabel;
  private final JLabel planarLabel;
  private final JLabel maximalPlanarLabel;
  private final JLabel connectedCountLabel;
  private final JLabel biconnectedCountLabel;

  public GraphEditorInfoSupport(Container container)
  {
    GridBagLayout layout = GraphEditorWindowUiSupport.installVerticalLayout(container);
    totalNodesLabel = addInfoLabel(container, layout);
    totalEdgesLabel = addInfoLabel(container, layout);
    generatedEdgesLabel = addInfoLabel(container, layout);
    curvedEdgesLabel = addInfoLabel(container, layout);
    planarLabel = addInfoLabel(container, layout);
    maximalPlanarLabel = addInfoLabel(container, layout);
    connectedCountLabel = addInfoLabel(container, layout);
    biconnectedCountLabel = addInfoLabel(container, layout);
  }

  private JLabel addInfoLabel(Container container, GridBagLayout layout)
  {
    JLabel label = new JLabel();
    GraphEditorWindowUiSupport.addFullWidth(container, layout, label,
                                            GridBagConstraints.BOTH, 1.0);
    return label;
  }

  public void update(Graph graph)
  {
    totalNodesLabel.setText("Total Nodes: " + graph.getNumNodes());
    totalEdgesLabel.setText("Total Edges: " + graph.getNumEdges());
    generatedEdgesLabel.setText("Generated Edges: " + graph.getNumGeneratedEdges());
    curvedEdgesLabel.setText("Curved Edges: " + graph.getNumCurvedEdges());

    boolean planar = PlanarityOperation.isPlanar(graph);
    planarLabel.setText("Planar?: " + planar);
    maximalPlanarLabel.setText("Maximal Planar?: " + (planar &&
      graph.getNumEdges() == graph.getNumNodes() * 3 - 6));
    connectedCountLabel.setText("Num Connected Components: " +
      ConnectivityOperation.getConnectedComponents(graph).size());
    biconnectedCountLabel.setText("Num Biconnected Components: " +
      BiconnectivityOperation.getBiconnectedComponents(graph).size());
  }
}
