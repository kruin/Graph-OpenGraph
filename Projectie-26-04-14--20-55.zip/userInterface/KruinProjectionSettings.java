package userInterface;

/**
 * Runtime settings for Kruin projection rendering.
 *
 * <p>These are kept separate from the grid settings so the layout logic can
 * decide independently whether the fitted grid should cover only the tree,
 * the tree plus projection bands, or the tree plus projection labels.</p>
 */
public class KruinProjectionSettings
{
  private int structureType;
  private boolean showProjections;
  private boolean leftProjectionEnabled;
  private boolean rightProjectionEnabled;
  private boolean topProjectionEnabled;
  private boolean bottomProjectionEnabled;
  private int leftProjectionPosition;
  private int rightProjectionPosition;
  private int topProjectionPosition;
  private int bottomProjectionPosition;

  public KruinProjectionSettings()
  {
    resetToDefaults();
  }

  public KruinProjectionSettings(KruinProjectionSettings other)
  {
    if ( other == null )
    {
      resetToDefaults();
    }
    else
    {
      structureType = other.structureType;
      showProjections = other.showProjections;
      leftProjectionEnabled = other.leftProjectionEnabled;
      rightProjectionEnabled = other.rightProjectionEnabled;
      topProjectionEnabled = other.topProjectionEnabled;
      bottomProjectionEnabled = other.bottomProjectionEnabled;
      leftProjectionPosition = other.leftProjectionPosition;
      rightProjectionPosition = other.rightProjectionPosition;
      topProjectionPosition = other.topProjectionPosition;
      bottomProjectionPosition = other.bottomProjectionPosition;
      normalize();
    }
  }

  public void resetToDefaults()
  {
    structureType = KruinDialog.STRUCTURE_LANGUAGE_TREE;
    showProjections = true;
    leftProjectionEnabled = true;
    rightProjectionEnabled = false;
    topProjectionEnabled = false;
    bottomProjectionEnabled = true;
    leftProjectionPosition = 2;
    rightProjectionPosition = 30;
    topProjectionPosition = 0;
    bottomProjectionPosition = 30;
    normalize();
  }

  public KruinProjectionSettings copy()
  {
    return new KruinProjectionSettings(this);
  }

  public void normalize()
  {
    if ( structureType < KruinDialog.STRUCTURE_SIMPLE_TREE ||
         structureType > KruinDialog.STRUCTURE_OTHER )
    {
      structureType = KruinDialog.STRUCTURE_SIMPLE_TREE;
    }

    if ( structureType == KruinDialog.STRUCTURE_SIMPLE_TREE )
    {
      showProjections = false;
      leftProjectionEnabled = false;
      rightProjectionEnabled = false;
      topProjectionEnabled = false;
      bottomProjectionEnabled = false;
    }
  }

  public boolean isLexicalProjectionActive()
  {
    return structureType == KruinDialog.STRUCTURE_LANGUAGE_TREE && showProjections &&
           (leftProjectionEnabled || rightProjectionEnabled || topProjectionEnabled || bottomProjectionEnabled);
  }

  public int getStructureType() { return structureType; }
  public void setStructureType(int structureType) { this.structureType = structureType; normalize(); }

  public boolean getShowProjections() { return showProjections; }
  public void setShowProjections(boolean showProjections) { this.showProjections = showProjections; normalize(); }

  public boolean getLeftProjectionEnabled() { return leftProjectionEnabled; }
  public void setLeftProjectionEnabled(boolean leftProjectionEnabled) { this.leftProjectionEnabled = leftProjectionEnabled; normalize(); }

  public boolean getRightProjectionEnabled() { return rightProjectionEnabled; }
  public void setRightProjectionEnabled(boolean rightProjectionEnabled) { this.rightProjectionEnabled = rightProjectionEnabled; normalize(); }

  public boolean getTopProjectionEnabled() { return topProjectionEnabled; }
  public void setTopProjectionEnabled(boolean topProjectionEnabled) { this.topProjectionEnabled = topProjectionEnabled; normalize(); }

  public boolean getBottomProjectionEnabled() { return bottomProjectionEnabled; }
  public void setBottomProjectionEnabled(boolean bottomProjectionEnabled) { this.bottomProjectionEnabled = bottomProjectionEnabled; normalize(); }

  public int getLeftProjectionPosition() { return leftProjectionPosition; }
  public void setLeftProjectionPosition(int leftProjectionPosition) { this.leftProjectionPosition = leftProjectionPosition; }

  public int getRightProjectionPosition() { return rightProjectionPosition; }
  public void setRightProjectionPosition(int rightProjectionPosition) { this.rightProjectionPosition = rightProjectionPosition; }

  public int getTopProjectionPosition() { return topProjectionPosition; }
  public void setTopProjectionPosition(int topProjectionPosition) { this.topProjectionPosition = topProjectionPosition; }

  public int getBottomProjectionPosition() { return bottomProjectionPosition; }
  public void setBottomProjectionPosition(int bottomProjectionPosition) { this.bottomProjectionPosition = bottomProjectionPosition; }
}
