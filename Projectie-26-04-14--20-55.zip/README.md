# OpenGraphEd

Legacy Java graph editor (2004) restored and refactored to run on modern Java.

## Status

This repository is currently based on the stable refactor baseline:

**OpenGraphEd_refactor_phase33_pq_lifecycle_support_2026-04-02**

This version has been verified as the current stable baseline after a long refactor series.

## What this baseline includes

The codebase has been substantially refactored in the following areas:

- application naming migrated to **OpenGraphEd**
- controller layer reduced and split into focused helpers
- window and dialog handling cleaned up
- file actions isolated
- editor support split into:
  - layout/grid support
  - render/transform support
  - mode/listener support
  - overlay support
- menu and toolbar logic reduced and split into helpers
- `Graph`, `Node`, and `Edge` significantly decomposed into focused support classes
- several operation classes refactored into orchestration + support structures
- partial non-critical cleanup of `PQNode` and `PQTree`

## Important note about scope

The deep PQ reduction core was **intentionally not fully refactored further**.

This was a deliberate decision to preserve stability in the most sensitive algorithmic part of the application.

## Regression note

During the refactor process, a display regression was found in the biconnectivity flow.

That issue was traced to the extracted support logic for biconnected component construction and was corrected. The stable baseline in this repository includes that fix.

## Run

You can run the application either from the built jar or by using the batch scripts.

### Run existing build

```bat
run.bat
```

or

```bat
java -jar OpenGraphEd.jar
```

## Build

On Windows:

```bat
build.bat
```

After building, the compiled output is available in:

```text
out\
```

The repository also includes the packaged runtime jar:

```text
OpenGraphEd.jar
```

## Basic structure

```text
dataStructure/                core data structures
graphStructure/               graph model
operation/                    graph algorithms and operations
userInterface/                Swing UI
userInterface/menuAndToolBar/ menus and toolbar helpers
userInterface/modes/          editor interaction modes
images/                       toolbar and UI images
help/                         HTML help pages
config/                       configuration and persisted dialog settings
docs/                         historical PDF material
out/                          compiled classes and copied runtime resources
```

## Notes

The original code used several legacy patterns and obsolete APIs.
The refactor baseline includes many internal cleanups while preserving behavior as much as possible.

Examples of preserved behavior that were explicitly checked during the refactor process:

- undo / redo
- render state after undo
- display flows
- dialog/window interaction
- save/load
- graph editing operations

## Recommended maintenance approach

For future work, prefer:

- small refactor steps
- build after every step
- functional checks after every step
- extra care in PQ-tree and embedding-related code

Recommended areas for safe future cleanup:

- documentation
- changelog / release notes
- small UI helpers
- isolated utility methods

Areas to treat as high risk:

- PQ reduction logic
- PQ templates
- deep embedding core behavior

## License / origin

This repository contains a restored legacy Java graph editor codebase with targeted modernization and refactoring for current Java environments.
