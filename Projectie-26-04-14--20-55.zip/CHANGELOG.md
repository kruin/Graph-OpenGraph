# Changelog

## 2026-04-02 — Stable refactor baseline

Stable baseline:

**OpenGraphEd_refactor_phase33_pq_lifecycle_support_2026-04-02**

### Included

#### Naming and packaging
- project naming standardized to **OpenGraphEd**
- runtime jar standardized as `OpenGraphEd.jar`

#### Controller and UI refactor
- controller responsibilities reduced and split into focused helpers
- file actions isolated
- window/dialog coordination isolated
- menu and toolbar heavily reduced and decomposed
- help/info/log/preferences windows simplified

#### Graph editor refactor
- layout/grid support extracted
- render/transform support extracted
- mode/listener support extracted
- overlay support extracted

#### Graph model refactor
- `Graph` decomposed into focused support classes for:
  - median helpers
  - selection helpers
  - copy helpers
  - bounds helpers
  - grid helpers
  - stats helpers
  - lookup helpers
  - transform helpers
  - persistence helpers
  - extender helpers
  - edge mutation helpers
  - appearance helpers
  - undo helpers
  - log helpers
  - property mutation helpers
  - topology helpers
  - structure mutation helpers

#### Node / Edge refactor
- `Node` split into:
  - incident support
  - geometry support
  - persistence support
- `Edge` split into:
  - cycle support
  - geometry support
  - persistence support

#### Operation refactor
- biconnectivity support extracted
- Chan tree draw support extracted
- embed support extracted
- Schnyder embedding support extracted

#### PQ and file utility partial cleanup
- debug support extracted from `PQNode`
- debug support extracted from `PQTree`
- lifecycle/state support extracted from PQ structures
- GIF palette/color conversion support extracted

### Fixed

#### Biconnectivity display regression
- fixed a regression introduced during refactoring of biconnected component support
- cause: temporary `newEdges` collection was not cleared per component
- result: component display/state corruption
- fix applied and included in stable baseline

### Deliberately not continued
- deep PQ reduction core not further refactored
- PQ template logic not further split
- high-risk algorithmic core intentionally left in place for stability

### Validation
The stable baseline was kept only after repeated successful checks of:

- compile
- jar build
- out folder generation
- undo / redo sanity
- render-after-undo behavior
- display flows
- editor interaction flows

## 2026-04-13

### Menu / file loading
- added `File -> Set Default Graph Dir` to choose the default folder for loading `.graph` files
- `File -> Graph Dir` now uses the chosen default graph directory instead of only the built-in `GRAPH` folder
- default graph directory is persisted in `config/opengraphed_user.properties`
- `Load Graph` accessory now shows the active default graph directory
