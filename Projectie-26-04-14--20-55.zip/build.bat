@echo off
setlocal
cd /d "%~dp0"

set "OUTDIR=out"
set "SOURCES_FILE=%TEMP%\OpenGraphEd_sources_%RANDOM%%RANDOM%.txt"
set "MANIFEST_FILE=%TEMP%\OpenGraphEd_manifest_%RANDOM%%RANDOM%.txt"

if not exist "%OUTDIR%" mkdir "%OUTDIR%"
if errorlevel 1 (
    echo.
    echo BUILD FAILED
    echo Could not create out\
    exit /b 1
)

if exist OpenGraphEd.jar del /q OpenGraphEd.jar >nul 2>nul
if exist "%SOURCES_FILE%" del /q "%SOURCES_FILE%" >nul 2>nul
if exist "%MANIFEST_FILE%" del /q "%MANIFEST_FILE%" >nul 2>nul

(
  for %%F in (*.java) do @echo %%F
  if exist dataStructure for /r dataStructure %%F in (*.java) do @echo %%F
  if exist graphException for /r graphException %%F in (*.java) do @echo %%F
  if exist graphStructure for /r graphStructure %%F in (*.java) do @echo %%F
  if exist operation for /r operation %%F in (*.java) do @echo %%F
  if exist userInterface for /r userInterface %%F in (*.java) do @echo %%F
) > "%SOURCES_FILE%"

if not exist "%SOURCES_FILE%" (
    echo.
    echo BUILD FAILED
    echo Could not create source list.
    exit /b 1
)

javac -Xmaxerrs 500 -encoding UTF-8 -d "%OUTDIR%" @"%SOURCES_FILE%"
if errorlevel 1 (
    echo.
    echo BUILD FAILED
    del /q "%SOURCES_FILE%" >nul 2>nul
    del /q "%MANIFEST_FILE%" >nul 2>nul
    exit /b 1
)

if exist images xcopy images "%OUTDIR%\images" /E /I /Y >nul
if exist help xcopy help "%OUTDIR%\help" /E /I /Y >nul
if exist config xcopy config "%OUTDIR%\config" /E /I /Y >nul

> "%MANIFEST_FILE%" echo Main-Class: OpenGraphEdFrame
>> "%MANIFEST_FILE%" echo.

jar cfm OpenGraphEd.jar "%MANIFEST_FILE%" -C "%OUTDIR%" .
if errorlevel 1 (
    echo.
    echo JAR BUILD FAILED
    del /q "%SOURCES_FILE%" >nul 2>nul
    del /q "%MANIFEST_FILE%" >nul 2>nul
    exit /b 1
)

del /q "%SOURCES_FILE%" >nul 2>nul
del /q "%MANIFEST_FILE%" >nul 2>nul

echo.
echo BUILD OK
echo Classes and resources are in out\
echo JAR created: OpenGraphEd.jar

echo.
echo Note: integration\ contains reference files only and is excluded from compilation.

endlocal
