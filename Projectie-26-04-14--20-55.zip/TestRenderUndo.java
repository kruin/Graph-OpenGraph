import java.io.*;
import graphStructure.*;
import operation.KruinTreeDrawOperation;

public class TestRenderUndo {
  public static void main(String[] args) throws Exception {
    Graph g = Graph.loadFrom(new BufferedReader(new FileReader("compact01.graph")));

    // choose root as topmost node
    Node root = g.getNodeAt(0);
    for (int i = 1; i < g.getNumNodes(); i++) {
      Node n = g.getNodeAt(i);
      if (n.getY() < root.getY() || (n.getY() == root.getY() && n.getX() < root.getX())) {
        root = n;
      }
    }

    // choose an internal node to mark as selected to exercise the old label-growth path
    Node focus = g.getNodeAt(1);
    focus.setSelected(true);

    String initialLabel = focus.getLabel();
    int initialX = root.getX();
    int initialY = root.getY();

    g.newMemento("render1");
    KruinTreeDrawOperation.displayKruinTreeDrawing(g, root, 1, 4, 4, 4, 4, 20, 20, 800, 600);
    g.doneMemento();
    String afterFirst = focus.getLabel();

    g.newMemento("render2");
    KruinTreeDrawOperation.displayKruinTreeDrawing(g, root, 1, 4, 4, 4, 4, 20, 20, 800, 600);
    g.doneMemento();
    String afterSecond = focus.getLabel();

    g.undo();
    g.undo();

    String afterUndo = focus.getLabel();
    int undoX = root.getX();
    int undoY = root.getY();

    System.out.println("initialLabel=[" + initialLabel + "]");
    System.out.println("afterFirst=[" + afterFirst + "]");
    System.out.println("afterSecond=[" + afterSecond + "]");
    System.out.println("afterUndo=[" + afterUndo + "]");
    System.out.println("initialRoot=" + initialX + "," + initialY);
    System.out.println("undoRoot=" + undoX + "," + undoY);
  }
}
