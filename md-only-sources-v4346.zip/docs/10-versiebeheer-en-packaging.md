# 10 — Versiebeheer en packaging

## Doel

Dit document beschrijft de release- en zipafspraken voor Mapping V4 / OpenGraphEd / Projectie.

## Versie

Deze pakketlaag is:

```text
v4336 — Greedy Grow geïntegreerd in static
```

v4336 bevat wel een Java-gedragswijziging: een nieuw read-only Greedy-presentatiescherm.

## Downloadnaam

Projectafspraak:

```text
naam-YY-MM-DD--time
```

Voor deze zip:

```text
Mapping_V4-26-06-01--v4336-greedy-grow-screen.zip
```

## Projectzip moet bevatten

```text
projectie-master-spec.md
md/projectie-master-spec.md
docs/
md/
chatlog/CHANGELOG-v4336.md
md-only-sources-v4336.zip
sources/
OpenGraphEd.jar
dist/OpenGraphEd.jar
```

## Md-only zip

Naam:

```text
md-only-sources-v4336.zip
```

Inhoud:

```text
projectie-master-spec.md
docs/*.md
md/**/*.md
chatlog/*.md
```

Niet opnemen in md-only:

```text
.java
.class
.jar
.pdf
.png
.svg
.zip
out/
dist/
```

## Sources

Beschikbare bronbestanden staan onder:

```text
sources/pdf/
sources/text/
```

Toekomstige projectzips blijven de PDF- en tekstbronnen uit Sources meeleveren wanneer die beschikbaar zijn.

## Verplichte controle vóór uitlevering

```text
1. javac compileert zonder errors.
2. OpenGraphEd.jar is vernieuwd.
3. dist/OpenGraphEd.jar is vernieuwd.
4. projectie-master-spec.md vermeldt v4336.
5. md/projectie-master-spec.md is gelijk aan rootversie.
6. chatlog/CHANGELOG-v4336.md bestaat.
7. md-only-sources-v4336.zip bestaat.
8. docs/11-greedy-grow-static.md bestaat.
```

## Testadvies v4336

```text
1. Start OpenGraphEd met run.bat of OpenGraphEd.bat.
2. Kies Greedy → Generate Greedy Graph.
3. Kies Greedy → Generate Greedy Grow.
4. Controleer ENTER / SPACE / klik.
5. Controleer Start grow.
6. Pas interval aan en start grow opnieuw.
```

## Packaging-regel

Bij een Java-wijziging hoort altijd:

```text
nieuwe versie
nieuwe changelog
nieuw md-only pakket
vernieuwde jar
```

## Status

v4336 bouwt verder op v4334. v4334 was documentatie/packaging; v4336 voegt runtimegedrag toe.
