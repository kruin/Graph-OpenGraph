# 19 — Greedy Grow PWA Free Nodes v4344

v4344 corrigeert de PWA-viewer na de AutoSize-versie.

## Aanleiding

In v4343 leek de standaarddemo te veel op een verbonden pad of kralenketting. Dat past niet bij de OpenGraph-notie van vrije knopen.

Daarnaast werd de actieve knoop visueel groter door de rode highlight-stroke.

## Nieuwe regels

```text
standaardweergave = vrije knopen
verbindingslijnen/edges = uit, tenzij expliciet aangezet
actieve stap = aparte buitenring, geen grotere knoop
labels/getallen = hoogste tekenlaag
Auto size = rustiger, geen harde minimumradius in rastercellen
No limit = gebruikt alle nodes/stappen uit het JSON-bestand
```

## Vieweroptie

Er is een aparte optie toegevoegd:

```text
Lijnen tonen
```

Deze staat standaard uit. Daardoor toont de viewer de knopen als vrije OpenGraph-knooppunten. Voor JSON-bestanden waarin edges informatief zijn, kan de optie handmatig worden aangezet.

## Poort

De lokale testpoort is gewijzigd naar:

```text
8084
```

Dit voorkomt storing door oude service-worker/cache-versies van v4340-v4343.
