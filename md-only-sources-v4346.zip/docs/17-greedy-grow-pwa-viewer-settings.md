# 17 — Greedy Grow PWA Viewer Settings

## Doel

v4342 maakt de Greedy Grow PWA-viewer bruikbaarer als mobiele promo-viewer.

De vorige viewer werkte, maar de standaarddemo was te klein en de visuele maatvoering was te grof:

```text
korte demo: maximaal stap 7
knopen te groot ten opzichte van grid/celgrootte
gridmaat niet instelbaar in de viewer
```

v4342 corrigeert dit.

## Wijzigingen

```text
standaard sample = volledige 31-knoops demo
Max knopen instelbaar
No limit toont alles uit JSON
knoopgrootte instelbaar
grid/celgrootte instelbaar
grid groeit mee of blijft static/eindgrid
undo/redo per grow-step toegevoegd
Static/all via laatste-stapknop
```

## Viewer-instellingen

De viewer heeft nu een eigen instellingenpaneel.

```text
Max knopen
No limit
Knoopgrootte
Grid/celgrootte
Interval ms
Grid groeit mee
Grid tonen
Labels tonen
Assen tonen
```

Deze instellingen veranderen alleen de viewerweergave. Het geladen JSON-bestand wordt niet gewijzigd.

## Max / NoLimit

`Max knopen` beperkt het aantal zichtbare/groeiende knopen.

`No limit` overrulet die begrenzing.

```text
No limit aan  = gebruik alle nodes/stappen uit JSON
No limit uit  = gebruik Max knopen als viewerlimiet
```

Voor de standaarddemo betekent dit:

```text
No limit aan  → 31 knopen
Max knopen 12 → maximaal 12 knopen
```

## Knoopgrootte en gridmaat

De viewer gebruikt waar mogelijk de modelcoördinaten uit de Greedy Grow JSON:

```text
node.model.x
node.model.y
```

Daarna wordt de positie vermenigvuldigd met de ingestelde grid/celgrootte.

Daardoor kunnen knoopgrootte en gridmaat onafhankelijk worden aangepast.

Default:

```text
knoopgrootte: 7
grid/celgrootte: 32
```

## Grid groeit mee

Als `Grid groeit mee` aan staat:

```text
de viewBox en grid worden berekend op basis van de zichtbare knopen
```

Als `Grid groeit mee` uit staat:

```text
de viewer gebruikt de volledige static/eindbounds
```

Dit sluit aan bij het onderscheid:

```text
Grow = stap voor stap
Static/all = eindbeeld
```

## Undo/redo

v4342 voegt expliciete undo/redo toe aan de PWA-viewer.

Bediening:

```text
↶      = undo grow-step
↷      = redo grow-step
Ctrl+Z = undo
Ctrl+Y = redo
```

De gewone `Vorige` en `Volgende` blijven bestaan.

## Static/all

De knop `⏭` toont de laatste toegestane stap.

```text
No limit aan  → laatste JSON-stap
No limit uit  → laatste stap binnen Max knopen
```

## Mobile status

De viewer is nog steeds een PWA/mobile viewer, geen volledige mobiele OpenGraphEd-editor.

Wel overgenomen uit Greedy Grow desktop:

```text
stap vooruit
stap terug
play/pause
undo/redo per step
static/all
grid groeit mee
zelfde JSON-bron
same-last-step-as-static principe
```

Niet overgenomen:

```text
volledige desktop-editor
Java/Swing menus
graphbestanden rechtstreeks bewerken
```

## Test

Start lokaal:

```bat
START-GREEDY-GROW-VIEWER.bat
```

Open:

```text
http://localhost:8082
```

Controle:

```text
1. De standaarddemo heeft meer dan stap 7.
2. No limit toont alle beschikbare knopen.
3. Max knopen begrenst de grow-run.
4. Knoopgrootte past direct aan.
5. Grid/celgrootte past direct aan.
6. Undo/redo werkt per grow-step.
7. ⏭ toont static/all binnen de huidige max/no-limit instelling.
```
