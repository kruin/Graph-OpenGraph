# 08 — Ontwikkelaarsdocumentatie

## Hoofdregel

```text
actuele editorgraph = bron voor Draw, Tree, Simple, Language en projecties
```

Opslag en reload zijn expliciete handelingen, geen verborgen side effects van weergaven.

## Technische basis uit JGraphEd

JGraphEd levert de graph-editorbasis:

- `Graph` bewaart knopen en edges;
- nodes hebben positie, label, kleur en selectie;
- edges hebben eindknopen, richting, center location, curve/orthogonal/straight status;
- graph editing loopt via façade-achtige bewerkingsmethoden;
- undo/redo gebruikt mementos;
- operations kunnen extenders gebruiken;
- graph files bewaren labels, posities, kleuren, grid en edge-info.

## Draw en editorstatus

Acceptatietest:

```text
1. open graph
2. wijzig label
3. niet opslaan
4. Draw
5. verwacht: gewijzigd label
```

## Simple

Simple moet:

```text
boomgeldigheid controleren
compact tekenen
projectieruimte zichtbaar/voorbereid houden
uitlegbeeld boven tekst tonen
geen crash geven als image ontbreekt
```

Boomgeldigheid:

```text
0 kindtakken = ok
1 kindtak = fout
2+ kindtakken = ok
```

## Language

Language voegt toe:

```text
LEX links
SYNT rechts
LOGical beneden
```

LF/LOGical mag rollen niet blind uit LEX-positie afleiden.

## Greedy document-first

Vanaf de huidige workflow:

```text
Greedy Generator → Genereren → graph zichtbaar in editor → fine-tune → Save As
```

`Genereren` schrijft geen verplicht tussenbestand. Save/export is expliciet.

## OPN v0.3

Schrijven en lezen moet rekening houden met:

```text
OPN_SOURCE_MODEL: free-nodes-on-grid
FREE_NODES
GROWTH_ORDER
GRID
GREEDY_SETTINGS_YAML
```

De compatibele tekenlaag `STRUCTURE_NODES` / `STRUCTURE_EDGES` blijft nodig voor bestaande loaders.

## Gridtag-regel

```text
gridH<hoogte>W<breedte> = gridcelhoogte/gridcelbreedte
```

Niet verwarren met aantal rijen/kolommen. Save As moet de actieve graph-gridcel gebruiken.

## Carrousel en uitlegbeelden

Resources staan onder:

```text
help/tree-images/
images/
opengraph_carousel/
```

Code moet ontbreken van images defensief opvangen.

## Move-mode

Edge-midpoints mogen in move-mode niet als gewone losse knopen achterblijven. Midpoints zijn intern/edge-gerelateerd, geen bronknooppunten.

## Branch-config

```text
auto
2
3
4
many
```

Simple mag niet hardcoded binair zijn. Binaire weergave hoort uit `Branches = 2` te komen.

## Packaging

Elke volgende zip bevat:

```text
projectie-master-spec.md
md/projectie-master-spec.md
docs/
md/
chatlog/CHANGELOG-vXXXX.md
md-only-sources-vXXXX.zip
sources/
```

## Regressietest

```text
1. build.bat
2. run.bat
3. A-B-C graph
4. Draw gebruikt actuele editorgraph
5. Simple uitlegbeeld zichtbaar
6. Language uitlegbeeld zichtbaar
7. Greedy Generator genereert in editor zonder verplicht opslaan
8. Save As OPN bevat gridtag en eventueel GREEDY_SETTINGS_YAML
9. OPN heropenen werkt
```

