# 09 — Theorie-achtergrond

## Centrale vraag

```text
Moet één syntactische boom alle taalkundige informatie dragen?
```

OpenGraphEd onderzoekt een alternatief:

```text
vrije bronnotatie + projecties + plaatsingsregels
```

## Traditionele boom

Een traditionele syntactische boom toont hiërarchie en vaak ook woordvolgorde. Woorden staan meestal onderaan. OpenGraphEd behandelt dat als tekenconventie, niet als inhoudelijke noodzaak.

## Probleem van één boomlaag

Een boom kan tegelijk moeten dragen:

```text
woordvolgorde
syntactische categorie
hiërarchie
logische rollen
lange-afstandsrelaties
informatie-structuur
```

Dat belast de notatie.

## Lange-afstandsafhankelijkheden

Voorbeelden:

```text
de persoon die ik gisteren gesproken heb
wie heeft de hond gebeten
de hond heeft de man gezien
```

Het element staat zichtbaar op één plek, maar heeft relationeel/logisch een andere functie.

## Projectie-oplossing als onderzoek

OpenGraphEd splitst dit:

```text
LEX toont zichtbare uitingspositie
SYNT toont syntactische categorie
LOGical/LF toont rol of relationele structuur
```

Voorbeeld:

```text
wie heeft de hond gebeten

LEX: wie vooraan
LOGical: wie = Object
```

## Geen transformaties als werkhypothese

De werkhypothese is:

```text
niet de bronboom herschrijven, maar projectie- en plaatsingsregels gebruiken
```

Dit betekent niet dat transformaties definitief overbodig zijn. Het project onderzoekt of en hoe ver projecties dragen.

## LF

LF / Logical Form wordt in OpenGraphEd voorlopig praktisch gebruikt als logische/functionele projectielaag.

Startset:

```text
V = Verb
S = Subject
O = Object
```

Dit is nog geen volledige formeel-semantische LF met scope, kwantoren en binding. Zulke uitbreiding kan later.

## SYN / SYNT

SYN toont categorieën zoals:

```text
CP, S, DP, NP, VP, PP, AP, Det, N, V, P, A, Comp
```

SYN is niet hetzelfde als LEX en niet hetzelfde als LOGical.

## Greedy en vrije knopen

De Greedy-generator ondersteunt de notatiekant: vrije knopen op raster, plaatsingsvolgorde, gridlijnen en diagonaalregels. Dit is geen klassieke syntactische derivatie, maar een manier om gecontroleerd vrije bronstructuren te maken.

## Chan-tree / tree drawing

De bronnen over tree drawing zijn relevant voor het layoutdeel: compacte, upward/order-preserving tekeningen en area-bounds laten zien dat boomtekening zelf een technisch probleem is. OpenGraphEd gebruikt zulke inzichten niet als taalkundige theorie, maar als achtergrond voor layoutkeuzes.

## Open vragen

```text
Wanneer volstaan LEX-plaatsingsregels?
Wanneer is extra syntactische structuur nodig?
Hoe wordt LOGical/LF betrouwbaar afgeleid?
Hoe gebruikt SYN informatie uit lagere knopen?
Hoe worden V-clusters en WH-vragen stabiel gemodelleerd?
Welke projectie hoort boven?
```

## Didactische kern

```text
Niet alles hoeft in één boom.
OpenGraphEd begint met vrije bronknopen.
Daarna tonen projecties wat in klassieke notatie vaak samenvalt.
```

