# 15 — Greedy Grow PWA Viewer

## Doel

De Greedy Grow PWA Viewer is een zelfstandige mobiele/webviewer voor OpenGraphEd Greedy Grow JSON-exporten.

```text
OpenGraphEd desktop → Export Greedy Grow JSON → PWA viewer → mobile demo
```

## Locatie

```text
mobile/greedy-grow-viewer/
```

## Start lokaal

Windows:

```bat
START-GREEDY-GROW-VIEWER.bat
```

Of direct in de viewer-map:

```bat
start-local-viewer.bat
```

Daarna:

```text
http://localhost:8080
```

## Op telefoon testen

Telefoon en pc moeten op hetzelfde netwerk zitten.

Gebruik op de telefoon het lokale IP-adres van de pc:

```text
http://<pc-ip>:8080
```

Voorbeeld:

```text
http://192.168.1.20:8080
```

## GitHub Pages

Voor echte mobile/promo:

```text
1. publiceer mobile/greedy-grow-viewer/ op GitHub Pages
2. open de URL op telefoon
3. installeer via browser op beginscherm
```

## Bediening

```text
Tap/click        = volgende stap
Swipe links      = volgende stap
Swipe rechts     = vorige stap
Spatie/Enter     = volgende stap
Backspace/←      = vorige stap
G                = play/pause
R                = reset
JSON             = eigen *_grow_demo.json laden
```

## Eigenschappen

```text
SVG-renderer
PWA-manifest
service worker
offline cache na eerste online bezoek
grid fit-content
grid groeit mee met zichtbare knopen
play/pause
undo/redo-achtige stapnavigatie
local JSON load
sample JSON inbegrepen
```

## Geen Java-port

De viewer is geen Java/Swing-port.

```text
Java/OpenGraphEd bepaalt de inhoud
PWA toont de demo
```

## Eerste status

v4340 is een eerste zelfstandige viewer. Geen Java-gedragswijziging.
