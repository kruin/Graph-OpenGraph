# 01 — Installatie en start

## Doel

Dit document beschrijft hoe je OpenGraphEd start, test en lokaal ordent op Windows.

## Vereisten

- Windows 10 of nieuwer;
- Java/JDK;
- een uitgepakte OpenGraphEd-projectmap;
- `run.bat` voor starten;
- `build.bat` voor ontwikkelbuilds.

Aanbevolen werkwijze: pak elke versie uit in een eigen map.

```text
C:\OpenGraphEd4333C:\OpenGraphEd4334```

## Starten

Vanuit Verkenner of command prompt:

```bat
cd /d C:\OpenGraphEd4334
run.bat
```

In de nieuwe zips bestaan ook startvarianten zoals:

```text
OpenGraphEd.bat
OpenGraphEd-console.bat
START-OpenGraphEd.bat
```

Gebruik bij gewone tests eerst `run.bat` of `OpenGraphEd.bat`.

## Bouwen

Voor broncodepakketten:

```bat
build.bat
run.bat
```

Java-waarschuwingen zijn niet automatisch fouten. Let vooral op regels met:

```text
error:
cannot find symbol
package ... does not exist
```

## Eerste test

Maak een minimale graph:

```text
A
├── B
└── C
```

Controleer:

1. knopen maken;
2. labels toevoegen;
3. takken trekken;
4. opslaan als `.graph` of `.opn`;
5. opnieuw openen;
6. `Draw` gebruiken;
7. Tree-menu testen.

## Tree-geldigheid

```text
0 kindtakken  = toegestaan als eindknoop
1 kindtak     = fout
2+ kindtakken = toegestaan
```

Richting is niet de fout. De fout is precies: een interne knoop heeft één kindtak.

## Belangrijke startcontrole

```text
1. Open een graph.
2. Wijzig een label.
3. Sla niet op.
4. Kies Draw of Simple.
5. Verwacht: het gewijzigde label verschijnt.
```

Als de oude label verschijnt, leest de functie waarschijnlijk opnieuw van schijf in plaats van uit de actuele editorgraph.

## Sources en docs

De zip bevat documentatie onder:

```text
docs/
md/
projectie-master-spec.md
chatlog/
sources/
```

Gebruik `projectie-master-spec.md` als centrale projectbron.

