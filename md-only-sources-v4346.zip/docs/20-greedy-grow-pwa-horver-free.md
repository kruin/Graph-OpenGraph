# 20 — Greedy Grow PWA HOR/VER-vrij v4345

v4345 corrigeert de betekenis van `vrije plaatsing` in de PWA-viewer.

## Correctie

`Vrije knopen` betekent niet alleen dat verbindingslijnen verborgen zijn.

Voor OpenGraph/OPN betekent vrij in deze Greedy-context minimaal:

```text
HOR vrij: geen twee knopen delen dezelfde horizontale lijn / y_line
VER vrij: geen twee knopen delen dezelfde verticale lijn / x_line
```

De viewer moet dus HOR/VER-vrijheid respecteren en tonen.

## Aanleiding

De v4344-NoLimit-demo gebruikte een spiraal. Daardoor stonden veel knopen op dezelfde horizontale en verticale lijnen. Dat is geen correcte vrije OpenGraph-bronplaatsing.

## Wijzigingen

```text
standaarddemo vervangen door HOR/VER-vrije 96-knoops demo
short_demo vervangen door HOR/VER-vrije korte demo
viewer toont in de statusregel of HOR/VER vrij is
bij conflicten toont de statusregel HOR/VER-conflict
NoLimit blijft alle nodes/stappen gebruiken
labels blijven boven cirkels en highlight-ringen
poort gewijzigd naar 8085 wegens PWA-cache
```

## Belangrijke regel

De viewer mag vrije plaatsing niet reduceren tot:

```text
losse knopen zonder lijnen
```

De correcte basisregel is:

```text
vrije bronknoop = label + bronpositie + HOR/VER-vrije plaatsingsstatus + optionele verbindingen + metadata
```

Edges blijven optioneel zichtbaar, maar bepalen niet of de knoop vrij is.
