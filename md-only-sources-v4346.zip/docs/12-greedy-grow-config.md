# 12 — Greedy Grow Config v4337

## Doel

Deze versie werkt de Greedy/Grow-specificatie bij.

Kern:

```text
Generate Greedy Graph = volledige statische eindweergave
Generate Greedy Grow  = dezelfde graph, stap voor stap zichtbaar
```

Grow blijft dus geïntegreerd in static.
Er is geen apart grow-scherm en geen aparte renderer.

## 1. Grid standaard aan

Vanaf v4337 staat het editorgrid standaard aan voor Greedy-output.

```yaml
grid:
  show_grid_in_editor: true
```

Bij `Generate Greedy Graph` en `Generate Greedy Grow` opent de graph dus meteen met zichtbaar grid.

## 2. Grid standaard fit-content

Vanaf v4337 gebruikt Greedy standaard fit-content.

```yaml
grid:
  fit_content: true
```

Betekenis:

```text
het grid wordt rond de werkelijk gegenereerde knopen gepast
```

Niet langer verplicht:

```text
gridgrootte = volledig venster op basis van max
```

Als `height` en `width` op `0` staan, wordt de gridmaat automatisch bepaald.

```yaml
grid:
  height: 0
  width: 0
  fit_content: true
```

## 3. Explicit grid blijft mogelijk

Wie geen fit-content wil, kan dit uitschakelen.

```yaml
grid:
  fit_content: false
  height: 45
  width: 45
```

Dan gebruikt de generator de opgegeven gridmaat of valt terug op:

```text
2 * max + 1 + 2 * margin
```

## 4. No limit

Vanaf v4337 is er een `no_limit`-instelling.

```yaml
graph:
  count: 31
  max: 20
  no_limit: false
```

Standaard blijft de gewone controle actief:

```text
count moet passen binnen max
```

Bij unieke x- en y-lijnen geldt dan praktisch:

```text
count <= 2 * max + 1
```

## 5. No limit aan

Met `no_limit: true` verdwijnt de kunstmatige 0..30-lesgrens.

```yaml
graph:
  count: 80
  max: 20
  no_limit: true
```

Betekenis:

```text
COUNT komt uit config
MAX komt uit config
als de zoekruimte te klein wordt, mag de generator die intern vergroten
```

Deze instelling is bedoeld om de oude maximale demonstratiegrens te overrulen.

## 6. Config max

`max` blijft een configwaarde.

```yaml
graph:
  max: 20
```

Betekenis zonder `no_limit`:

```text
max is harde modelgrens
```

Betekenis met `no_limit`:

```text
max is startgrens / configgrens
als nodig wordt de interne zoekgrens vergroot
```

In rapportage wordt zichtbaar:

```text
config max
actual generation max
```

## 7. Config voor alle Greedy-instellingen

De Greedy Generator-dialoog bevat nu configuratie voor:

```text
project
basis/count/max/no_limit
grid/fit-content/editorgrid/exportgrid
constraints
greedy style/rule/angle
grow interval/start/auto/reveal/stop/loop
output/export
```

## 8. Volledige voorbeeldconfig

```yaml
project:
  name: space3
  title: Space3 Greedy Graph
  description: Greedy spec edited from OpenGraphEd


grid:
  step_x: 20
  step_y: 20
  height: 0
  width: 0
  fit_content: true
  show_grid_in_editor: true
  show_grid_in_svg_png: true
  show_axes_through_origin: true
  show_major_grid_every: 5
  margin: 2


graph:
  count: 31
  max: 20
  no_limit: false
  start: [0, 0]


constraints:
  diagonal_free: none


greedy:
  style: near0
  rule: collinear
  angle_min: 30


grow:
  interval_ms: 700
  start_step: 0
  auto_start: false
  reveal_edges: when_both_nodes_visible
  stop_at_end: true
  loop: false


output:
  dir: output
  base_name: space3
  formats: [graph, opn, svg, png]
  naming: short
  language: nl
  write_report: true
  write_effective_spec: true
```

## 9. Acceptatietest: grid standaard aan

```text
1. Kies Greedy → Generate Greedy Graph.
2. Verwacht: graph opent met zichtbaar grid.
3. Kies Greedy → Generate Greedy Grow.
4. Verwacht: grow opent ook met zichtbaar grid.
```

## 10. Acceptatietest: fit-content

```text
1. Gebruik grid.height = 0 en grid.width = 0.
2. Gebruik grid.fit_content = true.
3. Genereer Greedy Graph.
4. Verwacht: grid past rond de gegenereerde knopen met marge.
```

## 11. Acceptatietest: no_limit

```text
1. Zet graph.count boven de oude 31-grens.
2. Zet graph.no_limit = true.
3. Genereer Greedy Graph.
4. Verwacht: geen fout op de oude 0..30-grens.
5. Verwacht: generator gebruikt config count en vergroot zo nodig de interne zoekruimte.
```

## 12. Acceptatietest: grow blijft static

```text
1. Genereer Greedy Graph.
2. Genereer Greedy Grow met dezelfde config.
3. Ga naar Static/all of laatste stap.
4. Verwacht: eindbeeld is gelijk aan static.
```

## 13. Samenvatting

```text
grid standaard aan
fit-content standaard aan
no_limit beschikbaar
config max blijft leidend
alle Greedy/Grow-instellingen in config
laatste Grow-stap blijft identiek aan static
```
