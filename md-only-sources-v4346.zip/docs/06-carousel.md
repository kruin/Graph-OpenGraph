# 06 — OpenGraph-carrousel en uitlegbeelden

## Doel

De carrousel en Tree-uitlegbeelden zijn didactische onderdelen van OpenGraphEd. Ze tonen vroeg wat de gebruiker moet zien vóór de abstracte uitleg volgt.

## Carrouselmap

```text
opengraph_carousel/
```

Itemstructuur:

```text
001-naam.png
001-naam.txt
002-naam.png
002-naam.txt
```

Elke afbeelding hoort een tekstbestand met dezelfde basisnaam te hebben.

## Tree-uitlegbeelden

Vanaf v4330-v4333 gebruiken Simple en Language ook vaste image resources:

```text
help/tree-images/simple-green-yellow-projections.png
help/tree-images/language-lex-synt-logical.png
help/tree-images/simple-free-space-projections.png
help/tree-images/simple-open-space-left-down.png
images/simple-free-space-projections.png
images/simple-open-space-left-down.png
```

Als een image ontbreekt, moet de tekstuitleg blijven werken zonder crash.

## Simple-uitlegbeeld

v4333 gebruikt de juiste tweede Simple-afbeelding: links groen/geel-projectieruimte, rechts de door de gebruiker aangeleverde vrije bronboom op raster.

De boodschap:

```text
vrije plaatsing op raster houdt projectieruimte open, voorlopig vooral links en beneden
```

## Language-uitlegbeeld

Language toont de LEX/SYNT/LOGical-afbeelding.

```text
links: LEX
rechts: SYNT
beneden: LOGical
centraal: open bronstructuur
```

## Bediening carrousel

Gewenst:

```text
Eerste
Vorige
Volgende
Laatste
Naar...
Screenshot toevoegen
Verwijder
Tekst opslaan
Ververs
Plaats <
Plaats >
Verplaats...
Wissel...
Import carousel
Export carousel
Reminder
```

## Hernummering

Bij verplaatsen of wisselen:

```text
1. lees alle items
2. wijzig volgorde intern
3. bouw map schoon opnieuw op
4. voorkom oude genummerde resten
5. controleer afbeelding/tekst-paren
```

## Workflow

Na lokale wijzigingen:

```text
1. controleer de carrousel in OpenGraphEd
2. Export carousel
3. upload exportzip bij volgend verzoek
4. volgende projectzip kan die stand meenemen
```

## Beeldvereisten

```text
leesbare labels
groot genoeg
raster duidelijk
vrije horizontale en verticale ruimte zichtbaar
projectielijnen niet door tekst
niet te veel concepten per afbeelding
```

## Eerste didactische route

```text
vrije knopen
simpele vertakking
projectieruimte
kale projectielijn
LEX
SYNT
LOGical
Language Tree
```

