# 03 — Tree-menu

## Doel

Dit document beschrijft de Tree-weergaven en de projectieweg van bron naar afgeleide lagen.

## Volgorde

```text
origineel - OpenGraph - Simple - Language - Functional - Frame - Anaphor
```

## Algemene regel

Alle Tree-weergaven gebruiken de actuele editorgraph, tenzij een item alleen uitleg of carrousel toont.

```text
editorwijziging → Tree-weergave ziet wijziging
```

## origineel

`origineel` toont de vrije bronnotatie zoals die nu in de editor staat. Het is geen reload vanaf schijf.

## OpenGraph

OpenGraph is de didactische laag:

```text
vrije knopen
vrije plaatsing
raster als notatieruimte
eigen projectielijnen
projectieruimte vóór LEX/SYNT/LOGical
```

## Simple

Simple controleert en toont de basisboom. De v4333-uitleg toont de juiste tweede afbeelding: links groen/geel-projectieruimte en rechts de door de gebruiker aangeleverde vrije bronboom op raster.

Simple legt uit:

- woorden hoeven niet “door zwaartekracht” onderaan te staan;
- `onder` is een tekenconventie;
- de centrale bronboom hoeft niet alle woordvolgorde te dragen;
- projectieruimte kan links en beneden openblijven.

Boomgeldigheid:

```text
0 kindtakken = eindknoop, toegestaan
1 kindtak    = fout
2+ kindtakken = toegestaan
```

## Language

Language gebruikt Simple/OpenGraph als basis en vult de projecties inhoudelijk in.

```text
LEX links
SYNT rechts
LOGical beneden
```

De Language-uitleg toont vroeg de afbeelding met:

- links LEX: woorden zoals `wie`, `heeft`, `de`, `hond`, `gebeten`;
- rechts SYNT: categoriecombinaties;
- onder LOGical: Subject, Object, Verb;
- blauw: centrale open bronstructuur.

## Functional / Frame / Anaphor

Deze items blijven gereserveerd. Ze horen later eigen projecties te krijgen, maar gebruiken hetzelfde uitgangspunt:

```text
één bron, meerdere projecties
```

## Acceptatietest

```text
1. Open A-B-C.graph.
2. Wijzig C naar C2.
3. Niet opslaan.
4. Kies origineel, Simple en Language.
5. Verwacht: C2 overal waar de actuele bron wordt gebruikt.
```

