# 00 — Overzicht

## Doel

Deze documentatieset beschrijft OpenGraphEd binnen het project **Mapping V4 / Projectie**. De set is opnieuw opgebouwd op basis van de actuele v4333-bronnen en vult de projectzip aan als gebruikers-, theorie- en ontwikkelaarsdocumentatie.

OpenGraphEd is geen gewone boomtekenaar. Het project gebruikt een vrije OpenGraph-bronnotatie en leidt daaruit verschillende weergaven af.

```text
vrije OpenGraph-bronknopen + projectieruimte = ruimte voor LEX, SYN, LF en latere projecties
```

## Hoofdidee

De editorgraph is de bron. Tree-weergaven en projecties zijn afgeleide lagen.

| Laag | Functie |
|---|---|
| bron / origineel | vrije OpenGraph-notatie in de editor |
| Simple | basiscontrole, compacte boomweergave en voorbereiding van projectieruimte |
| Language | taalboom met LEX, SYNT/SYN en LOGical/LF |
| Greedy | generatorworkflow voor vrije knopen op raster |
| OPN | opslag-/uitwisselformaat voor OpenGraph-bronnen |

## Nieuwe v4333-basis

De nieuwe sources leggen nadruk op:

- **vroeg beeld vóór tekst**: Simple en Language tonen eerst de relevante projectieafbeelding;
- **Simple**: vrije plaatsing op raster laat projectieruimte open, voorlopig vooral links en beneden;
- **Language**: LEX links, SYNT rechts, LOGical onder;
- **OPN v0.3**: vrije bronknopen, gridposities, `FREE_NODES`, `GROWTH_ORDER`, `OPN_SOURCE_MODEL`;
- **Greedy document-first**: genereren toont de graph; opslaan/exporteren is een aparte stap;
- **Greedy Grow Static v4336**: geïntegreerde grow-weergave in het normale statische Greedy-graphvenster;
- **Greedy Grow Config v4337**: grid standaard aan, fit-content, `no_limit` en configureerbare grow-instellingen;
- **Greedy Grow Grid Undo v4338**: grid groeit per stap mee en undo/redo werkt per grow-step;
- **Greedy Grow JSON Export v4339**: exportcontract voor latere PWA/mobile promo-demo;
- **gridtags**: `gridH<hoogte>W<breedte>` betekent gridcelhoogte en gridcelbreedte;
- **packaging**: projectzip bevat docs, master-spec, changelog, md-only zip en Sources.

- **Greedy Grow PWA HOR/VER-vrij v4345**: PWA-viewer toont standaard HOR/VER-vrije bronknopen; edges/lijnen zijn optioneel; statusregel controleert x_line/y_line.

## Documenten

```text
docs/00-overzicht.md
docs/01-installatie-en-start.md
docs/02-gebruikershandleiding.md
docs/03-tree-menu.md
docs/04-opengraph-projecties.md
docs/05-language-tree.md
docs/06-carousel.md
docs/07-graph-bestanden.md
docs/08-ontwikkelaarsdocumentatie.md
docs/09-theorie-achtergrond.md
docs/10-versiebeheer-en-packaging.md
docs/11-greedy-grow-static.md
docs/12-greedy-grow-config.md
docs/13-greedy-grow-grid-undo.md
docs/14-greedy-grow-json-export.md
docs/15-greedy-grow-pwa-viewer.md
docs/16-greedy-grow-pwa-viewer-fix.md
docs/17-greedy-grow-pwa-viewer-settings.md
docs/18-greedy-grow-pwa-autosize.md
docs/19-greedy-grow-pwa-free-nodes.md
```

## Basistermen

| Term | Betekenis |
|---|---|
| vrije knoop | bronknoop met label, positie, optionele verbindingen en metadata |
| projectie | afgeleide weergave naast/buiten de bron |
| projectielijn | lijn van bron naar afgeleide laag; geen gewone boomtak |
| LEX | lexicale/lineaire projectie, woorden in uitingsvolgorde |
| SYN / SYNT | syntactische categorieprojectie |
| LF / LOGical | logische/functionele projectie |
| OPN | OpenGraph-notatiebestand |
| Greedy | generator voor vrije bronknopen op raster |

## Hoofdregels

```text
Draw gebruikt de actuele editorgraph.
origineel toont de actuele editorgraph.
Tree-weergaven worden afgeleid.
Projecties wijzigen de bron niet ongevraagd.
Een interne boomknoop met precies één kindtak is fout.
```

## Status

Deze set hoort bij **v4345**. v4345 bevat de zelfstandige Greedy Grow PWA-viewer met HOR/VER-vrije bronknopen als standaardweergave.


- `docs/20-greedy-grow-pwa-horver-free.md` — correctie van vrije plaatsing als HOR/VER-vrije bronplaatsing.

## v4346 — Greedy Grow PWA menu/lines

Zie `docs/21-greedy-grow-pwa-menu-lines.md`.
