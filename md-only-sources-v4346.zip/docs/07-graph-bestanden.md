# 07 — Graph-, OPN- en Greedy-bestanden

## Doel

Dit document beschrijft bestandsvormen in OpenGraphEd.

## Bestandstypen

| Extensie | Functie |
|---|---|
| `.graph` | algemene JGraphEd/OpenGraphEd graph-opslag |
| `.opn` | OpenGraph-notatie en Greedy/Projectie-document |
| `.zip` | Greedy package of projectzip |
| `.png/.svg/.jpg/.gif` | visuele export |
| `.md` | documentatie en specs |

## `.graph`

Een `.graph`-bestand bewaart minimaal:

```text
knopen
labels
posities
takken/edges
edge-informatie
grid-informatie
```

JGraphEd bewaart ook details zoals kleuren, edge center location, curved/orthogonal/generated flags en node/edge ordering.

## `.opn`

OPN is de OpenGraph-specifieke bronnotatie.

Vanaf OPN v0.3:

```text
OPN_VERSION: 0.3
OPN_SOURCE_MODEL: free-nodes-on-grid
OPN_SOURCE_NOTATION:
FREE_NODES:
GROWTH_ORDER:
STRUCTURE_NODES:
STRUCTURE_EDGES:
GRID:
```

## FREE_NODES

`FREE_NODES` legt de vrije-bronstatus vast:

```text
id | label | model_x | model_y | source_x | source_y | x_line | y_line | slash_diag | backslash_diag | order | kind
```

Doel: zichtbaar maken waarom een kandidaatplaats vrij of onvrij is.

## GROWTH_ORDER

`GROWTH_ORDER` legt plaatsingsvolgorde vast:

```text
order | node_id | previous | incoming_vector | accepted_as
```

Dit is geen klassieke boomderivatie; het is een registratie van groei/plaatsing.

## GREEDY_SETTINGS_YAML

Herstelbare Greedy-OPN bevat:

```text
GREEDY_SETTINGS_YAML:
...
END_GREEDY_SETTINGS_YAML:
```

Daarmee kan `Greedy Generator` later vanuit het actieve document opnieuw worden geopend.

## Gridtag

Bestandsnamen gebruiken:

```text
gridH<gridcelhoogte>W<gridcelbreedte>
```

Voorbeeld:

```text
voorbeeld_gridH20W20.opn
```

Betekenis:

```text
H = rijhoogte / gridcelhoogte
W = kolombreedte / gridcelbreedte
```

Niet: aantal rijen/kolommen.

## Laden

Bij laden:

- gridtag in bestandsnaam lezen indien aanwezig;
- anders `GRID:`-sectie gebruiken indien aanwezig;
- oude bestanden zonder gridtag waarschuwen;
- knopen op het actieve grid snappen waar dat de afspraak is.

## Opslaan

Opslaan schrijft de actuele editorgraph.

```text
actuele editorgraph → bestand
```

Draw of Tree-menu mag niet automatisch opnieuw van schijf laden.

## Greedy package

Een Greedy package is herstelbaar en bevat bij voorkeur:

```text
.opn
.graph
spec.yaml
effective_spec.yaml
rapport/README
.svg
.png
```

## Acceptatietest

```text
1. Genereer Greedy graph.
2. Fine-tune in editor.
3. Save As → OPN.
4. Open OPN opnieuw.
5. Controleer grid, labels, vrije knopen en embedded settings.
```

