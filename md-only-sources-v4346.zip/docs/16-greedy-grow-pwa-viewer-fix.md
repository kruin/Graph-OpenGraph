# 16 — Greedy Grow PWA Viewer Fix

## Doel

v4341 repareert de eerste PWA-viewer.

De fout in v4340 was:

```text
Cannot read properties of null (reading 'steps')
```

## Oorzaak

De viewer riep bij het laden van een demo eerst `stopPlaying()` aan.

`stopPlaying()` werkte de tekststatus bij, maar op dat moment was `state.demo` nog `null`.
Daardoor probeerde `updateText()` `demo.steps` te lezen terwijl `demo` nog niet bestond.

## Herstel

v4341 wijzigt de volgorde en maakt de viewer toleranter:

```text
1. controls eerst uit
2. demo valideren en normaliseren
3. state.demo zetten
4. controls aan
5. renderen
```

Daarnaast:

```text
updateText() heeft nu een null-guard
navigatieknoppen doen niets zonder geldige demo
sample-load heeft fallback
JSON-schema is toleranter
fallback-demo is ingebouwd
favicon-link toegevoegd
service-worker cache versie verhoogd naar v4341
lokale testserver gebruikt poort 8081
```

## Waarom poort 8081

v4340 registreerde op `localhost:8080` een service-worker-cache.
Browsers kunnen daardoor tijdelijk oude `viewer.js` blijven gebruiken.

v4341 start lokaal daarom standaard op:

```text
http://localhost:8081
```

Dat vermijdt oude cache uit v4340.

## Test

Start:

```bat
START-GREEDY-GROW-VIEWER.bat
```

Open:

```text
http://localhost:8081
```

Verwacht:

```text
sample wordt direct geladen
Stap 0 / n verschijnt
grid is zichtbaar
Next/Play/Fit werken
geen Cannot read properties of null
```

## Mobiel

Pc en telefoon op hetzelfde wifi-netwerk.

Open op telefoon:

```text
http://<pc-ip-adres>:8081
```

Voorbeeld:

```text
http://192.168.1.20:8081
```
