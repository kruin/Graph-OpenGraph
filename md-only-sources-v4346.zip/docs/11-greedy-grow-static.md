# 11 — Greedy Grow Static

## Doel

Greedy Grow is geïntegreerd in de normale statische Greedy-weergave.
Er is dus geen apart tekenscherm meer.

De gebruiker kiest:

```text
Greedy → Generate Greedy Grow
```

Daarna opent OpenGraphEd de gewone Greedy-graph in een normaal graphvenster. Alleen de zichtbaarheid wordt stap voor stap opgebouwd.

## Beoordeling: static blijft

`Generate Greedy Graph` blijft noodzakelijk.

Reden:

```text
static = eindweergave / referentie / normale bewerkbare graph
grow   = dezelfde graph, maar stapsgewijs zichtbaar gemaakt
```

Grow mag geen aparte renderer of aparte presentatievariant worden. Grow moet dezelfde instellingen, dezelfde punten, dezelfde grid en dezelfde edges gebruiken als static.

## Menu

```text
Greedy → Generate Greedy Graph
Greedy → Generate Greedy Grow
```

Betekenis:

| Menu-item | Gedrag |
|---|---|
| `Generate Greedy Graph` | toont direct de volledige statische Greedy-graph |
| `Generate Greedy Grow` | genereert dezelfde graph, maar toont eerst alleen knoop 0 |

## Bedieningsvormen

### Handmatig

Volgende knoop:

```text
ENTER
SPACE
RIGHT
muisklik in het graphvenster
Next-knop
```

Vorige stap:

```text
LEFT
BACKSPACE
Vorige-knop
```

Reset:

```text
R
Reset-knop
```

Volledige eindweergave:

```text
Static/all
```

### Grow-mode

Grow-mode toont automatisch één knoop per interval.

Start/stop:

```text
G
Start grow
Pauze
```

## Configuratie

Grow leest het interval uit dezelfde Greedy-spec als static.

```yaml
grow:
  interval_ms: 700
```

Toegestaan bereik:

```text
100 ms t/m 10000 ms
```

Ontbreekt de waarde, dan geldt:

```text
700 ms
```

## Zelfde instellingen als static

Grow gebruikt exact dezelfde basis als static:

```text
project.name
project.title
grid.step_x
grid.step_y
grid.height
grid.width
graph.count
graph.max
constraints.diagonal_free
greedy.style
greedy.rule
greedy.angle_min
```

De grow-instelling voegt alleen toe:

```text
interval_ms
```

Die instelling verandert de graph zelf niet.

## Bron en opslag

De graph blijft een gewone Greedy-graph.

```text
nodes, edges, labels, grid, embedded GREEDY_SETTINGS_YAML
```

Grow wijzigt alleen tijdelijk de zichtbaarheid van knopen en edges in het open graphvenster.

```text
zichtbaarheidsstap ≠ nieuwe bronstructuur
```

`Static/all` toont de volledige eindgraph opnieuw.

## Acceptatietest

```text
1. Start OpenGraphEd.
2. Kies Greedy → Greedy Generator.
3. Zet count, max, grid, constraints en greedy-style.
4. Kies Generate.
5. Verwacht: volledige statische Greedy-graph.
6. Kies Greedy → Generate Greedy Grow.
7. Verwacht: normaal graphvenster, geen apart grow-scherm.
8. Verwacht: eerst alleen knoop 0 zichtbaar.
9. ENTER of klik toont telkens één extra knoop.
10. G of Start grow toont automatisch één knoop per interval.
11. Static/all toont de volledige eindgraph.
```

## Status

Aangepast in v4336.

## Aanvulling v4337

Vanaf v4337 geldt:

```text
editorgrid standaard aan
fit-content standaard aan
no_limit beschikbaar
alle Greedy/Grow-instellingen configureerbaar
```

Zie:

```text
docs/12-greedy-grow-config.md
```
