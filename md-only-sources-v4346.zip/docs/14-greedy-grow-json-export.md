# 14 — Greedy Grow JSON-export

## Doel

v4339 voegt een exportformaat toe voor een latere mobiele/PWA-demo van Greedy Grow.

Kern:

```text
OpenGraphEd desktop genereert de Greedy Grow-inhoud.
Mobiele/PWA-viewer leest alleen JSON en tekent de demo.
```

Dit voorkomt dat de volledige Java/Swing-editor naar mobiel geporteerd moet worden.

## 1. Nieuwe menuactie

Nieuw menu-item:

```text
Greedy → Export Greedy Grow JSON
```

Deze actie maakt een bestand:

```text
*_grow_demo.json
```

Voorbeeld:

```text
tools/greedy_generator_gui/output/space3_gridH20W20_grow_demo.json
```

## 2. Bron voor de export

De export gebruikt dezelfde Greedy-instellingen als static/grow.

Regel:

```text
als de actieve graph embedded Greedy-settings bevat → gebruik die settings
anders → gebruik tools/greedy_generator_gui/spec.yaml
```

Daarmee blijft de JSON-export consistent met:

```text
Greedy → Generate Greedy Graph
Greedy → Generate Greedy Grow
```

## 3. Exportcontract

Het JSON-bestand is bedoeld als contract tussen:

```text
OpenGraphEd Java desktop
↓
OpenGraph Greedy Grow PWA/mobile viewer
```

Het bevat geen Java-objecten en geen Swing-informatie.

Wel bevat het:

```text
metadata
grid
Greedy-config
grow-config
nodes
edges
steps
source_spec
```

## 4. JSON-topstructuur

Basisvorm:

```json
{
  "format": "opengraph-greedy-grow-demo",
  "format_version": 1,
  "engine": "OpenGraphEd java-internal greedy",
  "title": "Space3 Greedy Graph",
  "project": {},
  "grid": {},
  "greedy": {},
  "grow": {},
  "nodes": [],
  "edges": [],
  "steps": [],
  "source_spec": "..."
}
```

## 5. Grid

De grid-sectie bevat:

```json
"grid": {
  "rows": 35,
  "columns": 35,
  "cell_width": 20,
  "cell_height": 20,
  "origin": { "x": 17, "y": 18 },
  "fit_content": true,
  "grow_with_step": true,
  "show_grid": true,
  "show_axes_through_origin": true,
  "major_every": 5,
  "margin": 2
}
```

Belangrijk:

```text
grow_with_step = true
```

De mobiele viewer mag het zichtbare grid dus per stap fitten rond de zichtbare content.

## 6. Greedy

De Greedy-sectie bevat de gebruikte generatie-instellingen:

```json
"greedy": {
  "count": 31,
  "config_count": 31,
  "max": 20,
  "generation_max": 20,
  "no_limit": false,
  "style": "near0",
  "rule": "collinear",
  "diagonal_free": "none"
}
```

Betekenis:

| veld | betekenis |
|---|---|
| `count` | werkelijk aantal geëxporteerde knopen |
| `config_count` | count uit config |
| `max` | config-max |
| `generation_max` | werkelijk gebruikte max; kan groter zijn bij `no_limit` |
| `no_limit` | of de oude 30-grens/vensterlimiet is overruled |
| `style` | Greedy-plaatsingsstijl |
| `rule` | Greedy-regel |
| `diagonal_free` | diagonaalrestrictie |

## 7. Grow

De grow-sectie bevat mobiele afspeelgegevens:

```json
"grow": {
  "interval_ms": 700,
  "start_step": 0,
  "auto_start": false,
  "reveal_edges": "when_both_nodes_visible",
  "stop_at_end": true,
  "loop": false,
  "undo_redo_per_step": true,
  "tap_action": "next",
  "last_step_equals_static": true
}
```

Belangrijk voor mobiel:

```text
tap_action = next
undo_redo_per_step = true
last_step_equals_static = true
```

## 8. Nodes

Elke node heeft:

```json
{
  "id": "n000",
  "label": "0",
  "order": 0,
  "step": 0,
  "kind": "origin-free-node",
  "model": { "x": 0, "y": 0 },
  "grid": { "x": 17, "y": 18 },
  "position": { "x": 340, "y": 360 }
}
```

Betekenis:

| veld | betekenis |
|---|---|
| `id` | stabiele node-id |
| `label` | zichtbaar label |
| `order` | Greedy-volgorde |
| `step` | stap waarop de node zichtbaar wordt |
| `model` | modelcoördinaat rond oorsprong |
| `grid` | gridcoördinaat in de volledige static-layout |
| `position` | pixel/graphpositie volgens cell size |

## 9. Edges

Elke edge heeft:

```json
{
  "id": "e000",
  "from": "n000",
  "to": "n001",
  "order": 0,
  "step": 1,
  "kind": "growth-edge"
}
```

Regel:

```text
edge wordt zichtbaar op de stap waarop de doelknoop zichtbaar wordt
```

Dat past bij:

```yaml
grow:
  reveal_edges: when_both_nodes_visible
```

## 10. Steps

Elke step beschrijft de zichtbare prefix.

Voorbeeld:

```json
{
  "step": 4,
  "visible_nodes": 5,
  "node": "n004",
  "edge": "e003",
  "text": "Stap 4: voeg knoop 4 toe vanaf knoop 3; vector -2,1."
}
```

Mobiele viewer kan hiermee tonen:

```text
stapnummer
nieuwe node
nieuwe edge
korte uitlegtekst
```

## 11. PWA-gebruik later

De latere PWA doet minimaal:

```text
1. laad *_grow_demo.json
2. teken grid
3. teken nodes/edges tot huidige step
4. tap = next
5. swipe/undo = vorige step
6. play = interval_ms
7. fit grid per step indien grow_with_step true
```

## 12. Niet in v4339

v4339 maakt nog geen mobiele app.

Niet inbegrepen:

```text
PWA-viewer
GitHub Pages-publicatie
native Android/iOS-wrapper
appstore-build
```

v4339 levert alleen het exportcontract.

## 13. Acceptatietest

```text
1. Start OpenGraphEd.
2. Kies Greedy → Generate Greedy Grow.
3. Controleer dat de grow werkt.
4. Kies Greedy → Export Greedy Grow JSON.
5. Controleer dat *_grow_demo.json in tools/greedy_generator_gui/output/ staat.
6. Open het JSON-bestand in een teksteditor.
7. Controleer dat nodes, edges en steps aanwezig zijn.
8. Controleer met een JSON-validator dat het bestand geldig JSON is.
```

## 14. Samenvatting

v4339 voegt toe:

```text
Greedy → Export Greedy Grow JSON
```

Het resultaat is:

```text
*_grow_demo.json
```

Dit bestand is de eerste concrete stap richting:

```text
OpenGraph Greedy Grow PWA/mobile promo-demo
```
