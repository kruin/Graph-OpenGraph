# 02 — Gebruikershandleiding

## Doel

Deze handleiding beschrijft het dagelijkse gebruik van OpenGraphEd: tekenen, labelen, Draw, Tree-menu, Greedy, OPN en projecties.

## Basisidee

De graph in de editor is de bron. Afgeleide weergaven tonen een interpretatie van die bron.

```text
editorgraph → Draw / Simple / Language / projecties
```

Niet:

```text
laatst opgeslagen bestand → automatisch opnieuw laden bij elke view
```

## Knopen en takken

Een vrije bronknoop heeft minimaal:

```text
label
positie op of buiten raster
optionele takken
optionele metadata
```

Een tak binnen de bronstructuur is iets anders dan een projectielijn. Een projectielijn verbindt de bron met een afgeleide laag.

## Labels

Gebruik duidelijke labels:

```text
S, NP, VP, Det, N, V
de, man, ziet, hond
Subject, Object, Verb
LEX, SYNT, LOGical
```

Voor Language zijn labels noodzakelijk. Een graph zonder labels kan technisch bestaan, maar is taalkundig nauwelijks bruikbaar.

## Draw

`Draw` gebruikt de actuele editorgraph.

Test:

```text
1. Open A-B-C.graph.
2. Wijzig C naar C2.
3. Niet opslaan.
4. Draw.
5. Verwacht: C2.
```

## Tree-menu

Gewenste volgorde:

```text
origineel - OpenGraph - Simple - Language - Functional - Frame - Anaphor
```

In de huidige UI is het vroegere OpenGraph-generatorgedeelte voor Greedy apart doorontwikkeld. Het theoretische OpenGraph-principe blijft: vrije bronnotatie plus projectieruimte.

## Origineel

`origineel` toont de actuele vrije bronnotatie. Het is geen verborgen reload vanaf schijf.

## Simple

Simple is de basiscontrole. In v4333 toont de Simple-uitleg vroeg de afbeelding met:

- groen/geel projectieruimte;
- vrije bronboom op raster;
- ruimte links en beneden voor projecties.

Simple zegt dus nog niet: dit is al de volledige Language Tree. Simple laat zien dat vrije plaatsing ruimte openlaat.

## Language

Language vult projectieruimte inhoudelijk in:

```text
LEX links        = woorden / uitingsvolgorde
SYNT rechts      = syntactische categorieën
LOGical beneden  = logische/functionele projectie
```

Voorbeeld:

```text
wie heeft de hond gebeten
```

LEX:

```text
wie heeft de hond gebeten
```

LOGical:

```text
Object = wie
Subject = de hond
Verb = gebeten
```

## Greedy workflow

Vanaf v4320-v4328 is Greedy document-first:

```text
Greedy → Greedy Generator → Genereren
fine-tune in OpenGraphEd
Greedy → Save As...
```

`Genereren` toont de graph in de editor. Het schrijft niet verplicht eerst YAML, OPN, GRAPH, SVG of PNG.

Opslaan is een aparte stap:

```text
Greedy package (.zip)
OPN document (.opn)
Graph only (.graph)
Image only (.gif/.jpg/.jpeg)
```

## OPN

OPN is de OpenGraph-bronnotatie. Vanaf OPN v0.3 bevat Greedy-output vrije bronsecties zoals:

```text
OPN_VERSION: 0.3
OPN_SOURCE_MODEL: free-nodes-on-grid
FREE_NODES:
GROWTH_ORDER:
```

## Gridtags

Bestandsnamen kunnen een gridtag bevatten:

```text
gridH20W20
```

Betekenis:

```text
H = gridcelhoogte
W = gridcelbreedte
```

Niet: aantal rijen en kolommen.

## Save As

Bij Greedy Save As gebruikt OpenGraphEd de actieve gridcel voor outputnamen. Als de gebruiker later het grid aanpast, wordt het actieve grid leidend voor naamvoorstellen en embedded OPN/YAML-gridinstellingen.

## Bugrapport

Noteer bij fouten:

```text
versie
bestand
handeling
verwacht resultaat
zichtbaar resultaat
screenshot
```

Voor projectiefouten ook:

```text
verwachte LEX
zichtbare LEX
verwachte SYNT
zichtbare SYNT
verwachte LOGical/LF
zichtbare LOGical/LF
```

