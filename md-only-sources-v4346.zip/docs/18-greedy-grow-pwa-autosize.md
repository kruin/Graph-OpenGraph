# 18 — Greedy Grow PWA AutoSize

## Doel

v4343 corrigeert de PWA-viewer na praktijktest.

Problemen:

```text
labels/getallen konden visueel achter knopen verdwijnen
No limit leek nog begrensd door de sample/max-instelling
knoopgrootte, celgrootte en max voelden als losse configuratieknoppen
```

## Oplossing

### Labels altijd boven cirkels

De SVG-tekening gebruikt nu aparte lagen:

```text
grid
edges
node-circles
node-labels
```

`node-labels` wordt als laatste toegevoegd. Daardoor kunnen getallen niet meer achter cirkels verdwijnen.

Daarnaast krijgen labels een kleine halo:

```css
.node-label {
  paint-order: stroke fill;
  stroke: var(--panel);
  stroke-width: 0.28em;
}
```

## NoLimit

`No limit` betekent nu strikt:

```text
gebruik alle nodes/stappen die in het JSON-bestand staan
negeer Max knopen
```

Als `No limit` uit staat, begrenst `Max knopen` de viewer-run.

De meegeleverde standaardsample is daarom verhoogd naar een 96-knoops NoLimit-demo:

```text
samples/no_limit_96_demo.json
```

Zo is direct zichtbaar dat de viewer niet meer bij 30 of 31 stopt.

## Auto size

Nieuwe default:

```text
Auto size = aan
```

Daarmee worden grid, knoopgrootte en labelgrootte samen bepaald uit:

```text
zichtbare inhoud
huidige grow-step
canvasgrootte
NoLimit/Max-instelling
grow-grid/static-grid instelling
```

Handmatige sliders voor `Knoopgrootte` en `Grid/celgrootte` blijven beschikbaar als fallback, maar zijn uitgeschakeld zolang `Auto size` actief is.

## Startpoort

v4343 gebruikt lokaal poort:

```text
8083
```

Reden: oude service-worker/cache van v4340-v4342 vermijden.

## Acceptatietest

```text
1. Start START-GREEDY-GROW-VIEWER.bat.
2. Open http://localhost:8083.
3. Verwacht: NoLimit-demo met 96 nodes.
4. Klik/tap Next.
5. Verwacht: labels blijven zichtbaar boven de cirkels.
6. Laat NoLimit aan en klik Static/all.
7. Verwacht: stap 95 / alle 96 nodes.
8. Zet NoLimit uit.
9. Verwacht: Max knopen begrenst de run.
10. Zet Auto size uit.
11. Verwacht: handmatige knoop/cel-sliders worden actief.
```
