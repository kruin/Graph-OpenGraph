# 13 — Greedy Grow: meegroei-grid en undo/redo per stap

## Doel

Deze versie verfijnt Greedy Grow.

Kern:

```text
Grow gebruikt dezelfde statische Greedy-layout,
maar de zichtbare grid wordt per stap aangepast aan de zichtbare knopen.
```

Daarnaast worden grow-stappen opgenomen in de normale undo/redo-historie.

## 1. Grid groeit mee

In v4337 stond het grid standaard op `fit-content` voor de volledige statische Greedy-graph.

Vanaf v4338 geldt voor Greedy Grow:

```text
stap 1   → grid past rond zichtbare knoop/knopen
stap 2   → grid wordt groter indien nodig
stap 3   → grid wordt groter indien nodig
...
laatste → grid past rond volledige statische graph
```

De layout zelf verandert niet.

```text
knopen verspringen niet
edges verspringen niet
alleen het zichtbare grid-window groeit mee
```

## 2. Static blijft referentie

`Generate Greedy Graph` blijft de volledige eindweergave.

`Generate Greedy Grow` gebruikt dezelfde eindlayout, maar toont een prefix van de knopen.

Acceptatieregel:

```text
laatste grow-stap == static-weergave
```

## 3. Gridfit per grow-step

Bij elke grow-step wordt opnieuw bepaald:

```text
zichtbare knopen
zichtbare labels
benodigde grid-min-x
benodigde grid-min-y
benodigde grid-rijen
benodigde grid-kolommen
```

Daarna wordt alleen het grid-display-window aangepast.

Niet opnieuw berekend:

```text
Greedy-layout
node-posities
edge-posities
static eindgraph
```

## 4. Marges

De bestaande gridmarges blijven gelden.

Voorbeelden:

```yaml
grid:
  fit_content: true
  show_grid_in_editor: true
```

De grow-grid gebruikt dezelfde cell size en margeregels als de static grid.

## 5. Undo/redo per grow-step

Elke grow-stap krijgt een undo-memento.

Dus:

```text
Next       → nieuwe grow-step in undo-stack
Start grow → elke automatische stap komt in undo-stack
Reset      → undo-bare grow-actie
Static/all → undo-bare grow-actie
```

De undo/redo-stack bewaart:

```text
node-zichtbaarheid
edge-zichtbaarheid
grid-display-window
```

## 6. Bedieningsgedrag

### Next

```text
ENTER / SPACE / RIGHT / klik / Next
```

Gedrag:

```text
als er een redo-stap beschikbaar is → redo
anders → nieuwe grow-step
```

### Vorige

```text
LEFT / BACKSPACE / Vorige
```

Gedrag:

```text
als er een grow-undo-stap beschikbaar is → undo
anders → directe stap terug zonder nieuwe historie
```

### Undo / Redo menu

De normale OpenGraphEd undo/redo-functies werken ook per grow-step.

```text
Undo → vorige grow-step
Redo → volgende grow-step
```

## 7. Edges

Edges blijven zichtbaar zodra beide eindknopen zichtbaar zijn.

```yaml
grow:
  reveal_edges: when_both_nodes_visible
```

## 8. Automatische grow-mode

Bij automatische grow-mode:

```text
G / Start grow
```

maakt elke intervalstap één extra knoop zichtbaar en schrijft elke stap in de undo-stack.

Voorbeeld:

```yaml
grow:
  interval_ms: 700
```

## 9. Acceptatietest: grid groeit mee

```text
1. Kies Greedy → Generate Greedy Grow.
2. Controleer startstap.
3. Verwacht: grid past rond de eerste zichtbare knoop.
4. Druk ENTER.
5. Verwacht: één extra knoop zichtbaar.
6. Verwacht: grid wordt groter als de nieuwe knoop buiten het vorige grid viel.
7. Herhaal tot einde.
8. Verwacht: eindgrid past rond volledige static graph.
```

## 10. Acceptatietest: undo/redo

```text
1. Kies Greedy → Generate Greedy Grow.
2. Druk ENTER drie keer.
3. Verwacht: drie extra grow-stappen.
4. Kies Undo.
5. Verwacht: één grow-step terug.
6. Kies Undo.
7. Verwacht: opnieuw één grow-step terug.
8. Kies Redo.
9. Verwacht: één grow-step vooruit.
```

## 11. Acceptatietest: automatische grow en undo

```text
1. Kies Greedy → Generate Greedy Grow.
2. Kies Start grow.
3. Laat enkele stappen lopen.
4. Kies Pauze.
5. Kies Undo.
6. Verwacht: één automatische grow-step terug.
7. Kies Redo.
8. Verwacht: één automatische grow-step vooruit.
```

## 12. Samenvatting

Vanaf v4338:

```text
Greedy Grow laat het grid meegroeien met de zichtbare content.
Elke grow-step is undo/redo-baar.
Static blijft de eindweergave en regressiereferentie.
Grow blijft dezelfde layout gebruiken als static.
```
