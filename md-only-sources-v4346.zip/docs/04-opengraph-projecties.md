# 04 — OpenGraph en projecties

## Kern

OpenGraphEd splitst bron, woordvolgorde, syntactische categorie en logische rol.

```text
bronnotatie ≠ eindpresentatie
```

De centrale bron hoeft niet alle informatie in één traditionele boom te dragen.

## Vrije bronknopen

Een vrije bronknoop is:

```text
label + gridpositie + optionele verbindingen + optionele metadata
```

De knoop is nog niet automatisch LEX, SYN, LF, HOR of VER. Dit maakt projecties mogelijk.

## Projectieruimte

Projectieruimte is de ruimte buiten/rond de bron waarin afgeleide informatie wordt geplaatst.

Voorlopige conventie:

```text
LEX links
SYNT/SYN rechts
LOGical/LF beneden
boven gereserveerd
```

## Simple: projectieruimte voorbereiden

Simple toont met de v4333-afbeelding dat vrije plaatsing op een raster ruimte openhoudt. Vooral links en beneden kan projectieruimte ontstaan zonder de centrale bronboom te overschrijven.

## Language: projectieruimte invullen

Language vult de projectieruimte inhoudelijk in:

| Projectie | Plaats | Inhoud |
|---|---|---|
| LEX | links | woorden / uitingsvolgorde |
| SYNT/SYN | rechts | syntactische categorieën |
| LOGical/LF | beneden | Subject, Object, Verb en latere logische/functionele informatie |

## Projectielijn

Een projectielijn is geen boomtak.

| Lijn | Betekenis |
|---|---|
| boomtak | relatie binnen bronstructuur |
| projectielijn | verbinding naar afgeleide projectie |
| hulplijn | uitleg / visuele ondersteuning |
| gridlijn | plaatsingshulp |

## LEX

LEX toont de lexicale/lineaire projectie.

```text
wie heeft de hond gebeten
```

LEX is niet noodzakelijk de onderkant van de boom. In OpenGraphEd is LEX een eigen projectie.

## SYNT / SYN

SYNT/SYN toont syntactische categorieën:

```text
CP, S, DP, NP, VP, PP, AP, Det, N, V, P, A, Comp
```

SYN kan informatie uit lagere knopen gebruiken:

```text
de + man → DP / NP
ziet + de hond → VP
```

## LOGical / LF

LOGical/LF toont relationele of logische informatie.

Startset:

```text
V = Verb
S = Subject
O = Object
```

Voorbeeld:

```text
wie heeft de hond gebeten

LEX: wie heeft de hond gebeten
LOGical: O=wie, S=de hond, V=gebeten
```

## Geen transformaties als werkhypothese

Language werkt voorlopig met:

```text
geen transformaties als uitgangspunt
```

Niet de centrale boom herschrijven, maar projecties en plaatsingsregels gebruiken.

## Plaatsingsregels

Voorbeelden:

```text
LEX: plaats woorden in uitingsvolgorde
LEX: plaats persoonsvorm op positie 2 bij hoofdzin
LEX: plaats WH-element vooraan bij WH-vraag
SYNT: plaats categorieën naast de bron
LOGical: plaats rollen beneden als relationele laag
```

## Ontwerpregel

```text
projectie gebruikt actuele editorgraph
projectie wijzigt bron niet ongevraagd
projectielijn is geen gewone tak
labels blijven leesbaar en buiten de bron waar mogelijk
```

