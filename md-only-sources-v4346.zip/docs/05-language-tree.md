# 05 — Language Tree

## Doel

Language Tree toont taalkundige projecties vanuit een vrije OpenGraph-bron.

```text
Language Tree = open bronstructuur + raster + vrije plaatsing + eigen projectielijnen
```

## Lagen

| Laag | Betekenis | Voorbeeld |
|---|---|---|
| LEX | woorden / uitingsvolgorde | `wie heeft de hond gebeten` |
| SYNT/SYN | syntactische categorieën | `NP/vp`, `det/N`, `vp/VDW` |
| LOGical/LF | logische/functionele projectie | `Subject`, `Object`, `Verb` |

## Werkhypothese

```text
geen transformaties; projectie- en plaatsingsregels bepalen de zichtbare uitingsvolgorde
```

Dit is een onderzoekskeuze, geen definitieve ontkenning van transformationele analyses.

## Categorieën

Praktische startset:

```text
CP, S, DP, NP, VP, PP, AP, Det, N, V, P, A, Comp
```

Voorbeelden:

| Categorie | Voorbeeld |
|---|---|
| CP/S | `dat de man komt`, `de man komt` |
| DP/NP | `de oude man`, `een kind`, `Maria` |
| VP | `slaapt`, `ziet de hond` |
| PP | `op straat`, `met het mes` |
| AP | `heel oud`, `trots op de moeder` |

## Herschrijfregels als startmateriaal

De bronnen geven een bruikbare didactische startset:

```text
CP → (Comp) DP VP
DP → (Det) NP
NP → (AP) N (PP)
VP → (DP) (PP) V
VP → (CP) (PP) V
PP → P DP
AP → (AP) A (PP)
```

Dit is geen volledige grammatica; het is een werkset voor tests en uitleg.

## Voorbeeld: hoofdzin

```text
de man ziet de hond
```

LEX:

```text
de man ziet de hond
```

SYNT:

```text
S, DP/NP, VP, Det, N, V
```

LOGical:

```text
V = ziet
S = de man
O = de hond
```

## Voorbeeld: bijzin

```text
dat de man de hond ziet
```

LEX verschilt, maar LOGical kan vergelijkbaar blijven:

```text
V = ziet
S = de man
O = de hond
```

## Voorbeeld: WH-object

```text
wie heeft de hond gebeten
```

LEX:

```text
wie heeft de hond gebeten
```

LOGical:

```text
O = wie
S = de hond
V = gebeten
```

Hier wordt zichtbaar:

```text
LEX-positie ≠ LOGical-rol
```

## V2

Voor Nederlandse hoofdzinnen kan de persoonsvorm als LEX-plaatsingsregel worden behandeld:

```text
plaats persoonsvorm op positie 2 in LEX
```

## V-clusters

Voorbeelden:

```text
dat hij het gedaan heeft
dat hij het heeft gedaan
```

Language moet kunnen tonen:

```text
LEX verschilt
LOGical blijft vergelijkbaar
centrale bronstructuur hoeft niet te verspringen
```

## Layout

```text
bron compact plaatsen
LEX links
SYNT rechts
LOGical beneden
labels buiten de centrale graph houden
geen overbodige lege gridruimte
```

## Acceptatietests

```text
de man ziet de hond
verwacht: LEX volgorde, SYNT-categorieën, LOGical V/S/O
```

```text
wie heeft de hond gebeten
verwacht: LEX begint met wie; LOGical kan O=wie tonen
```

```text
dat hij het gedaan heeft / dat hij het heeft gedaan
verwacht: LEX-variant zonder centrale verspringing
```

