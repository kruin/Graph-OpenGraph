# 21 — Greedy Grow PWA: lijnen en menu-uitleg

Versie: v4346

## Doel

Deze versie corrigeert twee onduidelijkheden in de PWA-viewer:

1. `Lijnen tonen` moet zichtbaar effect hebben.
2. De knoppen `Fit` en `JSON` moeten begrijpelijker zijn.

## Correctie: Lijnen tonen

In v4345 waren sommige vrije HOR/VER-demo's bewust zonder `edges[]` opgeslagen. Daardoor had `Lijnen tonen` geen zichtbaar effect.

Vanaf v4346:

- als de JSON echte `edges[]` bevat, toont de viewer die JSON-lijnen;
- als de JSON geen `edges[]` bevat, toont de viewer afgeleide groeilijnen tussen opeenvolgende stappen;
- afgeleide groeilijnen zijn visuele hulplijnen, geen plaatsingsregels;
- HOR/VER-vrije plaatsing blijft leidend.

## Menu-tekst

De knop `Fit` is hernoemd naar:

```text
Passend maken
```

Betekenis: de viewer herberekent de zichtbare tekening, autosizing en SVG-viewBox voor de huidige zichtbare knopen. Dit wijzigt geen JSON en geen grow-stap.

De knop `JSON` is hernoemd naar:

```text
JSON laden
```

Betekenis: kies een eigen `*_grow_demo.json`, bijvoorbeeld uit OpenGraphEd via:

```text
Greedy → Export Greedy Grow JSON
```

## Poort

De lokale testpoort is gewijzigd naar `8086` om oude service-worker/cache-versies te vermijden.
