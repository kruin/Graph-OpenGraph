# PATCH MANIFEST — v4336 Greedy Grow Static

## Doel

Greedy Grow integreren in de normale statische Greedy-weergave.

## Beslissing

`static` blijft.

```text
Generate Greedy Graph = volledige eindweergave
Generate Greedy Grow  = dezelfde graph, stap voor stap zichtbaar
```

## Java

Gewijzigd:

```text
userInterface/GraphController.java
userInterface/GraphEditorWindow.java
userInterface/OpenGraphActions.java
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
```

Verwijderd uit de actuele Java-code:

```text
userInterface/GreedyGrowthWindow.java
```

## Menu

Nieuw:

```text
Greedy → Generate Greedy Grow
```

Vervangen:

```text
Greedy → Greedy Grow Screen  →  Greedy → Generate Greedy Grow
```

## Config

```yaml
grow:
  interval_ms: 700
```

## Build

```text
Implementation-Version: v4.33.6-greedy-grow-static
```

`build.bat` verwijdert `out/` vóór compilatie om oude classes te voorkomen.
