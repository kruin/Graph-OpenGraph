# PATCH MANIFEST v4332 — Simple-uitleg: tweede afbeelding opnieuw opgebouwd

## Doel

Corrigeer de tweede afbeelding in de Simple-uitleg. In v4331 stond rechts ten onrechte een Greedy Generator-instellingenscherm.

## Wijziging

De gecombineerde Simple-uitlegafbeelding is opnieuw opgebouwd:

- links: groen/geel-projecties;
- rechts: blauwe vrije bronboom op raster;
- toelichting: vrije plaatsing houdt projectieruimte open, voorlopig vooral links en beneden.

## Gewijzigde resources

- `help/tree-images/simple-free-space-projections.png`
- `help/tree-images/simple-open-space-left-down.png`
- `images/simple-free-space-projections.png`
- `images/simple-open-space-left-down.png`

## Java

Geen Java-gedragswijziging.
