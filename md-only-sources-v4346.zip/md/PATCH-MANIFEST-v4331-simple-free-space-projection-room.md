# PATCH MANIFEST v4.33.1 — Simple uitleg: vrije plaatsing en projectieruimte

## Doel

De Simple-uitleg laat nu explicieter zien dat OpenGraph-notatie niet alleen een boom tekent, maar ook ruimte vrijhoudt voor projecties.

## Wijzigingen

- Nieuwe Simple-uitlegafbeelding:
  - links: eerdere groen/geel-projecties;
  - rechts: vrije plaatsing van de bronboom op het raster;
  - caption: links en beneden blijft projectieruimte open.
- Simple-uitlegtekst uitgebreid:
  - raster = gecontroleerde notatieruimte;
  - vrije plaatsing = niet willekeurig, maar bronknopen op rasterpunten;
  - projectieruimte ontstaat links en beneden;
  - projectielijnen overschrijven de centrale bronboom niet.

## Bestanden

- `help/tree-images/simple-free-space-projections.png`
- `help/tree-images/simple-open-space-left-down.png`
- `images/simple-free-space-projections.png`
- `images/simple-open-space-left-down.png`
- `userInterface/GraphEditorWindow.java`

## Test

- Build moet slagen met `build.bat`.
- Test in de app: Tree = Simple, knop Uitleg.
