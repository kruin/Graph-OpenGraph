# Documentatie v4336 — Greedy Grow Static

Deze documentatielaag hoort bij `Mapping_V4-26-06-01--v4336-greedy-grow-static.zip`.

Belangrijkste wijziging:

```text
Greedy → Generate Greedy Grow
```

Grow gebruikt geen eigen tekenscherm meer. De normale statische Greedy-graph wordt in hetzelfde graphvenster stap voor stap zichtbaar gemaakt.

- static blijft: `Greedy → Generate Greedy Graph`;
- grow gebruikt dezelfde settings als static;
- handmatig: ENTER / SPACE / RIGHT / klik / Next;
- automatisch: Start grow / G;
- volledig tonen: Static/all;
- interval: `grow.interval_ms`.
