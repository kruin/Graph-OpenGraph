# PATCH MANIFEST — v4338 Greedy Grow Grid Undo

## Doel

Greedy Grow aanpassen volgens specificatie:

```text
grid groeit mee per grow-step
undo/redo werkt per grow-step
```

## Gewijzigde Java-bestanden

```text
userInterface/GraphEditorWindow.java
userInterface/GraphEditor.java
userInterface/GraphEditorActions.java
graphStructure/Graph.java
graphStructure/Node.java
graphStructure/Edge.java
graphStructure/mementos/GreedyGrowVisibilityMemento.java
```

## Gewijzigde build/documentatiebestanden

```text
build.bat
docs/13-greedy-grow-grid-undo.md
chatlog/CHANGELOG-v4338.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## Functioneel gedrag

```text
Next = grow-step vooruit, undo-baar
Vorige = undo indien mogelijk
Redo = grow-step vooruit indien beschikbaar
Start grow = elke timerstap schrijft een grow-step
Grid = fit rond zichtbare grow-prefix
```

## Niet gewijzigd

```text
Greedy static layout
Greedy plaatsingsregel
Greedy generatorconfig
Language Tree
OpenGraph-carrousel
```
