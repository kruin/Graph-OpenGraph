# PATCH MANIFEST — v4339 Greedy Grow JSON Export

## Doel

Een exportcontract toevoegen voor een latere mobiele/PWA-demo van Greedy Grow.

## Nieuwe functie

```text
Greedy → Export Greedy Grow JSON
```

Output:

```text
tools/greedy_generator_gui/output/*_grow_demo.json
```

## Gewijzigde Java-bestanden

```text
userInterface/GreedyInternalGenerator.java
userInterface/OpenGraphActions.java
userInterface/GraphController.java
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
```

## Gewijzigde build/documentatiebestanden

```text
build.bat
docs/14-greedy-grow-json-export.md
chatlog/CHANGELOG-v4339.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## JSON-contract

Het JSON-bestand bevat:

```text
metadata
grid
greedy
grow
nodes
edges
steps
source_spec
```

## Functioneel gedrag

```text
actieve Greedy-graph met embedded settings → export gebruikt die settings
geen actieve Greedy-settings → export gebruikt default spec.yaml
JSON is los van Java/Swing
PWA/mobile viewer kan JSON later rechtstreeks lezen
```

## Niet gewijzigd

```text
static Greedy layout
Greedy Grow renderer
Greedy Grow undo/redo
meegroei-grid
Language Tree
OpenGraph-carrousel
```
