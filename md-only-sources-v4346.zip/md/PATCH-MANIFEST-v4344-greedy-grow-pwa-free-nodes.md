# PATCH-MANIFEST v4344 — Greedy Grow PWA Free Nodes

## Doel

PWA-viewer herstellen naar vrije OpenGraph-knooppunten in de standaardweergave.

## Kernwijzigingen

```text
vrije knopen standaard
edges/lijnen optioneel
NoLimit-demo zonder verbindingspad
actieve knoop als aparte ring
labels altijd bovenaan
autosizing rustiger
poort 8084
```

## Gewijzigde PWA-bestanden

```text
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/styles.css
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/start-local-viewer.bat
mobile/greedy-grow-viewer/samples/no_limit_96_demo.json
mobile/greedy-grow-viewer/README.md
```

## Desktop Java

Geen Java-wijziging in v4344.
