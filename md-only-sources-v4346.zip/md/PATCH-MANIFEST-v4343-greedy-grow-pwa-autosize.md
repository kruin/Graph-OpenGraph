# PATCH MANIFEST v4343 — Greedy Grow PWA AutoSize

## Bestanden

```text
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/styles.css
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/README.md
mobile/greedy-grow-viewer/start-local-viewer.bat
mobile/greedy-grow-viewer/samples/no_limit_96_demo.json
docs/18-greedy-grow-pwa-autosize.md
chatlog/CHANGELOG-v4343.md
projectie-master-spec.md
```

## Korte inhoud

```text
labels boven cirkels
NoLimit gebruikt alle nodes
96-node NoLimit sample
Auto size koppelt grid/knoop/label/max
poort 8083
```
