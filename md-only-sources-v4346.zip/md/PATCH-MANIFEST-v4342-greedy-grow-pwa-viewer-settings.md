# PATCH-MANIFEST v4342 — Greedy Grow PWA Viewer Settings

## Scope

PWA-viewer verbetering. Geen wijziging aan Java/Swing editorlogica.

## Gewijzigde viewerfunctionaliteit

```text
Max knopen configureerbaar
No limit beschikbaar
knoopgrootte configureerbaar
grid/celgrootte configureerbaar
interval configureerbaar
grid groeit mee toggle
grid/labels/assen toggles
undo/redo per grow-step
static/all via laatste stap
volledige sample standaard geladen
```

## Poort

Lokale testserver:

```text
8082
```

Reden:

```text
vermijden van oude PWA/service-worker/cache op 8080/8081
```

## Hoofdbestanden

```text
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/styles.css
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/README.md
mobile/greedy-grow-viewer/start-local-viewer.bat
```
