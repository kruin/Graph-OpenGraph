# PATCH MANIFEST v4330 — Simple/Language projectie-afbeeldingen

## Gewijzigde Java-bestanden

- `userInterface/GraphEditorWindow.java`

## Nieuwe bestanden

- `help/tree-images/simple-green-yellow-projections.png`
- `help/tree-images/language-lex-synt-logical.png`

## Documentatie

- `projectie-master-spec.md`
- `md/projectie-master-spec.md`
- `chatlog/CHANGELOG-v4330.md`

## Gedrag

- Bij `Tree = Simple` toont `Uitleg` eerst de groen/geel-projectieafbeelding.
- Bij `Tree = Language` toont `Uitleg` eerst de LEX/SYNT/LOGical-afbeelding.
- Als een image ontbreekt, blijft de uitlegtekst werken zonder crash.
