# PATCH-MANIFEST v4345 — Greedy Grow PWA HOR/VER-vrij

## Doel

Corrigeer de PWA-betekenis van vrije plaatsing.

Vrij betekent hier:

```text
x_line uniek
 y_line uniek
```

Dus geen twee knopen mogen dezelfde verticale of horizontale bronlijn delen.

## Aangepaste bestanden

```text
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/styles.css
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/README.md
mobile/greedy-grow-viewer/start-local-viewer.bat
mobile/greedy-grow-viewer/samples/no_limit_96_demo.json
mobile/greedy-grow-viewer/samples/short_demo.json
START-GREEDY-GROW-VIEWER.bat
docs/20-greedy-grow-pwa-horver-free.md
chatlog/CHANGELOG-v4345.md
```

## Test

- `viewer.js` syntax gecontroleerd met `node --check`.
- JSON-samples gecontroleerd met `python -m json.tool`.
- Samples gecontroleerd op unieke x- en y-lijnen.

## Start

```text
http://localhost:8085
```
