- [PATCH-MANIFEST-v4261-ft-role-box-debug-trace-downstack-clearance.md](PATCH-MANIFEST-v4261-ft-role-box-debug-trace-downstack-clearance.md) — Adds FT role-box debug trace and stronger down-stack clearance.
- [PATCH-MANIFEST-v4259-ft-role-box-tiered-stacking.md](PATCH-MANIFEST-v4259-ft-role-box-tiered-stacking.md) — FT role-box visual tiers and safer down-stack.
- [PATCH-MANIFEST-v4254-functional-tree-type-skeleton.md](PATCH-MANIFEST-v4254-functional-tree-type-skeleton.md) — Adds FT as separate Functional Tree structure type; activates role_box only for FT.
- [PATCH-MANIFEST-v4252-role-box-preparation.md](PATCH-MANIFEST-v4252-role-box-preparation.md) — Internal role-box preparation for later Functional Grammar n-ary boxes; no GUI setting yet.
- [PATCH-MANIFEST-v4251-language-tree-projection-box-layout.md](PATCH-MANIFEST-v4251-language-tree-projection-box-layout.md) — Language Tree projection-box layout: projection order first, local box first.
- `PATCH-MANIFEST-v4248-language-tree-nary-same-side-terminal-corridor-fix.md` — n-ary same-side terminal corridor fix for repeated same-side lexical children.
- `CHANGELOG.md` — current project changelog.

- PATCH-MANIFEST-v4249-language-tree-nary-terminal-diagonal-clearance.md
- [PATCH-MANIFEST-v4250-language-tree-nary-nominal-lex-order.md](PATCH-MANIFEST-v4250-language-tree-nary-nominal-lex-order.md) — Language Tree n-ary nominal lexical order fix.

- `PATCH-MANIFEST-v4253-role-detection-diagnostics.md` — role detection diagnostics for future FG role-box layout.
- [PATCH-MANIFEST-v4262-ft-role-box-edge-cone-clearance.md](PATCH-MANIFEST-v4262-ft-role-box-edge-cone-clearance.md) — Adds edge-cone clearance for FT down-stack roles.

- `PATCH-MANIFEST-v4292-tree-uitleg-student-lex-projectie.md` — studentgerichte Uitleg voor Simple/Language met traditionele boom, vrije knopen en LEX-projectie.
- `PATCH-MANIFEST-v4298-opengraph-carousel-upload-reminder.md` — OpenGraph-carrousel reminder noemt expliciet: exportzip hier mee uploaden bij het volgende verzoek.

- `PATCH-MANIFEST-v4301-greedy-generate-load-opn.md` — Directe workflow: Greedy `.opn` genereren en meteen laden in OpenGraphEd.
- `PATCH-MANIFEST-v4300-greedy-generator-integration.md` — Fase-1 integratie van Greedy Graph Generator via OpenGraph-menu en `.opn`-brug.
- `PATCH-MANIFEST-v4328-greedy-documentation-unified.md` — Greedy Generator uitleg en documentatie geharmoniseerd rond document-first workflow.
- `PATCH-MANIFEST-v4339-greedy-grow-json-export.md` — Greedy Grow JSON-export voor latere PWA/mobile promo-demo.


## v4344 — Greedy Grow PWA Free Nodes

- PWA-viewer toont standaard vrije knopen.
- Edges/lijnen zijn optioneel via `Lijnen tonen`.
- Actieve knoop is een aparte ring; labels blijven bovenaan.
- NoLimit gebruikt alle JSON-nodes/stappen.

## v4345 — Greedy Grow PWA HOR/VER-vrij

- `PATCH-MANIFEST-v4345-greedy-grow-pwa-horver-free.md` — PWA-correctie voor echte vrije plaatsing: unieke x_line/y_line.
- `projectie-master-spec.md` — bijgewerkt t/m v4345.

- v4346 — `PATCH-MANIFEST-v4346-greedy-grow-pwa-menu-lines.md`: PWA `Lijnen tonen` en menu-uitleg.
