# PATCH-MANIFEST v4346 — Greedy Grow PWA menu/lines

## Type

PWA-viewer fix.

## Samenvatting

`Lijnen tonen` werkt nu ook voor demo's zonder JSON-edges. De viewer genereert dan afgeleide groeilijnen tussen opeenvolgende stappen. Menu-knoppen zijn verduidelijkt: `Fit` → `Passend maken`, `JSON` → `JSON laden`.

## Aangeraakte bestanden

```text
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/styles.css
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/start-local-viewer.bat
mobile/greedy-grow-viewer/README.md
docs/21-greedy-grow-pwa-menu-lines.md
chatlog/CHANGELOG-v4346.md
```

## Test

- `node --check viewer.js` geslaagd.
- JSON-samples blijven aanwezig.
- Lokale testpoort: `8086`.
