
# Documentatie v4334 — opnieuw opgebouwd op basis van nieuwe Sources

Deze maplaag hoort bij `Mapping_V4-26-05-31--v4334-docs-from-new-sources.zip`.

Belangrijkste bronstand:

- v4330: Simple/Language tonen projectie-afbeeldingen vroeg in de uitleg.
- v4331-v4333: Simple-uitleg over vrije plaatsing, projectieruimte links/beneden en correcte tweede afbeelding.
- v4320-v4328: Greedy document-first workflow.
- v4310-v4319: OPN vrije-bronnotatie en gridtag/gridcelregels.
- JGraphEd-bronnen: graph-editor, nodes/edges, modes, graph-fileformaat, operations.
- Taalkundige bronnen: categorieën, herschrijfregels, LF en kritiek op boomdiagram/transformaties/filler-gaps.

Zie `docs/00-overzicht.md` voor startpunt.
