# PATCH MANIFEST v4333 — Simple uitleg: juiste tweede afbeelding

## Doel

Gebruik de door de gebruiker aangeleverde afbeelding als tweede Simple-uitlegplaatje.

## Aangepast

- `help/tree-images/simple-open-space-left-down.png`
- `images/simple-open-space-left-down.png`
- `help/tree-images/simple-free-space-projections.png`
- `images/simple-free-space-projections.png`

De gecombineerde afbeelding toont links de groen/geel-projectieruimte en rechts de aangeleverde vrije bronboom op raster. De uitleg blijft: vrije plaatsing op raster houdt projectieruimte open, voorlopig vooral links en beneden.

## Test

- Java compile: OK
- JAR build: OK
