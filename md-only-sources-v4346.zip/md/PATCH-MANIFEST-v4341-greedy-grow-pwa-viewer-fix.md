# PATCH MANIFEST v4341 — Greedy Grow PWA Viewer Fix

## Type

Bugfix / PWA viewer stabilization.

## Probleem

v4340 kon leeg blijven met:

```text
Cannot read properties of null (reading 'steps')
```

## Oplossing

```text
state.demo null-safe maken
sample-load robuust maken
fallback-demo toevoegen
controls pas activeren na geldige demo
poort 8081 gebruiken voor lokale test
service-worker cache naar v4341
```

## Gewijzigd

```text
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/start-local-viewer.bat
mobile/greedy-grow-viewer/README.md
```

## Toegevoegd

```text
docs/16-greedy-grow-pwa-viewer-fix.md
chatlog/CHANGELOG-v4341.md
md/PATCH-MANIFEST-v4341-greedy-grow-pwa-viewer-fix.md
```

## Test

```text
START-GREEDY-GROW-VIEWER.bat
http://localhost:8081
```
