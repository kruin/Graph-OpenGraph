# PATCH MANIFEST — v4340 Greedy Grow PWA Viewer

## Doel

Mobiele/webviewer toevoegen voor Greedy Grow JSON-exporten.

## Bestanden

```text
mobile/greedy-grow-viewer/
START-GREEDY-GROW-VIEWER.bat
docs/15-greedy-grow-pwa-viewer.md
chatlog/CHANGELOG-v4340.md
```

## Status

Geen Java-codewijziging. Eerste zelfstandige PWA-viewer.
