# Changelog v4342 — Greedy Grow PWA Viewer Settings

## Vraag

Gebruiker meldt:

```text
In de viewer: de knopen zijn veel te groot.
Max7 is wel erg klein.
Maak de max instelbaar, pas de knoopgrootte en gridsize hier op aan.
Zo mogelijk, kopieer de gehele functionaliteit van greedy grow.
```

## Antwoord / wijziging

v4342 past de PWA-viewer aan:

```text
standaarddemo is nu de volledige 31-knoops Greedy Grow sample
max knopen is instelbaar
No limit toont alle knopen/stappen uit JSON
knoopgrootte is instelbaar
grid/celgrootte is instelbaar
grid groeit mee of blijft static/eindgrid
undo/redo per grow-step toegevoegd
Static/all toegevoegd via laatste-stapknop
poort verhoogd naar 8082 wegens service-worker/cache
```

## Bestanden

Aangepast:

```text
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/styles.css
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/README.md
mobile/greedy-grow-viewer/start-local-viewer.bat
START-GREEDY-GROW-VIEWER.bat
projectie-master-spec.md
```

Toegevoegd:

```text
docs/17-greedy-grow-pwa-viewer-settings.md
md/PATCH-MANIFEST-v4342-greedy-grow-pwa-viewer-settings.md
```
