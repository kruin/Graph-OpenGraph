# PATCH MANIFEST — v4335 Greedy Grow Screen

## Doel

Een eigen Greedy-scherm toevoegen dat knopen stap voor stap tekent.

## User request

```text
maak een greedy (eigen scherm) die knoop voor knoop tekent.
User, next on ENTER/CLICK of grow-mode (een knoop per interval, config)
```

## Implementatie

- Nieuw Swing-venster `GreedyGrowthWindow`.
- Handmatige stap: ENTER, SPACE, muisklik, rechterpijl, Next.
- Terug: Vorige, LEFT, BACKSPACE.
- Reset: R.
- Grow-mode: Start grow / G.
- Config: `grow.interval_ms` uit Greedy YAML-spec, standaard 700 ms.
- Read-only: presentatievenster wijzigt de editorgraph niet.

## Gewijzigde bestanden

- `userInterface/GreedyGrowthWindow.java`
- `userInterface/GraphController.java`
- `userInterface/OpenGraphActions.java`
- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
- `tools/greedy_generator_gui/spec.yaml`
- `docs/11-greedy-grow-screen.md`
- `chatlog/CHANGELOG-v4335.md`
