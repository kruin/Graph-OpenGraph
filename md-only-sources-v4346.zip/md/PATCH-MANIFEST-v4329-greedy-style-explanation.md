# PATCH MANIFEST v4329 - Greedy style explanation

## Samenvatting

Deze patch herschrijft de uitleg over de Greedy Generator-styles (`near0`, `maxturn`, `quadrant`, `ring`) in de app-help en documentatie.

## Bestanden inhoudelijk gewijzigd

- `userInterface/GreedyGeneratorSettingsDialog.java`
- `tools/greedy_generator_gui/greedy_generator_gui.py`
- `tools/greedy_generator_gui/README.md`
- `tools/greedy_generator_gui/HANDLEIDING_GUI.md`
- `tools/greedy_generator_gui/GREEDY_GENERATOR_UITLEG_NL.pdf`
- `tools/greedy_generator_gui/GREEDY_GENERATOR_EXPLANATION_EN.pdf`
- `sources/pdf/GREEDY_GENERATOR_UITLEG_NL.pdf`
- `sources/pdf/GREEDY_GENERATOR_EXPLANATION_EN.pdf`
- `projectie-master-spec.md`
- `md/projectie-master-spec.md`
- `chatlog/CHANGELOG-v4329.md`

## Gedrag

Geen wijziging aan de generatorlogica. Alleen uitleg/documentatie is aangepast.

## Kernuitleg

`STYLE` sorteert kandidaatpunten. De eerste kandidaat wordt alleen geplaatst als hij daarna door de harde filters komt.

Huidige styles:

| style | betekenis |
|---|---|
| `near0` | compact rond knoop 0 |
| `maxturn` | grootste draai t.o.v. vorige stap |
| `quadrant` | spreiding over kwadranten |
| `ring` | van binnen naar buiten |

Er zijn nu geen extra styles toegevoegd, om de testmatrix beperkt en de uitleg helder te houden.
