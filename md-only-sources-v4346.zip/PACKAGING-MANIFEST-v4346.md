# PACKAGING-MANIFEST v4346 — Greedy Grow PWA menu/lines

## Package

`Mapping_V4-26-06-03--v4346-greedy-grow-pwa-menu-lines.zip`

## Standalone viewer

`OpenGraph_Greedy_Grow_PWA_v4346.zip`

## Md-only sources

`md-only-sources-v4346.zip`

## Kernwijziging

- PWA-viewer: `Lijnen tonen` werkt ook zonder aanwezige JSON-edges.
- Menu-labels verduidelijkt: `Passend maken`, `JSON laden`.
- Poort: `8086`.
