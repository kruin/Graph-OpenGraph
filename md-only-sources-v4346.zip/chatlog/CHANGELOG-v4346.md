# CHANGELOG v4346 — Greedy Grow PWA lines/menu fix

Datum: 2026-06-03

## Aanleiding

Gebruiker meldde:

- `Lijnen tonen` werkt niet.
- Menu-knoppen `FIT` en `JSON` zijn onduidelijk.

## Wijzigingen

- `Lijnen tonen` toont echte JSON-edges als die aanwezig zijn.
- Als een vrije HOR/VER-demo geen `edges[]` bevat, worden afgeleide groeilijnen tussen opeenvolgende stappen getoond.
- Afgeleide groeilijnen zijn gestippeld en hebben geen invloed op HOR/VER-plaatsing.
- `Fit` hernoemd naar `Passend maken`.
- `JSON` hernoemd naar `JSON laden`.
- Korte uitleg over beide knoppen toegevoegd aan de viewer.
- Service-worker cache verhoogd naar v4346.
- Lokale poort verhoogd naar 8086.

## Bestanden

- `mobile/greedy-grow-viewer/index.html`
- `mobile/greedy-grow-viewer/viewer.js`
- `mobile/greedy-grow-viewer/styles.css`
- `mobile/greedy-grow-viewer/sw.js`
- `mobile/greedy-grow-viewer/start-local-viewer.bat`
- `mobile/greedy-grow-viewer/README.md`
