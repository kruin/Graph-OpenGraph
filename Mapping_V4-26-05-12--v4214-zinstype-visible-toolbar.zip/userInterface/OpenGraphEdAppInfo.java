package userInterface;

public final class OpenGraphEdAppInfo
{
  public static final String APP_NAME = "OpenGraphEd";
  public static final String APP_VERSION = "v4.21.4";
  public static final String HELP_TITLE = APP_NAME + " Help";
  public static final String PREFERENCES_TITLE = APP_NAME + " Preferences";
  public static final String EXIT_TITLE = "Exit " + APP_NAME;

  private OpenGraphEdAppInfo()
  {
  }

  public static String getJarVersion()
  {
    Package pkg = OpenGraphEdAppInfo.class.getPackage();
    String version = pkg == null ? null : pkg.getImplementationVersion();
    if ( version == null || version.trim().length() == 0 )
    {
      return APP_VERSION;
    }
    return version.trim();
  }

  public static String getJarVersionLine()
  {
    return "OpenGraphEd.jar: " + getJarVersion();
  }
}
