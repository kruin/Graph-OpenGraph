package userInterface;

/**
 * Runtime settings for OpenGraph projection rendering.
 *
 * <p>These are kept separate from the grid settings so the layout logic can
 * decide independently whether the fitted grid should cover only the tree,
 * the tree plus projection bands, or the tree plus projection labels.</p>
 */
public class OpenGraphProjectionSettings
{
  private int structureType;
  private boolean showProjections;
  private boolean leftProjectionEnabled;
  private boolean rightProjectionEnabled;
  private boolean topProjectionEnabled;
  private boolean bottomProjectionEnabled;
  private int leftProjectionPosition;
  private int rightProjectionPosition;
  private int topProjectionPosition;
  private int bottomProjectionPosition;
  private String languageTreeZinstype;
  private String languageTreeTopicPreview;

  public static final String ZINSTYPE_BASIS = "basis";
  public static final String ZINSTYPE_BIJZIN = "bijzin";
  public static final String ZINSTYPE_STELLEND = "stellend";
  public static final String ZINSTYPE_JA_NEE = "ja_nee";
  public static final String ZINSTYPE_WH = "wh";
  public static final String ZINSTYPE_TOPICALISATIE = "topicalisatie";

  public OpenGraphProjectionSettings()
  {
    resetToDefaults();
  }

  public OpenGraphProjectionSettings(OpenGraphProjectionSettings other)
  {
    if ( other == null )
    {
      resetToDefaults();
    }
    else
    {
      structureType = other.structureType;
      showProjections = other.showProjections;
      leftProjectionEnabled = other.leftProjectionEnabled;
      rightProjectionEnabled = other.rightProjectionEnabled;
      topProjectionEnabled = other.topProjectionEnabled;
      bottomProjectionEnabled = other.bottomProjectionEnabled;
      leftProjectionPosition = other.leftProjectionPosition;
      rightProjectionPosition = other.rightProjectionPosition;
      topProjectionPosition = other.topProjectionPosition;
      bottomProjectionPosition = other.bottomProjectionPosition;
      languageTreeZinstype = other.languageTreeZinstype;
      languageTreeTopicPreview = other.languageTreeTopicPreview;
      normalize();
    }
  }

  public void resetToDefaults()
  {
    structureType = OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    showProjections = true;
    leftProjectionEnabled = true;
    rightProjectionEnabled = false;
    topProjectionEnabled = false;
    bottomProjectionEnabled = true;
    leftProjectionPosition = 2;
    rightProjectionPosition = 30;
    topProjectionPosition = 0;
    bottomProjectionPosition = 30;
    languageTreeZinstype = ZINSTYPE_BASIS;
    languageTreeTopicPreview = "";
    normalize();
  }

  public OpenGraphProjectionSettings copy()
  {
    return new OpenGraphProjectionSettings(this);
  }

  public void normalize()
  {
    if ( structureType < OpenGraphDialog.STRUCTURE_SIMPLE_TREE ||
         structureType > OpenGraphDialog.STRUCTURE_FRAME )
    {
      structureType = OpenGraphDialog.STRUCTURE_FRAME;
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      showProjections = false;
      leftProjectionEnabled = false;
      rightProjectionEnabled = false;
      topProjectionEnabled = false;
      bottomProjectionEnabled = false;
    }

    languageTreeZinstype = normalizeLanguageTreeZinstype(languageTreeZinstype);
    if ( languageTreeTopicPreview == null )
    {
      languageTreeTopicPreview = "";
    }
    else
    {
      languageTreeTopicPreview = languageTreeTopicPreview.trim();
    }
  }

  public boolean isLexicalProjectionActive()
  {
    return isProjectionCapableStructureType(structureType) && showProjections &&
           (leftProjectionEnabled || rightProjectionEnabled || topProjectionEnabled || bottomProjectionEnabled);
  }

  public static boolean isProjectionCapableStructureType(int structureType)
  {
    return structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
           structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ||
           structureType == OpenGraphDialog.STRUCTURE_FRAME;
  }

  public int getStructureType() { return structureType; }
  public void setStructureType(int structureType) { this.structureType = structureType; normalize(); }

  public boolean getShowProjections() { return showProjections; }
  public void setShowProjections(boolean showProjections) { this.showProjections = showProjections; normalize(); }

  public boolean getLeftProjectionEnabled() { return leftProjectionEnabled; }
  public void setLeftProjectionEnabled(boolean leftProjectionEnabled) { this.leftProjectionEnabled = leftProjectionEnabled; normalize(); }

  public boolean getRightProjectionEnabled() { return rightProjectionEnabled; }
  public void setRightProjectionEnabled(boolean rightProjectionEnabled) { this.rightProjectionEnabled = rightProjectionEnabled; normalize(); }

  public boolean getTopProjectionEnabled() { return topProjectionEnabled; }
  public void setTopProjectionEnabled(boolean topProjectionEnabled) { this.topProjectionEnabled = topProjectionEnabled; normalize(); }

  public boolean getBottomProjectionEnabled() { return bottomProjectionEnabled; }
  public void setBottomProjectionEnabled(boolean bottomProjectionEnabled) { this.bottomProjectionEnabled = bottomProjectionEnabled; normalize(); }

  public int getLeftProjectionPosition() { return leftProjectionPosition; }
  public void setLeftProjectionPosition(int leftProjectionPosition) { this.leftProjectionPosition = leftProjectionPosition; }

  public int getRightProjectionPosition() { return rightProjectionPosition; }
  public void setRightProjectionPosition(int rightProjectionPosition) { this.rightProjectionPosition = rightProjectionPosition; }

  public int getTopProjectionPosition() { return topProjectionPosition; }
  public void setTopProjectionPosition(int topProjectionPosition) { this.topProjectionPosition = topProjectionPosition; }

  public int getBottomProjectionPosition() { return bottomProjectionPosition; }
  public void setBottomProjectionPosition(int bottomProjectionPosition) { this.bottomProjectionPosition = bottomProjectionPosition; }

  public String getLanguageTreeZinstype() { return normalizeLanguageTreeZinstype(languageTreeZinstype); }
  public void setLanguageTreeZinstype(String languageTreeZinstype)
  {
    this.languageTreeZinstype = normalizeLanguageTreeZinstype(languageTreeZinstype);
  }

  public String getLanguageTreeTopicPreview() { return languageTreeTopicPreview == null ? "" : languageTreeTopicPreview.trim(); }
  public void setLanguageTreeTopicPreview(String topicPreview)
  {
    languageTreeTopicPreview = topicPreview == null ? "" : topicPreview.trim();
  }

  public String getLanguageTreeZinstypeDisplayName()
  {
    String zinstype = getLanguageTreeZinstype();
    if ( ZINSTYPE_BIJZIN.equals(zinstype) ) return "Bijzin";
    if ( ZINSTYPE_STELLEND.equals(zinstype) ) return "Stellend";
    if ( ZINSTYPE_JA_NEE.equals(zinstype) ) return "Ja/nee-vraag";
    if ( ZINSTYPE_WH.equals(zinstype) ) return "WH-vraag";
    if ( ZINSTYPE_TOPICALISATIE.equals(zinstype) ) return "Topicalisatie";
    return "Basis";
  }

  public String[] getLanguageTreeZinstypeRulePreviewLines()
  {
    String zinstype = getLanguageTreeZinstype();
    if ( ZINSTYPE_BIJZIN.equals(zinstype) )
    {
      return new String[] { "slot0 = C", "slot1 = leeg", "PV blijft in basispositie" };
    }
    if ( ZINSTYPE_STELLEND.equals(zinstype) )
    {
      return new String[] { "slot1 = topic/subject", "PV = direct na slot1", "rest = DS-volgorde" };
    }
    if ( ZINSTYPE_JA_NEE.equals(zinstype) )
    {
      return new String[] { "slot0 = leeg", "slot1 = leeg", "PV = eerste positie" };
    }
    if ( ZINSTYPE_WH.equals(zinstype) )
    {
      return new String[] { "slot1 = WH", "PV = direct na slot1", "rest = DS-volgorde" };
    }
    if ( ZINSTYPE_TOPICALISATIE.equals(zinstype) )
    {
      String topic = getLanguageTreeTopicPreview();
      if ( topic.length() > 0 )
      {
        return new String[] { "slot1 = " + topic, "PV = direct na slot1", "rest = DS-volgorde zonder topic/PV" };
      }
      return new String[] { "slot1 = geselecteerde categoriale knoop", "LEX-label = gebundelde frase", "PV = direct na slot1" };
    }
    return new String[] { "geen verplaatsing", "LEX-as = DS-basisvolgorde" };
  }

  public static String normalizeLanguageTreeZinstype(String value)
  {
    if ( value == null ) return ZINSTYPE_BASIS;
    String v = value.trim().toLowerCase();
    if ( v.equals("bijzin") ) return ZINSTYPE_BIJZIN;
    if ( v.equals("stellend") || v.equals("hoofdzin") ) return ZINSTYPE_STELLEND;
    if ( v.equals("ja/nee") || v.equals("ja-nee") || v.equals("janee") || v.equals("ja_nee") ) return ZINSTYPE_JA_NEE;
    if ( v.equals("wh") || v.equals("wh-vraag") || v.equals("vraagwoord") ) return ZINSTYPE_WH;
    if ( v.equals("topicalisatie") || v.equals("topic") ) return ZINSTYPE_TOPICALISATIE;
    return ZINSTYPE_BASIS;
  }
}
