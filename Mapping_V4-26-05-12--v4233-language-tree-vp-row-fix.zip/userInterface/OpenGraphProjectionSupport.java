package userInterface;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.util.Collections;
import java.util.Comparator;
import java.util.Properties;
import java.util.Vector;
import graphStructure.Graph;
import graphStructure.Node;
import graphStructure.ProjectionDirection;
import graphStructure.ProjectionLayoutConfig;
import graphStructure.ProjectionLink;
import graphStructure.ProjectionType;

/**
 * Computes and renders the currently implemented OpenGraph projections.
 *
 * <p>The current first slice focuses on a static phrase/frame tree and renders
 * lexical projections on the left and syntactic projections on the right.
 * Bottom logical projections are shown only when the source node already
 * carries an explicit logical label. Projection labels stay outside the
 * visible OpenGraphGrid.</p>
 */
public final class OpenGraphProjectionSupport
{
  private static final int PROJECTION_BAND_CELLS = 1;
  private static final int LABEL_GAP = 6;
  private static final float PROJECTION_LINE_WIDTH = 2.0f;
  private static final int PROJECTION_AXIS_NODE_RADIUS = Node.RADIUS;
  private static final int RIGHT_LABEL_EXTRA_GAP = PROJECTION_AXIS_NODE_RADIUS + 4;
  private static final Color PROJECTION_AXIS_NODE_FILL_COLOR = Color.white;
  private static final Color PROJECTION_AXIS_NODE_BORDER_COLOR = GraphEditor.borderColor.darker();

  private OpenGraphProjectionSupport()
  {
  }

  public static OpenGraphProjectionSettings loadBestAvailable()
  {
    OpenGraphProjectionSettings settings = loadFromPath(OpenGraphGridSettingsIO.USER_SETTINGS_PATH);
    if ( settings != null )
    {
      return settings;
    }
    settings = loadFromPath(OpenGraphGridSettingsIO.DEFAULTS_PATH);
    if ( settings != null )
    {
      return settings;
    }
    return new OpenGraphProjectionSettings();
  }

  public static OpenGraphProjectionSettings loadBestAvailableForStructureType(int structureType)
  {
    OpenGraphProjectionSettings settings = loadFromPathForStructureType(OpenGraphGridSettingsIO.USER_SETTINGS_PATH, structureType);
    if ( settings != null )
    {
      return settings;
    }
    settings = loadFromPathForStructureType(OpenGraphGridSettingsIO.DEFAULTS_PATH, structureType);
    if ( settings != null )
    {
      return settings;
    }

    OpenGraphDialogSettingsState state = OpenGraphDialogSettingsSupport.createDefaultsForType(structureType);
    return fromState(state);
  }

  public static void applyBestAvailableProfileForStructureType(OpenGraphProjectionSettings target, int structureType)
  {
    if ( target == null )
    {
      return;
    }
    OpenGraphProjectionSettings profile = loadBestAvailableForStructureType(structureType);
    copyProjectionProfile(profile, target);
    target.setStructureType(structureType);
    target.normalize();
  }

  public static OpenGraphProjectionSettings fromDialog(OpenGraphDialog dialog)
  {
    OpenGraphProjectionSettings settings = new OpenGraphProjectionSettings();
    if ( dialog == null )
    {
      return settings;
    }

    settings.setStructureType(dialog.getStructureType());
    settings.setShowProjections(dialog.getShowProjections());
    settings.setLeftProjectionEnabled(dialog.getLeftProjectionEnabled());
    settings.setRightProjectionEnabled(dialog.getRightProjectionEnabled());
    settings.setTopProjectionEnabled(dialog.getTopProjectionEnabled());
    settings.setBottomProjectionEnabled(dialog.getBottomProjectionEnabled());
    settings.setLeftProjectionPosition(dialog.getLeftProjectionPosition());
    settings.setRightProjectionPosition(dialog.getRightProjectionPosition());
    settings.setTopProjectionPosition(dialog.getTopProjectionPosition());
    settings.setBottomProjectionPosition(dialog.getBottomProjectionPosition());
    settings.setLeftProjectionCaption(dialog.getLeftProjectionCaption());
    settings.setRightProjectionCaption(dialog.getRightProjectionCaption());
    settings.setTopProjectionCaption(dialog.getTopProjectionCaption());
    settings.setBottomProjectionCaption(dialog.getBottomProjectionCaption());
    settings.setLanguageTreeVerbClusterOrder(dialog.getLanguageTreeVerbClusterOrder());
    settings.normalize();
    return settings;
  }

  public static boolean hasReservedLexicalProjection(OpenGraphProjectionSettings settings)
  {
    return hasProjectionFootprint(settings);
  }

  public static boolean hasRenderableProjectionContext(GraphEditor editor)
  {
    return editor != null && editor.isOpenGraphProjectionContextActive();
  }

  public static boolean syncProjectionModel(GraphEditor editor)
  {
    return ensureProjectionModel(editor, true);
  }

  public static Rectangle2D.Double expandStructureBoundsForProjectionBands(GraphEditor editor,
                                                                           Rectangle2D.Double structureBounds,
                                                                           OpenGraphGridSettings gridSettings)
  {
    return copyBounds(structureBounds);
  }

  public static Rectangle2D.Double expandBoundsForProjectionLabels(GraphEditor editor,
                                                                   Rectangle2D.Double currentBounds)
  {
    return expandBoundsForProjectionLabels(editor, currentBounds, false);
  }

  public static Rectangle2D.Double expandBoundsForReservedProjectionLabels(GraphEditor editor,
                                                                           Rectangle2D.Double currentBounds)
  {
    return expandBoundsForProjectionLabels(editor, currentBounds, true);
  }

  private static Rectangle2D.Double expandBoundsForProjectionLabels(GraphEditor editor,
                                                                    Rectangle2D.Double currentBounds,
                                                                    boolean reserveSpaceEvenWhenHidden)
  {
    Rectangle2D.Double expanded = copyBounds(currentBounds);
    ProjectionGeometry geometry = getProjectionGeometry(editor, reserveSpaceEvenWhenHidden);
    if ( geometry == null )
    {
      return expanded;
    }

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        expanded = union(expanded, labelBounds);
      }
      Rectangle2D.Double lineBounds = item.getLineBounds();
      if ( lineBounds != null )
      {
        expanded = union(expanded, lineBounds);
      }
      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        expanded = union(expanded, markerBounds);
      }
    }
    return expanded;
  }

  public static Rectangle2D.Double expandBoundsForProjectionLabelsForFit(GraphEditor editor,
                                                                         Rectangle2D.Double currentBounds,
                                                                         OpenGraphGridSettings gridSettings)
  {
    Rectangle2D.Double expanded = copyBounds(currentBounds);
    if ( editor == null || currentBounds == null )
    {
      return expanded;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( !hasRenderableProjectionContext(editor) ||
         !hasProjectionFootprint(settings) )
    {
      return expanded;
    }

    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 )
    {
      return expanded;
    }

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    ProjectionGeometry geometry = new ProjectionGeometry(fm);

    int gridMinX = (int)Math.floor(currentBounds.getMinX());
    int gridMaxX = (int)Math.ceil(currentBounds.getMaxX());
    int gridMinY = (int)Math.floor(currentBounds.getMinY());
    int gridMaxY = (int)Math.ceil(currentBounds.getMaxY());

    populateProjectionItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        expanded = union(expanded, labelBounds);
      }
      Rectangle2D.Double lineBounds = item.getLineBounds();
      if ( lineBounds != null )
      {
        expanded = union(expanded, lineBounds);
      }
      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        expanded = union(expanded, markerBounds);
      }
    }

    return expanded;
  }

  public static void draw(Graphics2D g2, GraphEditor editor)
  {
    ProjectionGeometry geometry = getProjectionGeometry(editor, false);
    if ( geometry == null )
    {
      return;
    }

    Stroke oldStroke = g2.getStroke();
    Color oldColor = g2.getColor();
    g2.setStroke(new BasicStroke(PROJECTION_LINE_WIDTH));

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.drawLine )
      {
        g2.setColor(GraphEditor.borderColor.darker());
        g2.drawLine(item.fromX + GraphEditor.DRAW_BUFFER,
                    item.fromY + GraphEditor.DRAW_BUFFER,
                    item.toX + GraphEditor.DRAW_BUFFER,
                    item.toY + GraphEditor.DRAW_BUFFER);
      }
      if ( item.drawMarker )
      {
        int diameter = item.markerRadius * 2;
        int markerX = item.markerX - item.markerRadius + GraphEditor.DRAW_BUFFER;
        int markerY = item.markerY - item.markerRadius + GraphEditor.DRAW_BUFFER;
        g2.setColor(PROJECTION_AXIS_NODE_FILL_COLOR);
        g2.fillOval(markerX, markerY, diameter, diameter);
        g2.setColor(PROJECTION_AXIS_NODE_BORDER_COLOR);
        g2.drawOval(markerX, markerY, diameter, diameter);
      }
      if ( item.text != null && item.text.length() > 0 )
      {
        g2.setColor(Color.black);
        drawProjectionLabel(g2, geometry.fontMetrics, item);
      }
    }

    g2.setStroke(oldStroke);
    g2.setColor(oldColor);
  }


  /**
   * Returns true when a mouse click falls on a virtual language-tree overlay
   * item.  The slots and rule preview are overlay items, not DS graph nodes;
   * consuming these clicks prevents Edit/Grid mode from creating accidental
   * real nodes on slot0/slot1 or on the preview label.
   */
  public static boolean isLanguageTreeVirtualSlotHit(GraphEditor editor, Point screenPoint)
  {
    if ( editor == null || screenPoint == null )
    {
      return false;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( settings == null || settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return false;
    }

    ProjectionGeometry geometry = getProjectionGeometry(editor, false);
    if ( geometry == null )
    {
      return false;
    }

    int x = screenPoint.x - GraphEditor.DRAW_BUFFER;
    int y = screenPoint.y - GraphEditor.DRAW_BUFFER;
    int tolerance = Node.RADIUS + 3;

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item == null || !item.isLanguageTreeOverlayItem() )
      {
        continue;
      }

      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        Rectangle2D.Double expandedMarker = new Rectangle2D.Double(
          markerBounds.getX() - tolerance, markerBounds.getY() - tolerance,
          markerBounds.getWidth() + (2 * tolerance), markerBounds.getHeight() + (2 * tolerance));
        if ( expandedMarker.contains(x, y) )
        {
          return true;
        }
      }

      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        Rectangle2D.Double expandedLabel = new Rectangle2D.Double(
          labelBounds.getX() - tolerance, labelBounds.getY() - tolerance,
          labelBounds.getWidth() + (2 * tolerance), labelBounds.getHeight() + (2 * tolerance));
        if ( expandedLabel.contains(x, y) )
        {
          return true;
        }
      }
    }

    return false;
  }

  private static ProjectionGeometry getProjectionGeometry(GraphEditor editor, boolean reserveSpaceEvenWhenHidden)
  {
    if ( editor == null )
    {
      return null;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( settings == null )
    {
      return null;
    }

    if ( !ensureProjectionModel(editor, reserveSpaceEvenWhenHidden) )
    {
      return null;
    }

    Graph graph = editor.getGraph();

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    ProjectionGeometry geometry = new ProjectionGeometry(fm);

    int gridMinX = graph.getGridDisplayMinX();
    int gridMaxX = graph.getGridDisplayMaxX();
    int gridMinY = graph.getGridDisplayMinY();
    int gridMaxY = graph.getGridDisplayMaxY();

    populateProjectionItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);

    if ( geometry.items.isEmpty() )
    {
      return null;
    }

    return geometry;
  }

  private static boolean ensureProjectionModel(GraphEditor editor, boolean reserveSpaceEvenWhenHidden)
  {
    if ( editor == null )
    {
      return false;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( settings == null )
    {
      return false;
    }

    if ( !hasRenderableProjectionContext(editor) )
    {
      return false;
    }

    if ( reserveSpaceEvenWhenHidden )
    {
      if ( !hasProjectionFootprint(settings) )
      {
        return false;
      }
    }
    else if ( !settings.isLexicalProjectionActive() )
    {
      return false;
    }

    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graph.getDrawGrid() )
    {
      return false;
    }

    applyProjectionSettingsToGraph(graph, settings);
    graph.rebuildProjections();
    return true;
  }

  private static void applyProjectionSettingsToGraph(Graph graph,
                                                   OpenGraphProjectionSettings settings)
  {
    if ( graph == null )
    {
      return;
    }

    ProjectionLayoutConfig config = graph.getProjectionLayoutConfig();
    boolean show = settings != null && settings.getShowProjections();

    config.lex.enabled = show && settings.getLeftProjectionEnabled();
    config.lex.direction = ProjectionDirection.LEFT;

    config.syn.enabled = show && settings.getRightProjectionEnabled();
    config.syn.direction = ProjectionDirection.RIGHT;

    config.log.enabled = show && settings.getBottomProjectionEnabled();
    config.log.direction = ProjectionDirection.DOWN;
    graph.setProjectionLayoutConfig(config);
  }

  private static void populateProjectionItems(ProjectionGeometry geometry,
                                             Graph graph,
                                             OpenGraphProjectionSettings settings,
                                             int gridMinX,
                                             int gridMinY,
                                             int gridMaxX,
                                             int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null )
    {
      return;
    }

    addProjectionItemsFromGraphModel(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addLanguageTreeSlotItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addLanguageTreePlacementItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addLanguageTreeTypeCaptionItem(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addLanguageTreeZinstypePreviewItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addProjectionItemsForSide(geometry, graph, settings, SIDE_TOP, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addProjectionItemsForSide(geometry, graph, settings, SIDE_BOTTOM, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addSideCaptionItems(geometry, geometry.fontMetrics, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
  }

  private static void addProjectionItemsFromGraphModel(ProjectionGeometry geometry,
                                                     Graph graph,
                                                     OpenGraphProjectionSettings settings,
                                                     int gridMinX,
                                                     int gridMinY,
                                                     int gridMaxX,
                                                     int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null )
    {
      return;
    }

    Vector links = graph.getProjectionLinks();
    for ( int i=0; i<links.size(); i++ )
    {
      ProjectionLink link = (ProjectionLink)links.elementAt(i);
      if ( link == null || link.sourceNode == null || link.projectionNode == null )
      {
        continue;
      }

      int side = sideForProjectionType(link.projectionType);
      if ( !isSideEnabled(settings, side) )
      {
        continue;
      }

      int nodeX = link.sourceNode.getLocation().intX();
      int nodeY = link.sourceNode.getLocation().intY();
      int axisX = link.projectionNode.getLocation().intX();
      int axisY = link.projectionNode.getLocation().intY();

      geometry.items.addElement(ProjectionItem.createLineWithAxisNode(side, nodeX, nodeY, axisX, axisY));

      String projectionLabel = link.projectedLabel == null ? "" : trimmedLabel(link.projectedLabel.text);
      if ( projectionLabel.length() > 0 &&
           !isLanguageTreeMovedBaseProjectionLabel(graph, settings, side, link.sourceNode, projectionLabel) )
      {
        addNodeProjectionLabel(geometry, geometry.fontMetrics, side, projectionLabel, axisX, axisY, gridMinX, gridMinY, gridMaxX, gridMaxY);
      }
    }
  }


  private static boolean isLanguageTreeMovedBaseProjectionLabel(Graph graph,
                                                               OpenGraphProjectionSettings settings,
                                                               int side,
                                                               Node sourceNode,
                                                               String projectionLabel)
  {
    if ( graph == null || settings == null || sourceNode == null || side != SIDE_LEFT )
    {
      return false;
    }
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
         !settings.getShowProjections() ||
         !settings.getLeftProjectionEnabled() )
    {
      return false;
    }

    Node top = findTopStructureNode(graph);
    if ( top == null )
    {
      return false;
    }

    String zinstype = settings.getLanguageTreeZinstype();
    if ( suppressFiniteVerbOnBaseAxis(zinstype) )
    {
      Node finite = finiteVerbTerminalNode(top);
      String finiteLabel = finiteVerbTerminalLabel(top);
      if ( finite != null && isSameNode(sourceNode, finite) )
      {
        return true;
      }
      if ( projectionLabelMatches(projectionLabel, finiteLabel) &&
           projectionLabelMatches(trimmedLabel(sourceNode.getLabel()), finiteLabel) )
      {
        return true;
      }
    }

    Node movedCategory = null;
    if ( OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) )
    {
      movedCategory = defaultTopicNode(top);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) )
    {
      movedCategory = findPhraseNodeByPreview(top, settings.getLanguageTreeTopicPreview());
    }

    if ( movedCategory != null && isNodeOrDescendant(movedCategory, sourceNode, new Vector()) )
    {
      return true;
    }

    return false;
  }

  private static boolean suppressFiniteVerbOnBaseAxis(String zinstype)
  {
    return OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) ||
           OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) ||
           OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype) ||
           OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype);
  }

  private static boolean projectionLabelMatches(String a, String b)
  {
    String x = trimmedLabel(a);
    String y = trimmedLabel(b);
    if ( x.length() == 0 || y.length() == 0 )
    {
      return false;
    }
    return x.equals(y);
  }

  private static boolean isSameNode(Node a, Node b)
  {
    return a == b;
  }

  private static Node defaultTopicNode(Node top)
  {
    Vector children = getChildrenBelowSortedLeftToRight(top);
    if ( children == null || children.size() == 0 )
    {
      return null;
    }
    Node candidate = (Node)children.elementAt(0);
    String label = trimmedLabel(candidate.getLabel());
    if ( label.length() == 0 || !isLikelyCategoryLabel(label) )
    {
      return null;
    }
    return candidate;
  }

  private static Node findPhraseNodeByPreview(Node top, String preview)
  {
    String target = normalizePreviewPhrase(preview);
    if ( top == null || target.length() == 0 )
    {
      return null;
    }
    if ( target.equals("selecteer categoriale knoop") ||
         target.equals("meerdere selectie") ||
         target.equals("topic") )
    {
      return null;
    }
    return findPhraseNodeByPreview(top, target, new Vector());
  }

  private static Node findPhraseNodeByPreview(Node node, String target, Vector visited)
  {
    if ( node == null || target == null || visited == null || visited.contains(node) )
    {
      return null;
    }
    visited.addElement(node);
    String label = trimmedLabel(node.getLabel());
    if ( isLikelyCategoryLabel(label) )
    {
      String phrase = normalizePreviewPhrase(phraseLabel(node));
      if ( phrase.equals(target) )
      {
        return node;
      }
    }
    Vector children = getChildrenBelowSortedLeftToRight(node);
    for ( int i=0; i<children.size(); i++ )
    {
      Node found = findPhraseNodeByPreview((Node)children.elementAt(i), target, visited);
      if ( found != null )
      {
        return found;
      }
    }
    return null;
  }

  private static String normalizePreviewPhrase(String value)
  {
    String s = trimmedLabel(value);
    if ( s.length() == 0 )
    {
      return "";
    }
    while ( s.startsWith("(") && s.endsWith(")") && s.length() > 1 )
    {
      s = s.substring(1, s.length() - 1).trim();
    }
    return s;
  }

  private static boolean isNodeOrDescendant(Node ancestor, Node node, Vector visited)
  {
    if ( ancestor == null || node == null || visited == null || visited.contains(ancestor) )
    {
      return false;
    }
    if ( ancestor == node )
    {
      return true;
    }
    visited.addElement(ancestor);
    Vector children = getChildrenBelowSortedLeftToRight(ancestor);
    for ( int i=0; i<children.size(); i++ )
    {
      if ( isNodeOrDescendant((Node)children.elementAt(i), node, visited) )
      {
        return true;
      }
    }
    return false;
  }

  private static int sideForProjectionType(ProjectionType type)
  {
    if ( type == ProjectionType.LEX )
    {
      return SIDE_LEFT;
    }
    if ( type == ProjectionType.SYN )
    {
      return SIDE_RIGHT;
    }
    if ( type == ProjectionType.LOG )
    {
      return SIDE_BOTTOM;
    }
    return SIDE_TOP;
  }

  private static void addLanguageTreeSlotItems(ProjectionGeometry geometry,
                                               Graph graph,
                                               OpenGraphProjectionSettings settings,
                                               int gridMinX,
                                               int gridMinY,
                                               int gridMaxX,
                                               int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null )
    {
      return;
    }
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
         !settings.getShowProjections() ||
         !settings.getLeftProjectionEnabled() )
    {
      return;
    }

    Node top = findTopStructureNode(graph);
    if ( top == null )
    {
      return;
    }

    int axisX = gridMinX;
    int topY = top.getLocation().intY();
    int rowHeight = Math.max(2, graph.getGridRowHeight());
    int slot0Y = topY - rowHeight;
    int slot1Y = topY;

    String slot0Label = languageTreeSlot0Label(settings);
    String slot1Label = languageTreeSlot1Label(top, settings);

    if ( slot0Y >= gridMinY )
    {
      addLanguageTreeSlotItem(geometry, geometry.fontMetrics, slot0Label, axisX, slot0Y, gridMinX);
    }
    addLanguageTreeSlotItem(geometry, geometry.fontMetrics, slot1Label, axisX, slot1Y, gridMinX);

    String finLabel = languageTreeFinLabel(top, settings);
    if ( finLabel.length() > 0 )
    {
      addLanguageTreeSlotItem(geometry, geometry.fontMetrics, finLabel, axisX,
                              languageTreeFinAxisY(slot1Y, rowHeight), gridMinX);
    }
  }

  private static void addLanguageTreePlacementItems(ProjectionGeometry geometry,
                                                    Graph graph,
                                                    OpenGraphProjectionSettings settings,
                                                    int gridMinX,
                                                    int gridMinY,
                                                    int gridMaxX,
                                                    int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null || geometry.fontMetrics == null )
    {
      return;
    }
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
         !settings.getShowProjections() ||
         !settings.getLeftProjectionEnabled() )
    {
      return;
    }

    Node top = findTopStructureNode(graph);
    if ( top == null )
    {
      return;
    }

    FontMetrics fm = geometry.fontMetrics;
    int axisX = gridMinX;
    int topY = top.getLocation().intY();
    int rowHeight = Math.max(2, graph.getGridRowHeight());
    int slot0Y = topY - rowHeight;
    int slot1Y = topY;
    int labelX = axisX + LABEL_GAP + (PROJECTION_AXIS_NODE_RADIUS * 2);

    String zinstype = settings.getLanguageTreeZinstype();
    if ( OpenGraphProjectionSettings.ZINSTYPE_BIJZIN.equals(zinstype) )
    {
      addLanguageTreePlacementLabel(geometry, fm, "pv blijft basis", labelX,
                                    languageTreeFinAxisY(slot1Y, rowHeight));
      return;
    }

    if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) )
    {
      return;
    }
  }


  private static int languageTreeFinAxisY(int slot1Y, int rowHeight)
  {
    /*
     * FIN is an ordered surface-axis position on the lexical axis.  In Dutch
     * Language Tree mode the first DS root branching is now drawn one grid row
     * longer, so FIN can occupy a normal full grid row below slot1 without
     * colliding with the first NP/VP child row under S.
     */
    return slot1Y + Math.max(2, rowHeight);
  }

  private static String languageTreeSlot0Label(OpenGraphProjectionSettings settings)
  {
    if ( settings == null )
    {
      return "slot0";
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_BIJZIN.equals(settings.getLanguageTreeZinstype()) )
    {
      return "(om)dat";
    }
    return "slot0";
  }

  private static String languageTreeSlot1Label(Node top, OpenGraphProjectionSettings settings)
  {
    if ( settings == null )
    {
      return "slot1";
    }
    String zinstype = settings.getLanguageTreeZinstype();
    if ( OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) )
    {
      return lexicalDisplay(defaultTopicPhrase(top));
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) )
    {
      return finiteVerbTerminalLabel(top);
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype) )
    {
      return "WH";
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) )
    {
      String topic = settings.getLanguageTreeTopicPreview();
      if ( topic == null || topic.trim().length() == 0 )
      {
        return "topic";
      }
      return lexicalDisplay(topic);
    }
    return "slot1";
  }

  private static String languageTreeFinLabel(Node top, OpenGraphProjectionSettings settings)
  {
    if ( settings == null )
    {
      return "";
    }
    String zinstype = settings.getLanguageTreeZinstype();
    boolean needsFiniteOnSurfaceAxis =
      OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) ||
      OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) ||
      OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype);

    if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) )
    {
      // In ja/nee questions the finite verb is first visible material; it is
      // shown in the slot1 row by languageTreeSlot1Label, not on a V2 row.
      return "";
    }
    if ( !needsFiniteOnSurfaceAxis )
    {
      return "";
    }
    return finiteVerbTerminalLabel(top);
  }

  private static Node finiteVerbTerminalNode(Node top)
  {
    Node pv = findFirstNodeByLabel(top, "PV", new Vector());
    if ( pv != null )
    {
      Node terminal = firstLexicalTerminalNodeUnder(pv);
      if ( terminal != null ) return terminal;
    }

    Node fin = findFirstNodeByLabel(top, "FIN", new Vector());
    if ( fin != null )
    {
      Node terminal = firstLexicalTerminalNodeUnder(fin);
      if ( terminal != null ) return terminal;
    }

    Node v = findFirstNodeByLabel(top, "V", new Vector());
    if ( v != null )
    {
      Vector children = getChildrenBelowSortedLeftToRight(v);
      for ( int i=0; i<children.size(); i++ )
      {
        Node child = (Node)children.elementAt(i);
        String label = trimmedLabel(child.getLabel());
        if ( label.length() > 0 && !isLikelyCategoryLabel(label) )
        {
          return child;
        }
        Node terminal = firstLexicalTerminalNodeUnder(child);
        if ( terminal != null ) return terminal;
      }
    }
    return null;
  }

  private static Node firstLexicalTerminalNodeUnder(Node node)
  {
    if ( node == null ) return null;
    Vector leaves = new Vector();
    collectTerminalNodes(node, null, leaves, new Vector());
    sortNodesByPosition(leaves);
    for ( int i=0; i<leaves.size(); i++ )
    {
      Node leaf = (Node)leaves.elementAt(i);
      String label = trimmedLabel(leaf.getLabel());
      if ( label.length() > 0 && !isLikelyCategoryLabel(label) )
      {
        return leaf;
      }
    }
    String own = trimmedLabel(node.getLabel());
    return isLikelyCategoryLabel(own) || own.length() == 0 ? null : node;
  }

  private static String finiteVerbTerminalLabel(Node top)
  {
    Node pv = findFirstNodeByLabel(top, "PV", new Vector());
    if ( pv != null )
    {
      String terminal = firstLexicalTerminalUnder(pv);
      if ( terminal.length() > 0 ) return terminal;
    }

    Node fin = findFirstNodeByLabel(top, "FIN", new Vector());
    if ( fin != null )
    {
      String terminal = firstLexicalTerminalUnder(fin);
      if ( terminal.length() > 0 ) return terminal;
    }

    Node v = findFirstNodeByLabel(top, "V", new Vector());
    if ( v != null )
    {
      Vector children = getChildrenBelowSortedLeftToRight(v);
      for ( int i=0; i<children.size(); i++ )
      {
        Node child = (Node)children.elementAt(i);
        String label = trimmedLabel(child.getLabel());
        if ( label.length() > 0 && !isLikelyCategoryLabel(label) )
        {
          return label;
        }
        String terminal = firstLexicalTerminalUnder(child);
        if ( terminal.length() > 0 ) return terminal;
      }
    }

    return "pv";
  }

  private static Node findFirstNodeByLabel(Node node, String label, Vector visited)
  {
    if ( node == null || label == null || visited == null || visited.contains(node) )
    {
      return null;
    }
    visited.addElement(node);
    String nodeLabel = trimmedLabel(node.getLabel());
    if ( nodeLabel.equalsIgnoreCase(label) )
    {
      return node;
    }
    Vector children = getChildrenBelowSortedLeftToRight(node);
    for ( int i=0; i<children.size(); i++ )
    {
      Node found = findFirstNodeByLabel((Node)children.elementAt(i), label, visited);
      if ( found != null ) return found;
    }
    return null;
  }

  private static String firstLexicalTerminalUnder(Node node)
  {
    if ( node == null ) return "";
    Vector leaves = new Vector();
    collectTerminalNodes(node, null, leaves, new Vector());
    sortNodesByPosition(leaves);
    for ( int i=0; i<leaves.size(); i++ )
    {
      Node leaf = (Node)leaves.elementAt(i);
      String label = trimmedLabel(leaf.getLabel());
      if ( label.length() > 0 && !isLikelyCategoryLabel(label) )
      {
        return label;
      }
    }
    String own = trimmedLabel(node.getLabel());
    return isLikelyCategoryLabel(own) ? "" : own;
  }

  private static String lexicalDisplay(String phrase)
  {
    String value = trimmedLabel(phrase);
    if ( value.length() == 0 )
    {
      return value;
    }
    int open = value.indexOf('(');
    int close = value.lastIndexOf(')');
    if ( open >= 0 && close > open )
    {
      String inside = value.substring(open + 1, close).trim();
      if ( inside.length() > 0 )
      {
        value = inside;
      }
    }
    if ( value.indexOf(' ') >= 0 )
    {
      return "(" + value + ")";
    }
    return value;
  }

  private static void addLanguageTreePlacementLabel(ProjectionGeometry geometry, FontMetrics fm,
                                                    String text, int labelX, int axisY)
  {
    if ( geometry == null || fm == null || text == null || text.length() == 0 )
    {
      return;
    }
    int baselineY = axisY + (fm.getAscent() / 2);
    geometry.items.addElement(ProjectionItem.createLanguageTreeSlotLabel(text, labelX, baselineY));
  }

  private static String defaultTopicPhrase(Node top)
  {
    Vector children = getChildrenBelowSortedLeftToRight(top);
    if ( children == null || children.size() == 0 )
    {
      String label = trimmedLabel(top == null ? null : top.getLabel());
      return label.length() == 0 ? "topic/subject" : label;
    }
    return phraseLabel((Node)children.elementAt(0));
  }

  private static String phraseLabel(Node node)
  {
    if ( node == null )
    {
      return "";
    }
    String category = trimmedLabel(node.getLabel());
    Vector leaves = new Vector();
    collectTerminalNodes(node, null, leaves, new Vector());
    sortNodesByPosition(leaves);

    StringBuffer lexical = new StringBuffer();
    for ( int i=0; i<leaves.size(); i++ )
    {
      Node leaf = (Node)leaves.elementAt(i);
      String label = trimmedLabel(leaf.getLabel());
      if ( label.length() == 0 || isLikelyCategoryLabel(label) )
      {
        continue;
      }
      if ( lexical.length() > 0 )
      {
        lexical.append(' ');
      }
      lexical.append(label);
    }

    if ( lexical.length() > 0 && category.length() > 0 )
    {
      return category + "(" + lexical.toString() + ")";
    }
    if ( lexical.length() > 0 )
    {
      return lexical.toString();
    }
    return category.length() == 0 ? "topic/subject" : category;
  }

  private static void collectTerminalNodes(Node node, Node parent, Vector leaves, Vector visited)
  {
    if ( node == null || visited.contains(node) )
    {
      return;
    }
    visited.addElement(node);
    Vector children = new Vector();
    Vector neighbours = node.neighbours();
    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour != parent && neighbour.getLocation().intY() > nodeY )
      {
        children.addElement(neighbour);
      }
    }
    if ( children.size() == 0 )
    {
      leaves.addElement(node);
      return;
    }
    sortNodesByPosition(children);
    for ( int i=0; i<children.size(); i++ )
    {
      collectTerminalNodes((Node)children.elementAt(i), node, leaves, visited);
    }
  }

  private static boolean isLikelyCategoryLabel(String label)
  {
    if ( label == null ) return false;
    String v = label.trim();
    if ( v.length() == 0 ) return false;
    if ( v.equals("S") || v.equals("CP") || v.equals("VP") || v.equals("DP") ||
         v.equals("NP") || v.equals("PP") || v.equals("AP") || v.equals("V") ||
         v.equals("N") || v.equals("A") || v.equals("P") || v.equals("Det") ||
         v.equals("Comp") || v.equals("PV") || v.equals("VD") )
    {
      return true;
    }
    return v.toUpperCase().equals(v) && v.length() <= 6;
  }

  private static Node findTopStructureNode(Graph graph)
  {
    if ( graph == null )
    {
      return null;
    }

    Vector nodes = graph.getNodes();
    Node best = null;

    /*
     * Prefer real structure roots over accidental nodes that may have been
     * created by clicking on virtual slot markers in older builds.  A
     * language-tree root normally has at least one child below it (S, CP, V,
     * etc.).  Only fall back to any topmost node for degenerate one-node tests.
     */
    for ( int pass=0; pass<2; pass++ )
    {
      best = null;
      for ( int i=0; i<nodes.size(); i++ )
      {
        Node node = (Node)nodes.elementAt(i);
        if ( node == null )
        {
          continue;
        }
        if ( pass == 0 && !isLikelyLanguageTreeTop(node) )
        {
          continue;
        }
        if ( best == null ||
             node.getLocation().intY() < best.getLocation().intY() ||
             (node.getLocation().intY() == best.getLocation().intY() &&
              node.getLocation().intX() < best.getLocation().intX()) )
        {
          best = node;
        }
      }
      if ( best != null )
      {
        return best;
      }
    }
    return null;
  }

  private static boolean isLikelyLanguageTreeTop(Node node)
  {
    if ( node == null )
    {
      return false;
    }
    if ( countChildrenBelow(node) > 0 )
    {
      return true;
    }

    String label = trimmedLabel(node.getLabel()).toUpperCase();
    return label.equals("S") || label.equals("CP") || label.equals("VP") ||
           label.equals("V") || label.equals("DS");
  }

  private static void addLanguageTreeSlotItem(ProjectionGeometry geometry,
                                              FontMetrics fm,
                                              String label,
                                              int axisX,
                                              int axisY,
                                              int gridMinX)
  {
    if ( geometry == null || fm == null || label == null || label.length() == 0 )
    {
      return;
    }

    geometry.items.addElement(ProjectionItem.createLanguageTreeSlotMarker(axisX, axisY));

    int labelX = gridMinX - LABEL_GAP - fm.stringWidth(label);
    int baselineY = axisY + (fm.getAscent() / 2);
    geometry.items.addElement(ProjectionItem.createLanguageTreeSlotLabel(label, labelX, baselineY));
  }

  private static void addLanguageTreeTypeCaptionItem(ProjectionGeometry geometry,
                                                    Graph graph,
                                                    OpenGraphProjectionSettings settings,
                                                    int gridMinX,
                                                    int gridMinY,
                                                    int gridMaxX,
                                                    int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null || geometry.fontMetrics == null )
    {
      return;
    }
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
         !settings.getShowProjections() )
    {
      return;
    }

    FontMetrics fm = geometry.fontMetrics;
    String text = "LANGUAGE TREE";
    int labelX = gridMinX + LABEL_GAP;
    int baselineY = gridMinY - LABEL_GAP - fm.getHeight();
    if ( baselineY < fm.getAscent() )
    {
      baselineY = fm.getAscent();
    }
    geometry.items.addElement(ProjectionItem.createLanguageTreeCaption(text, labelX, baselineY));
  }


  private static void addLanguageTreeZinstypePreviewItems(ProjectionGeometry geometry,
                                                          Graph graph,
                                                          OpenGraphProjectionSettings settings,
                                                          int gridMinX,
                                                          int gridMinY,
                                                          int gridMaxX,
                                                          int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null || geometry.fontMetrics == null )
    {
      return;
    }
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
         !settings.getShowProjections() ||
         !settings.getLeftProjectionEnabled() )
    {
      return;
    }

    Node top = findTopStructureNode(graph);
    if ( top == null )
    {
      return;
    }

    FontMetrics fm = geometry.fontMetrics;
    int labelX = gridMinX + LABEL_GAP;
    int baselineY = gridMinY - LABEL_GAP;
    if ( baselineY < fm.getAscent() + fm.getHeight() )
    {
      baselineY = fm.getAscent() + fm.getHeight();
    }

    String header = "Zinstype: " + settings.getLanguageTreeZinstypeDisplayName() +
                    " | V-cluster: " + settings.getLanguageTreeVerbClusterDisplayName();
    String topic = settings.getLanguageTreeTopicPreview();
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) &&
         topic.length() > 0 )
    {
      header = header + " — " + topic;
    }
    geometry.items.addElement(ProjectionItem.createLanguageTreeCaption(header, labelX, baselineY));
    /*
     * Detailed rule preview is intentionally not drawn over the tree.  The
     * zinstype buttons expose the full rule preview as hover tooltip; this
     * compact overlay only shows the active profile.
     */
  }

  private static void addProjectionItemsForSide(ProjectionGeometry geometry,
                                                Graph graph,
                                                OpenGraphProjectionSettings settings,
                                                int side,
                                                int gridMinX,
                                                int gridMinY,
                                                int gridMaxX,
                                                int gridMaxY)
  {
    if ( !isSideEnabled(settings, side) )
    {
      return;
    }
    if ( side == SIDE_LEFT || side == SIDE_RIGHT )
    {
      return;
    }

    Vector sourceNodes = getProjectionSourceNodes(graph, side);
    for ( int i=0; i<sourceNodes.size(); i++ )
    {
      Node sourceNode = (Node)sourceNodes.elementAt(i);
      int nodeX = sourceNode.getLocation().intX();
      int nodeY = sourceNode.getLocation().intY();
      int axisX = nodeX;
      int axisY = nodeY;

      if ( side == SIDE_LEFT )
      {
        axisX = gridMinX;
      }
      else if ( side == SIDE_RIGHT )
      {
        axisX = gridMaxX;
      }
      else if ( side == SIDE_TOP )
      {
        axisY = gridMinY;
      }
      else if ( side == SIDE_BOTTOM )
      {
        axisY = gridMaxY;
      }

      geometry.items.addElement(ProjectionItem.createLineWithAxisNode(side, nodeX, nodeY, axisX, axisY));

      String projectionLabel = getProjectedLabelForSide(sourceNode, side);
      if ( projectionLabel.length() > 0 )
      {
        addNodeProjectionLabel(geometry, geometry.fontMetrics, side, projectionLabel, axisX, axisY, gridMinX, gridMinY, gridMaxX, gridMaxY);
      }
    }
  }

  private static boolean isSideEnabled(OpenGraphProjectionSettings settings, int side)
  {
    if ( settings == null )
    {
      return false;
    }
    if ( side == SIDE_LEFT )
    {
      return settings.getLeftProjectionEnabled();
    }
    if ( side == SIDE_RIGHT )
    {
      return settings.getRightProjectionEnabled();
    }
    if ( side == SIDE_TOP )
    {
      return settings.getTopProjectionEnabled();
    }
    if ( side == SIDE_BOTTOM )
    {
      return settings.getBottomProjectionEnabled();
    }
    return false;
  }

  private static void addSideCaptionItems(ProjectionGeometry geometry,
                                          FontMetrics fm,
                                          OpenGraphProjectionSettings settings,
                                          int gridMinX,
                                          int gridMinY,
                                          int gridMaxX,
                                          int gridMaxY)
  {
    if ( geometry == null || fm == null || settings == null )
    {
      return;
    }

    int centerY = gridMinY + ((gridMaxY - gridMinY) / 2);
    int centerX = gridMinX + ((gridMaxX - gridMinX) / 2);

    if ( settings.getLeftProjectionEnabled() )
    {
      addLeftVerticalCaptionItem(geometry, fm, settings.getLeftProjectionCaption(), gridMinX, centerY);
    }
    if ( settings.getRightProjectionEnabled() )
    {
      addRightVerticalCaptionItem(geometry, fm, settings.getRightProjectionCaption(), gridMaxX, centerY);
    }
    if ( settings.getTopProjectionEnabled() )
    {
      addVerticalCaptionItem(geometry, fm, SIDE_TOP, settings.getTopProjectionCaption(), centerX, gridMinY, LABEL_ORIENTATION_UP);
    }
    if ( settings.getBottomProjectionEnabled() )
    {
      addBottomHorizontalCaptionItem(geometry, fm, settings.getBottomProjectionCaption(), centerX, gridMaxY);
    }
  }

  private static boolean hasProjectionSourcesForSide(ProjectionGeometry geometry, int side)
  {
    if ( geometry == null )
    {
      return false;
    }
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side == side && (item.drawLine || item.drawMarker) )
      {
        return true;
      }
    }
    return false;
  }

  private static void addLeftVerticalCaptionItem(ProjectionGeometry geometry,
                                               FontMetrics fm,
                                               String text,
                                               int gridMinX,
                                               int centerY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelColumnX = getSideLabelMinX(geometry, fm, SIDE_LEFT);
    int maxCharWidth = getMaxCharWidth(fm, text);
    int labelX = Math.min(gridMinX - LABEL_GAP - maxCharWidth, labelColumnX - LABEL_GAP - maxCharWidth);
    int baselineY = centerY - (((text.length() - 1) * fm.getHeight()) / 2) + fm.getAscent();
    geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_LEFT, text, labelX, baselineY, LABEL_ORIENTATION_DOWN));
  }

  private static void addRightVerticalCaptionItem(ProjectionGeometry geometry,
                                                FontMetrics fm,
                                                String text,
                                                int gridMaxX,
                                                int centerY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelColumnX = getRightSideVerticalLabelX(geometry, fm, gridMaxX);
    int baselineY = centerY - (((text.length() - 1) * fm.getHeight()) / 2) + fm.getAscent();
    geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_RIGHT, text, labelColumnX, baselineY, LABEL_ORIENTATION_DOWN));
  }

  private static void addBottomHorizontalCaptionItem(ProjectionGeometry geometry,
                                                     FontMetrics fm,
                                                     String text,
                                                     int centerX,
                                                     int gridMaxY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelWidth = fm.stringWidth(text);
    int labelX = centerX - (labelWidth / 2);
    int labelTopY = getSideLabelMaxY(geometry, fm, SIDE_BOTTOM) + LABEL_GAP;
    int baselineY = Math.max(gridMaxY + LABEL_GAP + fm.getAscent(), labelTopY + fm.getAscent());
    geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_BOTTOM, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
  }

  private static void addHorizontalCaptionItem(ProjectionGeometry geometry,
                                               FontMetrics fm,
                                               int side,
                                               String text,
                                               int gridEdgeX,
                                               int centerY,
                                               boolean left)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelWidth = fm.stringWidth(text);
    int labelX = left ? gridEdgeX - LABEL_GAP - labelWidth : gridEdgeX + LABEL_GAP;
    int baselineY = centerY + (fm.getAscent() / 2);
    geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
  }

  private static void addVerticalCaptionItem(ProjectionGeometry geometry,
                                             FontMetrics fm,
                                             int side,
                                             String text,
                                             int centerX,
                                             int gridEdgeY,
                                             int orientation)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int maxCharWidth = getMaxCharWidth(fm, text);
    int labelX = centerX - (maxCharWidth / 2);
    int baselineY = (orientation == LABEL_ORIENTATION_DOWN)
                    ? gridEdgeY + LABEL_GAP + fm.getAscent()
                    : gridEdgeY - LABEL_GAP - ((text.length() - 1) * fm.getHeight());
    geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, orientation));
  }

  private static void addNodeProjectionLabel(ProjectionGeometry geometry,
                                             FontMetrics fm,
                                             int side,
                                             String text,
                                             int axisX,
                                             int axisY,
                                             int gridMinX,
                                             int gridMinY,
                                             int gridMaxX,
                                             int gridMaxY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    if ( side == SIDE_LEFT )
    {
      int labelX = gridMinX - LABEL_GAP - fm.stringWidth(text);
      int baselineY = axisY + (fm.getAscent() / 2);
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
    }
    else if ( side == SIDE_RIGHT )
    {
      int labelX = axisX + LABEL_GAP + RIGHT_LABEL_EXTRA_GAP;
      int baselineY = axisY + (fm.getAscent() / 2);
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
    }
    else if ( side == SIDE_TOP )
    {
      int labelX = axisX - (getMaxCharWidth(fm, text) / 2);
      int baselineY = gridMinY - LABEL_GAP - ((text.length() - 1) * fm.getHeight());
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_UP));
    }
    else if ( side == SIDE_BOTTOM )
    {
      int labelX = axisX - (getMaxCharWidth(fm, text) / 2);
      int baselineY = gridMaxY + LABEL_GAP + fm.getAscent();
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_DOWN));
    }
  }

  private static Vector getProjectionSourceNodes(Graph graph, int side)
  {
    if ( side == SIDE_LEFT )
    {
      return getLeafNodes(graph);
    }
    if ( side == SIDE_RIGHT )
    {
      return getBranchingNodes(graph, false);
    }
    if ( side == SIDE_TOP )
    {
      return getRootNodes(graph);
    }
    if ( side == SIDE_BOTTOM )
    {
      return getBranchingNodes(graph, true);
    }
    return new Vector();
  }

  private static Vector getRootNodes(Graph graph)
  {
    Vector roots = new Vector();
    if ( graph == null )
    {
      return roots;
    }

    Vector nodes = graph.getNodes();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node == null )
      {
        continue;
      }
      Vector neighbours = node.neighbours();
      int nodeY = node.getLocation().intY();
      boolean hasParentAbove = false;
      for ( int j=0; j<neighbours.size(); j++ )
      {
        Node neighbour = (Node)neighbours.elementAt(j);
        if ( neighbour.getLocation().intY() < nodeY )
        {
          hasParentAbove = true;
          break;
        }
      }
      if ( !hasParentAbove )
      {
        roots.addElement(node);
      }
    }

    sortNodesByPosition(roots);
    return roots;
  }

  private static Vector getLeafNodes(Graph graph)
  {
    Vector leaves = new Vector();
    Vector nodes = graph.getNodes();

    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( isLeafNode(node) )
      {
        leaves.addElement(node);
      }
    }

    sortNodesByPosition(leaves);
    return leaves;
  }

  private static Vector getBranchingNodes(Graph graph, boolean requireExplicitLogicalLabel)
  {
    Vector branching = new Vector();
    if ( graph == null )
    {
      return branching;
    }

    Vector nodes = graph.getNodes();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( isBranchingNode(node) &&
           (!requireExplicitLogicalLabel || hasExplicitLogicalProjectionLabel(node)) )
      {
        branching.addElement(node);
      }
    }

    sortNodesByPosition(branching);
    return branching;
  }

  private static void sortNodesByPosition(Vector nodes)
  {
    Collections.sort(nodes, new Comparator()
    {
      public int compare(Object leftObj, Object rightObj)
      {
        Node left = (Node)leftObj;
        Node right = (Node)rightObj;
        int xCompare = left.getLocation().intX() - right.getLocation().intX();
        if ( xCompare != 0 )
        {
          return xCompare;
        }
        return left.getLocation().intY() - right.getLocation().intY();
      }
    });
  }

  private static boolean isLeafNode(Node node)
  {
    if ( node == null )
    {
      return false;
    }

    Vector neighbours = node.neighbours();
    if ( neighbours.isEmpty() )
    {
      return true;
    }

    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        return false;
      }
    }
    return true;
  }

  private static boolean isBranchingNode(Node node)
  {
    if ( node == null )
    {
      return false;
    }
    return countChildrenBelow(node) >= 2;
  }


  private static String getProjectedLabelForSide(Node sourceNode, int side)
  {
    if ( sourceNode == null )
    {
      return "";
    }
    if ( side == SIDE_RIGHT )
    {
      return formatSynProjectionLabel(sourceNode);
    }
    if ( side == SIDE_TOP )
    {
      return "";
    }
    return trimmedLabel(sourceNode.getLabel());
  }

  private static String formatSynProjectionLabel(Node sourceNode)
  {
    Vector children = getChildrenBelowSortedLeftToRight(sourceNode);
    if ( children.isEmpty() )
    {
      return "";
    }

    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<children.size(); i++ )
    {
      Node child = (Node)children.elementAt(i);
      String label = trimmedLabel(child.getLabel());
      if ( label.length() == 0 )
      {
        continue;
      }
      if ( buffer.length() > 0 )
      {
        buffer.append(", ");
      }
      buffer.append(label);
    }
    return buffer.toString();
  }

  private static Vector getChildrenBelowSortedLeftToRight(Node node)
  {
    Vector children = new Vector();
    if ( node == null )
    {
      return children;
    }

    Vector neighbours = node.neighbours();
    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        children.addElement(neighbour);
      }
    }

    sortNodesByPosition(children);
    return children;
  }

  private static boolean hasExplicitLogicalProjectionLabel(Node node)
  {
    String label = trimmedLabel(node == null ? null : node.getLabel());
    if ( label.length() == 0 )
    {
      return false;
    }

    String upper = label.toUpperCase();
    return upper.equals("S") ||
           upper.equals("O") ||
           upper.equals("V") ||
           upper.equals("SUBJECT") ||
           upper.equals("OBJECT") ||
           upper.equals("VERB") ||
           upper.equals("LF") ||
           upper.equals("LOG");
  }

  private static int countChildrenBelow(Node node)
  {
    Vector neighbours = node.neighbours();
    int count = 0;
    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        count++;
      }
    }
    return count;
  }

  private static int getRightSideVerticalLabelX(ProjectionGeometry geometry, FontMetrics fm, int gridMaxX)
  {
    int markerExtentX = getSideMarkerMaxX(geometry, SIDE_RIGHT);
    int labelExtentX = getSideLabelMaxX(geometry, fm, SIDE_RIGHT);
    int baseX = Math.max(gridMaxX, markerExtentX);
    int candidateX = baseX + PROJECTION_AXIS_NODE_RADIUS + LABEL_GAP + RIGHT_LABEL_EXTRA_GAP;
    if ( labelExtentX != Integer.MIN_VALUE )
    {
      candidateX = Math.max(candidateX, labelExtentX + LABEL_GAP);
    }
    return candidateX;
  }

  private static int getSideMarkerMaxX(ProjectionGeometry geometry, int side)
  {
    if ( geometry == null )
    {
      return Integer.MIN_VALUE;
    }

    int maxX = Integer.MIN_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side || !item.drawMarker )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getMarkerBounds();
      if ( bounds != null )
      {
        maxX = Math.max(maxX, (int)Math.ceil(bounds.getMaxX()));
      }
    }
    return maxX == Integer.MIN_VALUE ? Integer.MIN_VALUE : maxX;
  }


  private static int getSideLabelMaxX(ProjectionGeometry geometry, FontMetrics fm, int side)
  {
    if ( geometry == null || fm == null )
    {
      return Integer.MIN_VALUE;
    }

    int maxX = Integer.MIN_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getLabelBounds(fm);
      if ( bounds != null )
      {
        maxX = Math.max(maxX, (int)Math.ceil(bounds.getMaxX()));
      }
    }
    return maxX;
  }

  private static int getSideLabelMinX(ProjectionGeometry geometry, FontMetrics fm, int side)
  {
    if ( geometry == null || fm == null )
    {
      return Integer.MAX_VALUE;
    }

    int minX = Integer.MAX_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getLabelBounds(fm);
      if ( bounds != null )
      {
        minX = Math.min(minX, (int)Math.floor(bounds.getMinX()));
      }
    }
    return minX;
  }

  private static int getSideLabelMaxY(ProjectionGeometry geometry, FontMetrics fm, int side)
  {
    if ( geometry == null || fm == null )
    {
      return Integer.MIN_VALUE;
    }

    int maxY = Integer.MIN_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getLabelBounds(fm);
      if ( bounds != null )
      {
        maxY = Math.max(maxY, (int)Math.ceil(bounds.getMaxY()));
      }
    }
    return maxY;
  }

  private static String trimmedLabel(String text)
  {
    if ( text == null )
    {
      return "";
    }
    return text.trim();
  }

  private static int getMaxCharWidth(FontMetrics fm, String text)
  {
    int width = 1;
    if ( fm == null || text == null )
    {
      return width;
    }
    for ( int i=0; i<text.length(); i++ )
    {
      width = Math.max(width, fm.charWidth(text.charAt(i)));
    }
    return width;
  }

  private static int safeCellWidth(OpenGraphGridSettings gridSettings, Graph graph)
  {
    if ( gridSettings != null )
    {
      return Math.max(2, gridSettings.getCellWidth());
    }
    if ( graph != null )
    {
      return Math.max(2, graph.getGridColWidth());
    }
    return 20;
  }

  private static int safeCellHeight(OpenGraphGridSettings gridSettings, Graph graph)
  {
    if ( gridSettings != null )
    {
      return Math.max(2, gridSettings.getCellHeight());
    }
    if ( graph != null )
    {
      return Math.max(2, graph.getGridRowHeight());
    }
    return 20;
  }

  private static boolean hasProjectionFootprint(OpenGraphProjectionSettings settings)
  {
    return settings != null &&
           OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) &&
           (settings.getLeftProjectionEnabled() ||
            settings.getRightProjectionEnabled() ||
            settings.getTopProjectionEnabled() ||
            settings.getBottomProjectionEnabled());
  }

  private static OpenGraphProjectionSettings loadFromPathForStructureType(String path, int structureType)
  {
    try
    {
      Properties props = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( props == null )
      {
        return null;
      }
      props.setProperty("structure.type", String.valueOf(structureType));
      OpenGraphDialogSettingsState state = OpenGraphDialogSettingsSupport.fromProperties(props);
      OpenGraphDialogSettingsSupport.applyPostLoadRules(state);
      state.structureType = structureType;
      OpenGraphProjectionSettings settings = fromState(state);
      if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
      {
        String prefix = "projection.profile." + OpenGraphDialogSettingsSupport.projectionProfileName(structureType) + ".";
        String order = props.getProperty(prefix + "verbcluster.order", props.getProperty("language.verbcluster.order", "pv_vd"));
        settings.setLanguageTreeVerbClusterOrder(order);
      }
      return settings;
    }
    catch (Exception e)
    {
      return null;
    }
  }

  private static OpenGraphProjectionSettings fromState(OpenGraphDialogSettingsState state)
  {
    OpenGraphProjectionSettings settings = new OpenGraphProjectionSettings();
    if ( state == null )
    {
      return settings;
    }
    settings.setStructureType(state.structureType);
    settings.setShowProjections(state.showProjections);
    settings.setLeftProjectionEnabled(state.leftProjectionEnabled);
    settings.setRightProjectionEnabled(state.rightProjectionEnabled);
    settings.setTopProjectionEnabled(state.topProjectionEnabled);
    settings.setBottomProjectionEnabled(state.bottomProjectionEnabled);
    settings.setLeftProjectionPosition(state.leftProjectionPosition);
    settings.setRightProjectionPosition(state.rightProjectionPosition);
    settings.setTopProjectionPosition(state.topProjectionPosition);
    settings.setBottomProjectionPosition(state.bottomProjectionPosition);
    settings.setLeftProjectionCaption(state.leftProjectionCaption);
    settings.setRightProjectionCaption(state.rightProjectionCaption);
    settings.setTopProjectionCaption(state.topProjectionCaption);
    settings.setBottomProjectionCaption(state.bottomProjectionCaption);
    settings.normalize();
    return settings;
  }

  private static void copyProjectionProfile(OpenGraphProjectionSettings source, OpenGraphProjectionSettings target)
  {
    if ( source == null || target == null )
    {
      return;
    }
    target.setShowProjections(source.getShowProjections());
    target.setLeftProjectionEnabled(source.getLeftProjectionEnabled());
    target.setRightProjectionEnabled(source.getRightProjectionEnabled());
    target.setTopProjectionEnabled(source.getTopProjectionEnabled());
    target.setBottomProjectionEnabled(source.getBottomProjectionEnabled());
    target.setLeftProjectionPosition(source.getLeftProjectionPosition());
    target.setRightProjectionPosition(source.getRightProjectionPosition());
    target.setTopProjectionPosition(source.getTopProjectionPosition());
    target.setBottomProjectionPosition(source.getBottomProjectionPosition());
    target.setLeftProjectionCaption(source.getLeftProjectionCaption());
    target.setRightProjectionCaption(source.getRightProjectionCaption());
    target.setTopProjectionCaption(source.getTopProjectionCaption());
    target.setBottomProjectionCaption(source.getBottomProjectionCaption());
    target.setLanguageTreeVerbClusterOrder(source.getLanguageTreeVerbClusterOrder());
  }

  private static OpenGraphProjectionSettings loadFromPath(String path)
  {
    try
    {
      Properties props = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( props == null )
      {
        return null;
      }
      OpenGraphDialogSettingsState state = OpenGraphDialogSettingsSupport.fromProperties(props);
      OpenGraphDialogSettingsSupport.applyPostLoadRules(state);
      OpenGraphProjectionSettings settings = new OpenGraphProjectionSettings();
      settings.setStructureType(state.structureType);
      settings.setShowProjections(state.showProjections);
      settings.setLeftProjectionEnabled(state.leftProjectionEnabled);
      settings.setRightProjectionEnabled(state.rightProjectionEnabled);
      settings.setTopProjectionEnabled(state.topProjectionEnabled);
      settings.setBottomProjectionEnabled(state.bottomProjectionEnabled);
      settings.setLeftProjectionPosition(state.leftProjectionPosition);
      settings.setRightProjectionPosition(state.rightProjectionPosition);
      settings.setTopProjectionPosition(state.topProjectionPosition);
      settings.setBottomProjectionPosition(state.bottomProjectionPosition);
      settings.setLeftProjectionCaption(state.leftProjectionCaption);
      settings.setRightProjectionCaption(state.rightProjectionCaption);
      settings.setTopProjectionCaption(state.topProjectionCaption);
      settings.setBottomProjectionCaption(state.bottomProjectionCaption);
      settings.normalize();
      return settings;
    }
    catch (Exception e)
    {
      return null;
    }
  }

  private static Rectangle2D.Double copyBounds(Rectangle2D.Double bounds)
  {
    if ( bounds == null )
    {
      return new Rectangle2D.Double();
    }
    return new Rectangle2D.Double(bounds.getX(), bounds.getY(), bounds.getWidth(), bounds.getHeight());
  }

  private static Rectangle2D.Double createBounds(double minX, double minY, double maxX, double maxY)
  {
    return new Rectangle2D.Double(minX, minY, Math.max(0, maxX - minX), Math.max(0, maxY - minY));
  }

  private static Rectangle2D.Double union(Rectangle2D.Double base, Rectangle2D.Double addition)
  {
    if ( base == null )
    {
      return copyBounds(addition);
    }
    if ( addition == null )
    {
      return copyBounds(base);
    }
    Rectangle2D rect = base.createUnion(addition);
    return new Rectangle2D.Double(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
  }

  private static void drawProjectionLabel(Graphics2D g2, FontMetrics fm, ProjectionItem item)
  {
    if ( g2 == null || fm == null || item == null || item.text == null || item.text.length() == 0 )
    {
      return;
    }

    if ( item.labelOrientation == LABEL_ORIENTATION_HORIZONTAL )
    {
      g2.drawString(item.text,
                    item.labelX + GraphEditor.DRAW_BUFFER,
                    item.labelBaselineY + GraphEditor.DRAW_BUFFER);
      return;
    }

    int x = item.labelX + GraphEditor.DRAW_BUFFER;
    if ( item.labelOrientation == LABEL_ORIENTATION_DOWN )
    {
      for ( int i=0; i<item.text.length(); i++ )
      {
        String glyph = String.valueOf(item.text.charAt(i));
        int baselineY = item.labelBaselineY + (i * fm.getHeight()) + GraphEditor.DRAW_BUFFER;
        g2.drawString(glyph, x, baselineY);
      }
    }
    else if ( item.labelOrientation == LABEL_ORIENTATION_UP )
    {
      for ( int i=0; i<item.text.length(); i++ )
      {
        String glyph = String.valueOf(item.text.charAt(i));
        int baselineY = item.labelBaselineY + ((item.text.length() - 1 - i) * fm.getHeight()) + GraphEditor.DRAW_BUFFER;
        g2.drawString(glyph, x, baselineY);
      }
    }
  }

  private static final class ProjectionGeometry
  {
    private final FontMetrics fontMetrics;
    private final Vector items = new Vector();

    private ProjectionGeometry(FontMetrics fontMetrics)
    {
      this.fontMetrics = fontMetrics;
    }
  }

  private static final int SIDE_LEFT = 1;
  private static final int SIDE_RIGHT = 2;
  private static final int SIDE_TOP = 3;
  private static final int SIDE_BOTTOM = 4;

  private static final int LABEL_ORIENTATION_HORIZONTAL = 0;
  private static final int LABEL_ORIENTATION_DOWN = 1;
  private static final int LABEL_ORIENTATION_UP = 2;

  private static final int ITEM_KIND_NORMAL = 0;
  private static final int ITEM_KIND_LANGUAGE_TREE_SLOT = 1;
  private static final int ITEM_KIND_LANGUAGE_TREE_CAPTION = 2;

  private static final class ProjectionItem
  {
    private final int side;
    private final int fromX;
    private final int fromY;
    private final int toX;
    private final int toY;
    private final boolean drawLine;
    private final boolean drawMarker;
    private final int markerX;
    private final int markerY;
    private final int markerRadius;
    private final String text;
    private final int labelX;
    private int labelBaselineY;
    private final int labelOrientation;
    private final int itemKind;

    private ProjectionItem(int side, int fromX, int fromY, int toX, int toY,
                           boolean drawLine, boolean drawMarker, int markerX, int markerY, int markerRadius,
                           String text, int labelX, int labelBaselineY, int labelOrientation)
    {
      this(side, fromX, fromY, toX, toY, drawLine, drawMarker, markerX, markerY, markerRadius,
           text, labelX, labelBaselineY, labelOrientation, ITEM_KIND_NORMAL);
    }

    private ProjectionItem(int side, int fromX, int fromY, int toX, int toY,
                           boolean drawLine, boolean drawMarker, int markerX, int markerY, int markerRadius,
                           String text, int labelX, int labelBaselineY, int labelOrientation, int itemKind)
    {
      this.side = side;
      this.fromX = fromX;
      this.fromY = fromY;
      this.toX = toX;
      this.toY = toY;
      this.drawLine = drawLine;
      this.drawMarker = drawMarker;
      this.markerX = markerX;
      this.markerY = markerY;
      this.markerRadius = markerRadius;
      this.text = text;
      this.labelX = labelX;
      this.labelBaselineY = labelBaselineY;
      this.labelOrientation = labelOrientation;
      this.itemKind = itemKind;
    }

    private static ProjectionItem createLineOnly(int side, int fromX, int fromY, int toX, int toY)
    {
      return new ProjectionItem(side, fromX, fromY, toX, toY, true, false, 0, 0, 0, null, 0, 0, LABEL_ORIENTATION_HORIZONTAL);
    }

    private static ProjectionItem createLineWithAxisNode(int side, int fromX, int fromY, int toX, int toY)
    {
      return new ProjectionItem(side, fromX, fromY, toX, toY, true, true, toX, toY,
                                PROJECTION_AXIS_NODE_RADIUS, null, 0, 0, LABEL_ORIENTATION_HORIZONTAL);
    }

    private static ProjectionItem createMarkerOnly(int side, int markerX, int markerY)
    {
      return new ProjectionItem(side, 0, 0, 0, 0, false, true, markerX, markerY,
                                PROJECTION_AXIS_NODE_RADIUS, null, 0, 0, LABEL_ORIENTATION_HORIZONTAL);
    }

    private static ProjectionItem createLanguageTreeSlotMarker(int markerX, int markerY)
    {
      return new ProjectionItem(SIDE_LEFT, 0, 0, 0, 0, false, true, markerX, markerY,
                                PROJECTION_AXIS_NODE_RADIUS, null, 0, 0, LABEL_ORIENTATION_HORIZONTAL,
                                ITEM_KIND_LANGUAGE_TREE_SLOT);
    }

    private static ProjectionItem createLanguageTreeSlotLabel(String text, int labelX, int labelBaselineY)
    {
      return new ProjectionItem(SIDE_LEFT, 0, 0, 0, 0, false, false, 0, 0, 0,
                                text, labelX, labelBaselineY, LABEL_ORIENTATION_HORIZONTAL,
                                ITEM_KIND_LANGUAGE_TREE_SLOT);
    }

    private static ProjectionItem createLanguageTreeCaption(String text, int labelX, int labelBaselineY)
    {
      return new ProjectionItem(SIDE_TOP, 0, 0, 0, 0, false, false, 0, 0, 0,
                                text, labelX, labelBaselineY, LABEL_ORIENTATION_HORIZONTAL,
                                ITEM_KIND_LANGUAGE_TREE_CAPTION);
    }

    private static ProjectionItem createLabelOnly(int side, String text, int labelX, int labelBaselineY, int labelOrientation)
    {
      return new ProjectionItem(side, 0, 0, 0, 0, false, false, 0, 0, 0, text, labelX, labelBaselineY, labelOrientation);
    }

    private boolean isLanguageTreeSlotItem()
    {
      return itemKind == ITEM_KIND_LANGUAGE_TREE_SLOT;
    }

    private boolean isLanguageTreeOverlayItem()
    {
      return itemKind == ITEM_KIND_LANGUAGE_TREE_SLOT ||
             itemKind == ITEM_KIND_LANGUAGE_TREE_CAPTION;
    }

    private Rectangle2D.Double getLineBounds()
    {
      if ( !drawLine )
      {
        return null;
      }
      int minX = Math.min(fromX, toX);
      int maxX = Math.max(fromX, toX);
      int minY = Math.min(fromY, toY);
      int maxY = Math.max(fromY, toY);
      return new Rectangle2D.Double(minX, minY, Math.max(1, maxX - minX), Math.max(1, maxY - minY));
    }

    private Rectangle2D.Double getMarkerBounds()
    {
      if ( !drawMarker || markerRadius <= 0 )
      {
        return null;
      }
      int diameter = markerRadius * 2;
      return new Rectangle2D.Double(markerX - markerRadius, markerY - markerRadius, diameter, diameter);
    }

    private Rectangle2D.Double getLabelBounds(FontMetrics fm)
    {
      if ( text == null || text.length() == 0 || fm == null )
      {
        return null;
      }
      int width;
      int height;
      if ( labelOrientation == LABEL_ORIENTATION_HORIZONTAL )
      {
        width = Math.max(1, fm.stringWidth(text));
        height = Math.max(1, fm.getHeight());
        int y = labelBaselineY - fm.getAscent();
        return new Rectangle2D.Double(labelX, y, width, height);
      }

      width = Math.max(1, getMaxCharWidth(fm, text));
      height = Math.max(1, text.length() * fm.getHeight());
      int y = labelBaselineY - fm.getAscent();
      return new Rectangle2D.Double(labelX, y, width, height);
    }
  }
}
