@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem Direct launcher generated for OpenGraphEd v4.21.4.
rem No wrapper calls. No recursion. No %TEMP%. No PowerShell.

set "JAVA_CMD="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_CMD=%JAVA_HOME%\bin\java.exe"
if not defined JAVA_CMD set "JAVA_CMD=java.exe"

if exist "%~dp0out\OpenGraphEdFrame.class" (
  "%JAVA_CMD%" -cp "%~dp0out" OpenGraphEdFrame %*
  exit /b %errorlevel%
)

if exist "%~dp0dist\OpenGraphEd.jar" (
  "%JAVA_CMD%" -jar "%~dp0dist\OpenGraphEd.jar" %*
  exit /b %errorlevel%
)

if exist "%~dp0OpenGraphEd.jar" (
  "%JAVA_CMD%" -jar "%~dp0OpenGraphEd.jar" %*
  exit /b %errorlevel%
)

echo No compiled classes or jar found. Run build.bat first.
exit /b 1
