package tools;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import graphStructure.*;
import userInterface.GraphFileActions;

public class LanguageTreeRegressionChecker
{
  public static void main(String[] args)
  {
    File root = new File(args.length > 0 ? args[0] : ".");
    File dir = new File(root, "examples/opn/language-tree-v420");
    File expected = new File(dir, "EXPECTED.txt");
    int pass = 0, fail = 0;
    System.out.println("Mapping V4.20.1 Language Tree OPN regression checker");
    System.out.println("Root: " + root.getAbsolutePath());
    System.out.println();
    try
    {
      List rows = readExpected(expected);
      for ( int i=0; i<rows.size(); i++ )
      {
        ExpectedRow row = (ExpectedRow)rows.get(i);
        CheckResult result = checkOne(new File(dir, row.fileName), row);
        if ( result.passed ) pass++; else fail++;
        System.out.println((result.passed ? "  PASS " : "  FAIL ") + row.fileName);
        for ( int m=0; m<result.messages.size(); m++ ) System.out.println("       " + result.messages.get(m));
      }
      System.out.println();
      System.out.println("summary: " + pass + " pass, " + fail + " fail");
      if ( fail > 0 ) System.exit(1);
    }
    catch ( Exception ex )
    {
      System.out.println("FAIL checker error: " + ex.getClass().getName() + (ex.getMessage() == null ? "" : ": " + ex.getMessage()));
      ex.printStackTrace(System.out);
      System.exit(2);
    }
  }

  private static CheckResult checkOne(File opnFile, ExpectedRow expected) throws Exception
  {
    CheckResult result = new CheckResult();
    Graph graph = loadOPN(opnFile);
    graph.rebuildProjections();
    int lex = 0, syn = 0;
    Vector links = graph.getProjectionLinks();
    for ( int i=0; i<links.size(); i++ )
    {
      ProjectionLink link = (ProjectionLink)links.elementAt(i);
      if ( link.projectionType == ProjectionType.LEX ) lex++;
      if ( link.projectionType == ProjectionType.SYN ) syn++;
    }
    expect(result, expected.nodes, graph.getNumNodes(), "node count");
    expect(result, expected.edges, graph.getNumEdges(), "edge count");
    expect(result, expected.lex, lex, "LEX projection count");
    expect(result, expected.syn, syn, "SYN projection count");
    checkAllNodesOnOpenGraphGrid(result, graph);
    checkUniqueHorizontalRows(result, graph);
    checkAllNodesInsideOpenGraphGrid(result, graph);
    if ( !graph.isOPNLanguageTreePreferred() ) result.messages.add("OPN language tree projection preference was not set");
    String summary = graph.getOPNMappingV1Summary();
    if ( expected.generated.length() > 0 && (summary == null || summary.indexOf(expected.generated) < 0) )
    {
      result.messages.add("generated output missing; expected: " + expected.generated + "; actual summary: " + summary);
    }
    result.passed = result.messages.isEmpty();
    return result;
  }

  private static Graph loadOPN(File file) throws Exception
  {
    GraphFileActions actions = new GraphFileActions();
    Method method = GraphFileActions.class.getDeclaredMethod("loadOPNFileAsGraph", new Class[] { File.class });
    method.setAccessible(true);
    try { return (Graph)method.invoke(actions, new Object[] { file }); }
    catch ( InvocationTargetException ite )
    {
      Throwable cause = ite.getCause();
      if ( cause instanceof Exception ) throw (Exception)cause;
      throw ite;
    }
  }

  private static void checkAllNodesOnOpenGraphGrid(CheckResult result, Graph graph)
  {
    for ( int i=0; i<graph.getNumNodes(); i++ )
    {
      Node node = graph.getNodeAt(i);
      if ( !graph.isOnGrid(node.getLocation()) )
      {
        result.messages.add("node is not on OpenGraphGrid: " + printableNode(node));
      }
    }
  }

  private static void checkUniqueHorizontalRows(CheckResult result, Graph graph)
  {
    Map yToNode = new LinkedHashMap();
    for ( int i=0; i<graph.getNumNodes(); i++ )
    {
      Node node = graph.getNodeAt(i);
      String key = String.valueOf(node.getY());
      Node existing = (Node)yToNode.get(key);
      if ( existing != null )
      {
        result.messages.add("multiple source nodes on same horizontal grid row: " +
          printableNode(existing) + " and " + printableNode(node));
      }
      else
      {
        yToNode.put(key, node);
      }
    }
  }

  private static void checkAllNodesInsideOpenGraphGrid(CheckResult result, Graph graph)
  {
    int minX = graph.getGridDisplayMinX();
    int minY = graph.getGridDisplayMinY();
    int maxX = graph.getGridDisplayMaxX();
    int maxY = graph.getGridDisplayMaxY();
    for ( int i=0; i<graph.getNumNodes(); i++ )
    {
      Node node = graph.getNodeAt(i);
      if ( node.getX() < minX || node.getX() > maxX ||
           node.getY() < minY || node.getY() > maxY )
      {
        result.messages.add("node outside OpenGraphGrid display window: " + printableNode(node));
      }
    }
  }

  private static String printableNode(Node node)
  {
    if ( node == null ) return "<null>";
    String label = node.getLabel();
    if ( label == null || label.trim().length() == 0 ) label = "<unlabeled>";
    return label.trim() + "@" + node.getX() + "," + node.getY();
  }

  private static void expect(CheckResult result, int expected, int actual, String label)
  {
    if ( expected != actual ) result.messages.add(label + " mismatch; expected " + expected + ", actual " + actual);
  }

  private static List readExpected(File expected) throws IOException
  {
    List rows = new ArrayList();
    BufferedReader reader = new BufferedReader(new FileReader(expected));
    try
    {
      String line;
      while ( (line = reader.readLine()) != null )
      {
        line = line.trim();
        if ( line.length() == 0 || line.startsWith("#") ) continue;
        String[] parts = line.split("\\|", 6);
        if ( parts.length < 6 ) throw new IOException("Invalid EXPECTED row: " + line);
        ExpectedRow row = new ExpectedRow();
        row.fileName = parts[0].trim();
        row.nodes = parseInt(parts[1]);
        row.edges = parseInt(parts[2]);
        row.lex = parseInt(parts[3]);
        row.syn = parseInt(parts[4]);
        row.generated = parts[5].trim();
        rows.add(row);
      }
    }
    finally { reader.close(); }
    return rows;
  }

  private static int parseInt(String value) throws IOException
  {
    try { return Integer.parseInt(value.trim()); }
    catch ( NumberFormatException nfe ) { throw new IOException("Expected integer, got: " + value); }
  }

  private static final class ExpectedRow { String fileName; int nodes; int edges; int lex; int syn; String generated; }
  private static final class CheckResult { boolean passed; List messages = new ArrayList(); }
}
