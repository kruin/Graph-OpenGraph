package tools;

import java.io.*;
import java.util.*;

/** Mapping V3 regression checker for the OpenGraphEd example manifests. */
public class MappingV4RegressionChecker
{
  private static final int MAX_MESSAGES = 4;

  public static void main(String[] args)
  {
    File root = new File(args.length > 0 ? args[0] : ".");
    int pass = 0;
    int fail = 0;
    System.out.println("Mapping V4.16 morphology metadata validator regression checker");
    System.out.println("Root: " + root.getAbsolutePath());
    System.out.println();
    try
    {
      int[] totals;
      totals = checkExpectedSet("V3 core valid", new File(root, "examples/opn/mapping-v3-core"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V3 core invalid", new File(root, "examples/opn/mapping-v3-core-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.1 NEG/TIME/PLACE valid", new File(root, "examples/opn/mapping-v4-neg-time-place"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.1 NEG/TIME/PLACE invalid", new File(root, "examples/opn/mapping-v4-neg-time-place-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.3 WH valid", new File(root, "examples/opn/mapping-v4-wh"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.3 WH invalid", new File(root, "examples/opn/mapping-v4-wh-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.5 DET valid", new File(root, "examples/opn/mapping-v4-det"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.5 DET invalid", new File(root, "examples/opn/mapping-v4-det-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.9 FRAME.graph slot validation valid", new File(root, "examples/opn/mapping-v4-frame"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.9 FRAME.graph slot validation invalid", new File(root, "examples/opn/mapping-v4-frame-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.12 lexicon validation valid", new File(root, "examples/opn/mapping-v4-lexicon"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.12 lexicon validation invalid", new File(root, "examples/opn/mapping-v4-lexicon-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.16 morphology validation valid", new File(root, "examples/opn/mapping-v4-morphology"), "EXPECTED.txt", true); pass += totals[0]; fail += totals[1];
      totals = checkExpectedSet("V4.16 morphology validation invalid", new File(root, "examples/opn/mapping-v4-morphology-invalid"), "EXPECTED-FAIL.txt", false); pass += totals[0]; fail += totals[1];
      System.out.println();
      System.out.println("summary: " + pass + " pass, " + fail + " fail");
      if ( fail > 0 ) System.exit(1);
    }
    catch ( Exception ex )
    {
      System.out.println("FAIL checker error: " + ex.getClass().getName() +
                         (ex.getMessage() == null ? "" : ": " + ex.getMessage()));
      ex.printStackTrace(System.out);
      System.exit(2);
    }
  }

  private static int[] checkExpectedSet(String label, File dir, String expectedFile, boolean valid) throws IOException
  {
    int pass = 0;
    int fail = 0;
    System.out.println(label + ":");
    if ( valid )
    {
      List expectedRows = readValidExpected(new File(dir, expectedFile));
      for ( int i=0; i<expectedRows.size(); i++ )
      {
        ExpectedValid expected = (ExpectedValid)expectedRows.get(i);
        CheckResult result = checkValid(new File(dir, expected.fileName), expected);
        if ( result.passed ) pass++; else fail++;
        printResult(result);
      }
    }
    else
    {
      List expectedRows = readInvalidExpected(new File(dir, expectedFile));
      for ( int i=0; i<expectedRows.size(); i++ )
      {
        ExpectedInvalid expected = (ExpectedInvalid)expectedRows.get(i);
        CheckResult result = checkInvalid(new File(dir, expected.fileName), expected);
        if ( result.passed ) pass++; else fail++;
        printResult(result);
      }
    }
    System.out.println();
    return new int[] { pass, fail };
  }

  private static void printResult(CheckResult result)
  {
    System.out.println((result.passed ? "  PASS " : "  FAIL ") + result.fileName);
    if ( !result.passed )
    {
      for ( int i=0; i<result.messages.size(); i++ ) System.out.println("       " + result.messages.get(i));
      if ( result.actualMapping != null ) System.out.println("       actual mapping: " + result.actualMapping);
      if ( result.actualValidation != null ) System.out.println("       actual validation: " + result.actualValidation);
      if ( result.actualGenerated != null ) System.out.println("       actual generated: " + result.actualGenerated);
      if ( result.actualFrameGraph != null ) System.out.println("       actual frame graph: " + result.actualFrameGraph);
      if ( result.actualLexicon != null ) System.out.println("       actual lexicon: " + result.actualLexicon);
    }
  }

  private static CheckResult checkValid(File opnFile, ExpectedValid expected) throws IOException
  {
    MappingSummary actual = analyzeOPN(opnFile);
    CheckResult result = new CheckResult(expected.fileName);
    result.actualMapping = actual.mappingLine;
    result.actualValidation = actual.validationLine;
    result.actualGenerated = actual.generatedLine;
    result.actualFrameGraph = actual.frameGraphLine;
    result.actualLexicon = actual.lexiconLine;
    expectEquals(result, "mapping", expected.mappingLine, actual.mappingLine);
    expectEquals(result, "validation", expected.validationLine, actual.validationLine);
    expectEquals(result, "generated", expected.generatedLine, actual.generatedLine);
    expectEquals(result, "frame graph", expected.frameGraphLine, actual.frameGraphLine);
    expectEquals(result, "lexicon", expected.lexiconLine, actual.lexiconLine);
    result.finish();
    return result;
  }

  private static CheckResult checkInvalid(File opnFile, ExpectedInvalid expected) throws IOException
  {
    MappingSummary actual = analyzeOPN(opnFile);
    CheckResult result = new CheckResult(expected.fileName);
    result.actualMapping = actual.mappingLine;
    result.actualValidation = actual.validationLine;
    result.actualGenerated = actual.generatedLine;
    result.actualFrameGraph = actual.frameGraphLine;
    result.actualLexicon = actual.lexiconLine;
    if ( !actual.validationLine.startsWith(expected.validationStartsWith) ) result.messages.add("validation does not start with expected prefix: " + expected.validationStartsWith);
    for ( int i=0; i<expected.detailContains.size(); i++ )
    {
      String needle = (String)expected.detailContains.get(i);
      if ( !containsNormalized(actual.validationLine, needle) ) result.messages.add("validation details missing: " + needle);
    }
    expectEquals(result, "generated", expected.generatedLine, actual.generatedLine);
    if ( expected.frameGraphLine != null && expected.frameGraphLine.length() > 0 )
    {
      expectEquals(result, "frame graph", expected.frameGraphLine, actual.frameGraphLine);
    }
    if ( expected.lexiconLine != null && expected.lexiconLine.length() > 0 )
    {
      expectEquals(result, "lexicon", expected.lexiconLine, actual.lexiconLine);
    }
    result.finish();
    return result;
  }

  private static boolean containsNormalized(String haystack, String needle)
  {
    return normalizeForContains(haystack).indexOf(normalizeForContains(needle)) >= 0;
  }

  private static String normalizeForContains(String value)
  {
    if ( value == null ) return "";
    return value.toLowerCase().replace('-', '_');
  }

  private static void expectEquals(CheckResult result, String label, String expected, String actual)
  {
    if ( expected == null ) expected = "";
    if ( actual == null ) actual = "";
    if ( !expected.equals(actual) ) result.messages.add(label + " mismatch; expected: " + expected);
  }

  private static MappingSummary analyzeOPN(File opnFile) throws IOException
  {
    List lines = readAllLines(opnFile);
    int lexicalItems = countPipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    int verbDomains = countPipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    int placementRules = countPipeSectionRows(lines, "PLACEMENT_RULES:", getMappingEndMarker(lines));
    FrameGraphValidation frameGraph = validateFrameGraph(lines, opnFile.getName());
    LexiconValidation lexicon = validateLexicon(lines, opnFile.getName());
    MorphologyValidation morphology = validateMorphology(lines, opnFile.getName());
    Validation validation = validateMappingV3(lines, opnFile.getName());
    String generated = validation.failed == 0 ? generateBest(lines) : "none (invalid mapping)";
    MappingSummary summary = new MappingSummary();
    summary.mappingLine = "Mapping " + mappingVersionLabel(lines) + ": " + lexicalItems + " lexical items, " + verbDomains + " verb domains, " + placementRules + " placement rules";
    summary.validationLine = "validation: " + validation.passed + " ok, " + validation.failed + " fail";
    String details = validation.details();
    if ( details.length() > 0 ) summary.validationLine += " (" + details + ")";
    summary.generatedLine = "generated: " + generated;
    summary.frameGraphLine = frameGraph.present ? frameGraph.summaryLine() : "";
    summary.lexiconLine = lexicon.present ? lexicon.summaryLine(morphology) : "";
    return summary;
  }

  private static LexiconValidation validateLexicon(List lines, String fileName)
  {
    LexiconValidation result = new LexiconValidation(fileName);
    List rows = pipeSectionRows(lines, "LEXICON:", "END_LEXICON:");
    if ( rows.size() == 0 ) return result;
    result.present = true;
    result.entries = rows.size();

    Map mappingRoles = readLexiconCheckedMappingRoles(lines);
    Set frameNames = readFrameGraphNames(lines);
    boolean frameGraphPresent = containsTrimmedLine(lines, "FRAME_GRAPH:");
    Set seenKeys = new LinkedHashSet();

    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      boolean rowFailed = false;
      if ( parts.length < 2 || !parts[0].equalsIgnoreCase("lex") )
      {
        result.fail("malformed LEXICON row");
        continue;
      }

      String key = parts[1];
      String lemma = "";
      String form = "";
      String role = "";
      String frame = "";

      if ( key == null || key.length() == 0 )
      {
        result.fail("missing lexical key");
        rowFailed = true;
      }
      else if ( seenKeys.contains(key) )
      {
        result.fail("duplicate lexical key " + key);
        rowFailed = true;
      }
      else
      {
        seenKeys.add(key);
      }

      for ( int j=2; j<parts.length; j++ )
      {
        String part = (String)parts[j];
        if ( part.startsWith("lemma:") ) lemma = part.substring("lemma:".length()).trim();
        else if ( part.startsWith("form:") ) form = part.substring("form:".length()).trim();
        else if ( part.startsWith("role:") ) role = canonicalRoleToken(part.substring("role:".length()));
        else if ( part.startsWith("frame:") ) frame = part.substring("frame:".length()).trim();
      }

      if ( lemma.length() == 0 )
      {
        result.fail("missing lemma for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      if ( form.length() == 0 )
      {
        result.fail("missing form for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      if ( role.length() == 0 )
      {
        result.fail("missing lexical role for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      else if ( !isKnownRole(role) )
      {
        result.fail("unknown lexical role " + role + " for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      else if ( mappingRoles.get(role) == null )
      {
        result.fail("lexical role " + role + " is not present in explicit MAPPING_V4 items");
        rowFailed = true;
      }

      if ( frameGraphPresent && frame.length() > 0 && !frameNames.contains(frame) )
      {
        result.fail("lexicon frame " + frame + " is not present in FRAME_GRAPH");
        rowFailed = true;
      }

      if ( !rowFailed ) result.pass();
    }

    return result;
  }

  private static MorphologyValidation validateMorphology(List lines, String fileName)
  {
    MorphologyValidation result = new MorphologyValidation(fileName);
    List rows = pipeSectionRows(lines, "LEXICON:", "END_LEXICON:");
    if ( rows.size() == 0 ) return result;

    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 || !parts[0].equalsIgnoreCase("lex") ) continue;

      String entryKey = printableLexiconKey(parts[1]);
      String pos = "";
      for ( int j=2; j<parts.length; j++ )
      {
        String part = (String)parts[j];
        if ( part.startsWith("pos:") ) pos = part.substring("pos:".length()).trim();
      }

      boolean hasMorphology = false;
      boolean rowFailed = false;
      Set seenFeatures = new LinkedHashSet();

      for ( int j=2; j<parts.length; j++ )
      {
        String part = (String)parts[j];
        int colon = part.indexOf(':');
        String feature = colon >= 0 ? part.substring(0, colon).trim() : part.trim();
        String value = colon >= 0 ? part.substring(colon + 1).trim() : "";
        if ( feature.length() == 0 || isBaseLexiconFeature(feature) ) continue;

        result.present = true;
        if ( !isKnownMorphologyFeature(feature) )
        {
          result.fail("unknown morphology feature " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }

        hasMorphology = true;
        if ( seenFeatures.contains(feature) )
        {
          result.fail("duplicate morphology feature " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
        seenFeatures.add(feature);

        if ( value.length() == 0 )
        {
          result.fail("missing morphology feature value for " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
        if ( !isKnownMorphologyFeatureValue(feature, value) )
        {
          result.fail("unknown morphology feature value " + value + " for " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
        if ( !isMorphologyFeatureCompatibleWithPos(feature, pos) )
        {
          result.fail("morphology feature " + feature + " incompatible with pos:" + printablePos(pos) + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
      }

      if ( hasMorphology && !rowFailed ) result.pass();
    }

    return result;
  }

  private static boolean isBaseLexiconFeature(String feature)
  {
    return "lemma".equals(feature) || "form".equals(feature) || "role".equals(feature) ||
      "frame".equals(feature) || "pos".equals(feature) ||
      "det-target".equals(feature) || "det_target".equals(feature) ||
      "wh-target".equals(feature) || "wh_target".equals(feature);
  }

  private static boolean isKnownMorphologyFeature(String feature)
  {
    return "tense".equals(feature) || "number".equals(feature) || "person".equals(feature) ||
      "gender".equals(feature) || "case".equals(feature) || "mood".equals(feature) ||
      "aspect".equals(feature) || "finite".equals(feature);
  }

  private static boolean isKnownMorphologyFeatureValue(String feature, String value)
  {
    if ( "tense".equals(feature) ) return hasValue(value, new String[] { "present", "past" });
    if ( "number".equals(feature) ) return hasValue(value, new String[] { "sg", "pl" });
    if ( "person".equals(feature) ) return hasValue(value, new String[] { "1", "2", "3" });
    if ( "gender".equals(feature) ) return hasValue(value, new String[] { "common", "neuter", "masc", "fem" });
    if ( "case".equals(feature) ) return hasValue(value, new String[] { "nom", "acc", "dat", "gen" });
    if ( "mood".equals(feature) ) return hasValue(value, new String[] { "indicative", "imperative", "subjunctive" });
    if ( "aspect".equals(feature) ) return hasValue(value, new String[] { "simple", "perfect", "progressive" });
    if ( "finite".equals(feature) ) return hasValue(value, new String[] { "true", "false" });
    return false;
  }

  private static boolean hasValue(String value, String[] values)
  {
    String normalized = value == null ? "" : value.trim().toLowerCase();
    for ( int i=0; i<values.length; i++ ) if ( values[i].equals(normalized) ) return true;
    return false;
  }

  private static boolean isMorphologyFeatureCompatibleWithPos(String feature, String pos)
  {
    String p = pos == null ? "" : pos.trim().toUpperCase();
    if ( p.length() == 0 ) return false;
    if ( "finite".equals(feature) ) return isVerbPos(p);
    if ( "person".equals(feature) ) return isVerbPos(p) || "PRON".equals(p);
    if ( "case".equals(feature) ) return isNominalMorphologyPos(p);
    if ( "tense".equals(feature) || "mood".equals(feature) || "aspect".equals(feature) ) return isVerbPos(p);
    if ( "gender".equals(feature) ) return isNominalMorphologyPos(p);
    if ( "number".equals(feature) ) return isVerbPos(p) || isNominalMorphologyPos(p);
    return false;
  }

  private static boolean isVerbPos(String pos)
  {
    return pos != null && pos.startsWith("V");
  }

  private static boolean isNominalMorphologyPos(String pos)
  {
    return "N".equals(pos) || "PRON".equals(pos) || "DET".equals(pos) || "ADJ".equals(pos);
  }

  private static String printablePos(String pos)
  {
    return pos == null || pos.trim().length() == 0 ? "<missing>" : pos.trim();
  }

  private static Map readLexiconCheckedMappingRoles(List lines)
  {
    Map roles = new LinkedHashMap();
    List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      for ( int j=2; j<parts.length; j++ )
      {
        String part = (String)parts[j];
        if ( part.startsWith("role:") )
        {
          String role = canonicalRoleToken(part.substring("role:".length()));
          if ( role.length() > 0 ) roles.put(role, Boolean.TRUE);
        }
      }
    }
    return roles;
  }

  private static Set readFrameGraphNames(List lines)
  {
    Set frames = new LinkedHashSet();
    List rows = pipeSectionRows(lines, "FRAME_GRAPH:", "END_FRAME_GRAPH:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 2 && parts[0].equalsIgnoreCase("frame") && parts[1].length() > 0 ) frames.add(parts[1]);
    }
    return frames;
  }

  private static String printableLexiconKey(String key)
  {
    return key == null || key.length() == 0 ? "<missing>" : key;
  }

  private static FrameGraphValidation validateFrameGraph(List lines, String fileName)
  {
    FrameGraphValidation result = new FrameGraphValidation(fileName);
    List rows = pipeSectionRows(lines, "FRAME_GRAPH:", "END_FRAME_GRAPH:");
    if ( rows.size() == 0 ) return result;
    result.present = true;

    Set frames = new LinkedHashSet();
    Map frameSlots = new LinkedHashMap();
    List requiredSlots = new ArrayList();

    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 3 || !parts[0].equalsIgnoreCase("frame") || parts[1].length() == 0 )
      {
        result.fail("malformed FRAME_GRAPH row");
        continue;
      }

      String frameName = parts[1];
      frames.add(frameName);
      Set slotsForFrame = (Set)frameSlots.get(frameName);
      if ( slotsForFrame == null )
      {
        slotsForFrame = new LinkedHashSet();
        frameSlots.put(frameName, slotsForFrame);
      }

      boolean hasSlot = false;
      boolean required = false;
      List currentRowSlots = new ArrayList();
      for ( int j=2; j<parts.length; j++ )
      {
        String part = (String)parts[j];
        if ( part.startsWith("slot:") )
        {
          hasSlot = true;
          String slotRole = canonicalRoleToken(part.substring("slot:".length()));
          result.slots++;
          slotsForFrame.add(slotRole);
          currentRowSlots.add(slotRole);
          if ( !isKnownFrameSlotRole(slotRole) ) result.fail("unknown frame slot role " + slotRole + " for frame " + frameName);
        }
        else if ( part.equalsIgnoreCase("required") ) required = true;
      }
      if ( !hasSlot )
      {
        result.fail("malformed FRAME_GRAPH row");
        continue;
      }
      if ( required )
      {
        for ( int j=0; j<currentRowSlots.size(); j++ )
        {
          String slotRole = (String)currentRowSlots.get(j);
          if ( isKnownFrameSlotRole(slotRole) ) requiredSlots.add(new String[] { frameName, slotRole });
        }
      }
    }

    result.frames = frames.size();
    Set lexicalRoles = readFrameCheckedLexicalRoles(lines);

    for ( int i=0; i<requiredSlots.size(); i++ )
    {
      String[] row = (String[])requiredSlots.get(i);
      String frameName = row[0];
      String role = row[1];
      if ( lexicalRoles.contains(role) ) result.pass();
      else result.fail("missing required frame slot " + role + " for frame " + frameName);
    }

    Iterator frameIt = frameSlots.keySet().iterator();
    while ( frameIt.hasNext() )
    {
      String frameName = (String)frameIt.next();
      Set slotsForFrame = (Set)frameSlots.get(frameName);
      Iterator roleIt = lexicalRoles.iterator();
      while ( roleIt.hasNext() )
      {
        String role = (String)roleIt.next();
        if ( isLicensableLexicalFrameRole(role) && !slotsForFrame.contains(role) ) result.fail("lexical role " + role + " is not licensed by frame " + frameName);
      }
    }

    return result;
  }

  private static Set readFrameCheckedLexicalRoles(List lines)
  {
    Set roles = new LinkedHashSet();
    List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("role:") )
        {
          String role = canonicalRoleToken(part.substring("role:".length()));
          if ( isFrameCheckedLexicalRole(role) ) roles.add(role);
        }
      }
    }
    return roles;
  }

  private static boolean isKnownFrameSlotRole(String role)
  {
    String r = canonicalRoleToken(role);
    return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") || r.equals("THEME");
  }

  private static boolean isFrameCheckedLexicalRole(String role)
  {
    String r = canonicalRoleToken(role);
    return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") || r.equals("THEME") || r.equals("TIME") || r.equals("PLACE");
  }

  private static boolean isLicensableLexicalFrameRole(String role)
  {
    return isFrameCheckedLexicalRole(role);
  }

  private static Validation validateMappingV3(List lines, String fileName)
  {
    Validation result = new Validation(fileName);
    Map roleToX = new HashMap();
    Map roleToWord = new HashMap();
    Map xToWord = new HashMap();
    Map xIds = new HashMap();
    List detTargets = new ArrayList();
    readLexicalItems(lines, roleToX, roleToWord, xToWord, xIds, detTargets, result);
    validateDetTargets(roleToX, detTargets, result);
    Map verbDomain = new HashMap();
    readVerbDomain(lines, verbDomain, xIds, result);
    List rules = new ArrayList();
    readPlacementRules(lines, rules);
    List validationRules = bestPlacementRules(rules);
    Map before = new HashMap();
    List roles = sortedRolesByX(roleToX);
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new ArrayList());
    List afterClauseRoles = rolesWithRelation(validationRules, roleToWord, "after_clause");
    for ( int i=0; i<validationRules.size(); i++ ) validateRule((String[])validationRules.get(i), roleToX, verbDomain, before, roles, afterClauseRoles, result);
    if ( result.failed == 0 && roles.size() > 0 )
    {
      List ordered = topologicalRoleOrder(roles, before);
      if ( ordered.size() == 0 ) result.fail("ordering cycle in best placement rules");
    }
    return result;
  }

  private static String generateBest(List lines)
  {
    Map roleToWord = new HashMap();
    Map roleToX = new HashMap();
    Map xToWord = new HashMap();
    readLexicalItemsLenient(lines, roleToX, roleToWord, xToWord);
    Map verbDomain = new HashMap();
    readVerbDomainLenient(lines, verbDomain);
    List rules = new ArrayList();
    readPlacementRules(lines, rules);
    List words = generateUtterance(roleToWord, roleToX, verbDomain, bestPlacementRules(rules));
    if ( words.size() == 0 ) return "";
    return "best: " + joinWords(words);
  }

  private static void readLexicalItems(List lines, Map roleToX, Map roleToWord, Map xToWord, Map xIds, List detTargets, Validation result)
  {
    List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 ) { result.fail("invalid lexical item row"); continue; }
      String xId = parts[0];
      String word = parts[1];
      if ( xIds.get(xId) != null ) result.fail("duplicate lexical id " + xId);
      xIds.put(xId, Boolean.TRUE);
      xToWord.put(xId, word);
      String role = null;
      String detTarget = null;
      for ( int j=2; j<parts.length; j++ )
      {
        if ( parts[j].startsWith("role:") ) role = canonicalRoleToken(parts[j].substring("role:".length()));
        else if ( parts[j].startsWith("det-target:") ) detTarget = canonicalRoleToken(parts[j].substring("det-target:".length()));
        else if ( parts[j].startsWith("det_target:") ) detTarget = canonicalRoleToken(parts[j].substring("det_target:".length()));
      }
      if ( role == null || role.length() == 0 ) { result.fail(xId + " missing role"); continue; }
      if ( !isKnownRole(role) ) { result.fail("unknown role " + role + " at " + xId); continue; }
      roleToX.put(role, new Integer(parseXIndex(xId)));
      roleToWord.put(role, word);
      if ( role.equals("DET") ) detTargets.add(new String[] { xId, detTarget });
    }
  }

  private static void validateDetTargets(Map roleToX, List detTargets, Validation result)
  {
    if ( detTargets == null ) return;
    for ( int i=0; i<detTargets.size(); i++ )
    {
      String[] row = (String[])detTargets.get(i);
      String xId = row[0];
      String target = row.length > 1 ? row[1] : null;
      if ( target == null || target.length() == 0 ) { result.fail("missing det-target for role DET at " + xId); continue; }
      if ( !isKnownRole(target) || target.equals("DET") ) { result.fail("unknown det-target " + target + " for role DET at " + xId); continue; }
      if ( resolveRoleKey(roleToX, target) == null ) result.fail("missing lexical target " + target + " for DET at " + xId);
    }
  }

  private static void readLexicalItemsLenient(List lines, Map roleToX, Map roleToWord, Map xToWord)
  {
    List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 ) continue;
      String xId = parts[0];
      String word = parts[1];
      xToWord.put(xId, word);
      for ( int j=2; j<parts.length; j++ )
      {
        if ( parts[j].startsWith("role:") )
        {
          String role = canonicalRoleToken(parts[j].substring("role:".length()));
          roleToX.put(role, new Integer(parseXIndex(xId)));
          roleToWord.put(role, word);
        }
      }
    }
  }

  private static void readVerbDomain(List lines, Map verbDomain, Map xIds, Validation result)
  {
    List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 3 ) { result.fail("invalid verb-domain row"); continue; }
      verbDomain.put(parts[0], parts[2]);
      String[] refs = parts[2].split(",");
      for ( int j=0; j<refs.length; j++ )
      {
        String ref = refs[j].trim();
        if ( ref.length() > 0 && xIds.get(ref) == null ) result.fail("verb-domain " + parts[0] + " references unknown lexical item " + ref);
      }
    }
  }

  private static void readVerbDomainLenient(List lines, Map verbDomain)
  {
    List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 3 ) verbDomain.put(parts[0], parts[2]);
    }
  }

  private static void readPlacementRules(List lines, List rules)
  {
    List rows = pipeSectionRows(lines, "PLACEMENT_RULES:", getMappingEndMarker(lines));
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] rule = normalizePlacementRule(splitPipe((String)rows.get(i)));
      if ( rule != null ) rules.add(rule);
    }
  }

  private static void validateRule(String[] rule, Map roleToX, Map verbDomain, Map before, List roles, List afterClauseRoles, Validation result)
  {
    if ( rule == null || rule.length < 2 ) { result.fail("invalid placement rule"); return; }
    String role = resolveRoleKey(roleToX, rule[0]);
    String relation = rule[1];
    String target = rule.length > 2 ? rule[2] : "";
    String label = rule[0] + " " + relation + (target != null && target.length() > 0 ? " " + target : "");
    if ( role == null ) { result.fail("missing role for rule " + label); return; }
    if ( relation.equals("left_of") && target.equals("V") )
    {
      String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
      if ( vAnchorRole == null ) result.fail("missing V-anchor for rule " + label);
      else { addOrderingConstraint(before, role, vAnchorRole); result.pass(); }
      return;
    }
    if ( relation.equals("right_of") && target.equals("V") )
    {
      String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
      if ( vAnchorRole == null ) result.fail("missing V-anchor for rule " + label);
      else { addOrderingConstraint(before, vAnchorRole, role); result.pass(); }
      return;
    }
    if ( relation.equals("realizes_before") || relation.equals("before") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      if ( resolvedTarget == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, role, resolvedTarget); result.pass(); }
      return;
    }
    if ( relation.equals("realizes_after") || relation.equals("after") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      if ( resolvedTarget == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, resolvedTarget, role); result.pass(); }
      return;
    }
    if ( relation.equals("after_aux_before_object") )
    {
      String auxRole = resolveRoleKey(roleToX, "V-AUX");
      String objectRole = resolveRoleKey(roleToX, target == null || target.length() == 0 ? "Patiens" : target);
      if ( auxRole == null ) result.fail("missing V-AUX for rule " + label);
      else if ( objectRole == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, auxRole, role); addOrderingConstraint(before, role, objectRole); result.pass(); }
      return;
    }
    if ( relation.equals("before_clause") ) { addClauseBoundaryConstraints(before, roles, role, true); result.pass(); return; }
    if ( relation.equals("after_clause") ) { addClauseBoundaryConstraints(before, roles, role, false); result.pass(); return; }
    if ( relation.equals("clause_end") ) { addClauseEndConstraints(before, roles, role, afterClauseRoles); result.pass(); return; }
    if ( relation.equals("anchor") ) { result.pass(); return; }
    result.fail("unknown placement relation " + relation + " for rule " + label);
  }

  private static List generateUtterance(Map roleToWord, Map roleToX, Map verbDomain, List rules)
  {
    List roles = sortedRolesByX(roleToX);
    Map before = new HashMap();
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new ArrayList());
    List afterClauseRoles = rolesWithRelation(rules, roleToWord, "after_clause");
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      String role = resolveRoleKey(roleToWord, rule[0]);
      String relation = rule[1];
      String target = rule.length > 2 ? rule[2] : "";
      if ( role == null ) continue;
      if ( relation.equals("left_of") && target.equals("V") ) addOrderingConstraint(before, role, findVerbAnchorRole(roleToX, verbDomain));
      else if ( relation.equals("right_of") && target.equals("V") ) addOrderingConstraint(before, findVerbAnchorRole(roleToX, verbDomain), role);
      else if ( relation.equals("realizes_before") || relation.equals("before") ) addOrderingConstraint(before, role, resolveRoleKey(roleToWord, target));
      else if ( relation.equals("realizes_after") || relation.equals("after") ) addOrderingConstraint(before, resolveRoleKey(roleToWord, target), role);
      else if ( relation.equals("after_aux_before_object") ) { String objectRole = resolveRoleKey(roleToWord, target.length() == 0 ? "Patiens" : target); addOrderingConstraint(before, resolveRoleKey(roleToWord, "V-AUX"), role); addOrderingConstraint(before, role, objectRole); }
      else if ( relation.equals("before_clause") ) addClauseBoundaryConstraints(before, roles, role, true);
      else if ( relation.equals("after_clause") ) addClauseBoundaryConstraints(before, roles, role, false);
      else if ( relation.equals("clause_end") ) addClauseEndConstraints(before, roles, role, afterClauseRoles);
    }
    List orderedRoles = topologicalRoleOrder(roles, before);
    List words = new ArrayList();
    for ( int i=0; i<orderedRoles.size(); i++ )
    {
      Object word = roleToWord.get((String)orderedRoles.get(i));
      if ( word != null && word.toString().length() > 0 ) words.add(word.toString());
    }
    return words;
  }

  private static List bestPlacementRules(List rules)
  {
    List filtered = new ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      if ( isCoreRule(rule) || getRuleRank(rule) == 1 ) filtered.add(rule);
    }
    return filtered;
  }
  private static boolean isCoreRule(String[] rule) { if ( rule == null || rule.length < 4 ) return true; String marker = rule[3] == null ? "" : rule[3].trim(); return marker.length() == 0 || marker.equalsIgnoreCase("core") || marker.equals("-"); }
  private static int getRuleRank(String[] rule) { if ( rule == null || rule.length < 4 ) return 0; String marker = rule[3] == null ? "" : rule[3].trim(); if ( marker.startsWith("rank:")) marker = marker.substring("rank:".length()); if ( marker.startsWith("pref:")) marker = marker.substring("pref:".length()); try { return Integer.parseInt(marker); } catch ( Exception e ) { return 0; } }

  private static String[] normalizePlacementRule(String[] parts)
  {
    if ( parts == null || parts.length < 2 ) return null;
    String role = safeTrim(parts[0]); String relation = safeTrim(parts[1]); String target = ""; String marker = "";
    if ( parts.length >= 4 ) { target = safeTrim(parts[2]); marker = safeTrim(parts[3]); }
    else if ( parts.length == 3 ) { String third = safeTrim(parts[2]); if ( isRuleMarker(third) || relationImpliesTarget(relation) || isUnaryPlacementRelation(relation) ) marker = third; else target = third; }
    String[] expanded = expandPlacementRelation(relation, target); relation = expanded[0]; target = expanded[1];
    if ( role.length() == 0 || relation.length() == 0 ) return null;
    return new String[] { canonicalRoleToken(role), relation, canonicalRoleToken(target), marker };
  }
  private static String[] expandPlacementRelation(String relation, String target)
  {
    String original = safeTrim(relation); String compact = original.toLowerCase().replace('-', '_'); String resolvedTarget = safeTrim(target);
    if ( compact.equals("left_of_v") ) return new String[] { "left_of", "V" };
    if ( compact.equals("right_of_v") ) return new String[] { "right_of", "V" };
    if ( compact.startsWith("before_") && !compact.equals("before_clause") ) { String s = original.replace('-', '_'); return new String[] { "before", s.substring(s.indexOf('_') + 1) }; }
    if ( compact.startsWith("after_") && !compact.equals("after_clause") && !compact.equals("after_aux_before_object") ) { String s = original.replace('-', '_'); return new String[] { "after", s.substring(s.indexOf('_') + 1) }; }
    if ( compact.equals("before_clause") ) return new String[] { "before_clause", "" };
    if ( compact.equals("after_clause") ) return new String[] { "after_clause", "" };
    if ( compact.equals("after_aux_before_object") ) return new String[] { "after_aux_before_object", resolvedTarget.length() == 0 ? "Patiens" : resolvedTarget };
    if ( compact.equals("anchor") ) return new String[] { "anchor", "" };
    if ( compact.equals("clause_end") ) return new String[] { "clause_end", "" };
    if ( compact.equals("realizes_before") ) return new String[] { "realizes_before", resolvedTarget };
    if ( compact.equals("realizes_after") ) return new String[] { "realizes_after", resolvedTarget };
    return new String[] { original, resolvedTarget };
  }
  private static boolean relationImpliesTarget(String relation) { String compact = safeTrim(relation).toLowerCase().replace('-', '_'); return compact.equals("left_of_v") || compact.equals("right_of_v") || (compact.startsWith("before_") && !compact.equals("before_clause")) || (compact.startsWith("after_") && !compact.equals("after_clause") && !compact.equals("after_aux_before_object")); }
  private static boolean isUnaryPlacementRelation(String relation) { String compact = safeTrim(relation).toLowerCase().replace('-', '_'); return compact.equals("before_clause") || compact.equals("after_clause") || compact.equals("anchor") || compact.equals("clause_end"); }
  private static boolean isRuleMarker(String value) { String marker = safeTrim(value).toLowerCase(); return marker.length() == 0 || marker.equals("-") || marker.equals("core") || marker.startsWith("rank:") || marker.startsWith("pref:"); }
  private static boolean isKnownRole(String role) { String r = canonicalRoleToken(role); return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") || r.equals("THEME") || r.equals("TIME") || r.equals("PLACE") || r.equals("NEG") || r.equals("WH") || r.equals("DET") || r.equals("C") || r.equals("V") || r.equals("V-AUX") || r.equals("V-PART"); }
  private static String canonicalRoleToken(String value) { String token = safeTrim(value); if ( token.length() == 0 ) return token; token = token.replace('_', '-'); if ( token.equalsIgnoreCase("v") ) return "V"; if ( token.equalsIgnoreCase("v-aux") ) return "V-AUX"; if ( token.equalsIgnoreCase("v-part") ) return "V-PART"; if ( token.equalsIgnoreCase("recipient") ) return "RECIPIENT"; if ( token.equalsIgnoreCase("theme") ) return "THEME"; if ( token.equalsIgnoreCase("time") ) return "TIME"; if ( token.equalsIgnoreCase("place") ) return "PLACE"; if ( token.equalsIgnoreCase("neg") ) return "NEG"; if ( token.equalsIgnoreCase("wh") ) return "WH"; if ( token.equalsIgnoreCase("det") ) return "DET"; if ( token.equalsIgnoreCase("agens") ) return "Agens"; if ( token.equalsIgnoreCase("patiens") ) return "Patiens"; return token; }
  private static List rolesWithRelation(List rules, Map roleMap, String relation) { List result = new ArrayList(); for ( int i=0; i<rules.size(); i++ ) { String[] rule = (String[])rules.get(i); if ( rule.length < 2 || !relation.equals(rule[1]) ) continue; String role = resolveRoleKey(roleMap, rule[0]); if ( role != null && !result.contains(role) ) result.add(role); } return result; }
  private static String resolveRoleKey(Map roleMap, String requested) { if ( requested == null ) return null; String wanted = canonicalRoleToken(requested); if ( wanted.length() == 0 ) return null; if ( roleMap.get(wanted) != null ) return wanted; Iterator it = roleMap.keySet().iterator(); while ( it.hasNext() ) { String candidate = (String)it.next(); if ( sameRoleToken(candidate, wanted) ) return candidate; } return null; }
  private static boolean sameRoleToken(String a, String b) { return canonicalRoleToken(a).replace('-', '_').equalsIgnoreCase(canonicalRoleToken(b).replace('-', '_')); }
  private static List sortedRolesByX(final Map roleToX) { List roles = new ArrayList(roleToX.keySet()); Collections.sort(roles, new Comparator() { public int compare(Object a, Object b) { Integer xa = (Integer)roleToX.get(a); Integer xb = (Integer)roleToX.get(b); int av = xa == null ? Integer.MAX_VALUE : xa.intValue(); int bv = xb == null ? Integer.MAX_VALUE : xb.intValue(); if ( av != bv ) return av - bv; return a.toString().compareTo(b.toString()); } }); return roles; }
  private static String findVerbAnchorRole(Map roleToX, Map verbDomain) { Object value = verbDomain.get("V"); if ( value == null ) return null; String[] xs = value.toString().split(","); int bestX = Integer.MAX_VALUE; String bestRole = null; for ( int i=0; i<xs.length; i++ ) { int x = parseXIndex(xs[i].trim()); if ( x < 0 ) continue; Iterator it = roleToX.keySet().iterator(); while ( it.hasNext() ) { String role = (String)it.next(); Integer rx = (Integer)roleToX.get(role); if ( rx != null && rx.intValue() == x && x < bestX ) { bestX = x; bestRole = role; } } } return bestRole; }
  private static void addOrderingConstraint(Map before, String first, String second) { if ( first == null || second == null || first.equals(second) ) return; List list = (List)before.get(first); if ( list == null ) { list = new ArrayList(); before.put(first, list); } if ( !list.contains(second) ) list.add(second); if ( before.get(second) == null ) before.put(second, new ArrayList()); }
  private static void addClauseBoundaryConstraints(Map before, List roles, String role, boolean beforeClause) { if ( role == null ) return; for ( int i=0; i<roles.size(); i++ ) { String other = (String)roles.get(i); if ( other == null || other.equals(role) ) continue; if ( beforeClause ) addOrderingConstraint(before, role, other); else addOrderingConstraint(before, other, role); } }
  private static void addClauseEndConstraints(Map before, List roles, String role, List afterClauseRoles) { if ( role == null ) return; for ( int i=0; i<roles.size(); i++ ) { String other = (String)roles.get(i); if ( other == null || other.equals(role) ) continue; if ( afterClauseRoles != null && afterClauseRoles.contains(other) ) continue; addOrderingConstraint(before, other, role); } }
  private static List topologicalRoleOrder(List initialRoles, Map before) { List remaining = new ArrayList(initialRoles); List ordered = new ArrayList(); while ( remaining.size() > 0 ) { String candidate = null; for ( int i=0; i<remaining.size(); i++ ) { String role = (String)remaining.get(i); if ( hasNoIncomingConstraints(role, remaining, before) ) { candidate = role; break; } } if ( candidate == null ) return new ArrayList(); ordered.add(candidate); remaining.remove(candidate); } return ordered; }
  private static boolean hasNoIncomingConstraints(String role, List remaining, Map before) { for ( int i=0; i<remaining.size(); i++ ) { String other = (String)remaining.get(i); List list = (List)before.get(other); if ( list != null && list.contains(role) ) return false; } return true; }
  private static String joinWords(List words) { StringBuffer b = new StringBuffer(); for ( int i=0; i<words.size(); i++ ) { if ( i > 0 ) b.append(" "); b.append(words.get(i).toString()); } return b.toString(); }
  private static List readValidExpected(File file) throws IOException { List lines = readAllLines(file); List result = new ArrayList(); ExpectedValid current = null; for ( int i=0; i<lines.size(); i++ ) { String line = ((String)lines.get(i)).trim(); if ( isExpectedFileHeader(line) ) { if ( current != null ) result.add(current); current = new ExpectedValid(line); } else if ( current != null && line.startsWith("expected mapping:")) current.mappingLine = line.substring("expected mapping:".length()).trim(); else if ( current != null && line.startsWith("expected validation:")) current.validationLine = line.substring("expected validation:".length()).trim(); else if ( current != null && line.startsWith("expected generated:")) current.generatedLine = line.substring("expected generated:".length()).trim(); else if ( current != null && line.startsWith("expected frame graph:")) current.frameGraphLine = line.substring("expected frame graph:".length()).trim(); else if ( current != null && line.startsWith("expected lexicon:")) current.lexiconLine = line.substring("expected lexicon:".length()).trim(); } if ( current != null ) result.add(current); return result; }
  private static List readInvalidExpected(File file) throws IOException { List lines = readAllLines(file); List result = new ArrayList(); ExpectedInvalid current = null; for ( int i=0; i<lines.size(); i++ ) { String line = ((String)lines.get(i)).trim(); if ( isExpectedFileHeader(line) ) { if ( current != null ) result.add(current); current = new ExpectedInvalid(line); } else if ( current != null && line.startsWith("expected validation starts with:")) current.validationStartsWith = line.substring("expected validation starts with:".length()).trim(); else if ( current != null && line.startsWith("expected details contain:")) current.detailContains.add(line.substring("expected details contain:".length()).trim()); else if ( current != null && line.startsWith("expected generated:")) current.generatedLine = line.substring("expected generated:".length()).trim(); else if ( current != null && line.startsWith("expected frame graph:")) current.frameGraphLine = line.substring("expected frame graph:".length()).trim(); else if ( current != null && line.startsWith("expected lexicon:")) current.lexiconLine = line.substring("expected lexicon:".length()).trim(); } if ( current != null ) result.add(current); return result; }
  private static boolean isExpectedFileHeader(String line) { return line != null && line.endsWith(".opn") && !line.startsWith("expected ") && line.indexOf(":") < 0; }
  private static int countPipeSectionRows(List lines, String startMarker, String endMarker) { return pipeSectionRows(lines, startMarker, endMarker).size(); }
  private static List pipeSectionRows(List lines, String startMarker, String endMarker) { List rows = new ArrayList(); boolean inSection = false; for ( int i=0; i<lines.size(); i++ ) { String raw = (String)lines.get(i); String line = raw == null ? "" : raw.trim(); if ( line.equals(startMarker) ) { inSection = true; continue; } if ( inSection && line.equals(endMarker) ) break; if ( inSection ) { if ( line.length() == 0 || line.startsWith("#") ) continue; if ( line.endsWith(":")) break; if ( line.indexOf("|") >= 0 ) rows.add(line); } } return rows; }
  private static String getMappingEndMarker(List lines) { if ( containsTrimmedLine(lines, "END_MAPPING_V4:") ) return "END_MAPPING_V4:"; if ( containsTrimmedLine(lines, "END_MAPPING_V3:") ) return "END_MAPPING_V3:"; if ( containsTrimmedLine(lines, "END_MAPPING_V2:") ) return "END_MAPPING_V2:"; return "END_MAPPING_V1:"; }
  private static String mappingVersionLabel(List lines) { if ( containsTrimmedLine(lines, "MAPPING_V4:") ) return "v4"; if ( containsTrimmedLine(lines, "MAPPING_V3:") ) return "v3"; if ( containsTrimmedLine(lines, "MAPPING_V2:") ) return "v2"; return "v1"; }
  private static boolean containsTrimmedLine(List lines, String text) { for ( int i=0; i<lines.size(); i++ ) { String line = (String)lines.get(i); if ( line != null && line.trim().equals(text) ) return true; } return false; }
  private static String[] splitPipe(String line) { List parts = new ArrayList(); String[] rawParts = line.split("\\|", -1); for ( int i=0; i<rawParts.length; i++ ) parts.add(rawParts[i].trim()); return (String[])parts.toArray(new String[parts.size()]); }
  private static int parseXIndex(String xId) { if ( xId == null ) return -1; String s = xId.trim(); if ( s.length() > 0 && (s.charAt(0) == 'x' || s.charAt(0) == 'X') ) s = s.substring(1); try { return Integer.parseInt(s); } catch ( Exception e ) { return -1; } }
  private static String safeTrim(String value) { return value == null ? "" : value.trim(); }
  private static List readAllLines(File file) throws IOException { List lines = new ArrayList(); BufferedReader reader = new BufferedReader(new FileReader(file)); try { String line; while ( (line = reader.readLine()) != null ) lines.add(line); } finally { reader.close(); } return lines; }
  private static class ExpectedValid { String fileName; String mappingLine = ""; String validationLine = ""; String generatedLine = ""; String frameGraphLine = ""; String lexiconLine = ""; ExpectedValid(String fileName) { this.fileName = fileName; } }
  private static class ExpectedInvalid { String fileName; String validationStartsWith = ""; List detailContains = new ArrayList(); String generatedLine = ""; String frameGraphLine = ""; String lexiconLine = ""; ExpectedInvalid(String fileName) { this.fileName = fileName; } }
  private static class CheckResult { String fileName; boolean passed = false; List messages = new ArrayList(); String actualMapping; String actualValidation; String actualGenerated; String actualFrameGraph; String actualLexicon; CheckResult(String fileName) { this.fileName = fileName; } void finish() { passed = messages.size() == 0; } }
  private static class MappingSummary { String mappingLine; String validationLine; String generatedLine; String frameGraphLine = ""; String lexiconLine = ""; }
  private static class LexiconValidation { boolean present = false; int entries = 0; int passed = 0; int failed = 0; List messages = new ArrayList(); String fileName; LexiconValidation(String fileName) { this.fileName = fileName; } void pass() { passed++; } void fail(String message) { failed++; if ( message != null && message.length() > 0 ) messages.add(message); } String details() { if ( failed == 0 ) return ""; StringBuffer b = new StringBuffer(); if ( fileName != null && fileName.length() > 0 ) b.append("file: ").append(fileName); for ( int i=0; i<messages.size(); i++ ) { if ( b.length() > 0 ) b.append("; "); b.append(messages.get(i).toString()); if ( i >= MAX_MESSAGES - 1 && messages.size() > MAX_MESSAGES ) { b.append("; ..."); break; } } return b.toString(); } String summaryLine(MorphologyValidation morphology) { String line = "Lexicon: " + entries + " entries; lexicon validation: " + passed + " ok, " + failed + " fail"; String d = details(); if ( d.length() > 0 ) line += " (" + d + ")"; if ( morphology != null && morphology.present ) line += "; " + morphology.summaryLine(); return line; } }
  private static class MorphologyValidation { boolean present = false; int passed = 0; int failed = 0; List messages = new ArrayList(); String fileName; MorphologyValidation(String fileName) { this.fileName = fileName; } void pass() { passed++; } void fail(String message) { failed++; if ( message != null && message.length() > 0 ) messages.add(message); } String details() { if ( failed == 0 ) return ""; StringBuffer b = new StringBuffer(); if ( fileName != null && fileName.length() > 0 ) b.append("file: ").append(fileName); for ( int i=0; i<messages.size(); i++ ) { if ( b.length() > 0 ) b.append("; "); b.append(messages.get(i).toString()); if ( i >= MAX_MESSAGES - 1 && messages.size() > MAX_MESSAGES ) { b.append("; ..."); break; } } return b.toString(); } String summaryLine() { String line = "morphology validation: " + passed + " ok, " + failed + " fail"; String d = details(); if ( d.length() > 0 ) line += " (" + d + ")"; return line; } }
  private static class FrameGraphValidation { boolean present = false; int frames = 0; int slots = 0; int passed = 0; int failed = 0; List messages = new ArrayList(); String fileName; FrameGraphValidation(String fileName) { this.fileName = fileName; } void pass() { passed++; } void fail(String message) { failed++; if ( message != null && message.length() > 0 ) messages.add(message); } String details() { if ( failed == 0 ) return "frame slots satisfied"; StringBuffer b = new StringBuffer(); if ( fileName != null && fileName.length() > 0 ) b.append("file: ").append(fileName); for ( int i=0; i<messages.size(); i++ ) { if ( b.length() > 0 ) b.append("; "); b.append(messages.get(i).toString()); if ( i >= MAX_MESSAGES - 1 && messages.size() > MAX_MESSAGES ) { b.append("; ..."); break; } } return b.toString(); } String summaryLine() { String line = "Frame graph: " + frames + " frames, " + slots + " slots; frame validation: " + passed + " ok, " + failed + " fail"; String d = details(); if ( d.length() > 0 ) line += " (" + d + ")"; return line; } }
  private static class Validation { int passed = 0; int failed = 0; List messages = new ArrayList(); String fileName; Validation(String fileName) { this.fileName = fileName; } void pass() { passed++; } void fail(String message) { failed++; if ( message != null && message.length() > 0 ) messages.add(message); } String details() { if ( failed == 0 ) return "best placement rules satisfied"; StringBuffer b = new StringBuffer(); if ( fileName != null && fileName.length() > 0 ) b.append("file: ").append(fileName); for ( int i=0; i<messages.size(); i++ ) { if ( b.length() > 0 ) b.append("; "); b.append(messages.get(i).toString()); if ( i >= MAX_MESSAGES - 1 && messages.size() > MAX_MESSAGES ) { b.append("; ..."); break; } } return b.toString(); } }
}
