Mapping V4.20 Language Tree examples.

Open these files via File -> Open OPN. They should open as Language Tree structure with projection context already active:
- LEX projection left for terminal/lexical leaves
- SYN projection right for branching syntax nodes

Run the checker:
java tools.LanguageTreeRegressionChecker .
