package userInterface;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import graphStructure.*;

public class GraphEditorWindow extends OpenGraphEdInternalFrame
{
  public static int WIDTH = 1150;//400;//SET MAX, see below:setSize
  public static int HEIGHT = 750;//400;

  private GraphController graphController;
  private GraphEditor graphEditor;
  private static int newCount = 0;
  private GraphEditorDialog ged;
  private GraphEditorInfoWindow infoWindow;
  private GraphEditorLogWindow logWindow;
  private ButtonGroup zinstypeButtonGroup;
  private JToggleButton basisZinstypeButton;
  private JToggleButton bijzinZinstypeButton;
  private JToggleButton stellendZinstypeButton;
  private JToggleButton jaNeeZinstypeButton;
  private JToggleButton whZinstypeButton;
  private JToggleButton topicalisatieZinstypeButton;
  private JComboBox structureTypeCombo;
  private JButton openGraphDrawButton;
  private JLabel zinstypeLabel;
  private JPanel zinstypePanel;
  private boolean updatingStructureTypeCombo = false;

  public GraphEditorWindow(GraphController graphController, Graph graph)
  {
    super(graphController, graph.getFileName(),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    if ( graph.getLabel().length() == 0 )
    {
      setTitle(graph.getFileName());
    }
    init(graphController);
    graphEditor.setGraph(graph);
    if ( graph != null && graph.isOPNLanguageTreePreferred() )
    {
      OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
      settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
      settings.setShowProjections(true);
      settings.setLeftProjectionEnabled(true);
      settings.setRightProjectionEnabled(true);
      settings.setTopProjectionEnabled(true);
      settings.setBottomProjectionEnabled(true);
      graphEditor.setOpenGraphProjectionSettings(settings);
      graphEditor.rememberLanguageProjectionSettings(settings);
      graphEditor.setOpenGraphProjectionContextActive(true);
    }
    updateOpenGraphHeaderControls();
  }

  public GraphEditorWindow(GraphController graphController)
  {
    super(graphController, "Untitled " + ++newCount,
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    init(graphController);
  }

  private void init(GraphController graphController)
  {
    this.graphController = graphController;
    infoWindow = new GraphEditorInfoWindow(graphController, this);
    logWindow = new GraphEditorLogWindow(graphController, this);
    graphEditor = new GraphEditor(graphController, infoWindow, logWindow);
    ged = null;
    installImmediateZinstypeToolTips();

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    getContentPane().setLayout(layout);

    JPanel openGraphActionBar = createOpenGraphActionBar();
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.HORIZONTAL;
    layoutCons.insets = new Insets(3,3,0,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 0.0;
    layout.setConstraints(openGraphActionBar, layoutCons);
    getContentPane().add(openGraphActionBar);

    JScrollPane scrollPane = new JScrollPane(graphEditor,
                                             JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = GridBagConstraints.REMAINDER;
    layoutCons.fill = GridBagConstraints.BOTH;
    layoutCons.insets = new Insets(3,3,3,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 1.0;
    layout.setConstraints(scrollPane, layoutCons);
    getContentPane().add(scrollPane);

    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    addInternalFrameListener(graphController);

  //  setSize(WIDTH, HEIGHT);
    
    setSize(graphController.getGraphWindow().getWidth(), graphController.getGraphWindow().getHeight());
    setVisible(true);
  }

  private void installImmediateZinstypeToolTips()
  {
    ToolTipManager manager = ToolTipManager.sharedInstance();
    manager.setInitialDelay(0);
    manager.setReshowDelay(0);
    manager.setDismissDelay(15000);
  }

  private JPanel createOpenGraphActionBar()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
    panel.setBorder(BorderFactory.createEtchedBorder());
    panel.add(new JLabel("OpenGraph:"));

    panel.add(new JLabel("Structure type:"));
    structureTypeCombo = createStructureTypeCombo();
    panel.add(structureTypeCombo);

    /* Keep Zinstype directly next to Structure type.  In v4.21.3 it was
     * after Grid/Toggle/Save; on narrow windows it could appear to be
     * missing.  It remains hidden for Simple/Frame/Anafoor and visible for
     * Language Tree / Phrase. */
    zinstypePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    zinstypePanel.setOpaque(false);
    zinstypeLabel = new JLabel("Zinstype:");
    zinstypeLabel.setToolTipText("Language Tree / Phrase: zinstypeprofielen werken op de lexicale as en voeren direct Draw/Redraw uit; de DS-boom blijft ongewijzigd.");
    zinstypePanel.add(zinstypeLabel);
    zinstypeButtonGroup = new ButtonGroup();
    basisZinstypeButton = createZinstypeButton("Basis", OpenGraphProjectionSettings.ZINSTYPE_BASIS);
    bijzinZinstypeButton = createZinstypeButton("Bijzin", OpenGraphProjectionSettings.ZINSTYPE_BIJZIN);
    stellendZinstypeButton = createZinstypeButton("Stellend", OpenGraphProjectionSettings.ZINSTYPE_STELLEND);
    jaNeeZinstypeButton = createZinstypeButton("Ja/nee", OpenGraphProjectionSettings.ZINSTYPE_JA_NEE);
    whZinstypeButton = createZinstypeButton("WH", OpenGraphProjectionSettings.ZINSTYPE_WH);
    topicalisatieZinstypeButton = createZinstypeButton("Topicalisatie", OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE);
    zinstypePanel.add(basisZinstypeButton);
    zinstypePanel.add(bijzinZinstypeButton);
    zinstypePanel.add(stellendZinstypeButton);
    zinstypePanel.add(jaNeeZinstypeButton);
    zinstypePanel.add(whZinstypeButton);
    zinstypePanel.add(topicalisatieZinstypeButton);
    panel.add(zinstypePanel);

    openGraphDrawButton = createOpenGraphButton("Draw", "Draw/Redraw using the selected Structure type. Structure type selection alone does not draw.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.drawSelectedOpenGraphStructure(GraphEditorWindow.this);
      }
    });
    panel.add(openGraphDrawButton);

    panel.add(createOpenGraphButton("Grid", "Set or reapply the OpenGraph grid without clearing the current OPN result", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.openGraphGridMode(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Toggle Proj.", "Show or hide OpenGraph projections without moving the structure grid", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.toggleLexicalProjection(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Save OPN", "Save the current OpenGraph result as .opn", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.saveOPN(GraphEditorWindow.this);
      }
    }));

    updateZinstypeButtonSelection();
    updateStructureTypeComboSelection();
    updateOpenGraphHeaderControlsVisibility();
    return panel;
  }

  private JComboBox createStructureTypeCombo()
  {
    final StructureTypeItem[] items = new StructureTypeItem[]
    {
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_SIMPLE_TREE, "Simple"),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE, "Language Tree / Phrase"),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_ANAPHOR_TREE, "Anafoor"),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_FRAME, "Frame")
    };
    final JComboBox combo = new JComboBox(items);
    combo.setFocusable(false);
    combo.setToolTipText("Kies het OpenGraph-structuurtype. Deze keuze tekent niet direct; gebruik Draw bij Simple/Frame/Anafoor of een Zinstypeknop bij Language Tree / Phrase.");
    combo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if ( updatingStructureTypeCombo )
        {
          return;
        }
        Object selected = combo.getSelectedItem();
        if ( selected instanceof StructureTypeItem )
        {
          graphController.applyOpenGraphStructureType(GraphEditorWindow.this, ((StructureTypeItem)selected).getValue());
        }
      }
    });
    return combo;
  }

  private static class StructureTypeItem
  {
    private final int value;
    private final String label;

    StructureTypeItem(int value, String label)
    {
      this.value = value;
      this.label = label;
    }

    int getValue()
    {
      return value;
    }

    public String toString()
    {
      return label;
    }
  }

  private JToggleButton createZinstypeButton(String text, final String zinstype)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 8, 2, 8));
    button.setFocusable(false);
    button.setToolTipText(buildZinstypeToolTip(zinstype));
    if ( zinstypeButtonGroup != null )
    {
      zinstypeButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeZinstype(GraphEditorWindow.this, zinstype);
          updateZinstypeButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  private String buildZinstypeToolTip(String zinstype)
  {
    OpenGraphProjectionSettings settings = graphEditor == null ? new OpenGraphProjectionSettings() : new OpenGraphProjectionSettings(graphEditor.getOpenGraphProjectionSettings());
    settings.setLanguageTreeZinstype(zinstype);
    String[] lines = settings.getLanguageTreeZinstypeRulePreviewLines();
    StringBuffer html = new StringBuffer("<html><b>Zinstype: ");
    html.append(settings.getLanguageTreeZinstypeDisplayName());
    html.append("</b><br>");
    html.append("Language Tree / Phrase; geen Frame. DS blijft staan, regels werken op de LEX-as.<br><br>");
    for ( int i=0; i<lines.length; i++ )
    {
      if ( lines[i] != null && lines[i].trim().length() > 0 )
      {
        html.append("&#8226; ").append(lines[i]).append("<br>");
      }
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) )
    {
      html.append("<br>Klik eerst een categoriale knoop, bijvoorbeeld NP of DP.<br>");
      html.append("De lexicale vorm wordt als frase getoond, bijvoorbeeld NP(de man).");
    }
    html.append("</html>");
    return html.toString();
  }

  public void updateZinstypeButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String zinstype = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeZinstype();
    if ( OpenGraphProjectionSettings.ZINSTYPE_BIJZIN.equals(zinstype) && bijzinZinstypeButton != null )
    {
      bijzinZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) && stellendZinstypeButton != null )
    {
      stellendZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) && jaNeeZinstypeButton != null )
    {
      jaNeeZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype) && whZinstypeButton != null )
    {
      whZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) && topicalisatieZinstypeButton != null )
    {
      topicalisatieZinstypeButton.setSelected(true);
    }
    else if ( basisZinstypeButton != null )
    {
      basisZinstypeButton.setSelected(true);
    }
  }

  public void updateStructureTypeComboSelection()
  {
    if ( graphEditor == null || structureTypeCombo == null )
    {
      return;
    }
    int structureType = graphEditor.getOpenGraphProjectionSettings().getStructureType();
    updatingStructureTypeCombo = true;
    try
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          structureTypeCombo.setSelectedIndex(i);
          return;
        }
      }
    }
    finally
    {
      updatingStructureTypeCombo = false;
    }
  }

  public void updateOpenGraphHeaderControls()
  {
    updateZinstypeButtonSelection();
    updateStructureTypeComboSelection();
    updateOpenGraphHeaderControlsVisibility();
  }

  private void updateOpenGraphHeaderControlsVisibility()
  {
    if ( graphEditor == null )
    {
      return;
    }
    int structureType = graphEditor.getOpenGraphProjectionSettings().getStructureType();
    boolean isLanguageTree = structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    if ( zinstypePanel != null )
    {
      zinstypePanel.setVisible(isLanguageTree);
    }
    if ( openGraphDrawButton != null )
    {
      openGraphDrawButton.setVisible(!isLanguageTree);
    }
    revalidate();
    repaint();
  }


  private JButton createOpenGraphButton(String text, String toolTip, ActionListener listener)
  {
    JButton button = new JButton(text);
    button.setMargin(new Insets(2, 8, 2, 8));
    button.setFocusable(false);
    button.setToolTipText(toolTip);
    button.addActionListener(listener);
    return button;
  }

  public void dispose()
  {
    graphEditor.prepareForClose();
    super.dispose();
  }

  public GraphEditor getGraphEditor()
  {
    return graphEditor;
  }

  public GraphEditorDialog getDialog() { return ged; }

  public void setDialog(GraphEditorDialog d) { ged = d; }

  public GraphEditorInfoWindow getInfoWindow()
  {
    return infoWindow;
  }
  
  public GraphEditorLogWindow getLogWindow()
  {
    return logWindow;
  }  
}