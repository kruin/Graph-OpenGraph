package userInterface;

import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.*;
import java.util.*;
import graphStructure.*;
import graphException.*;
import operation.*;
import userInterface.menuAndToolBar.*;
import userInterface.fileUtils.*;

public class OpenGraphActions
{
  private static final int DEFAULT_VISIBLE_PADDING_CELLS = 2;
  private final GraphWindow graphWindow;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;
  private final OpenTreeStructureSupport opnSupport;
  private final MenuAndToolBar menuAndToolBar;

  public OpenGraphActions(GraphWindow graphWindow,
                           GraphWindowCoordinator graphWindowCoordinator,
                           GraphEditorActions graphEditorActions,
                           OpenTreeStructureSupport opnSupport,
                           MenuAndToolBar menuAndToolBar)
  {
    this.graphWindow = graphWindow;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphEditorActions = graphEditorActions;
    this.opnSupport = opnSupport;
    this.menuAndToolBar = menuAndToolBar;
  }

  public void refreshOPNMenuVisibility(GraphEditorWindow activeWindow)
  {
    if ( menuAndToolBar == null )
    {
      return;
    }

    menuAndToolBar.showSaveOPN();
    menuAndToolBar.setSaveOPNEnabled(activeWindow != null);
  }

  public void toggleLexicalProjection(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      return;
    }

    GraphEditor editor = activeWindow.getGraphEditor();
    OpenGraphProjectionSettings projectionSettings = editor.getOpenGraphProjectionSettings();
    boolean currentlyVisible = editor.isOpenGraphProjectionContextActive() &&
                               projectionSettings.isLexicalProjectionActive();
    boolean enable = !currentlyVisible;

    if ( enable )
    {
      if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) ||
           (!projectionSettings.getLeftProjectionEnabled() &&
            !projectionSettings.getRightProjectionEnabled() &&
            !projectionSettings.getTopProjectionEnabled() &&
            !projectionSettings.getBottomProjectionEnabled()) )
      {
        projectionSettings = editor.getRememberedLanguageProjectionSettings();
      }

      if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
      {
        projectionSettings.setStructureType(OpenGraphDialog.STRUCTURE_FRAME);
      }
      projectionSettings.setShowProjections(true);
      if ( !projectionSettings.getLeftProjectionEnabled() &&
           !projectionSettings.getRightProjectionEnabled() &&
           !projectionSettings.getTopProjectionEnabled() &&
           !projectionSettings.getBottomProjectionEnabled() )
      {
        projectionSettings.setLeftProjectionEnabled(true);
        projectionSettings.setRightProjectionEnabled(true);
        projectionSettings.setTopProjectionEnabled(true);
        projectionSettings.setBottomProjectionEnabled(true);
      }
    }
    else
    {
      projectionSettings.setShowProjections(false);
    }

    editor.setOpenGraphProjectionSettings(projectionSettings);
    if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
    {
      editor.rememberLanguageProjectionSettings(projectionSettings);
    }

    if ( !editor.isOpenGraphProjectionContextActive() )
    {
      editor.resetTransientEditorArtifacts();
      editor.update();
      return;
    }

    OpenGraphGridSettings gridSettings = editor.getOpenGraphGridSettings();
    if ( enable &&
         gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
    {
      gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
      editor.setOpenGraphGridSettings(gridSettings);
    }

    if ( editor.isInGridMode() )
    {
      // Do not refit or recalculate the OpenGraph grid window on a visibility
      // toggle. The project specification keeps the structure grid fixed while
      // projections are rendered in extra margin/render space. Reapplying the
      // fit-content grid here made Toggle ON appear to move the source graph
      // left by about two grid lines in FRAME examples.
    }
    editor.resetTransientEditorArtifacts();
    editor.update();
  }
  private void ensureProjectionContentVisible(GraphEditor graphEditor, OpenGraphGridSettings gridSettings)
  {
    centerVisibleContentInWindow(graphEditor);
  }

  private void centerVisibleContentInWindow(GraphEditor graphEditor)
  {
    if ( graphEditor == null )
    {
      return;
    }

    Graph graph = graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graphEditor.isInGridMode() )
    {
      return;
    }

    OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
    int cellWidth = Math.max(2, gridSettings.getCellWidth());
    int cellHeight = Math.max(2, gridSettings.getCellHeight());
    int drawWidth = Math.max(cellWidth * 2, graphEditor.getVisibleDrawWidth());
    int drawHeight = Math.max(cellHeight * 2, graphEditor.getVisibleDrawHeight());
    int paddingX = DEFAULT_VISIBLE_PADDING_CELLS * cellWidth;
    int paddingY = DEFAULT_VISIBLE_PADDING_CELLS * cellHeight;

    Rectangle2D.Double visibleBounds = graphEditor.getVisibleContentBounds();
    double visibleWidth = visibleBounds.getWidth();
    double visibleHeight = visibleBounds.getHeight();

    double desiredMinX;
    if ( visibleWidth + (2 * paddingX) <= drawWidth )
    {
      desiredMinX = (drawWidth - visibleWidth) / 2.0;
    }
    else
    {
      desiredMinX = paddingX;
    }

    double desiredMinY;
    if ( visibleHeight + (2 * paddingY) <= drawHeight )
    {
      desiredMinY = (drawHeight - visibleHeight) / 2.0;
    }
    else
    {
      desiredMinY = paddingY;
    }

    int dx = snapToGrid((int)Math.round(desiredMinX - visibleBounds.getMinX()), cellWidth);
    int dy = snapToGrid((int)Math.round(desiredMinY - visibleBounds.getMinY()), cellHeight);

    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    graphEditor.changeToOpenGraphGridMode(gridSettings);
  }

  private int snapToGrid(int value, int step)
  {
    if ( step <= 1 )
    {
      return value;
    }
    return (int)Math.round((double)value / (double)step) * step;
  }


  public void applyLanguageTreeZinstype(GraphEditorWindow editorWindow, String zinstype)
  {
    if ( editorWindow == null )
    {
      return;
    }

    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    settings.setShowProjections(true);
    settings.setLeftProjectionEnabled(true);
    settings.setRightProjectionEnabled(true);
    settings.setTopProjectionEnabled(true);
    settings.setBottomProjectionEnabled(true);
    settings.setLanguageTreeZinstype(zinstype);
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) )
    {
      settings.setLanguageTreeTopicPreview(buildLanguageTreeTopicPreview(graphEditor.getGraph()));
    }
    else
    {
      settings.setLanguageTreeTopicPreview("");
    }

    redrawOpenGraphFromSettings(editorWindow, settings, true);
  }

  public void applyOpenGraphStructureType(GraphEditorWindow editorWindow, int structureType)
  {
    if ( editorWindow == null )
    {
      return;
    }
    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }

    if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
         structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
         structureType != OpenGraphDialog.STRUCTURE_ANAPHOR_TREE &&
         structureType != OpenGraphDialog.STRUCTURE_FRAME )
    {
      structureType = OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    settings.setStructureType(structureType);
    applyStructureTypeDefaults(settings, structureType);
    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(OpenGraphProjectionSettings.isProjectionCapableStructureType(structureType));
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.resetTransientEditorArtifacts();
    graphEditor.update();
    editorWindow.updateOpenGraphHeaderControls();
  }

  public void drawSelectedOpenGraphStructure(GraphEditorWindow editorWindow)
  {
    if ( editorWindow == null )
    {
      return;
    }
    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }
    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    applyStructureTypeDefaults(settings, settings.getStructureType());
    redrawOpenGraphFromSettings(editorWindow, settings, true);
  }

  private void applyStructureTypeDefaults(OpenGraphProjectionSettings settings, int structureType)
  {
    if ( settings == null )
    {
      return;
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      settings.setShowProjections(false);
      settings.setLeftProjectionEnabled(false);
      settings.setRightProjectionEnabled(false);
      settings.setTopProjectionEnabled(false);
      settings.setBottomProjectionEnabled(false);
      settings.setLanguageTreeTopicPreview("");
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      settings.setShowProjections(true);
      settings.setLeftProjectionEnabled(true);
      settings.setRightProjectionEnabled(true);
      settings.setTopProjectionEnabled(true);
      settings.setBottomProjectionEnabled(true);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      settings.setShowProjections(true);
      settings.setLeftProjectionEnabled(true);
      settings.setRightProjectionEnabled(true);
      settings.setTopProjectionEnabled(true);
      settings.setBottomProjectionEnabled(false);
      settings.setLanguageTreeTopicPreview("");
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      settings.setShowProjections(true);
      settings.setLeftProjectionEnabled(true);
      settings.setRightProjectionEnabled(true);
      settings.setTopProjectionEnabled(true);
      settings.setBottomProjectionEnabled(true);
      settings.setLanguageTreeTopicPreview("");
    }
  }

  private void redrawOpenGraphFromSettings(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings)
  {
    redrawOpenGraphFromSettings(editorWindow, projectionSettings, false);
  }

  private void redrawOpenGraphFromSettings(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings, boolean reloadOriginalGraph)
  {
    if ( editorWindow == null || projectionSettings == null )
    {
      return;
    }

    boolean mementoStarted = false;
    try
    {
      GraphEditor graphEditor = editorWindow.getGraphEditor();
      if ( reloadOriginalGraph )
      {
        reloadOriginalGraphForOpenGraphDraw(editorWindow, projectionSettings);
        graphEditor = editorWindow.getGraphEditor();
      }

      clearOPNState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }

      Graph graph = graphEditor.getGraph();
      if ( graph == null || graph.getNumNodes() == 0 )
      {
        throw new GraphException("OpenGraph Draw requires an open graph with at least one node.");
      }

      int structureType = projectionSettings.getStructureType();
      if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_ANAPHOR_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_FRAME )
      {
        throw new GraphException("Only Simple, Language Tree / Phrase, Anafoor, and Frame are implemented reliably at the moment.");
      }

      int rootIndex = OpenGraphRootSelector.getRootIndex(editorWindow);
      graph.newMemento("Display OpenGraph Drawing");
      mementoStarted = true;

      graphEditor.setOpenGraphProjectionSettings(projectionSettings);
      boolean projectionContext =
        OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType());
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);

      OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
      if ( projectionContext &&
           gridSettings.getGridMode() == OpenGraphGridSettings.MODE_FIT_CONTENT &&
           gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
      {
        gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
        graphEditor.setOpenGraphGridSettings(gridSettings);
      }

      OpenGraphTreeDrawOperation.displayOpenGraphTreeDrawing(
        graph,
        graph.getNodeAt(rootIndex),
        1,
        2,
        2,
        gridSettings.getCellWidth(),
        gridSettings.getCellHeight(),
        graphEditor.getDrawWidth(),
        graphEditor.getDrawHeight(),
        structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
        structureType == OpenGraphDialog.STRUCTURE_FRAME ||
        structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE,
        structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE );

      graphEditor.changeToOpenGraphGridMode(gridSettings);
      centerVisibleContentInWindow(graphEditor);
      if ( projectionContext )
      {
        graphEditor.rememberLanguageProjectionSettings(projectionSettings);
      }
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);
      graphEditor.resetTransientEditorArtifacts();
      graphEditor.update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graph.doneMemento();
      graphEditorActions.updateUndo(editorWindow);
      opnSupport.rememberResult(editorWindow, graph);
      refreshOPNMenuVisibility(editorWindow);
      editorWindow.updateOpenGraphHeaderControls();
    }
    catch ( Exception e )
    {
      reportOpenGraphDisplayError(e);

      Graph graph = null;
      try
      {
        graph = editorWindow.getGraphEditor().getGraph();
        if ( graph != null && mementoStarted )
        {
          graph.undoMemento();
          graph.abortMemento();
        }
      }
      catch ( Exception ignored )
      {
      }

      JOptionPane.showMessageDialog(graphWindow, errorMessage(e),
                                    "Error During OpenGraph Drawing Display", JOptionPane.ERROR_MESSAGE);
      if ( editorWindow != null )
      {
        editorWindow.updateOpenGraphHeaderControls();
      }
    }
  }

  private void reloadOriginalGraphForOpenGraphDraw(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings) throws Exception
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null )
    {
      throw new GraphException("OpenGraph Draw requires an active graph editor window.");
    }

    Graph currentGraph = editorWindow.getGraphEditor().getGraph();
    String path = currentGraph == null ? "" : currentGraph.getFilePath();
    if ( path == null || path.trim().length() == 0 )
    {
      throw new GraphException("Deze zinstype-/OpenGraph-draw moet uitgaan van de oorspronkelijke .graph. Er is geen .graph-pad bekend. Open eerst een opgeslagen .graph-bestand.");
    }

    File sourceFile = new File(path);
    if ( !sourceFile.exists() || !sourceFile.isFile() )
    {
      throw new GraphException("De oorspronkelijke .graph ontbreekt. Verwacht bestand:\n" + sourceFile.getPath());
    }

    String extension = Utils.getExtension(sourceFile);
    if ( extension == null || !extension.equalsIgnoreCase(Utils.graph) )
    {
      throw new GraphException("Deze zinstype-/OpenGraph-draw gebruikt voorlopig alleen de oorspronkelijke .graph als bron. Huidig bronbestand is geen .graph:\n" + sourceFile.getPath());
    }

    BufferedReader reader = new BufferedReader(new FileReader(sourceFile));
    Graph originalGraph = null;
    try
    {
      originalGraph = Graph.loadFrom(reader);
    }
    finally
    {
      reader.close();
    }

    originalGraph.setFilePath(sourceFile.getCanonicalPath());
    applyGraphFileLanguageTreeHint(originalGraph, sourceFile);

    GraphEditor graphEditor = editorWindow.getGraphEditor();
    graphEditor.setGraph(originalGraph);
    graphEditor.setOpenGraphProjectionSettings(projectionSettings);
    graphEditor.setOpenGraphProjectionContextActive(OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()));
  }

  private void applyGraphFileLanguageTreeHint(Graph graph, File selectedFile)
  {
    if ( graph == null )
    {
      return;
    }

    String label = graph.getLabel();
    String fileName = selectedFile == null ? "" : selectedFile.getName();
    String combined = ((label == null ? "" : label) + " " + fileName).toUpperCase();

    if ( combined.indexOf("LANGUAGE_TREE") >= 0 ||
         combined.indexOf("LANGUAGE TREE") >= 0 ||
         combined.indexOf("LEXTEST") >= 0 )
    {
      graph.setOPNLanguageTreePreferred(true);
      graph.setOPNLanguageTreeTypeSummary("Language Tree graph");
    }
  }


  private String buildLanguageTreeTopicPreview(Graph graph)
  {
    if ( graph == null )
    {
      return "";
    }
    Vector selectedNodes = graph.selectedNodes();
    if ( selectedNodes == null || selectedNodes.size() == 0 )
    {
      return "";
    }
    if ( selectedNodes.size() > 1 )
    {
      return "meerdere selectie";
    }

    Node selected = (Node)selectedNodes.elementAt(0);
    String category = cleanLabel(selected == null ? "" : selected.getLabel());
    if ( selected == null || category.length() == 0 )
    {
      return "";
    }
    if ( !isLikelyCategoryLabel(category) )
    {
      return "selecteer categoriale knoop";
    }

    Vector terminals = collectLanguageTreeTerminalNodes(selected);
    Collections.sort(terminals, new Comparator()
    {
      public int compare(Object a, Object b)
      {
        Node n1 = (Node)a;
        Node n2 = (Node)b;
        int y1 = n1.getLocation().intY();
        int y2 = n2.getLocation().intY();
        if ( y1 != y2 ) return y1 - y2;
        return n1.getLocation().intX() - n2.getLocation().intX();
      }
    });

    StringBuffer lexical = new StringBuffer();
    for ( int i=0; i<terminals.size(); i++ )
    {
      Node terminal = (Node)terminals.elementAt(i);
      String label = cleanLabel(terminal.getLabel());
      if ( label.length() == 0 || isLikelyCategoryLabel(label) )
      {
        continue;
      }
      if ( lexical.length() > 0 ) lexical.append(' ');
      lexical.append(label);
    }

    if ( lexical.length() > 0 && isLikelyCategoryLabel(category) )
    {
      return category + "(" + lexical.toString() + ")";
    }
    if ( lexical.length() > 0 && !category.equals(lexical.toString()) )
    {
      return category + "(" + lexical.toString() + ")";
    }
    return category;
  }

  private Vector collectLanguageTreeTerminalNodes(Node start)
  {
    Vector result = new Vector();
    Vector visited = new Vector();
    collectLanguageTreeTerminalNodes(start, null, result, visited);
    return result;
  }

  private void collectLanguageTreeTerminalNodes(Node node, Node parent, Vector result, Vector visited)
  {
    if ( node == null || visited.contains(node) )
    {
      return;
    }
    visited.addElement(node);

    Vector children = childNodesBelow(node, parent);
    if ( children.size() == 0 )
    {
      result.addElement(node);
      return;
    }

    for ( int i=0; i<children.size(); i++ )
    {
      collectLanguageTreeTerminalNodes((Node)children.elementAt(i), node, result, visited);
    }
  }

  private Vector childNodesBelow(Node node, Node parent)
  {
    Vector children = new Vector();
    Vector edges = node.incidentEdges();
    for ( int i=0; i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      Node other = null;
      if ( edge.getStartNode() == node )
      {
        other = (Node)edge.getEndNode();
      }
      else if ( edge.getEndNode() == node )
      {
        other = (Node)edge.getStartNode();
      }
      if ( other == null || other == parent )
      {
        continue;
      }
      if ( other.getLocation().intY() > node.getLocation().intY() )
      {
        children.addElement(other);
      }
    }
    return children;
  }

  private String cleanLabel(String label)
  {
    return label == null ? "" : label.trim();
  }

  private boolean isLikelyCategoryLabel(String label)
  {
    if ( label == null ) return false;
    String v = label.trim();
    if ( v.length() == 0 ) return false;
    if ( v.equals("S") || v.equals("CP") || v.equals("VP") || v.equals("DP") ||
         v.equals("NP") || v.equals("PP") || v.equals("AP") || v.equals("V") ||
         v.equals("N") || v.equals("A") || v.equals("P") || v.equals("Det") ||
         v.equals("Comp") || v.equals("PV") || v.equals("VD") )
    {
      return true;
    }
    return v.toUpperCase().equals(v) && v.length() <= 6;
  }

  public void clearOPNState(GraphEditorWindow activeWindow)
  {
    opnSupport.clear();
    refreshOPNMenuVisibility(activeWindow);
  }

  public void saveOPN(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Save OPN requires an open graph or OPN window.",
                                    "Save OPN",
                                    JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    try
    {
      Graph currentGraph = activeWindow.getGraphEditor().getGraph();
      if ( opnSupport.isSaveAvailableFor(activeWindow) )
      {
        opnSupport.saveResult(graphWindow, currentGraph);
        clearOPNState(activeWindow);
      }
      else
      {
        opnSupport.saveCurrentGraph(graphWindow, currentGraph);
      }
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                    "Error During Save OPN", JOptionPane.ERROR_MESSAGE);
    }
  }

  public void displayOpenGraphTree(final GraphController controller,
                               final GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      clearOPNState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }
      OpenGraphDialog dialog = new OpenGraphDialog( controller,
        editorWindow,
        "OpenGraph Draw",
        "<html>Select structure type, then Draw.</html>" )
      {
        public void actionPerformed(ActionEvent e)
        {
          displayOpenGraphTreeHelper(getOwner(), this);
        }
      };
      dialog.preloadFromEditor(editorWindow.getGraphEditor());
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
    }
  }

  private void displayOpenGraphTreeHelper(GraphEditorWindow editorWindow, OpenGraphDialog dialog)
  {
    try
    {
      GraphEditor graphEditor = editorWindow.getGraphEditor();
      Graph graph = graphEditor.getGraph();
      int rootIndex = OpenGraphRootSelector.getRootIndex(editorWindow);
      graph.newMemento("Display OpenGraph Drawing");

      int structureType = dialog.getStructureType();
      if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_FRAME )
      {
        throw new GraphException("Only Simple, Phrase, and Frame are implemented reliably at the moment.");
      }

      OpenGraphProjectionSettings projectionSettings = OpenGraphProjectionSupport.fromDialog(dialog);
      graphEditor.setOpenGraphProjectionSettings(projectionSettings);
      boolean projectionContext =
        OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType());
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);

      OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
      if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) &&
           gridSettings.getGridMode() == OpenGraphGridSettings.MODE_FIT_CONTENT &&
           gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
      {
        gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
        graphEditor.setOpenGraphGridSettings(gridSettings);
      }
      OpenGraphTreeDrawOperation.displayOpenGraphTreeDrawing(
        graph,
        graph.getNodeAt(rootIndex),
        dialog.getSelectedMethodNumber(),
        dialog.getStructureOffsetFromLeft(),
        dialog.getStructureOffsetFromTop(),
        gridSettings.getCellWidth(),
        gridSettings.getCellHeight(),
        graphEditor.getDrawWidth(),
        graphEditor.getDrawHeight(),
        structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
        structureType == OpenGraphDialog.STRUCTURE_FRAME ||
        structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE,
        structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE );
      graphEditor.changeToOpenGraphGridMode(gridSettings);
      centerVisibleContentInWindow(graphEditor);
      if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
      {
        graphEditor.rememberLanguageProjectionSettings(projectionSettings);
      }
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);
      graphEditor.resetTransientEditorArtifacts();
      graphEditor.update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.closeDialogAndClearOwner(editorWindow);
      graph.doneMemento();
      graphEditorActions.updateUndo(editorWindow);
      opnSupport.rememberResult(editorWindow, graph);
      refreshOPNMenuVisibility(editorWindow);
    }
    catch ( Exception e )
    {
      reportOpenGraphDisplayError(e);

      try
      {
        Graph graph = editorWindow.getGraphEditor().getGraph();
        if ( graph != null )
        {
          graph.undoMemento();
          graph.abortMemento();
        }
      }
      catch ( Exception ignored )
      {
      }

      JOptionPane.showMessageDialog(graphWindow, errorMessage(e),
                                    "Error During OpenGraph Drawing Display", JOptionPane.ERROR_MESSAGE);
    }
  }

  private void reportOpenGraphDisplayError(Exception e)
  {
    System.err.println("[OpenGraph] Error During OpenGraph Drawing Display: " + errorMessage(e));
    if ( e != null )
    {
      e.printStackTrace(System.err);
    }
  }

  private String errorMessage(Exception e)
  {
    if ( e == null )
    {
      return "Unknown OpenGraph error";
    }
    if ( e.getMessage() != null && e.getMessage().length() > 0 )
    {
      return e.getMessage();
    }
    return e.getClass().getName();
  }
}
