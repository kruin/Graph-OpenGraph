Mapping v3 testbestand.

Doel:
- MAPPING_V3 tonen in Info.
- Best placement rules valideren.
- Een beste gegenereerde uiting tonen plus alternatieven.

Verwachte Info-samenvatting ongeveer:
OPN Mapping v3: 7 lexical items, 1 verb domains, 11 placement rules; validation: ...; generated: best: gisteren vrouw niet heeft trui gebreid daar; alternatives: ...
