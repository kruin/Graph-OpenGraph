Mapping v3 NEG-after-AUX testbestand.

Open:
  voorbeeldzin-met-bijwoorden.lexical-axis-view.mapping-v3-neg-after-aux.opn

Verwachte Info-samenvatting ongeveer:
  OPN Mapping v3: 7 lexical items, 1 verb domains, 12 placement rules; validation: 7 ok, 0 fail; generated: best: gisteren vrouw heeft niet trui gebreid daar; alternatives: ...

Opmerking:
  NEG is hier niet langer before V-AUX, maar canoniek after AUX en before Patiens.
