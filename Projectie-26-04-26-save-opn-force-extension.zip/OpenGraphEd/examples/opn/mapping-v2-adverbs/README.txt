Test file:
  voorbeeldzin-met-bijwoorden.lexical-axis-view.mapping-v2.opn

Expected Info tail:
  OPN Mapping v2: 7 lexical items, 1 verb domains, 7 placement rules; validation: 7 ok, 0 fail; generated: gisteren vrouw niet heeft trui gebreid daar
