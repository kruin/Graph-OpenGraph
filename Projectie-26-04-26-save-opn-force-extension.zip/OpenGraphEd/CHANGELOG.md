## 2026-04-18 — Move-mode edge midpoint cleanup

### Fixed
- ordinary undirected edge midpoint markers are now hidden while the editor is in **Move** mode
- the suppression applies both to the buffered graph image and to temporary redraw overlays during transforms

### Scope
- directed edge arrows are unchanged
- projection rendering is unchanged
- midpoint markers still remain available outside Move mode

## 2026-04-18 — First projection slice follow-up

### Included
- Sources-led markdown files restored into the package root
- first projection slice refined for phrase trees
- rebuilt `OpenGraphEd.jar` and `dist/OpenGraphEd.jar`

### Changed
- default phrase-tree projections now enable **LEX left** and **SYN right**
- right-side projection labels are now computed from ordered child labels
- simple JAN convention for this slice: first child uppercase, following children lowercase, joined with `, `
- bottom logical projection rendering is limited to source nodes that already carry explicit logical labels
- phrase-tree UI copy updated to describe the current first slice

### Layout
- fitted OpenGraph grid no longer expands the structure grid for projection bands or projection labels
- projection visibility is handled through render/visible bounds rather than structure-grid growth

- 2026-04-17: Moved `Set Default Graph Dir` into the Load Graph dialog accessory and removed the now-redundant File menu item.
- 2026-04-17: Removed the duplicate File menu checkbox for starting Load Graph in the Graph directory. The option remains available in the Load Graph dialog; the separate File menu item was redundant.
# Changelog

## 2026-04-02 — Stable refactor baseline

Stable baseline:

**OpenGraphEd_refactor_phase33_pq_lifecycle_support_2026-04-02**

### Included

#### Naming and packaging
- project naming standardized to **OpenGraphEd**
- runtime jar standardized as `OpenGraphEd.jar`

#### Controller and UI refactor
- controller responsibilities reduced and split into focused helpers
- file actions isolated
- window/dialog coordination isolated
- menu and toolbar heavily reduced and decomposed
- help/info/log/preferences windows simplified

#### Graph editor refactor
- layout/grid support extracted
- render/transform support extracted
- mode/listener support extracted
- overlay support extracted

#### Graph model refactor
- `Graph` decomposed into focused support classes for:
  - median helpers
  - selection helpers
  - copy helpers
  - bounds helpers
  - grid helpers
  - stats helpers
  - lookup helpers
  - transform helpers
  - persistence helpers
  - extender helpers
  - edge mutation helpers
  - appearance helpers
  - undo helpers
  - log helpers
  - property mutation helpers
  - topology helpers
  - structure mutation helpers

#### Node / Edge refactor
- `Node` split into:
  - incident support
  - geometry support
  - persistence support
- `Edge` split into:
  - cycle support
  - geometry support
  - persistence support

#### Operation refactor
- biconnectivity support extracted
- Chan tree draw support extracted
- embed support extracted
- Schnyder embedding support extracted

#### PQ and file utility partial cleanup
- debug support extracted from `PQNode`
- debug support extracted from `PQTree`
- lifecycle/state support extracted from PQ structures
- GIF palette/color conversion support extracted

### Fixed

#### Biconnectivity display regression
- fixed a regression introduced during refactoring of biconnected component support
- cause: temporary `newEdges` collection was not cleared per component
- result: component display/state corruption
- fix applied and included in stable baseline

### Deliberately not continued
- deep PQ reduction core not further refactored
- PQ template logic not further split
- high-risk algorithmic core intentionally left in place for stability

### Validation
The stable baseline was kept only after repeated successful checks of:

- compile
- jar build
- out folder generation
- undo / redo sanity
- render-after-undo behavior
- display flows
- editor interaction flows

## 2026-04-13

### Menu / file loading
- added `File -> Set Default Graph Dir` to choose the default folder for loading `.graph` files
- `File -> Graph Dir` now uses the chosen default graph directory instead of only the built-in `GRAPH` folder
- default graph directory is persisted in `config/opengraphed_user.properties`
- `Load Graph` accessory now shows the active default graph directory

## 2026-04-16

### Graph file click / direct open
- OpenGraphEd can now start with one or more `.graph` file paths as command-line arguments
- added shared path-based graph loading so startup and file chooser use the same open logic
- updated `run.bat` so `run.bat "bestand.graph"` opens that graph directly
- added `open_graph_file.bat` as a dedicated launcher for a specific `.graph` file
- added `register_graph_file_association.bat` and `unregister_graph_file_association.bat` for Windows double-click association of `.graph` files

### Internal OpenGraph rename
- renamed the internal `Kruin*` module/class/config layer to `OpenGraph*`
- kept the GitHub owner/account name `kruin` unchanged
- renamed OpenGraph settings/config files to `config/opengraph_defaults.properties` and `config/opengraph_user.properties`
- updated source lists, tests, UI labels, dialog titles, grid/projection helpers, and draw operations to the OpenGraph naming line
- rebuilt the project so `out/` and `OpenGraphEd.jar` match the renamed sources

## 2026-04-16 — graph click single-instance fix

- added single-instance forwarding for launches from the same app folder
- later `.graph` double-clicks now open in the existing OpenGraphEd window instead of starting a second app instance
- added `OpenGraphEd.bat` as the named launcher
- updated Windows `.graph` association to use the launcher name `OpenGraphEd (Java, via DOS .batfile)`
- added `create_desktop_shortcut.bat` to create a desktop shortcut with that display name


- 2026-04-17: build.bat made resilient on Windows when OpenGraphEd.jar is locked by a running app; build now keeps refreshed classes in out\ and writes OpenGraphEd.new.jar as fallback instead of failing the whole build.

- 2026-04-17: Move mode in OpenGraph projection context now shifts the visible grid display window together with the graph so projection bands and markers stay attached during drag.

- 2026-04-17: OpenGraph projection labels phase 1 added visible side captions (LEX/SYN/LF/PM) and copied source labels on projection targets; bottom labels now render downward.

- 2026-04-18: projection caption orientation updated: LEX vertical on the left; LF horizontal below projected labels.

## 2026-04-26 — OPN structure loader fix

- Fixed `Open OPN` so metadata is not drawn as graph nodes.
- Current supported demo/test OPN formats:
  - YAML-like `structure.nodes` / `structure.edges`
  - older pipe-delimited `STRUCTURE_NODES` / `STRUCTURE_EDGES`
- `meta`, `notes`, `OPN_VERSION`, and `STRUCTURE_TYPE` are not graph content.
- Included example OPN files for ONBEZIELD bovenboom and the V-centered example sentence.

## 2026-04-26 - OPN mapping v1 visibility
- Added non-drawing support for `MAPPING_V1` sections in pipe-safe OPN files.
- `Open OPN` still draws only `STRUCTURE_NODES` / `STRUCTURE_EDGES`.
- Mapping sections are counted and reported in the Info window as OPN Mapping v1 metadata.
- Added mapping-v1 example OPN files under `examples/opn/mapping-v1/`.

## 2026-04-26 — OPN placement rules v2
- Generalized generator: generated utterance is now derived from `PLACEMENT_RULES` ordering constraints instead of hardcoded role sequence.
- Supported `MAPPING_V2:` / `END_MAPPING_V2:` markers while preserving `MAPPING_V1:` compatibility.
- Current v2 rule relations: `left_of V`, `right_of V`, `realizes_before`, `realizes_after`, plus aliases `before` and `after`.
- Added `examples/opn/mapping-v2/` with the same three views using the v2 markers.

## 2026-04-26 - adverbs-v2 example
- Added mapping-v2 adverb example with TIME, NEG and PLACE lexical items.
- Existing data-driven placement-rule engine is used; graph nodes are not mutated.

2026-04-26: mapping v3 NEG constraint upgraded to after_aux_before_object (V-AUX < NEG < Patiens).
