import java.awt.Frame;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.SwingUtilities;

public class OpenGraphEdSingleInstance
{
  private static final String LOOPBACK_ADDRESS = "127.0.0.1";
  private static final String HANDSHAKE = "OpenGraphEdSingleInstanceV1";
  private static final int CONNECT_TIMEOUT_MS = 400;
  private static final int BASE_PORT = 49152;
  private static final int PORT_RANGE = 16384;

  private ServerSocket serverSocket;
  private Thread listenerThread;

  public static boolean forwardToRunningInstance(String[] graphPaths)
  {
    Socket socket = null;
    DataOutputStream output = null;

    try
    {
      socket = new Socket();
      socket.connect(new InetSocketAddress(InetAddress.getByName(LOOPBACK_ADDRESS), getPort()),
                     CONNECT_TIMEOUT_MS);
      output = new DataOutputStream(socket.getOutputStream());
      output.writeUTF(HANDSHAKE);

      if ( graphPaths == null )
      {
        output.writeInt(0);
      }
      else
      {
        output.writeInt(graphPaths.length);
        for ( int i=0; i<graphPaths.length; i++ )
        {
          output.writeUTF(graphPaths[i] != null ? graphPaths[i] : "");
        }
      }

      output.flush();
      return true;
    }
    catch ( IOException ioe )
    {
      return false;
    }
    finally
    {
      closeQuietly(output);
      closeQuietly(socket);
    }
  }

  public boolean startListening(final OpenGraphEdFrame frame)
  {
    try
    {
      serverSocket = new ServerSocket(getPort(), 50, InetAddress.getByName(LOOPBACK_ADDRESS));
    }
    catch ( IOException ioe )
    {
      return false;
    }

    listenerThread = new Thread(new Runnable()
    {
      public void run()
      {
        listenLoop(frame);
      }
    }, "OpenGraphEd-single-instance-listener");
    listenerThread.setDaemon(true);
    listenerThread.start();
    return true;
  }

  private void listenLoop(final OpenGraphEdFrame frame)
  {
    while ( serverSocket != null && !serverSocket.isClosed() )
    {
      Socket clientSocket = null;
      DataInputStream input = null;

      try
      {
        clientSocket = serverSocket.accept();
        input = new DataInputStream(clientSocket.getInputStream());

        String handshake = input.readUTF();
        if ( !HANDSHAKE.equals(handshake) )
        {
          continue;
        }

        int pathCount = input.readInt();
        final String[] graphPaths = new String[Math.max(pathCount, 0)];
        for ( int i=0; i<graphPaths.length; i++ )
        {
          graphPaths[i] = input.readUTF();
        }

        SwingUtilities.invokeLater(new Runnable()
        {
          public void run()
          {
            frame.handleExternalGraphOpenRequests(graphPaths);
          }
        });
      }
      catch ( IOException ioe )
      {
        if ( serverSocket == null || serverSocket.isClosed() )
        {
          return;
        }
      }
      finally
      {
        closeQuietly(input);
        closeQuietly(clientSocket);
      }
    }
  }

  public static void bringFrameToFront(Frame frame)
  {
    if ( frame == null )
    {
      return;
    }

    frame.setVisible(true);
    frame.setState(Frame.NORMAL);
    frame.toFront();
    frame.requestFocus();
    frame.setAlwaysOnTop(true);
    frame.setAlwaysOnTop(false);
  }

  private static int getPort()
  {
    String canonicalDir = getCanonicalUserDir();
    int normalizedHash = (canonicalDir != null ? canonicalDir.hashCode() : 0) & 0x7fffffff;
    return BASE_PORT + (normalizedHash % PORT_RANGE);
  }

  private static String getCanonicalUserDir()
  {
    try
    {
      return new File(System.getProperty("user.dir", ".")).getCanonicalPath();
    }
    catch ( IOException ioe )
    {
      return System.getProperty("user.dir", ".");
    }
  }

  private static void closeQuietly(Closeable closeable)
  {
    if ( closeable != null )
    {
      try
      {
        closeable.close();
      }
      catch ( IOException ioe ) { }
    }
  }
}
