import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import userInterface.*;

public class OpenGraphEdFrame extends JFrame implements WindowListener
{
  public static final int WIDTH = 1000;//865;//HOW TO SET MAX?
  public static final int HEIGHT = 800;//600;
//GraphEditorWindow = 1150/750
  private GraphController controller;
  private final OpenGraphEdSingleInstance singleInstanceManager;

  public OpenGraphEdFrame() throws Exception
  {
    super(OpenGraphEdAppInfo.APP_NAME);
    controller = new GraphController(true);
    singleInstanceManager = new OpenGraphEdSingleInstance();

    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(controller.getToolBar(), BorderLayout.NORTH);
    getContentPane().add(controller.getGraphWindow(), BorderLayout.CENTER);
    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    setJMenuBar(controller.getMenuBar());
    addWindowListener(this);
    setSize(WIDTH,HEIGHT);
  }

  public boolean startSingleInstanceListener()
  {
    return singleInstanceManager.startListening(this);
  }

  public void showApplicationWindow()
  {
    setVisible(true);
    OpenGraphEdSingleInstance.bringFrameToFront(this);
  }

  public void handleExternalGraphOpenRequests(String[] graphPaths)
  {
    showApplicationWindow();
    openGraphsFromArguments(graphPaths);
  }

  public void openGraphsFromArguments(String[] graphPaths)
  {
    if ( graphPaths == null || graphPaths.length == 0 )
    {
      return;
    }

    for ( int i=0; i<graphPaths.length; i++ )
    {
      String graphPath = graphPaths[i];
      if ( graphPath == null || graphPath.trim().length() == 0 )
      {
        continue;
      }

      File graphFile = new File(graphPath);
      if ( !graphFile.exists() )
      {
        JOptionPane.showMessageDialog(this,
                                      "The requested GRAPH / OPN file does not exist.\n\nPath: " + graphPath,
                                      "GRAPH / OPN file not found",
                                      JOptionPane.ERROR_MESSAGE);
        continue;
      }

      controller.loadGraphFromPath(graphPath);
    }
  }

  public void windowClosing(WindowEvent e)
  {
    if ( controller.hasUnsavedGraphs() )
    {
      int returnInt = JOptionPane.showConfirmDialog(controller.getGraphWindow(),
                      "Are you sure you want to discard all changes to " + 
                      "open graph editor windows ?",
                      OpenGraphEdAppInfo.EXIT_TITLE, JOptionPane.YES_NO_OPTION);
      if ( returnInt == JOptionPane.YES_OPTION )
      {
        System.exit(0);
      }
    }
    else
    {
      System.exit(0);
    }
  }
  
  public void windowActivated(WindowEvent e) { }
  public void windowClosed(WindowEvent e) { }
  public void windowDeactivated(WindowEvent e) { }
  public void windowDeiconified(WindowEvent e) { }
  public void windowIconified(WindowEvent e) { }
  public void windowOpened(WindowEvent e) { }
  
  public GraphController getController() { return controller; }
  
  public static void main(String args[]) throws Exception
  {
    if ( OpenGraphEdSingleInstance.forwardToRunningInstance(args) )
    {
      return;
    }

    OpenGraphEdFrame frame = new OpenGraphEdFrame();
    if ( !frame.startSingleInstanceListener() )
    {
      if ( OpenGraphEdSingleInstance.forwardToRunningInstance(args) )
      {
        frame.dispose();
        return;
      }
    }

    frame.showApplicationWindow();
    frame.openGraphsFromArguments(args);
  }
}
