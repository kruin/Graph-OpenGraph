package operation;

import graphException.*;
import graphStructure.*;
import java.util.Vector;
import operation.extenders.*;

public class OpenGraphTreeDrawOperation
{
  private static final int DEFAULT_DRAWING_OFFSET_X = 4;
  private static final int DEFAULT_DRAWING_OFFSET_Y = 4;
  private static final int DEFAULT_CELL_WIDTH = 20;
  private static final int DEFAULT_CELL_HEIGHT = 20;

  /**
   * Keep one empty grid column between the root axis and each child box.
   * This preserves the open-tree character while keeping the reserved box minimal.
   */
  private static final int ROOT_SIDE_GAP = 1;

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                            int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method,
                            DEFAULT_DRAWING_OFFSET_X,
                            DEFAULT_DRAWING_OFFSET_Y,
                            DEFAULT_CELL_WIDTH, DEFAULT_CELL_HEIGHT,
                            width, height);
  }


  /**
   * Compatibility overload for older callers. Right and bottom structure offsets
   * are intentionally ignored: tree positioning is anchored by left/top only.
   */
  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int rightOffset,
                                             int topOffset, int bottomOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method,
                            leftOffset, topOffset,
                            cellWidth, cellHeight,
                            width, height);
  }
  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height) throws Exception
  {
    boolean oldSpecialSelected = root.isSpecialSelected();
    root.setSpecialSelected(true);
    LogEntry logEntry = g.startLogEntry("OpenGraph Tree Drawing");
    try
    {
      if ( !ConnectivityOperation.isConnected(g) )
      {
        logEntry.setData("Graph was not connected");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph is not connected!");
      }
      else if ( TreeOperation.hasCycles(g) )
      {
        logEntry.setData("Graph had cycles");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph has Cycles!");
      }
      else if ( method != 4 && !TreeOperation.isBinaryTree(g, root) )
      {
        logEntry.setData("Graph was not a Binary Tree");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph is not a Binary Tree!");
      }
      else
      {
        Vector nodes = g.createNodeExtenders(OpenGraphNodeEx.class);
        Vector edges = g.createEdgeExtenders(OpenGraphEdgeEx.class);
        OpenGraphNodeEx rootEx = (OpenGraphNodeEx)root.getExtender();

        buildTree(rootEx);

        if ( method == 1 )
        {
          domainTreeMethod(rootEx);
        }
        else if ( method == 5 )
        {
          logEntry.setData("Method 5 is not implemented reliably");
          g.stopLogEntry(logEntry);
          throw new GraphException("OpenGraph method 5 is not implemented reliably. Use the Simple open-tree renderer.");
        }
        else
        {
          logEntry.setData("Unsupported OpenGraph method: " + method);
          g.stopLogEntry(logEntry);
          throw new GraphException("Unsupported OpenGraph drawing method: " + method);
        }

        int gridWidth = rootEx.getBoundWidth();
        int gridHeight = rootEx.getBoundHeight();

        leftOffset = Math.max(0, leftOffset);
        topOffset = Math.max(0, topOffset);
        cellWidth = Math.max(2, cellWidth);
        cellHeight = Math.max(2, cellHeight);

        correctGridCoordinates(rootEx, leftOffset + rootEx.getBoundX(), topOffset);

        int totalGridCols = gridWidth + leftOffset + 1;
        int totalGridRows = gridHeight + topOffset + 1;

        g.setGrid(totalGridRows, cellHeight,
                  totalGridCols, cellWidth, true);

        OpenGraphNodeEx aNode;
        OpenGraphEdgeEx anEdge;
        for ( int i=0; i<nodes.size(); i++ )
        {
          aNode = (OpenGraphNodeEx)nodes.elementAt(i);
          g.relocateNode(aNode.getRef(),
                         new Location(aNode.getGridX()*cellWidth,
                                      aNode.getGridY()*cellHeight),
                         true);
        }

        for ( int i=0; i<edges.size(); i++ )
        {
          anEdge = (OpenGraphEdgeEx)edges.elementAt(i);
          g.straightenEdge(anEdge.getRef(), true);
        }

        g.stopLogEntry(logEntry);
      }
    }
    finally
    {
      root.setSpecialSelected(oldSpecialSelected);
    }
  }

  private static int buildTree(OpenGraphNodeEx root)
  {
    Vector children = root.getChildren();
    OpenGraphNodeEx child;
    int size = 1;
    for ( int i=0; i<children.size(); i++ )
    {
      child = (OpenGraphNodeEx)children.elementAt(i);
      if ( child != root.getParent() )
      {
        child.setParent(root);
        size += buildTree(child);
      }
    }
    root.setSubTreeSize(size);
    root.setSubTreeDone(false);
    return size;
  }

  private static void domainTreeMethod(OpenGraphNodeEx root)
  {
    OpenGraphNodeEx leftChild = root.getLeftChild();
    OpenGraphNodeEx rightChild = root.getRightChild();

    if ( leftChild == null && rightChild == null )
    {
      initializeLeaf(root);
    }
    else
    {
      if ( leftChild != null )
      {
        domainTreeMethod(leftChild);
      }
      if ( rightChild != null )
      {
        domainTreeMethod(rightChild);
      }

      if ( leftChild != null && rightChild != null )
      {
        if ( !(root.getNode().isSelected()) )
        {
          domainRule(root, leftChild, rightChild);
        }
        else
        {
          /*
           * Do not mutate the actual node label during rendering.
           *
           * The legacy renderer prefixed selected focus nodes with "Focus -"
           * by writing directly into the backing Node. That made each redraw
           * lengthen labels permanently and bypassed the normal label-memento
           * path, so undo could never fully restore the pre-render state.
           *
           * Focus still affects the subtree ordering here, but the visual label
           * is left untouched.
           */
          domainRule(root, rightChild, leftChild);
        }
      }
      else if ( leftChild != null )
      {
        otherRule(root, leftChild);
      }
      else
      {
        otherRule(root, rightChild);
      }
    }
  }

  private static void initializeLeaf(OpenGraphNodeEx root)
  {
    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(0);
    root.setBoundY(0);
    root.setBoundWidth(0);
    root.setBoundHeight(0);
  }

  /**
   * Compact bottom-up box integration for the open tree.
   *
   * Each child first owns its smallest reserved bounding box.
   * The left subtree is placed completely left of the root axis;
   * the right subtree is placed completely right of the root axis and below
   * the reserved left box, so sibling leaves do not collapse onto one line.
   */
  static void domainRule(OpenGraphNodeEx root, OpenGraphNodeEx left, OpenGraphNodeEx right)
  {
    int leftShiftX = -(rightExtent(left) + ROOT_SIDE_GAP);
    int leftShiftY = 1;

    int rightShiftX = leftExtent(right) + ROOT_SIDE_GAP;
    int rightShiftY = leftShiftY + left.getBoundHeight() + 1;

    left.shiftX(leftShiftX);
    left.shiftY(leftShiftY);

    right.shiftX(rightShiftX);
    right.shiftY(rightShiftY);

    int minX = Math.min(0, Math.min(boxMinX(left), boxMinX(right)));
    int maxX = Math.max(0, Math.max(boxMaxX(left), boxMaxX(right)));
    int maxY = Math.max(0, Math.max(boxMaxY(left), boxMaxY(right)));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(-minX);
    root.setBoundY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
  }

  private static void otherRule(OpenGraphNodeEx root, OpenGraphNodeEx child)
  {
    child.shiftY(1);

    int minX = Math.min(0, boxMinX(child));
    int maxX = Math.max(0, boxMaxX(child));
    int maxY = Math.max(0, boxMaxY(child));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
    root.setBoundX(-minX);
    root.setBoundY(0);
  }

  private static int leftExtent(OpenGraphNodeEx node)
  {
    return node.getBoundX();
  }

  private static int rightExtent(OpenGraphNodeEx node)
  {
    return node.getBoundWidth() - node.getBoundX();
  }

  private static int boxMinX(OpenGraphNodeEx node)
  {
    return node.getGridX() - node.getBoundX();
  }

  private static int boxMaxX(OpenGraphNodeEx node)
  {
    return node.getGridX() + node.getBoundWidth() - node.getBoundX();
  }

  private static int boxMaxY(OpenGraphNodeEx node)
  {
    return node.getGridY() + node.getBoundHeight();
  }

  private static void correctGridCoordinates(OpenGraphNodeEx root, int shiftX, int shiftY)
  {
    root.shiftX(shiftX);
    root.shiftY(shiftY);
    if ( root.getLeftChild() != null )
    {
      correctGridCoordinates(root.getLeftChild(), root.getGridX(), root.getGridY());
    }
    if ( root.getRightChild() != null )
    {
      correctGridCoordinates(root.getRightChild(), root.getGridX(), root.getGridY());
    }
  }
}
