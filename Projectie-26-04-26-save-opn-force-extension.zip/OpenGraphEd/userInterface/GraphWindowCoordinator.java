package userInterface;

public class GraphWindowCoordinator
{
  private final GraphWindow graphWindow;

  public GraphWindowCoordinator(GraphWindow graphWindow)
  {
    this.graphWindow = graphWindow;
  }

  public void showPreferences(GraphController controller)
  {
    graphWindow.show(new GraphEditorPreferencesWindow(controller));
  }

  public void showHelp(GraphController controller)
  {
    graphWindow.show(new GraphEditorHelpWindow(controller));
  }

  public void showInfo(GraphEditorWindow window)
  {
    if ( window != null )
    {
      graphWindow.showInfo(window);
    }
  }

  public void showLog(GraphEditorWindow window)
  {
    if ( window != null )
    {
      graphWindow.showLog(window);
    }
  }

  public void closeOwnedWindows(GraphEditorWindow window)
  {
    if ( window == null )
    {
      return;
    }

    GraphEditorDialog dialog = window.getDialog();
    if ( dialog != null )
    {
      window.setDialog(null);
      dialog.setOwner(null);
      graphWindow.close(dialog);
    }

    if ( window.getInfoWindow().isVisible() )
    {
      graphWindow.closeInfo(window.getInfoWindow());
    }

    if ( window.getLogWindow().isVisible() )
    {
      graphWindow.closeLog(window.getLogWindow());
    }
  }

  public void releaseDialogAfterClose(GraphEditorDialog dialog)
  {
    if ( dialog != null && dialog.getOwner() != null )
    {
      dialog.getOwner().getGraphEditor().allowNodeSelection(0);
      dialog.getOwner().setDialog(null);
      graphWindow.activate(dialog.getOwner());
      dialog.setOwner(null);
    }
  }

  public void closeCurrentDialog(GraphEditorWindow window)
  {
    if ( window != null && window.getDialog() != null )
    {
      graphWindow.close(window.getDialog());
    }
  }

  public void closeDialogAndClearOwner(GraphEditorWindow window)
  {
    if ( window != null && window.getDialog() != null )
    {
      graphWindow.close(window.getDialog());
      window.setDialog(null);
    }
  }

  public void attachAndShowDialog(GraphEditorWindow window, GraphEditorDialog dialog)
  {
    if ( window == null || dialog == null )
    {
      return;
    }

    window.setDialog(dialog);
    graphWindow.showDialog(dialog);
  }
}
