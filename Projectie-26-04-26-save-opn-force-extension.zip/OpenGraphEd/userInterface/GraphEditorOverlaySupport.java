package userInterface;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.QuadCurve2D;
import java.awt.geom.Rectangle2D;
import graphStructure.Edge;
import graphStructure.Location;
import graphStructure.Node;

/**
 * Overlay preview and mode-specific shape support for {@link GraphEditor}.
 *
 * <p>The editor delegates transient preview shapes and their painting here so
 * that resize, rotate, edit and grid previews remain isolated from the core
 * editor orchestration.</p>
 */
public class GraphEditorOverlaySupport
{
  private final GraphEditor editor;
  private final GraphEditorOverlayState state;

  public GraphEditorOverlaySupport(GraphEditor editor, GraphEditorOverlayState state)
  {
    this.editor = editor;
    this.state = state;
  }

  public void initShapes()
  {
    state.setLineToDraw(null);
    state.setPointToDraw(null);
    state.setRectangleToDraw(null);
    state.setPolygonToDraw(null);
    state.setCurveToDraw(null);
  }

  public void setLineToDraw(Line2D.Double lineToDraw)
  {
    state.setLineToDraw(lineToDraw);
  }

  public void setLineToDrawColor(Color color)
  {
    state.setLineToDrawColor(color);
  }

  public void setPointToDraw(Ellipse2D.Double pointToDraw)
  {
    state.setPointToDraw(pointToDraw);
  }

  public void setRectangleToDraw(Rectangle2D.Double rectangleToDraw)
  {
    state.setRectangleToDraw(rectangleToDraw);
  }

  public Rectangle2D.Double getRectangleToDraw()
  {
    return state.getRectangleToDraw();
  }

  public void setPolygonToDraw(Polygon polygonToDraw)
  {
    state.setPolygonToDraw(polygonToDraw);
  }

  public Polygon getPolygonToDraw()
  {
    return state.getPolygonToDraw();
  }

  public void setPolygonToDrawColor(Color color)
  {
    state.setPolygonToDrawColor(color);
  }

  public void setCurveToDraw(QuadCurve2D.Double curveToDraw)
  {
    state.setCurveToDraw(curveToDraw);
  }

  public QuadCurve2D.Double getCurveToDraw()
  {
    return state.getCurveToDraw();
  }

  public void setCurveToDrawColor(Color color)
  {
    state.setCurveToDrawColor(color);
  }

  public void updateShapes()
  {
    if ( editor.isInGridMode() )
    {
      editor.getGraph().setDrawGrid(true);
    }
    else if ( editor.isInResizeMode() )
    {
      updateResizeShapes();
    }
    else if ( editor.isInRotateMode() )
    {
      updateRotateShapes();
    }
    else
    {
      state.setPointToDraw(null);
      state.setRectangleToDraw(null);
      editor.getGraph().setDrawGrid(false);
    }
  }

  public void paintOverlayShapes(Graphics2D g2)
  {
    if ( state.getRectangleToDraw() != null )
    {
      g2.setStroke(new BasicStroke((float)Edge.THICKNESS));
      g2.setColor(Color.green);
      g2.draw(state.getRectangleToDraw());
    }
    if ( state.getPolygonToDraw() != null )
    {
      g2.setStroke(new BasicStroke((float)Edge.THICKNESS));
      g2.setColor(state.getPolygonToDrawColor());
      g2.fill(state.getPolygonToDraw());
    }
    if ( state.getCurveToDraw() != null )
    {
      g2.setStroke(new BasicStroke((float)Edge.THICKNESS));
      g2.setColor(state.getCurveToDrawColor());
      g2.draw(state.getCurveToDraw());
    }
    if ( state.getLineToDraw() != null )
    {
      paintLineOverlay(g2);
    }
    if ( state.getPointToDraw() != null )
    {
      g2.setStroke(new BasicStroke((float)Node.LINE_THICKNESS));
      g2.setColor(Color.green);
      g2.draw(state.getPointToDraw());
    }
  }

  private void updateResizeShapes()
  {
    if ( editor.getGraph().getNumNodes() > 1 )
    {
      Rectangle2D.Double rectangleToDraw = editor.getGraph().getBounds(2, 2);
      rectangleToDraw.setRect(rectangleToDraw.getX() + GraphEditor.DRAW_BUFFER - 1,
                              rectangleToDraw.getY() + GraphEditor.DRAW_BUFFER - 1,
                              rectangleToDraw.getWidth(),
                              rectangleToDraw.getHeight());
      state.setRectangleToDraw(rectangleToDraw);
    }
    else
    {
      state.setRectangleToDraw(null);
    }
    state.setPointToDraw(null);
    editor.getGraph().setDrawGrid(false);
  }

  private void updateRotateShapes()
  {
    if ( editor.getGraph().getNumNodes() > 1 )
    {
      Location location = editor.getGraph().getCenterPointLocation();
      state.setPointToDraw(new Ellipse2D.Double(location.intX() - Node.RADIUS + GraphEditor.DRAW_BUFFER,
                                                location.intY() - Node.RADIUS + GraphEditor.DRAW_BUFFER,
                                                Node.RADIUS * 2,
                                                Node.RADIUS * 2));
    }
    else
    {
      state.setPointToDraw(null);
    }
    state.setRectangleToDraw(null);
    editor.getGraph().setDrawGrid(false);
  }

  private void paintLineOverlay(Graphics2D g2)
  {
    Line2D.Double lineToDraw = state.getLineToDraw();
    if ( lineToDraw.getX2() < GraphEditor.DRAW_BUFFER ||
         lineToDraw.getX2() > editor.getWidth() - GraphEditor.DRAW_BUFFER ||
         lineToDraw.getY2() < GraphEditor.DRAW_BUFFER ||
         lineToDraw.getY2() > editor.getHeight() - GraphEditor.DRAW_BUFFER )
    {
      float dash1[] = {(float)Edge.GENERATED_DASH_LENGTH};
      g2.setStroke(new BasicStroke((float)Edge.THICKNESS,
                                   BasicStroke.CAP_BUTT,
                                   BasicStroke.JOIN_MITER,
                                   10.0f, dash1, 0.0f));
    }
    else
    {
      g2.setStroke(new BasicStroke((float)Edge.THICKNESS));
    }
    g2.setColor(state.getLineToDrawColor());
    g2.draw(lineToDraw);
  }
}
