package userInterface;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import dataStructure.DoublyLinkedList;

public class GraphEditorHelpSupport
{
  private final JTree contentsTree;
  private final JEditorPane contentPane;
  private final JToolBar toolBar;
  private final DoublyLinkedList pageList;
  private final JButton backButton;
  private final JButton upButton;
  private final JButton forwardButton;
  private boolean navigation;

  public GraphEditorHelpSupport(ActionListener actionListener,
                                TreeSelectionListener treeSelectionListener,
                                HyperlinkListener hyperlinkListener)
  {
    navigation = false;

    toolBar = new JToolBar();
    toolBar.setFloatable(false);

    backButton = createToolbarButton("/images/Back.gif",
      "Move Back to the Previously Viewed Page", false, actionListener);
    upButton = createToolbarButton("/images/Up.gif",
      "Move Up One Page in the Contents Tree", false, actionListener);
    forwardButton = createToolbarButton("/images/Forward.gif",
      "Move Forward to a Recently Viewed Page", false, actionListener);

    toolBar.add(backButton);
    toolBar.add(upButton);
    toolBar.add(forwardButton);

    pageList = new DoublyLinkedList();

    contentsTree = buildContentsTree();
    contentsTree.getSelectionModel().setSelectionMode(
      TreeSelectionModel.SINGLE_TREE_SELECTION);
    contentsTree.addTreeSelectionListener(treeSelectionListener);

    contentPane = new JEditorPane();
    contentPane.setEditable(false);
    contentPane.addHyperlinkListener(hyperlinkListener);
    openInitialPage();
    pageList.enqueue((GraphEditorHelpLink)((DefaultMutableTreeNode)
      contentsTree.getModel().getRoot()).getUserObject());
  }

  public JToolBar getToolBar()
  {
    return toolBar;
  }

  public JSplitPane createSplitPane()
  {
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
      GraphEditorWindowUiSupport.createScrollPane(contentsTree),
      GraphEditorWindowUiSupport.createScrollPane(contentPane));
    splitPane.setOneTouchExpandable(true);
    splitPane.setResizeWeight(0.3);
    return splitPane;
  }

  public void handleHyperlinkUpdate(HyperlinkEvent e)
  {
    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
    {
      try
      {
        contentsTree.getSelectionModel().setSelectionPath(pathForLink(e.getURL()));
      }
      catch ( Exception ex )
      {
        ex.printStackTrace();
      }
    }
  }

  public void handleValueChanged()
  {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)
      contentsTree.getLastSelectedPathComponent();
    if (node != null)
    {
      GraphEditorHelpLink linkAndDesc = (GraphEditorHelpLink)node.getUserObject();
      if ( linkAndDesc.getURL() != null )
      {
        try
        {
          if ( !navigation )
          {
            pageList.enqueueAfterCurrent(linkAndDesc);
          }
          else
          {
            navigation = false;
          }
          contentPane.setPage(linkAndDesc.getURL());
          updateNavigationButtons();
        }
        catch ( java.io.IOException ioe )
        {
          ioe.printStackTrace();
        }
      }
    }
  }

  public void handleAction(Object source)
  {
    if ( source == backButton )
    {
      if ( pageList.hasPrev() )
      {
        navigation = true;
        pageList.toPrev();
        GraphEditorHelpLink link = (GraphEditorHelpLink)pageList.getCurrent();
        contentsTree.getSelectionModel().setSelectionPath(pathForLink(link.getURL()));
      }
    }
    else if ( source == forwardButton )
    {
      if ( pageList.hasNext() )
      {
        navigation = true;
        pageList.toNext();
        GraphEditorHelpLink link = (GraphEditorHelpLink)pageList.getCurrent();
        contentsTree.getSelectionModel().setSelectionPath(pathForLink(link.getURL()));
      }
    }
    else if ( source == upButton )
    {
      GraphEditorHelpLink link = (GraphEditorHelpLink)
        ((DefaultMutableTreeNode)((DefaultMutableTreeNode)contentsTree.
        getLastSelectedPathComponent()).getParent()).getUserObject();
      contentsTree.getSelectionModel().setSelectionPath(pathForLink(link.getURL()));
    }
  }

  private JButton createToolbarButton(String imagePath, String toolTip,
                                      boolean enabled,
                                      ActionListener actionListener)
  {
    JButton button = new JButton(new ImageIcon(
      GraphEditorHelpSupport.class.getResource(imagePath)));
    button.setToolTipText(toolTip);
    button.setEnabled(enabled);
    button.addActionListener(actionListener);
    return button;
  }

  private void openInitialPage()
  {
    try
    {
      contentPane.setPage(GraphEditorHelpSupport.class.getResource("/help/index.htm"));
    }
    catch (Exception e)
    {
      System.out.println("Couldn't create help URL: " + "/help/index.htm");
    }
  }

  private JTree buildContentsTree()
  {
    try
    {
      DefaultMutableTreeNode root, nodeOne, nodeTwo, nodeThree;
      root = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/index.htm"),
        "OpenGraphEd Help Contents"));

      nodeOne = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/using.htm"),
        "Using OpenGraphEd"));
      root.add(nodeOne);
      nodeTwo = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/commands.htm"),
        "Commands - ToolBar Button and Menu Items"));
      nodeOne.add(nodeTwo);
      nodeTwo = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/modes.htm"),
        "Modes of Operation"));
      nodeOne.add(nodeTwo);
      nodeThree = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/edit.htm"),
        "Edit Mode"));
      nodeTwo.add(nodeThree);
      nodeThree = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/move.htm"),
        "Move Mode"));
      nodeTwo.add(nodeThree);
      nodeThree = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/rotate.htm"),
        "Rotate Mode"));
      nodeTwo.add(nodeThree);
      nodeThree = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/resize.htm"),
        "Resize Mode"));
      nodeTwo.add(nodeThree);
      nodeTwo = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/preferences.htm"),
        "Preferences"));
      nodeOne.add(nodeTwo);

      nodeOne = new DefaultMutableTreeNode(new GraphEditorHelpLink(
        GraphEditorHelpSupport.class.getResource("/help/about.htm"),
        "About OpenGraphEd"));
      root.add(nodeOne);

      return new JTree(root);
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      return new JTree();
    }
  }

  private TreePath pathForLink(URL url)
  {
    TreeNode treeNode = nodeForLink(url);
    return new TreePath(((DefaultTreeModel)contentsTree.getModel()).getPathToRoot(treeNode));
  }

  private TreeNode nodeForLink(URL url)
  {
    return findNodeWithLink((DefaultMutableTreeNode)contentsTree.getModel().getRoot(), url);
  }

  private TreeNode findNodeWithLink(DefaultMutableTreeNode parentNode, URL url)
  {
    if ( parentNode.getUserObject().equals(url) )
    {
      return parentNode;
    }
    else
    {
      TreeNode childNode;
      for ( int i=0; i<parentNode.getChildCount(); i++ )
      {
        childNode = findNodeWithLink((DefaultMutableTreeNode)parentNode.getChildAt(i), url);
        if ( childNode != null )
        {
          return childNode;
        }
      }
      return null;
    }
  }

  private void updateNavigationButtons()
  {
    backButton.setEnabled(pageList.hasPrev());
    forwardButton.setEnabled(pageList.hasNext());
    upButton.setEnabled(!((DefaultMutableTreeNode)
      contentsTree.getLastSelectedPathComponent()).isRoot());
  }
}

class GraphEditorHelpLink
{
  private String title;
  private URL url;

  public GraphEditorHelpLink(URL url, String title)
  {
    this.title = title;
    this.url = url;
  }

  public String getTitle() { return title; }
  public URL getURL() { return url; }

  public boolean equals(Object o)
  {
    if ( url == null )
    {
      return false;
    }
    return url.equals(o);
  }

  public String toString() { return title; }
}
