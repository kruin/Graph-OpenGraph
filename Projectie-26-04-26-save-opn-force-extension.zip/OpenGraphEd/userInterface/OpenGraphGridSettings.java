package userInterface;

/**
 * Stores the visual display settings for OpenGraphGrid.
 *
 * The grid can either fill the entire editor window, or float around the
 * rendered content with separately configurable margins per side.
 */
public class OpenGraphGridSettings
{
  public static final int MODE_FULL_WINDOW = 1;
  public static final int MODE_FIT_CONTENT = 2;

  public static final int SCOPE_STRUCTURE_ONLY = 1;
  public static final int SCOPE_STRUCTURE_AND_PROJECTIONS = 2;
  public static final int SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS = 3;

  private int gridMode;
  private int fitScope;
  private int marginLeftLines;
  private int marginRightLines;
  private int marginTopLines;
  private int marginBottomLines;
  private int cellWidth;
  private int cellHeight;

  public OpenGraphGridSettings()
  {
    resetToDefaults();
  }

  public OpenGraphGridSettings(OpenGraphGridSettings other)
  {
    if ( other == null )
    {
      resetToDefaults();
    }
    else
    {
      gridMode = other.gridMode;
      fitScope = other.fitScope;
      marginLeftLines = other.marginLeftLines;
      marginRightLines = other.marginRightLines;
      marginTopLines = other.marginTopLines;
      marginBottomLines = other.marginBottomLines;
      cellWidth = other.cellWidth;
      cellHeight = other.cellHeight;
      normalize();
    }
  }

  public void resetToDefaults()
  {
    gridMode = MODE_FIT_CONTENT;
    fitScope = SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS;
    marginLeftLines = 1;
    marginRightLines = 1;
    marginTopLines = 1;
    marginBottomLines = 1;
    cellWidth = 20;
    cellHeight = 20;
    normalize();
  }

  public OpenGraphGridSettings copy()
  {
    return new OpenGraphGridSettings(this);
  }

  public void normalize()
  {
    if ( gridMode != MODE_FULL_WINDOW && gridMode != MODE_FIT_CONTENT )
    {
      gridMode = MODE_FIT_CONTENT;
    }
    if ( fitScope < SCOPE_STRUCTURE_ONLY || fitScope > SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
    {
      fitScope = SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS;
    }
    marginLeftLines = Math.max(0, marginLeftLines);
    marginRightLines = Math.max(0, marginRightLines);
    marginTopLines = Math.max(0, marginTopLines);
    marginBottomLines = Math.max(0, marginBottomLines);
    cellWidth = Math.max(2, cellWidth);
    cellHeight = Math.max(2, cellHeight);
  }

  public int getGridMode() { return gridMode; }
  public void setGridMode(int gridMode) { this.gridMode = gridMode; normalize(); }

  public int getFitScope() { return fitScope; }
  public void setFitScope(int fitScope) { this.fitScope = fitScope; normalize(); }

  public int getMarginLeftLines() { return marginLeftLines; }
  public void setMarginLeftLines(int marginLeftLines) { this.marginLeftLines = marginLeftLines; normalize(); }

  public int getMarginRightLines() { return marginRightLines; }
  public void setMarginRightLines(int marginRightLines) { this.marginRightLines = marginRightLines; normalize(); }

  public int getMarginTopLines() { return marginTopLines; }
  public void setMarginTopLines(int marginTopLines) { this.marginTopLines = marginTopLines; normalize(); }

  public int getMarginBottomLines() { return marginBottomLines; }
  public void setMarginBottomLines(int marginBottomLines) { this.marginBottomLines = marginBottomLines; normalize(); }

  public int getCellWidth() { return cellWidth; }
  public void setCellWidth(int cellWidth) { this.cellWidth = cellWidth; normalize(); }

  public int getCellHeight() { return cellHeight; }
  public void setCellHeight(int cellHeight) { this.cellHeight = cellHeight; normalize(); }
}
