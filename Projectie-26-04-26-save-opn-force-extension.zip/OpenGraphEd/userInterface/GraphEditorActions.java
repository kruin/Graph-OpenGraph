package userInterface;

import graphStructure.*;
import operation.*;
import userInterface.menuAndToolBar.*;

public class GraphEditorActions
{
  private final GraphWindow graphWindow;
  private final MenuAndToolBar menuAndToolBar;

  public GraphEditorActions(GraphWindow graphWindow, MenuAndToolBar menuAndToolBar)
  {
    this.graphWindow = graphWindow;
    this.menuAndToolBar = menuAndToolBar;
  }

  public void changeToEditMode(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().changeToEditMode();
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
    }
  }

  public void changeToGridMode(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().changeToGridMode();
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
    }
  }

  public void changeToOpenGraphGridMode(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      GraphEditor editor = editorWindow.getGraphEditor();
      OpenGraphGridModeDialog dialog = new OpenGraphGridModeDialog(graphWindow, editor.getOpenGraphGridSettings());
      dialog.setVisible(true);
      if ( dialog.isApproved() )
      {
        OpenGraphGridSettings settings = dialog.getOpenGraphGridSettings();
        editor.setOpenGraphGridSettings(settings);
        editor.changeToOpenGraphGridMode(settings);
        menuAndToolBar.showControls(editor);
        graphWindow.repaint();
      }
    }
  }

  public void changeToMoveMode(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().changeToMoveMode();
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      graphWindow.repaint();
    }
  }

  public void changeToRotateMode(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().changeToRotateMode();
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
    }
  }

  public void changeToResizeMode(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().changeToResizeMode();
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
    }
  }

  public void toggleUndo(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.setTrackUndos(!graph.getTrackUndos());
      menuAndToolBar.updateUndo(graph);
    }
  }

  public void undo(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().undo();
      updateUndo(editorWindow);
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      editorWindow.getGraphEditor().update();
    }
  }

  public void redo(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().redo();
      updateUndo(editorWindow);
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      editorWindow.getGraphEditor().update();
    }
  }

  public void updateUndo(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      menuAndToolBar.updateUndo(editorWindow.getGraphEditor().getGraph());
    }
  }

  public void unselectAll(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().getGraph().unselectAll();
      editorWindow.getGraphEditor().repaint();
    }
  }

  public void removeSelected(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Remove Selected", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        graph.deleteSelected();
      }
    });
  }

  public void removeAll(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Remove All", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        graph.deleteAll();
      }
    });
  }

  public void removeGenerated(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Remove Generated Edges", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        graph.deleteGeneratedEdges();
      }
    });
  }

  public void preserveGenerated(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Make Generated Edges Permanent", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        graph.makeGeneratedEdgesPermanent();
      }
    });
  }

  public void showCoords(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.setShowCoords(true);
      graph.setShowLabels(false);
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      editorWindow.repaint();
    }
  }

  public void showLabels(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.setShowCoords(false);
      graph.setShowLabels(true);
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      editorWindow.repaint();
    }
  }

  public void showNothing(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.setShowCoords(false);
      graph.setShowLabels(false);
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      editorWindow.repaint();
    }
  }

  public void resetDisplay(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Reset To Default Display", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        graph.resetColors(true);
      }
    });
  }

  public void displayDFS(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      showLabels(editorWindow);
      applySimpleGraphChange(editorWindow, "Display Depth First Search", new GraphMutation()
      {
        public void apply(Graph graph)
        {
          DepthFirstSearchOperation.displayDepthFirstSearch(graph);
        }
      });
    }
  }

  public void displayBiconnected(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Display Biconnected Components", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        BiconnectivityOperation.displayBiconnectedComponents(graph);
      }
    });
  }

  public void displayMST(GraphEditorWindow editorWindow)
  {
    applySimpleGraphChange(editorWindow, "Display Minimum Spanning Tree", new GraphMutation()
    {
      public void apply(Graph graph)
      {
        MinimumSpanningTreeOperation.drawMinimumSpanningTree(graph);
      }
    });
  }

  private void applySimpleGraphChange(GraphEditorWindow editorWindow, String mementoName, GraphMutation mutation)
  {
    if ( editorWindow != null )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.newMemento(mementoName);
      mutation.apply(graph);
      graph.doneMemento();
      updateUndo(editorWindow);
      editorWindow.getGraphEditor().update();
    }
  }

  private static interface GraphMutation
  {
    void apply(Graph graph);
  }
}
