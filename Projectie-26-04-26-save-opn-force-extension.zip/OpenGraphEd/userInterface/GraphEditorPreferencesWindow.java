package userInterface;

import java.awt.event.*;

public class GraphEditorPreferencesWindow extends OpenGraphEdInternalFrame
                                          implements ActionListener
{
  public static int WIDTH = 400;
  public static int HEIGHT = 400;

  private final GraphEditorPreferencesSupport preferencesSupport;

  public GraphEditorPreferencesWindow(GraphController controller)
  {
    super(controller, OpenGraphEdAppInfo.PREFERENCES_TITLE,
          true, true, true, false);
    preferencesSupport = new GraphEditorPreferencesSupport(controller,
      getContentPane(), this);

    addInternalFrameListener(controller);
    setSize(WIDTH, HEIGHT);
    setVisible(true);
  }

  public void actionPerformed(ActionEvent e)
  {
    preferencesSupport.handleAction(e.getSource());
  }
}
