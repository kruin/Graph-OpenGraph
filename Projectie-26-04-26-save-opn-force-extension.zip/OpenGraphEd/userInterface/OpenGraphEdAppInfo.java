package userInterface;

public final class OpenGraphEdAppInfo
{
  public static final String APP_NAME = "OpenGraphEd";
  public static final String HELP_TITLE = APP_NAME + " Help";
  public static final String PREFERENCES_TITLE = APP_NAME + " Preferences";
  public static final String EXIT_TITLE = "Exit " + APP_NAME;

  private OpenGraphEdAppInfo()
  {
  }
}
