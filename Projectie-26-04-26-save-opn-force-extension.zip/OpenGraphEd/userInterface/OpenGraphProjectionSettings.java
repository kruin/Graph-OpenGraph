package userInterface;

/**
 * Runtime settings for OpenGraph projection rendering.
 *
 * <p>These are kept separate from the grid settings so the layout logic can
 * decide independently whether the fitted grid should cover only the tree,
 * the tree plus projection bands, or the tree plus projection labels.</p>
 */
public class OpenGraphProjectionSettings
{
  private int structureType;
  private boolean showProjections;
  private boolean leftProjectionEnabled;
  private boolean rightProjectionEnabled;
  private boolean topProjectionEnabled;
  private boolean bottomProjectionEnabled;
  private int leftProjectionPosition;
  private int rightProjectionPosition;
  private int topProjectionPosition;
  private int bottomProjectionPosition;

  public OpenGraphProjectionSettings()
  {
    resetToDefaults();
  }

  public OpenGraphProjectionSettings(OpenGraphProjectionSettings other)
  {
    if ( other == null )
    {
      resetToDefaults();
    }
    else
    {
      structureType = other.structureType;
      showProjections = other.showProjections;
      leftProjectionEnabled = other.leftProjectionEnabled;
      rightProjectionEnabled = other.rightProjectionEnabled;
      topProjectionEnabled = other.topProjectionEnabled;
      bottomProjectionEnabled = other.bottomProjectionEnabled;
      leftProjectionPosition = other.leftProjectionPosition;
      rightProjectionPosition = other.rightProjectionPosition;
      topProjectionPosition = other.topProjectionPosition;
      bottomProjectionPosition = other.bottomProjectionPosition;
      normalize();
    }
  }

  public void resetToDefaults()
  {
    structureType = OpenGraphDialog.STRUCTURE_FRAME;
    showProjections = true;
    leftProjectionEnabled = true;
    rightProjectionEnabled = true;
    topProjectionEnabled = false;
    bottomProjectionEnabled = true;
    leftProjectionPosition = 2;
    rightProjectionPosition = 30;
    topProjectionPosition = 0;
    bottomProjectionPosition = 30;
    normalize();
  }

  public OpenGraphProjectionSettings copy()
  {
    return new OpenGraphProjectionSettings(this);
  }

  public void normalize()
  {
    if ( structureType < OpenGraphDialog.STRUCTURE_SIMPLE_TREE ||
         structureType > OpenGraphDialog.STRUCTURE_FRAME )
    {
      structureType = OpenGraphDialog.STRUCTURE_FRAME;
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      showProjections = false;
      leftProjectionEnabled = false;
      rightProjectionEnabled = false;
      topProjectionEnabled = false;
      bottomProjectionEnabled = false;
    }
  }

  public boolean isLexicalProjectionActive()
  {
    return isProjectionCapableStructureType(structureType) && showProjections &&
           (leftProjectionEnabled || rightProjectionEnabled || topProjectionEnabled || bottomProjectionEnabled);
  }

  public static boolean isProjectionCapableStructureType(int structureType)
  {
    return structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
           structureType == OpenGraphDialog.STRUCTURE_FRAME;
  }

  public int getStructureType() { return structureType; }
  public void setStructureType(int structureType) { this.structureType = structureType; normalize(); }

  public boolean getShowProjections() { return showProjections; }
  public void setShowProjections(boolean showProjections) { this.showProjections = showProjections; normalize(); }

  public boolean getLeftProjectionEnabled() { return leftProjectionEnabled; }
  public void setLeftProjectionEnabled(boolean leftProjectionEnabled) { this.leftProjectionEnabled = leftProjectionEnabled; normalize(); }

  public boolean getRightProjectionEnabled() { return rightProjectionEnabled; }
  public void setRightProjectionEnabled(boolean rightProjectionEnabled) { this.rightProjectionEnabled = rightProjectionEnabled; normalize(); }

  public boolean getTopProjectionEnabled() { return topProjectionEnabled; }
  public void setTopProjectionEnabled(boolean topProjectionEnabled) { this.topProjectionEnabled = topProjectionEnabled; normalize(); }

  public boolean getBottomProjectionEnabled() { return bottomProjectionEnabled; }
  public void setBottomProjectionEnabled(boolean bottomProjectionEnabled) { this.bottomProjectionEnabled = bottomProjectionEnabled; normalize(); }

  public int getLeftProjectionPosition() { return leftProjectionPosition; }
  public void setLeftProjectionPosition(int leftProjectionPosition) { this.leftProjectionPosition = leftProjectionPosition; }

  public int getRightProjectionPosition() { return rightProjectionPosition; }
  public void setRightProjectionPosition(int rightProjectionPosition) { this.rightProjectionPosition = rightProjectionPosition; }

  public int getTopProjectionPosition() { return topProjectionPosition; }
  public void setTopProjectionPosition(int topProjectionPosition) { this.topProjectionPosition = topProjectionPosition; }

  public int getBottomProjectionPosition() { return bottomProjectionPosition; }
  public void setBottomProjectionPosition(int bottomProjectionPosition) { this.bottomProjectionPosition = bottomProjectionPosition; }
}
