package userInterface;

public class GraphControllerOptions
{
  private boolean drawOnEmbedding;
  private boolean clearGenerated;
  private boolean testFeaturesEnabled;
  private boolean loadGraphFromGraphDir;
  private String preferredGraphDirectoryPath;

  public GraphControllerOptions()
  {
    drawOnEmbedding = true;
    clearGenerated = false;
    testFeaturesEnabled = false;
    loadGraphFromGraphDir = true;
    preferredGraphDirectoryPath = null;
  }

  public void setDrawOnEmbedding(boolean drawOnEmbedding)
  {
    this.drawOnEmbedding = drawOnEmbedding;
  }

  public boolean getDrawOnEmbedding()
  {
    return drawOnEmbedding;
  }

  public void toggleDrawOnEmbedding()
  {
    drawOnEmbedding = !drawOnEmbedding;
  }

  public void setClearGenerated(boolean clearGenerated)
  {
    this.clearGenerated = clearGenerated;
  }

  public boolean getClearGenerated()
  {
    return clearGenerated;
  }

  public void toggleClearGenerated()
  {
    clearGenerated = !clearGenerated;
  }

  public boolean getTestFeaturesEnabled()
  {
    return testFeaturesEnabled;
  }

  public void toggleTestFeaturesEnabled()
  {
    testFeaturesEnabled = !testFeaturesEnabled;
  }

  public boolean getLoadGraphFromGraphDir()
  {
    return loadGraphFromGraphDir;
  }

  public void setLoadGraphFromGraphDir(boolean loadGraphFromGraphDir)
  {
    this.loadGraphFromGraphDir = loadGraphFromGraphDir;
  }

  public void toggleLoadGraphFromGraphDir()
  {
    loadGraphFromGraphDir = !loadGraphFromGraphDir;
  }

  public String getPreferredGraphDirectoryPath()
  {
    return preferredGraphDirectoryPath;
  }

  public void setPreferredGraphDirectoryPath(String preferredGraphDirectoryPath)
  {
    this.preferredGraphDirectoryPath = preferredGraphDirectoryPath;
  }
}
