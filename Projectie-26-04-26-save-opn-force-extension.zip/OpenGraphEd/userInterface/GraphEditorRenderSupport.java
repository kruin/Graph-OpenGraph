package userInterface;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Vector;
import graphStructure.Edge;
import graphStructure.Graph;
import graphStructure.Location;
import graphStructure.Node;

/**
 * Rendering and transform support for {@link GraphEditor}.
 *
 * <p>The editor keeps interaction and overlay drawing, while this helper owns
 * image buffering, affine transforms and temporary redraw suppression for drag
 * operations.</p>
 */
public class GraphEditorRenderSupport
{
  private final GraphEditor editor;
  private final GraphEditorRenderState state;

  public GraphEditorRenderSupport(GraphEditor editor, GraphEditorRenderState state)
  {
    this.editor = editor;
    this.state = state;
  }


  public void resetTransientRenderState()
  {
    state.setAffineTransform(null);
    state.setNodesToRedraw(null);
    state.setEdgesToRedraw(null);
    state.setOldBounds(null);
    state.setAngle(0);
    state.setBufferedImage(null);
  }

  public void startTranslateNode(Node aNode)
  {
    Vector nodesToRedraw = new Vector(1);
    nodesToRedraw.addElement(aNode);
    state.setNodesToRedraw(nodesToRedraw);
    if ( aNode.getNumEdges() > 0 )
    {
      Vector edgesToRedraw = new Vector(aNode.getNumEdges());
      edgesToRedraw.addAll(aNode.incidentEdges());
      state.setEdgesToRedraw(edgesToRedraw);
    }
    recreateImage(true);
  }

  public void startTranslateNodes(Vector nodes)
  {
    state.setNodesToRedraw(nodes);
    state.setEdgesToRedraw(editor.getGraph().getEdges(nodes));
    recreateImage(true);
  }

  public void stopTranslateNodes()
  {
    state.setNodesToRedraw(null);
    state.setEdgesToRedraw(null);
    recreateImage(true);
  }

  public void startTranslateEdge(Edge anEdge)
  {
    Vector edgesToRedraw = new Vector(1);
    edgesToRedraw.addElement(anEdge);
    state.setEdgesToRedraw(edgesToRedraw);
  }

  public void stopTranslateEdge()
  {
    state.setEdgesToRedraw(null);
    recreateImage(true);
  }

  public void startTranslate()
  {
    recreateImage(true);
  }

  public void translate(int dx, int dy)
  {
    editor.getGraph().translate(dx, dy, false);

    // OpenGraph projection/grid rendering is drawn as part of the live editor scene,
    // not only inside the buffered graph image. In that context the classic move-mode
    // affine preview can desynchronise the visible layers during dragging. Prefer a
    // direct redraw from the translated graph state so the whole visible composition
    // stays together while dragging.
    if ( editor.isOpenGraphProjectionContextActive() )
    {
      if ( editor.getGraph().getDrawGrid() )
      {
        editor.getGraph().shiftGridDisplayWindow(dx, dy, false);
      }
      state.setAffineTransform(null);
      recreateImage(true);
      return;
    }

    state.setAffineTransform(
      AffineTransform.getTranslateInstance(dx + state.getImageOffsetX() + GraphEditor.DRAW_BUFFER,
                                           dy + state.getImageOffsetY() + GraphEditor.DRAW_BUFFER));
  }

  public void stopTranslate()
  {
    state.setAffineTransform(null);
    recreateImage(true);
  }

  public void startRotate()
  {
    recreateImage(true);
    state.setAngle(0);
  }

  public void rotate(Location pivotPoint, double angle)
  {
    state.setAngle(state.getAngle() + angle);
    editor.getGraph().rotate(pivotPoint, angle, false);
    AffineTransform affineTransform =
      AffineTransform.getTranslateInstance(state.getImageOffsetX() + GraphEditor.DRAW_BUFFER,
                                           state.getImageOffsetY() + GraphEditor.DRAW_BUFFER);
    affineTransform.rotate(Math.toRadians(state.getAngle()),
                           pivotPoint.intX() - state.getImageOffsetX(),
                           pivotPoint.intY() - state.getImageOffsetY());
    state.setAffineTransform(affineTransform);
  }

  public void stopRotate()
  {
    state.setAffineTransform(null);
    recreateImage(true);
  }

  public void startScaleTo()
  {
    state.setOldBounds(editor.getGraph().getBounds());
    recreateImage(true);
  }

  public void scaleTo(Rectangle2D.Double newBounds)
  {
    editor.getGraph().scaleTo(newBounds, false);
    AffineTransform affineTransform =
      AffineTransform.getTranslateInstance(state.getImageOffsetX() + GraphEditor.DRAW_BUFFER,
                                           state.getImageOffsetY() + GraphEditor.DRAW_BUFFER);
    affineTransform.scale(newBounds.width / state.getOldBounds().width,
                          newBounds.height / state.getOldBounds().height);
    state.setAffineTransform(affineTransform);
  }

  public void stopScaleTo()
  {
    state.setAffineTransform(null);
    editor.getGraph().refreshEdgeCurves();
    recreateImage(true);
  }

  public void paintGraph(Graphics2D g2)
  {
    Graph graph = editor.getGraph();
    Rectangle2D.Double bounds = graph.getBounds();
    boolean showUndirectedMidpoints = !editor.isInMoveMode() &&
                                     !editor.suppressUndirectedMidpointMarkers();

    g2.setColor(GraphEditor.backgroundColor);
    g2.fillRect(GraphEditor.DRAW_BUFFER, GraphEditor.DRAW_BUFFER,
                editor.getWidth()-2*GraphEditor.DRAW_BUFFER,
                editor.getHeight()-2*GraphEditor.DRAW_BUFFER);

    if ( graph.getDrawGrid() )
    {
      graph.drawGrid(g2, GraphEditor.DRAW_BUFFER, GraphEditor.DRAW_BUFFER);
    }

    recreateImage(graph, bounds, false);

    boolean previousDrawUndirectedMidpoints = Edge.getDrawUndirectedMidpointMarkers();
    Edge.setDrawUndirectedMidpointMarkers(showUndirectedMidpoints);
    try
    {
      if ( state.getAffineTransform() == null )
      {
        g2.drawImage(state.getBufferedImage(),
                     state.getImageOffsetX() + GraphEditor.DRAW_BUFFER,
                     state.getImageOffsetY() + GraphEditor.DRAW_BUFFER,
                     editor);
      }
      else
      {
        g2.drawImage(state.getBufferedImage(), state.getAffineTransform(), editor);
      }

      drawHiddenDuringTransformOverlays(g2, graph);
      OpenGraphProjectionSupport.draw(g2, editor);
    }
    finally
    {
      Edge.setDrawUndirectedMidpointMarkers(previousDrawUndirectedMidpoints);
    }
  }

  private void recreateImage(boolean forceCreation)
  {
    Graph graph = editor.getGraph();
    recreateImage(graph, graph.getBounds(), forceCreation);
  }

  private void recreateImage(Graph aGraph, Rectangle2D.Double bounds, boolean forceCreation)
  {
    if ( state.getBufferedImage() == null || aGraph.hasChangedSinceLastDraw() || forceCreation )
    {
      BufferedImage bufferedImage = new BufferedImage((int)bounds.getWidth() + 2*(Node.RADIUS+2)+200,
                                                      (int)bounds.getHeight() + 2*(Node.RADIUS+2)+20,
                                                      BufferedImage.TYPE_INT_ARGB);
      state.setBufferedImage(bufferedImage);
      state.setImageOffsetX((int)(bounds.getMinX()-Node.RADIUS-2));
      state.setImageOffsetY((int)(bounds.getMinY()-Node.RADIUS-2));

      Graphics2D g2i = bufferedImage.createGraphics();
      g2i.setColor(new Color(255,255,255,0));
      g2i.fillRect(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight());

      setElementsVisible(state.getNodesToRedraw(), false);
      setElementsVisible(state.getEdgesToRedraw(), false);

      boolean previousDrawUndirectedMidpoints = Edge.getDrawUndirectedMidpointMarkers();
      Edge.setDrawUndirectedMidpointMarkers(!editor.isInMoveMode() &&
                                            !editor.suppressUndirectedMidpointMarkers());
      try
      {
        aGraph.draw(g2i, -1*state.getImageOffsetX(), -1*state.getImageOffsetY());
      }
      finally
      {
        Edge.setDrawUndirectedMidpointMarkers(previousDrawUndirectedMidpoints);
      }

      setElementsVisible(state.getNodesToRedraw(), true);
      setElementsVisible(state.getEdgesToRedraw(), true);
      g2i.dispose();
    }
  }

  private void setElementsVisible(Vector elements, boolean visible)
  {
    if ( elements == null )
    {
      return;
    }

    for ( int i=0; i<elements.size(); i++ )
    {
      Object element = elements.elementAt(i);
      if ( element instanceof Node )
      {
        ((Node)element).setIsVisible(visible);
      }
      else if ( element instanceof Edge )
      {
        ((Edge)element).setIsVisible(visible);
      }
    }
  }

  private void drawHiddenDuringTransformOverlays(Graphics2D g2, Graph graph)
  {
    Vector edgesToRedraw = state.getEdgesToRedraw();
    if ( edgesToRedraw != null )
    {
      for ( int i=0; i<edgesToRedraw.size(); i++ )
      {
        ((Edge)edgesToRedraw.elementAt(i)).draw(g2, GraphEditor.DRAW_BUFFER,
                                                GraphEditor.DRAW_BUFFER,
                                                graph.getDrawSelected());
      }
    }

    Vector nodesToRedraw = state.getNodesToRedraw();
    if ( nodesToRedraw != null )
    {
      for ( int i=0; i<nodesToRedraw.size(); i++ )
      {
        ((Node)nodesToRedraw.elementAt(i)).draw(g2, GraphEditor.DRAW_BUFFER,
                                                GraphEditor.DRAW_BUFFER,
                                                graph.getDrawSelected(),
                                                graph.getShowCoords(),
                                                graph.getShowLabels());
      }
    }
  }
}
