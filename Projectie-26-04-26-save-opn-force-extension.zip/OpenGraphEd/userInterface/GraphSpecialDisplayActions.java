package userInterface;

import javax.swing.*;
import java.awt.event.*;
import graphStructure.*;
import graphException.*;
import operation.*;

public class GraphSpecialDisplayActions
{
  private final GraphWindow graphWindow;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;

  public GraphSpecialDisplayActions(GraphWindow graphWindow,
                                    GraphWindowCoordinator graphWindowCoordinator,
                                    GraphEditorActions graphEditorActions)
  {
    this.graphWindow = graphWindow;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphEditorActions = graphEditorActions;
  }

  public void displayCanonical(final GraphController controller, GraphEditorWindow editorWindow)
  {
    prepareSchnyderSelectionDialog(controller,
                                   editorWindow,
                                   "Canonical Order Display",
                                   "Display Canonical Ordering",
                                   "Error During Canonical Order Display",
                                   true,
                                   new TriangleSelectionAction()
                                   {
                                     public void apply(GraphEditorWindow window,
                                                       Node[] triangleNodes,
                                                       boolean onEmbedding) throws Exception
                                     {
                                       graphEditorActions.showLabels(window);
                                       if ( onEmbedding )
                                       {
                                         SchnyderEmbeddingOperation.displayCanonicalOrdering(
                                           window.getGraphEditor().getGraph(),
                                           triangleNodes[0], triangleNodes[1], triangleNodes[2],
                                           window.getGraphEditor().getDrawWidth(),
                                           window.getGraphEditor().getDrawHeight() );
                                       }
                                       else
                                       {
                                         CanonicalOrderOperation.displayCanonicalOrdering(
                                           window.getGraphEditor().getGraph(),
                                           triangleNodes[0], triangleNodes[1], triangleNodes[2]);
                                       }
                                     }
                                   });
  }

  public void displayNormal(final GraphController controller, GraphEditorWindow editorWindow)
  {
    prepareSchnyderSelectionDialog(controller,
                                   editorWindow,
                                   "Normal Labeling Display",
                                   "Display Normal Labeling",
                                   "Error During Normal Label Display",
                                   true,
                                   new TriangleSelectionAction()
                                   {
                                     public void apply(GraphEditorWindow window,
                                                       Node[] triangleNodes,
                                                       boolean onEmbedding) throws Exception
                                     {
                                       if ( onEmbedding )
                                       {
                                         SchnyderEmbeddingOperation.displayNormalLabeling(
                                           window.getGraphEditor().getGraph(),
                                           triangleNodes[0], triangleNodes[1], triangleNodes[2],
                                           window.getGraphEditor().getDrawWidth(),
                                           window.getGraphEditor().getDrawHeight() );
                                       }
                                       else
                                       {
                                         NormalLabelOperation.displayNormalLabeling(
                                           window.getGraphEditor().getGraph(),
                                           triangleNodes[0], triangleNodes[1], triangleNodes[2]);
                                       }
                                     }
                                   });
  }

  public void displaySchnyder(final GraphController controller, GraphEditorWindow editorWindow)
  {
    prepareSchnyderSelectionDialog(controller,
                                   editorWindow,
                                   "Schnyder Embedding Display",
                                   "Display Schnyder Embedding",
                                   "Error During Schnyder Embedding Display",
                                   false,
                                   new TriangleSelectionAction()
                                   {
                                     public void apply(GraphEditorWindow window,
                                                       Node[] triangleNodes,
                                                       boolean onEmbedding) throws Exception
                                     {
                                       SchnyderEmbeddingOperation.displayStraightLineGridEmbedding(
                                         window.getGraphEditor().getGraph(),
                                         triangleNodes[0], triangleNodes[1], triangleNodes[2],
                                         window.getGraphEditor().getDrawWidth(),
                                         window.getGraphEditor().getDrawHeight() );
                                       window.getGraphEditor().setPreferredSize();
                                     }
                                   });
  }

  public void displayChanTree(final GraphController controller, GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }
      ChanDialog dialog = new ChanDialog( controller,
        editorWindow,
        "Chan Tree Drawing Display",
        "<html>Please Select which Drawing Method to Use<br>and Select the Root Node of the Tree</html>" )
      {
        public void actionPerformed(ActionEvent e)
        {
          GraphEditorWindow owner = getOwner();
          try
          {
            Graph graph = owner.getGraphEditor().getGraph();
            graph.newMemento("Display Chan Tree Drawing");
            ChanTreeDrawOperation.displayChanTreeDrawing(
              graph,
              owner.getGraphEditor().getSpecialNodeSelections()[0],
              getSelectedMethodNumber(),
              owner.getGraphEditor().getDrawWidth(),
              owner.getGraphEditor().getDrawHeight() );
            owner.getGraphEditor().setPreferredSize();
            owner.getGraphEditor().update();
            owner.getGraphEditor().allowNodeSelection(0);
            graphWindowCoordinator.closeDialogAndClearOwner(owner);
            graph.doneMemento();
            graphEditorActions.updateUndo(owner);
          }
          catch ( Exception ex )
          {
            Graph graph = owner.getGraphEditor().getGraph();
            graph.undoMemento();
            graph.abortMemento();
            showDisplayError(ex, "Error During Chan Tree Drawing Display");
          }
        }
      };
      dialog.disableRunButton();
      editorWindow.getGraphEditor().allowNodeSelection(1);
      graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
    }
  }

  private void prepareSchnyderSelectionDialog(final GraphController controller,
                                              final GraphEditorWindow editorWindow,
                                              final String dialogTitle,
                                              final String resultMementoName,
                                              final String errorTitle,
                                              final boolean allowOnEmbedding,
                                              final TriangleSelectionAction action)
  {
    if ( editorWindow != null )
    {
      try
      {
        Graph graph = editorWindow.getGraphEditor().getGraph();
        graph.newMemento("Make Maximal");
        if ( ! MakeMaximalOperation.makeMaximal(graph) )
        {
          EmbedOperation.embed(graph, false);
        }
        editorWindow.getGraphEditor().update();

        if ( editorWindow.getDialog() != null )
        {
          graphWindowCoordinator.closeCurrentDialog(editorWindow);
        }

        SchnyderDialog dialog = new SchnyderDialog( controller,
          editorWindow,
          dialogTitle,
          "Please Select 3 Nodes to Bound the Outer-Face/Triangle",
          allowOnEmbedding, true )
        {
          public void actionPerformed(ActionEvent e)
          {
            GraphEditorWindow owner = getOwner();
            owner.getGraphEditor().getGraph().renameMemento(resultMementoName);
            handleTriangleSelection(owner,
                                    e.getSource() == getRandomButton(),
                                    getOnEmbedding(),
                                    action,
                                    errorTitle);
          }

          public void dispose()
          {
            if ( getOwner() != null )
            {
              getOwner().getGraphEditor().getGraph().doneMemento();
              graphEditorActions.updateUndo(getOwner());
            }
            super.dispose();
          }
        };
        dialog.disableRunButton();
        editorWindow.getGraphEditor().allowTriangleSelection();
        graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
      }
      catch ( Exception e )
      {
        editorWindow.getGraphEditor().getGraph().abortMemento();
        showDisplayError(e, errorTitle);
      }
    }
  }

  private void handleTriangleSelection(GraphEditorWindow editorWindow,
                                       boolean useRandom,
                                       boolean onEmbedding,
                                       TriangleSelectionAction action,
                                       String errorTitle)
  {
    try
    {
      Node[] triangleNodes = getTriangleNodes(editorWindow, useRandom);
      action.apply(editorWindow, triangleNodes, onEmbedding);
      editorWindow.getGraphEditor().update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.closeDialogAndClearOwner(editorWindow);
    }
    catch ( Exception e )
    {
      editorWindow.getGraphEditor().getGraph().abortMemento();
      showDisplayError(e, errorTitle);
    }
  }

  private Node[] getTriangleNodes(GraphEditorWindow editorWindow, boolean useRandom) throws Exception
  {
    if ( useRandom )
    {
      return editorWindow.getGraphEditor().getGraph().getRandomTriangularFace();
    }
    return editorWindow.getGraphEditor().getSpecialNodeSelections();
  }

  private void showDisplayError(Exception e, String errorTitle)
  {
    JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                  errorTitle, JOptionPane.ERROR_MESSAGE);
    if ( !(e instanceof GraphException) )
    {
      e.printStackTrace();
    }
  }

  private static interface TriangleSelectionAction
  {
    void apply(GraphEditorWindow editorWindow,
               Node[] triangleNodes,
               boolean onEmbedding) throws Exception;
  }
}
