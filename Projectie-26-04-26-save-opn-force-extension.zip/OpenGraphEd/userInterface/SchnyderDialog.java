package userInterface;

import javax.swing.*;
import java.awt.event.*;

public class SchnyderDialog extends RunGraphEditorDialog
{
  public static int WIDTH = 400;
  public static int HEIGHT = 200;

  private boolean useEmbeddingBox;
  private boolean useRandomButton;
  private JCheckBox embeddingBox;
  private JButton randomButton;

  public SchnyderDialog( GraphController controller,GraphEditorWindow owner,
                         String title, String message )
  {
    this( controller, owner, title, message, false, false );
  }

  public SchnyderDialog( GraphController controller,GraphEditorWindow owner,
                         String title, String message,
                         boolean useEmbeddingBox, boolean useRandomButton )
  {
    super(controller, owner, title, message);
    this.useEmbeddingBox = useEmbeddingBox;
    this.useRandomButton = useRandomButton;

    if ( useEmbeddingBox )
    {
      embeddingBox = new JCheckBox("Display on Embedding");
      embeddingBox.setSelected(controller.getDrawOnEmbedding());
      addFullWidth(embeddingBox);
    }

    if ( useRandomButton )
    {
      randomButton = createActionButton("Run With Random Outer Face");
      addFullWidth(randomButton);
    }

    if ( useRandomButton )
    {
      setRunButton(createActionButton("Run With Selected Outer Face"));
    }
    else
    {
      setRunButton(createActionButton("Run"));
    }

    addInternalFrameListener(controller);

    setSize(WIDTH, HEIGHT);
    setVisible(true);
  }

  public JButton getRandomButton() { return randomButton; }

  public boolean getOnEmbedding()
  {
    return useEmbeddingBox && embeddingBox != null && embeddingBox.isSelected();
  }

  public boolean usesEmbeddingBox() { return useEmbeddingBox; }

  public boolean usesRandomButton() { return useRandomButton; }

  public void actionPerformed(ActionEvent e)
  {
    // do nothing, let this be overriden...
  }
}
