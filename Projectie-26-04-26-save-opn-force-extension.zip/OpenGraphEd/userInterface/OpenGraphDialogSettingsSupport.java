package userInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

final class OpenGraphDialogSettingsSupport
{
  private OpenGraphDialogSettingsSupport() {}

  public static OpenGraphDialogSettingsState createDefaultsForType(int structureType)
  {
    OpenGraphDialogSettingsState state = createCommonDefaults();
    state.structureType = structureType;

    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      state.showProjections = true;
      state.leftProjectionEnabled = true;
      state.rightProjectionEnabled = true;
      state.topProjectionEnabled = false;
      state.bottomProjectionEnabled = true;
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      state.showProjections = true;
      state.leftProjectionEnabled = true;
      state.rightProjectionEnabled = true;
      state.topProjectionEnabled = true;
      state.bottomProjectionEnabled = false;
      state.rightProjectionPosition = 32;
      state.bottomProjectionPosition = 34;
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      state.showProjections = true;
      state.leftProjectionEnabled = true;
      state.rightProjectionEnabled = true;
      state.topProjectionEnabled = false;
      state.bottomProjectionEnabled = true;
    }
    else
    {
      state.showProjections = false;
      state.leftProjectionEnabled = false;
      state.rightProjectionEnabled = false;
      state.topProjectionEnabled = false;
      state.bottomProjectionEnabled = false;
    }

    return state;
  }

  public static OpenGraphDialogSettingsState fromProperties(Properties props)
  {
    OpenGraphDialogSettingsState state = createCommonDefaults();

    state.structureType = parseInt(props.getProperty("structure.type"), OpenGraphDialog.STRUCTURE_FRAME);
    state.showProjections = parseBoolean(props.getProperty("projections.show"), true);
    state.leftProjectionEnabled = parseBoolean(firstNonNull(props, "projection.left.enabled", "projections.left.enabled"), true);
    state.rightProjectionEnabled = parseBoolean(firstNonNull(props, "projection.right.enabled", "projections.right.enabled"), true);
    state.topProjectionEnabled = parseBoolean(firstNonNull(props, "projection.top.enabled", "projections.top.enabled"), false);
    state.bottomProjectionEnabled = parseBoolean(firstNonNull(props, "projection.bottom.enabled", "projections.bottom.enabled"), true);

    state.structureOffsetLeft = parseInt(props.getProperty("structure.offset.left"), 2);
    state.structureOffsetRight = 0;
    state.structureOffsetTop = parseInt(props.getProperty("structure.offset.top"), 2);
    state.structureOffsetBottom = 0;

    state.leftProjectionPosition = parseInt(props.getProperty("projection.left.position"), 2);
    state.rightProjectionPosition = parseInt(props.getProperty("projection.right.position"), 30);
    state.topProjectionPosition = parseInt(props.getProperty("projection.top.position"), 0);
    state.bottomProjectionPosition = parseInt(props.getProperty("projection.bottom.position"), 30);

    state.gridColumnWidth = parseInt(props.getProperty("grid.column.width"), 20);
    state.gridRowHeight = parseInt(props.getProperty("grid.row.height"), 20);
    state.gridMarginLeft = parseInt(props.getProperty("grid.margin.left"), 2);
    state.gridMarginRight = parseInt(props.getProperty("grid.margin.right"), 2);
    state.gridMarginTop = parseInt(props.getProperty("grid.margin.top"), 2);
    state.gridMarginBottom = parseInt(props.getProperty("grid.margin.bottom"), 2);

    state.gridMode = parseInt(props.getProperty("grid.mode"), OpenGraphGridSettings.MODE_FIT_CONTENT);
    state.fitScope = parseInt(props.getProperty("grid.fit.scope"),
                              OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);

    return state;
  }

  public static void applyPostLoadRules(OpenGraphDialogSettingsState state)
  {
    if ( state.structureType < OpenGraphDialog.STRUCTURE_SIMPLE_TREE ||
         state.structureType > OpenGraphDialog.STRUCTURE_FRAME )
    {
      state.structureType = OpenGraphDialog.STRUCTURE_FRAME;
    }
  }

  public static Properties loadPropertiesIfExists(String path) throws IOException
  {
    File file = new File(path);
    if ( !file.exists() )
    {
      return null;
    }

    Properties props = new Properties();
    try ( FileInputStream in = new FileInputStream(file) )
    {
      props.load(in);
    }
    return props;
  }

  public static void saveProperties(String path, Properties props, String comment) throws IOException
  {
    File file = new File(path);
    File parent = file.getParentFile();
    if ( parent != null && !parent.exists() )
    {
      parent.mkdirs();
    }

    try ( FileOutputStream out = new FileOutputStream(file) )
    {
      props.store(out, comment);
    }
  }

  public static Properties mergeUserProperties(Properties existing, OpenGraphDialogSettingsState state)
  {
    Properties props = new Properties();
    if ( existing != null )
    {
      props.putAll(existing);
    }

    props.setProperty("structure.type", String.valueOf(state.structureType));
    props.setProperty("projections.show", String.valueOf(state.showProjections));
    props.setProperty("projection.left.enabled", String.valueOf(state.leftProjectionEnabled));
    props.setProperty("projection.right.enabled", String.valueOf(state.rightProjectionEnabled));
    props.setProperty("projection.top.enabled", String.valueOf(state.topProjectionEnabled));
    props.setProperty("projection.bottom.enabled", String.valueOf(state.bottomProjectionEnabled));

    props.setProperty("structure.offset.left", String.valueOf(state.structureOffsetLeft));
    props.remove("structure.offset.right");
    props.setProperty("structure.offset.top", String.valueOf(state.structureOffsetTop));
    props.remove("structure.offset.bottom");

    props.setProperty("projection.left.position", String.valueOf(state.leftProjectionPosition));
    props.setProperty("projection.right.position", String.valueOf(state.rightProjectionPosition));
    props.setProperty("projection.top.position", String.valueOf(state.topProjectionPosition));
    props.setProperty("projection.bottom.position", String.valueOf(state.bottomProjectionPosition));

    props.setProperty("grid.column.width", String.valueOf(state.gridColumnWidth));
    props.setProperty("grid.row.height", String.valueOf(state.gridRowHeight));
    props.setProperty("grid.mode", String.valueOf(state.gridMode));
    props.setProperty("grid.fit.scope", String.valueOf(state.fitScope));
    props.setProperty("grid.margin.left", String.valueOf(state.gridMarginLeft));
    props.setProperty("grid.margin.right", String.valueOf(state.gridMarginRight));
    props.setProperty("grid.margin.top", String.valueOf(state.gridMarginTop));
    props.setProperty("grid.margin.bottom", String.valueOf(state.gridMarginBottom));

    return props;
  }

  public static String getSettingsHeader(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return "Phrase settings";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      return "Anaphor settings";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      return "Frame settings";
    }
    return "Simple tree settings";
  }

  public static String getSettingsSubHeader(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return "Phrase draws LEX on leaf nodes and computed SYN on branching nodes; projection options and grid options are on separate tabs.";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      return "Simple uses only the open tree. Grid settings remain available on the separate Grid tab.";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      return "Anaphor is reserved for later expansion.";
    }
    return "Frame currently uses the same minimal projection slice as Phrase: left LEX, right computed SYN, and optional bottom LOG for explicit logical labels.";
  }

  private static String firstNonNull(Properties props, String primaryKey, String fallbackKey)
  {
    String value = props.getProperty(primaryKey);
    if ( value != null )
    {
      return value;
    }
    return props.getProperty(fallbackKey);
  }

  private static OpenGraphDialogSettingsState createCommonDefaults()
  {
    return new OpenGraphDialogSettingsState();
  }

  private static int parseInt(String value, int fallback)
  {
    if ( value == null )
    {
      return fallback;
    }
    try
    {
      return Integer.parseInt(value.trim());
    }
    catch ( NumberFormatException nfe )
    {
      return fallback;
    }
  }

  private static boolean parseBoolean(String value, boolean fallback)
  {
    if ( value == null )
    {
      return fallback;
    }
    return "true".equalsIgnoreCase(value.trim()) || "yes".equalsIgnoreCase(value.trim());
  }
}
