package userInterface;

import javax.swing.*;

public class GraphDesktopFrames
{
  private final JDesktopPane desktopPane;

  public GraphDesktopFrames(JDesktopPane desktopPane)
  {
    this.desktopPane = desktopPane;
  }

  public void addAndActivate(OpenGraphEdInternalFrame frame)
  {
    desktopPane.add(frame);
    activate(frame);
  }

  public void activate(OpenGraphEdInternalFrame frame)
  {
    try
    {
      if ( frame.isIcon() )
      {
        frame.setIcon(false);
      }
      else
      {
        frame.setSelected(true);
      }
    }
    catch (java.beans.PropertyVetoException pve)
    {
      pve.printStackTrace();
    }
    if ( frame.isSelected() )
    {
      desktopPane.getDesktopManager().activateFrame(frame);
    }
  }

  public void show(OpenGraphEdInternalFrame frame)
  {
    if ( !frame.isIcon() && !contains(frame) )
    {
      frame.setVisible(true);
      desktopPane.add(frame);
    }
    activate(frame);
  }

  public void reopenAndActivate(OpenGraphEdInternalFrame frame)
  {
    try
    {
      frame.setClosed(false);
    }
    catch (java.beans.PropertyVetoException pve)
    {
      pve.printStackTrace();
    }
    activate(frame);
  }

  public void close(OpenGraphEdInternalFrame frame)
  {
    frame.dispose();
  }

  public void closeIfPossible(OpenGraphEdInternalFrame frame)
  {
    try
    {
      frame.setClosed(true);
    }
    catch (java.beans.PropertyVetoException pve)
    {
      pve.printStackTrace();
    }
  }

  public boolean contains(OpenGraphEdInternalFrame frame)
  {
    return desktopPane.getIndexOf(frame) != -1;
  }

  public JInternalFrame[] allFrames()
  {
    return desktopPane.getAllFrames();
  }
}
