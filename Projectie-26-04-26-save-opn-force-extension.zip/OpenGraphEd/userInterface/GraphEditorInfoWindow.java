package userInterface;

import graphStructure.Graph;

public class GraphEditorInfoWindow extends OpenGraphEdInternalFrame
{
  public static int WIDTH = 400;
  public static int HEIGHT = 400;

  private final GraphEditorWindow editorWindow;
  private final GraphEditorInfoSupport infoSupport;

  public GraphEditorInfoWindow(GraphController controller,
                               GraphEditorWindow editorWindow)
  {
    super(controller, editorWindow.getTitle() + " - Info",
          true, true, true, true);
    this.editorWindow = editorWindow;
    infoSupport = new GraphEditorInfoSupport(getContentPane());

    update();
    addInternalFrameListener(controller);
    setSize(WIDTH, HEIGHT);
  }

  public void update()
  {
    if ( isVisible() )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      infoSupport.update(graph);
    }
  }
}
