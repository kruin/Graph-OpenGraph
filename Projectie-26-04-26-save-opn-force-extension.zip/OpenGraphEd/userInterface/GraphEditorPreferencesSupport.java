package userInterface;

import javax.swing.*;
import java.awt.*;
import userInterface.modes.*;

public class GraphEditorPreferencesSupport
{
  private final GraphController controller;
  private final JCheckBox singleClickAddNodeBox;
  private final JCheckBox addNodeOnEdgeDropBox;
  private final JCheckBox drawOnEmbeddingBox;
  private final JCheckBox clearGeneratedBox;
  private final JCheckBox opaqueTextBox;

  public GraphEditorPreferencesSupport(GraphController controller,
                                       Container container,
                                       java.awt.event.ActionListener listener)
  {
    this.controller = controller;

    GridBagLayout layout = GraphEditorWindowUiSupport.installVerticalLayout(container);
    singleClickAddNodeBox = addOption(container, layout,
      "Allow Single (as well as Double) Click To Add Nodes",
      EditListener.SINGLE_CLICK_ADD_NODE, listener);
    addNodeOnEdgeDropBox = addOption(container, layout,
      "Create a New End Node if a new Edge has only one Node",
      EditListener.ADD_NODE_ON_EDGE_DROP, listener);
    drawOnEmbeddingBox = addOption(container, layout,
      "Default for Draw Canonical Order and Normal Label on Embedding",
      controller.getDrawOnEmbedding(), listener);
    clearGeneratedBox = addOption(container, layout,
      "Clear Generated Edges after Straight Line Embedding",
      controller.getClearGenerated(), listener);
    opaqueTextBox = addOption(container, layout,
      "Draw Text Background on Top of Edges",
      graphStructure.Node.OPAQUE_TEXT, listener);
  }

  private JCheckBox addOption(Container container, GridBagLayout layout,
                              String text, boolean selected,
                              java.awt.event.ActionListener listener)
  {
    JCheckBox checkBox = GraphEditorWindowUiSupport.createCheckBox(text,
      selected, listener);
    GraphEditorWindowUiSupport.addFullWidth(container, layout, checkBox,
      GridBagConstraints.HORIZONTAL, 0.0);
    return checkBox;
  }

  public boolean handleAction(Object source)
  {
    if ( source == singleClickAddNodeBox )
    {
      EditListener.SINGLE_CLICK_ADD_NODE = !EditListener.SINGLE_CLICK_ADD_NODE;
      return true;
    }
    if ( source == addNodeOnEdgeDropBox )
    {
      EditListener.ADD_NODE_ON_EDGE_DROP = !EditListener.ADD_NODE_ON_EDGE_DROP;
      return true;
    }
    if ( source == drawOnEmbeddingBox )
    {
      controller.toggleDrawOnEmbedding();
      return true;
    }
    if ( source == clearGeneratedBox )
    {
      controller.toggleClearGenerated();
      return true;
    }
    if ( source == opaqueTextBox )
    {
      graphStructure.Node.OPAQUE_TEXT = !graphStructure.Node.OPAQUE_TEXT;
      controller.getGraphWindow().forceGraphRepaints();
      return true;
    }
    return false;
  }
}
