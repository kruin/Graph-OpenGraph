package userInterface;

import graphStructure.Graph;
import graphStructure.Node;

final class OpenGraphRootSelector
{
  private OpenGraphRootSelector()
  {
  }

  public static int getRootIndex(GraphEditorWindow editorWindow)
  {
    Graph graph = editorWindow.getGraphEditor().getGraph();
    Node[] selectedRoots = editorWindow.getGraphEditor().getSpecialNodeSelections();
    if ( selectedRoots != null && selectedRoots.length > 0 && selectedRoots[0] != null )
    {
      int selectedIndex = findNodeIndex(graph, selectedRoots[0]);
      if ( selectedIndex >= 0 )
      {
        return selectedIndex;
      }
    }

    if ( graph.getNumNodes() <= 0 )
    {
      return 0;
    }

    int bestIndex = 0;
    Node bestNode = graph.getNodeAt(0);
    for ( int i=1; i<graph.getNumNodes(); i++ )
    {
      Node candidate = graph.getNodeAt(i);
      if ( candidate.getY() < bestNode.getY() ||
           (candidate.getY() == bestNode.getY() && candidate.getX() < bestNode.getX()) )
      {
        bestNode = candidate;
        bestIndex = i;
      }
    }
    return bestIndex;
  }

  private static int findNodeIndex(Graph graph, Node target)
  {
    for ( int i=0; i<graph.getNumNodes(); i++ )
    {
      if ( graph.getNodeAt(i) == target )
      {
        return i;
      }
    }
    return -1;
  }
}
