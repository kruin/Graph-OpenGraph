package userInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Loads and saves the persisted OpenGraphGrid settings.
 *
 * Grid settings live in the same config files as the other OpenGraph settings,
 * but are handled separately so they can be edited from Modes -> OpenGraphGrid.
 */
public final class OpenGraphGridSettingsIO
{
  public static final String DEFAULTS_PATH = "config/opengraph_defaults.properties";
  public static final String USER_SETTINGS_PATH = "config/opengraph_user.properties";

  private OpenGraphGridSettingsIO()
  {
  }

  public static OpenGraphGridSettings loadBestAvailable()
  {
    OpenGraphGridSettings settings = loadUserSettings();
    if ( settings != null )
    {
      return settings;
    }
    settings = loadDefaultSettings();
    if ( settings != null )
    {
      return settings;
    }
    return new OpenGraphGridSettings();
  }

  public static OpenGraphGridSettings loadUserSettings()
  {
    return loadFromPath(USER_SETTINGS_PATH);
  }

  public static OpenGraphGridSettings loadDefaultSettings()
  {
    return loadFromPath(DEFAULTS_PATH);
  }

  private static OpenGraphGridSettings loadFromPath(String path)
  {
    File file = new File(path);
    if ( !file.exists() )
    {
      return null;
    }

    FileInputStream in = null;
    try
    {
      Properties props = new Properties();
      in = new FileInputStream(file);
      props.load(in);
      OpenGraphGridSettings settings = new OpenGraphGridSettings();
      applyGridProperties(props, settings);
      settings.normalize();
      return settings;
    }
    catch (IOException ioe)
    {
      return null;
    }
    finally
    {
      if ( in != null )
      {
        try { in.close(); } catch (IOException ioe) { }
      }
    }
  }

  public static void saveUserSettings(OpenGraphGridSettings settings) throws IOException
  {
    if ( settings == null )
    {
      settings = new OpenGraphGridSettings();
    }

    File configDir = new File("config");
    if ( !configDir.exists() )
    {
      configDir.mkdirs();
    }

    Properties props = new Properties();
    File file = new File(USER_SETTINGS_PATH);
    if ( file.exists() )
    {
      FileInputStream in = null;
      try
      {
        in = new FileInputStream(file);
        props.load(in);
      }
      finally
      {
        if ( in != null )
        {
          try { in.close(); } catch (IOException ioe) { }
        }
      }
    }

    applySettingsToProperties(settings, props);

    FileOutputStream out = null;
    try
    {
      out = new FileOutputStream(file);
      props.store(out, "OpenGraph user settings");
    }
    finally
    {
      if ( out != null )
      {
        try { out.close(); } catch (IOException ioe) { }
      }
    }
  }

  public static void applyGridProperties(Properties props, OpenGraphGridSettings settings)
  {
    if ( props == null || settings == null )
    {
      return;
    }

    settings.setCellWidth(parseInt(props.getProperty("grid.column.width"), settings.getCellWidth()));
    settings.setCellHeight(parseInt(props.getProperty("grid.row.height"), settings.getCellHeight()));
    settings.setGridMode(parseInt(props.getProperty("grid.mode"), settings.getGridMode()));
    settings.setFitScope(parseInt(props.getProperty("grid.fit.scope"), settings.getFitScope()));
    settings.setMarginLeftLines(parseInt(props.getProperty("grid.margin.left"), settings.getMarginLeftLines()));
    settings.setMarginRightLines(parseInt(props.getProperty("grid.margin.right"), settings.getMarginRightLines()));
    settings.setMarginTopLines(parseInt(props.getProperty("grid.margin.top"), settings.getMarginTopLines()));
    settings.setMarginBottomLines(parseInt(props.getProperty("grid.margin.bottom"), settings.getMarginBottomLines()));
  }

  public static void applySettingsToProperties(OpenGraphGridSettings settings, Properties props)
  {
    if ( settings == null || props == null )
    {
      return;
    }

    settings.normalize();
    props.setProperty("grid.column.width", String.valueOf(settings.getCellWidth()));
    props.setProperty("grid.row.height", String.valueOf(settings.getCellHeight()));
    props.setProperty("grid.mode", String.valueOf(settings.getGridMode()));
    props.setProperty("grid.fit.scope", String.valueOf(settings.getFitScope()));
    props.setProperty("grid.margin.left", String.valueOf(settings.getMarginLeftLines()));
    props.setProperty("grid.margin.right", String.valueOf(settings.getMarginRightLines()));
    props.setProperty("grid.margin.top", String.valueOf(settings.getMarginTopLines()));
    props.setProperty("grid.margin.bottom", String.valueOf(settings.getMarginBottomLines()));
  }

  private static int parseInt(String value, int fallback)
  {
    if ( value == null )
    {
      return fallback;
    }
    try
    {
      return Integer.parseInt(value.trim());
    }
    catch (NumberFormatException nfe)
    {
      return fallback;
    }
  }
}
