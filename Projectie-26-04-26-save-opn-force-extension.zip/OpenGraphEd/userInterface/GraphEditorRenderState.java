package userInterface;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Vector;

/**
 * Mutable rendering and transform state for {@link GraphEditor}.
 *
 * <p>This keeps the transient image-buffer and transform data out of the
 * editor itself while preserving the original behaviour.</p>
 */
public class GraphEditorRenderState
{
  private BufferedImage bufferedImage;
  private int imageOffsetX;
  private int imageOffsetY;
  private AffineTransform affineTransform;
  private Vector nodesToRedraw;
  private Vector edgesToRedraw;
  private Rectangle2D.Double oldBounds;
  private double angle;

  public BufferedImage getBufferedImage() { return bufferedImage; }
  public void setBufferedImage(BufferedImage bufferedImage) { this.bufferedImage = bufferedImage; }

  public int getImageOffsetX() { return imageOffsetX; }
  public void setImageOffsetX(int imageOffsetX) { this.imageOffsetX = imageOffsetX; }

  public int getImageOffsetY() { return imageOffsetY; }
  public void setImageOffsetY(int imageOffsetY) { this.imageOffsetY = imageOffsetY; }

  public AffineTransform getAffineTransform() { return affineTransform; }
  public void setAffineTransform(AffineTransform affineTransform) { this.affineTransform = affineTransform; }

  public Vector getNodesToRedraw() { return nodesToRedraw; }
  public void setNodesToRedraw(Vector nodesToRedraw) { this.nodesToRedraw = nodesToRedraw; }

  public Vector getEdgesToRedraw() { return edgesToRedraw; }
  public void setEdgesToRedraw(Vector edgesToRedraw) { this.edgesToRedraw = edgesToRedraw; }

  public Rectangle2D.Double getOldBounds() { return oldBounds; }
  public void setOldBounds(Rectangle2D.Double oldBounds) { this.oldBounds = oldBounds; }

  public double getAngle() { return angle; }
  public void setAngle(double angle) { this.angle = angle; }
}
