package userInterface.modes;

import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import userInterface.GraphEditor;
import graphStructure.Location;

public class MoveListenerSupport
{
  private boolean isInsideDrawableArea(MoveListener listener, MouseEvent event)
  {
    return event.getPoint().x >= GraphEditor.DRAW_BUFFER &&
           event.getPoint().x <= listener.editor.getWidth() - GraphEditor.DRAW_BUFFER &&
           event.getPoint().y >= GraphEditor.DRAW_BUFFER &&
           event.getPoint().y <= listener.editor.getHeight() - GraphEditor.DRAW_BUFFER;
  }

  public void handleMousePressed(MoveListener listener, MouseEvent event)
  {
    if ( isInsideDrawableArea(listener, event) &&
         event.getButton() != MouseEvent.BUTTON3 )
    {
      listener.setDragStartLocation( new Location( event.getPoint().x - GraphEditor.DRAW_BUFFER,
                                                   event.getPoint().y - GraphEditor.DRAW_BUFFER ) );
      Rectangle2D.Double bounds = listener.graph.getBounds();
      listener.setMaxX((int)bounds.getMaxX());
      listener.setMinX((int)bounds.getMinX());
      listener.setMaxY((int)bounds.getMaxY());
      listener.setMinY((int)bounds.getMinY());
      listener.graph.newMemento("Move Graph");
      listener.graph.translate(0, 0, true); // memento
      if ( listener.editor.isOpenGraphProjectionContextActive() && listener.graph.getDrawGrid() )
      {
        listener.graph.shiftGridDisplayWindow(0, 0, true); // memento
      }
      listener.editor.startTranslate();
      listener.setDragging(true);
    }
  }

  public void handleMouseDragged(MoveListener listener, MouseEvent event)
  {
    listener.mouseMoved(event);
    if ( listener.isDragging() )
    {
      Location ePoint = new Location( event.getPoint().x - GraphEditor.DRAW_BUFFER,
                                      event.getPoint().y - GraphEditor.DRAW_BUFFER );
      int transX = ePoint.intX() - listener.getDragStartLocation().intX();
      int transY = ePoint.intY() - listener.getDragStartLocation().intY();
      listener.setDragStartLocation(ePoint);

      if ( listener.getMaxX() + transX > listener.editor.getWidth() - 2*GraphEditor.DRAW_BUFFER )
      {
        transX = (listener.editor.getWidth() - 2*GraphEditor.DRAW_BUFFER) - listener.getMaxX();
      }
      else if ( listener.getMinX() + transX < 0 )
      {
        transX = 0 - listener.getMinX();
      }
      if ( listener.getMaxY() + transY > listener.editor.getHeight() - 2*GraphEditor.DRAW_BUFFER )
      {
        transY = (listener.editor.getHeight() - 2*GraphEditor.DRAW_BUFFER) - listener.getMaxY();
      }
      else if ( listener.getMinY() + transY < 0 )
      {
        transY = 0 - listener.getMinY();
      }
      listener.setMaxX(listener.getMaxX() + transX);
      listener.setMinX(listener.getMinX() + transX);
      listener.setMaxY(listener.getMaxY() + transY);
      listener.setMinY(listener.getMinY() + transY);
      if ( transX != 0 || transY != 0 )
      {
        listener.setDragged(true);
        listener.controller.newUndo();
        listener.editor.translate(transX, transY);
        listener.editor.setPreferredSize();
        listener.editor.repaint();
      }
    }
  }

  public void handleMouseReleased(MoveListener listener, MouseEvent event)
  {
    listener.setDragStartLocation(null);
    if ( listener.isDragging() )
    {
      if ( listener.isDragged() )
      {
        listener.graph.doneMemento();
        listener.controller.newUndo();
      }
      else
      {
        listener.graph.abortMemento();
      }
      listener.setDragged(false);
      listener.editor.stopTranslate();
      listener.editor.repaint();
      listener.setDragging(false);
    }
  }
}
