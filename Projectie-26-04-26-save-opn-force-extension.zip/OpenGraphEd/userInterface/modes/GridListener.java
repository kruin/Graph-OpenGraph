package userInterface.modes;

import java.awt.event.*;
import javax.swing.event.*;
import java.awt.Point;
import java.awt.Color;
import java.awt.geom.*;
import userInterface.GraphController;
import userInterface.GraphEditor;

import graphStructure.*;

public class GridListener extends EditListener
{
  private boolean undoOrthogonal;
  private GridListenerSupport gridSupport;
  
  public GridListener(GraphEditorListener listener)
  {
    super(listener);
    init();
  }

  public GridListener(Graph graph, GraphEditor editor, GraphController controller)
  {
    super(graph, editor, controller);
    init();
  }

  private void init()
  {
    editor.changeToNormalCursor();
    undoOrthogonal = false;
    gridSupport = new GridListenerSupport();
  }

  public boolean isEditListener() { return false; }
  
  public boolean isGridListener() { return true; }

  boolean isUndoOrthogonal() { return undoOrthogonal; }

  void setUndoOrthogonal(boolean value) { undoOrthogonal = value; }

  /**
   * This method is triggered when the user clicks the mouse within the
   * GraphEditor.<br>
   * <br>
   *
   * @param MouseEvent event: The MouseEvent that triggered this method.
   */
  public void mouseClicked(MouseEvent event)
  {
    if ( !gridSupport.handleMouseClicked(this, event) )
    {
      super.mouseClicked(event);
    }
  }
  
  /**
   * This method is triggered when the user presses a mouse button
   * within the GraphEditor. This typically means the user has begun
   * dragging an object, and actions are taken accordingly depending
   * on the mode of the GraphEditor.
   *
   * @param MouseEvent event: The MouseEvent that triggered this method.
   */
  public void mousePressed(MouseEvent event)
  {
    if ( !gridSupport.handleMousePressed(this, event) )
    {
      super.mousePressed(event);
    }
  }

  /**
   * This method is triggered when the user drags the mouse within
   * the GraphEditor. Actions are taken accordingly depending
   * on the mode of the GraphEditor. (ex: drag a Node, draw a potential
   * Edge).
   *
   * @param MouseEvent event: The MouseEvent that triggered this method.
   */
  public void mouseDragged(MouseEvent event)
  {
    if ( !gridSupport.handleMouseDragged(this, event) )
    {
      super.mouseDragged(event);
    }
  }

  /**
   * This method is triggered when the user releases the mouse button
   * within the GraphEditor. This typically denotes the end of a mouse
   * drag by the user. Actions are taken accordingly depending
   * on the mode of the GraphEditor. (ex: Stop moving a Node, create an
   * Edge).
   *
   * @param MouseEvent event: The MouseEvent that triggered this method.
   */
  public void mouseReleased(MouseEvent event)
  {
    if ( !gridSupport.handleMouseReleased(this, event) )
    {
      super.mouseReleased(event);
    }
  }

  /**
   * This method is triggered when the user presses a key on the
   * keyboard while within the GraphEditor. If any Nodes or Edges
   * are selected, these Nodes and Edges are deleted.
   *
   * @param KeyEvent event: The KeyEvent that triggered this method.
   */
  public void keyPressed(KeyEvent event)
  {
    if ( !gridSupport.handleKeyPressed(this, event) )
    {
      // no-op
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    if ( !gridSupport.handleActionPerformed(this, e) )
    {
      super.actionPerformed(e);
    }
  }

  public void focusGained(FocusEvent e) { }

  public void focusLost(FocusEvent e)
  {
    
  }

  public void ancestorMoved(AncestorEvent event)
  {
    
  }

  public void ancestorAdded(AncestorEvent event) { }
  public void ancestorRemoved(AncestorEvent event) { }

  // Unused event handlers
  public void keyTyped(KeyEvent event) {}
  public void keyReleased(KeyEvent event) {}  
  
}
