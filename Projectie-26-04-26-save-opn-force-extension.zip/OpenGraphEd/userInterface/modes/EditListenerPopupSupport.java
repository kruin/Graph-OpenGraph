package userInterface.modes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JWindow;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;

import graphStructure.Edge;
import graphStructure.Node;
import userInterface.GraphEditor;

class EditListenerPopupSupport
{
  boolean isPopupFocusComponent(EditListener listener, Component component)
  {
    return component == listener.popupWindow ||
           component == listener.labelButton ||
           component == listener.colorButton ||
           component == listener.makeStraightButton ||
           component == listener.closeButton;
  }

  void showPopup(EditListener listener, Node aNode, Point location)
  {
    hidePopup(listener);
    listener.popupPanel = createPopupPanel();

    PopupLayout popupLayout = new PopupLayout(listener.popupPanel);

    listener.selectedNodeVector = listener.graph.selectedNodes();
    listener.selectedEdgeVector = listener.graph.selectedEdges();
    if ( listener.applyToSelected && listener.selectedNodeVector.size() > 1 )
    {
      popupLayout.addRow(new JLabel("Edit All Selected"));
    }
    else
    {
      popupLayout.addRow(new JLabel("Index: " + aNode.getIndex()));
    }

    popupLayout.addRow(new JLabel("X, Y: " + aNode.getX() + ", " + aNode.getY()));

    JPanel labelPanel = new JPanel(new BorderLayout());
    listener.labelButton = new JButton("Set Label: ");
    if ( listener.applyToSelected && listener.selectedNodeVector.size() > 1 )
    {
      listener.labelButton.setToolTipText("Set all Selected Nodes' Label");
    }
    else
    {
      listener.labelButton.setToolTipText("Set this Node's Label");
    }
    listener.labelButton.addActionListener(listener);
    labelPanel.add(listener.labelButton, BorderLayout.WEST);
    labelPanel.add(new JLabel("\"" + aNode.getLabel() + "\""), BorderLayout.CENTER);
    popupLayout.addRow(labelPanel);

    JPanel colorPanel = new JPanel(new BorderLayout());
    listener.colorButton = new JButton("Set Color:");
    if ( listener.applyToSelected && listener.selectedNodeVector.size() > 1 )
    {
      listener.colorButton.setToolTipText("Set all Selected Nodes' Color");
    }
    else
    {
      listener.colorButton.setToolTipText("Set this Node's Color");
    }
    listener.colorButton.addActionListener(listener);
    colorPanel.add(listener.colorButton, BorderLayout.WEST);
    JPanel subColorPanel = new JPanel();
    subColorPanel.setBackground(aNode.getColor());
    colorPanel.add(subColorPanel, BorderLayout.CENTER);
    popupLayout.addRow(colorPanel);

    listener.selectButton = new JButton(aNode.isSelected() ? "Toggle Select (T) " : "Toggle Select (F) ");
    listener.selectButton.setToolTipText("Toggle Node Selection");
    listener.selectButton.addActionListener(listener);
    popupLayout.addRow(listener.selectButton);

    if ( listener.isGridListener() && !listener.graph.isOnGrid(aNode.getLocation()) )
    {
      listener.gridButton = new JButton("Snap To Grid");
      listener.gridButton.addActionListener(listener);
      popupLayout.addRow(listener.gridButton);
    }
    else
    {
      listener.gridButton = null;
    }

    listener.closeButton = new JButton("Close");
    listener.closeButton.setToolTipText("Close this Window");
    listener.closeButton.addActionListener(listener);
    popupLayout.addRow(listener.closeButton);

    showPopup(listener, location);
  }

  void showPopup(EditListener listener, Edge anEdge, Point location)
  {
    hidePopup(listener);
    listener.popupPanel = createPopupPanel();

    PopupLayout popupLayout = new PopupLayout(listener.popupPanel);

    listener.selectedNodeVector = listener.graph.selectedNodes();
    listener.selectedEdgeVector = listener.graph.selectedEdges();
    if ( listener.applyToSelected && listener.selectedEdgeVector.size() > 1 )
    {
      popupLayout.addRow(new JLabel("Edit All Selected"));
    }
    else
    {
      popupLayout.addRow(new JLabel("Index: " + anEdge.getIndex()));
    }

    popupLayout.addRow(new JLabel("s.X, s.Y: " + anEdge.getStartNode().getX() + ", " + anEdge.getStartNode().getY()));
    popupLayout.addRow(new JLabel("e.X, e.Y: " + anEdge.getEndNode().getX() + ", " + anEdge.getEndNode().getY()));

    JPanel colorPanel = new JPanel(new BorderLayout());
    listener.colorButton = new JButton("Color: ");
    if ( listener.applyToSelected && listener.selectedEdgeVector.size() > 1 )
    {
      listener.colorButton.setToolTipText("Set all Selected Edges' Color");
    }
    else
    {
      listener.colorButton.setToolTipText("Set this Edge's Color");
    }
    listener.colorButton.addActionListener(listener);
    colorPanel.add(listener.colorButton, BorderLayout.WEST);
    JPanel subColorPanel = new JPanel();
    subColorPanel.setBackground(anEdge.getColor());
    colorPanel.add(subColorPanel, BorderLayout.CENTER);
    popupLayout.addRow(colorPanel);

    if ( shouldShowMakeStraight(listener.selectedEdgeVector, listener.applyToSelected, anEdge) )
    {
      listener.makeStraightButton = new JButton("Make Straight");
      listener.makeStraightButton.setToolTipText(listener.applyToSelected && listener.selectedEdgeVector.size() > 1 ?
                                                 "Make all Selected Edges Straight" :
                                                 "Make this Edge Straight");
      listener.makeStraightButton.addActionListener(listener);
      popupLayout.addRow(listener.makeStraightButton);
    }
    else
    {
      listener.makeStraightButton = null;
    }

    if ( listener.isGridListener() && !anEdge.isOrthogonal() && anEdge.isCurved() )
    {
      listener.gridButton = new JButton("Make Orthogonal");
      listener.gridButton.addActionListener(listener);
      popupLayout.addRow(listener.gridButton);
    }
    else
    {
      listener.gridButton = null;
    }

    if ( shouldShowUndirect(listener.selectedEdgeVector, listener.applyToSelected, anEdge) )
    {
      listener.undirectButton = new JButton(listener.applyToSelected && listener.selectedEdgeVector.size() > 1 ?
                                            "Remove Directions" : "Remove Direction");
      listener.undirectButton.setToolTipText(listener.applyToSelected && listener.selectedEdgeVector.size() > 1 ?
                                             "Make All Selected Edges Undirected" :
                                             "Make this Edge Undirected");
      listener.undirectButton.addActionListener(listener);
      popupLayout.addRow(listener.undirectButton);
    }
    else
    {
      listener.undirectButton = null;
    }

    if ( shouldShowMakePermanent(listener.selectedEdgeVector, listener.applyToSelected, anEdge) )
    {
      listener.makePermanentButton = new JButton("Make Permanent");
      listener.makePermanentButton.setToolTipText(listener.applyToSelected && listener.selectedEdgeVector.size() > 1 ?
                                                  "Make All Generated Edges Permanent" :
                                                  "Make this Generated Edge Permanent");
      listener.makePermanentButton.addActionListener(listener);
      popupLayout.addRow(listener.makePermanentButton);
    }
    else
    {
      listener.makePermanentButton = null;
    }

    listener.selectButton = new JButton(anEdge.isSelected() ? "Toggle Select (T) " : "Toggle Select (F) ");
    listener.selectButton.setToolTipText("Toggle Node Selection");
    listener.selectButton.addActionListener(listener);
    popupLayout.addRow(listener.selectButton);

    listener.closeButton = new JButton("Close");
    listener.closeButton.setToolTipText("Close this Window");
    listener.closeButton.addActionListener(listener);
    popupLayout.addRow(listener.closeButton);

    showPopup(listener, location);
  }

  void hidePopup(EditListener listener)
  {
    if ( listener.windowPopup )
    {
      if ( listener.popupPanel != null )
      {
        listener.popupPanel.setVisible(false);
        listener.wLayeredPane.remove(listener.popupPanel);
        listener.popupPanel = null;
        listener.popupWindow.setVisible(false);
      }
    }
    else
    {
      if ( listener.popupPanel != null )
      {
        listener.popupPanel.setVisible(false);
        listener.layeredPane.remove(listener.popupPanel);
        listener.popupPanel = null;
      }
    }
  }

  private JPanel createPopupPanel()
  {
    JPanel popupPanel = new JPanel();
    popupPanel.setBorder(BorderFactory.createEtchedBorder());
    return popupPanel;
  }

  private boolean shouldShowMakeStraight(Vector selectedEdgeVector, boolean applyToSelected, Edge anEdge)
  {
    if ( applyToSelected && selectedEdgeVector.size() > 1 )
    {
      for ( int x=0; x<selectedEdgeVector.size(); x++ )
      {
        Edge edge = (Edge)selectedEdgeVector.elementAt(x);
        if ( edge.isCurved() || edge.isOrthogonal() )
        {
          return true;
        }
      }
      return false;
    }
    return anEdge.isCurved() || anEdge.isOrthogonal();
  }

  private boolean shouldShowUndirect(Vector selectedEdgeVector, boolean applyToSelected, Edge anEdge)
  {
    if ( applyToSelected && selectedEdgeVector.size() > 1 )
    {
      for ( int x=0; x<selectedEdgeVector.size(); x++ )
      {
        if ( ((Edge)selectedEdgeVector.elementAt(x)).isDirected() )
        {
          return true;
        }
      }
      return false;
    }
    return anEdge.isDirected();
  }

  private boolean shouldShowMakePermanent(Vector selectedEdgeVector, boolean applyToSelected, Edge anEdge)
  {
    if ( applyToSelected && selectedEdgeVector.size() > 1 )
    {
      for ( int x=0; x<selectedEdgeVector.size(); x++ )
      {
        if ( ((Edge)selectedEdgeVector.elementAt(x)).isGenerated() )
        {
          return true;
        }
      }
      return false;
    }
    return anEdge.isGenerated();
  }

  private void showPopup(EditListener listener, Point location)
  {
    if ( !listener.layerInited )
    {
      listener.layerInited = true;
      Container container = listener.editor.getTopLevelAncestor();
      if ( container instanceof RootPaneContainer )
      {
        RootPaneContainer rootPaneContainer = (RootPaneContainer)container;
        listener.layeredPane = rootPaneContainer.getLayeredPane();
        listener.rootPane = rootPaneContainer.getRootPane();
      }
      else
      {
        listener.layeredPane = null;
        listener.rootPane = null;
      }
      listener.popupWindow = new JWindow(getParentWindow(listener.editor));
      listener.popupWindow.setFocusableWindowState(false);
      listener.popupWindow.addFocusListener(listener);
      listener.wLayeredPane = listener.popupWindow.getLayeredPane();
      listener.wRootPane = listener.popupWindow.getRootPane();
    }
    location = SwingUtilities.convertPoint(listener.editor, location, listener.rootPane);
    listener.popupPanel.setSize(listener.popupPanel.getPreferredSize());

    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Rectangle screenBounds;
    Insets screenInsets;
    GraphicsConfiguration gc = null;

    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    GraphicsDevice[] gd = ge.getScreenDevices();
    for(int i = 0; i < gd.length; i++)
    {
      if(gd[i].getType() == GraphicsDevice.TYPE_RASTER_SCREEN)
      {
        GraphicsConfiguration dgc = gd[i].getDefaultConfiguration();
        if(dgc.getBounds().contains(location))
        {
          gc = dgc;
          break;
        }
      }
    }

    if(gc != null)
    {
      screenInsets = toolkit.getScreenInsets(gc);
      screenBounds = gc.getBounds();
    }
    else
    {
      screenInsets = new Insets(0, 0, 0, 0);
      screenBounds = new Rectangle(toolkit.getScreenSize());
    }

    int scrWidth = screenBounds.width - Math.abs(screenInsets.left+screenInsets.right);
    int scrHeight = screenBounds.height - Math.abs(screenInsets.top+screenInsets.bottom);

    Dimension size = listener.popupPanel.getPreferredSize();

    Point screenLocation = new Point(location);
    SwingUtilities.convertPointToScreen(screenLocation, listener.rootPane);

    listener.windowPopup = true;
    if( (screenLocation.x + size.width) > screenBounds.x + scrWidth )
    {
      screenLocation.x = screenBounds.x + scrWidth - size.width;
      listener.windowPopup = true;
    }

    if( (screenLocation.y + size.height) > screenBounds.y + scrHeight)
    {
      screenLocation.y = screenBounds.y + scrHeight - size.height;
      listener.windowPopup = true;
    }

    if( screenLocation.x < screenBounds.x )
    {
      screenLocation.x = screenBounds.x;
      listener.windowPopup = true;
    }
    if( screenLocation.y < screenBounds.y )
    {
      screenLocation.y = screenBounds.y;
      listener.windowPopup = true;
    }

    if ( location.y + listener.popupPanel.getHeight() > listener.rootPane.getHeight() ||
         location.x + listener.popupPanel.getWidth() > listener.rootPane.getWidth() )
    {
      listener.windowPopup = true;
    }

    if ( listener.windowPopup )
    {
      listener.popupWindow.setLocation(screenLocation.x, screenLocation.y);
      listener.popupPanel.setLocation(0,0);
      listener.popupPanel.setVisible(true);
      listener.popupWindow.setSize(listener.popupPanel.getSize());
      listener.popupWindow.setVisible(true);
      listener.wLayeredPane.add(listener.popupPanel, JLayeredPane.POPUP_LAYER);
    }
    else
    {
      listener.popupPanel.setLocation(location.x, location.y);
      listener.popupPanel.setVisible(true);
      listener.layeredPane.add(listener.popupPanel, JLayeredPane.POPUP_LAYER);
    }
  }

  private Window getParentWindow(Component owner)
  {
    Window window = null;

    if (owner instanceof Window)
    {
      window = (Window)owner;
    }
    else if (owner != null)
    {
      window = SwingUtilities.getWindowAncestor(owner);
    }
    if (window == null)
    {
      window = new Frame();
    }
    return window;
  }

  private static final class PopupLayout
  {
    private final JPanel popupPanel;
    private final java.awt.GridBagLayout layout;
    private final java.awt.GridBagConstraints constraints;

    private PopupLayout(JPanel popupPanel)
    {
      this.popupPanel = popupPanel;
      this.layout = new java.awt.GridBagLayout();
      this.constraints = new java.awt.GridBagConstraints();
      popupPanel.setLayout(layout);
      constraints.gridx = java.awt.GridBagConstraints.RELATIVE;
      constraints.gridy = java.awt.GridBagConstraints.RELATIVE;
      constraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
      constraints.gridheight = 1;
      constraints.fill = java.awt.GridBagConstraints.BOTH;
      constraints.insets = new Insets(1,1,1,1);
      constraints.anchor = java.awt.GridBagConstraints.NORTH;
      constraints.weightx = 1.0;
      constraints.weighty = 1.0;
    }

    private void addRow(Component component)
    {
      layout.setConstraints(component, constraints);
      popupPanel.add(component);
    }
  }
}
