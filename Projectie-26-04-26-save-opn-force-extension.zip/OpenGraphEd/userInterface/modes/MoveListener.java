package userInterface.modes;

import java.awt.event.*;

import graphStructure.Location;

public class MoveListener extends GraphEditorListener
{
  private Location dragStartLocation;
  private int minX, maxX, minY, maxY;
  private boolean dragged;
  private boolean dragging;
  private MoveListenerSupport moveSupport;

  public MoveListener(GraphEditorListener listener)
  {
    super(listener);
    graph.setDrawSelected(false);
    editor.changeToMoveCursor();
    dragging = false;
    dragged = false;
    moveSupport = new MoveListenerSupport();
  }

  public boolean isMoveListener() { return true; }

  Location getDragStartLocation() { return dragStartLocation; }
  void setDragStartLocation(Location value) { dragStartLocation = value; }
  int getMinX() { return minX; }
  void setMinX(int value) { minX = value; }
  int getMaxX() { return maxX; }
  void setMaxX(int value) { maxX = value; }
  int getMinY() { return minY; }
  void setMinY(int value) { minY = value; }
  int getMaxY() { return maxY; }
  void setMaxY(int value) { maxY = value; }
  boolean isDragged() { return dragged; }
  void setDragged(boolean value) { dragged = value; }
  boolean isDragging() { return dragging; }
  void setDragging(boolean value) { dragging = value; }

  public void mousePressed(MouseEvent event)
  {
    moveSupport.handleMousePressed(this, event);
  }

  public void mouseDragged(MouseEvent event)
  {
    moveSupport.handleMouseDragged(this, event);
  }

  public void mouseReleased(MouseEvent event)
  {
    moveSupport.handleMouseReleased(this, event);
  }

  public void mouseClicked(MouseEvent event)
  {
    super.mouseClicked(event);
  }

  // Unused event handlers
  public void keyPressed(KeyEvent event) {}
  public void keyTyped(KeyEvent event) {}
  public void keyReleased(KeyEvent event) {}
}
