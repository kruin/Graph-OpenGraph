package userInterface.modes;

import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.Vector;

import userInterface.GraphEditor;
import graphStructure.Location;
import graphStructure.Node;

public class RotateListenerSupport
{
  private boolean isInsideDrawableArea(RotateListener listener, MouseEvent event)
  {
    return event.getPoint().x >= GraphEditor.DRAW_BUFFER &&
           event.getPoint().x <= listener.editor.getWidth() - GraphEditor.DRAW_BUFFER &&
           event.getPoint().y >= GraphEditor.DRAW_BUFFER &&
           event.getPoint().y <= listener.editor.getHeight() - GraphEditor.DRAW_BUFFER;
  }

  public void handleMousePressed(RotateListener listener, MouseEvent event)
  {
    if ( listener.graph.getNumNodes() > 1 &&
         isInsideDrawableArea(listener, event) &&
         event.getButton() != MouseEvent.BUTTON3 )
    {
      listener.setRotatePivotPoint(listener.graph.getCenterPointLocation());
      listener.setRotateAxisPoint( new Location( event.getPoint().x - GraphEditor.DRAW_BUFFER,
                                                 event.getPoint().y - GraphEditor.DRAW_BUFFER ) );
      listener.editor.setPointToDraw( new Ellipse2D.Double(
                                    listener.getRotatePivotPoint().intX() - Node.RADIUS + GraphEditor.DRAW_BUFFER,
                                    listener.getRotatePivotPoint().intY() - Node.RADIUS + GraphEditor.DRAW_BUFFER,
                                    Node.RADIUS * 2, Node.RADIUS * 2 ) );
      Rectangle2D.Double bounds = listener.graph.getBounds();
      listener.setMinX((int)bounds.getMinX());
      listener.setMinY((int)bounds.getMinY());
      listener.graph.newMemento("Rotate Graph");
      listener.graph.rotate(listener.getRotatePivotPoint(), 0.0, true);
      listener.editor.startRotate();
      listener.setDragging(true);
    }
  }

  public void handleMouseDragged(RotateListener listener, MouseEvent event)
  {
    listener.mouseMoved(event);
    if ( listener.isDragging() &&
         listener.graph.getNumNodes() > 1 && listener.getRotatePivotPoint() != null )
    {
      listener.setNewRotateAxisPoint( new Location( event.getPoint().x - GraphEditor.DRAW_BUFFER,
                                                    event.getPoint().y - GraphEditor.DRAW_BUFFER ) );
      double angle = Node.angleBetween( listener.getRotateAxisPoint(),
                                        listener.getRotatePivotPoint(),
                                        listener.getNewRotateAxisPoint() );
      listener.setRotateAxisPoint(listener.getNewRotateAxisPoint());
      listener.editor.rotate(listener.getRotatePivotPoint(), angle);
      listener.setDragged(true);

      Vector nodes = listener.graph.getNodes();
      if ( !nodes.isEmpty() )
      {
        Rectangle2D.Double bounds = listener.graph.getBounds();
        listener.setMinX((int)bounds.getMinX());
        listener.setMinY((int)bounds.getMinY());
        listener.setMaxX((int)bounds.getMaxX());
        listener.setMaxY((int)bounds.getMaxY());
      }

      if ( listener.getMaxX() > (listener.editor.getWidth() - 2*GraphEditor.DRAW_BUFFER) ||
           listener.getMinX() <= 0 ||
           listener.getMaxY() > (listener.editor.getHeight() - 2*GraphEditor.DRAW_BUFFER) ||
           listener.getMinY() <= 0 )
      {
        listener.editor.rotate(listener.getRotatePivotPoint(), -1.0*angle);
      }
      listener.editor.setPreferredSize();
      listener.editor.repaint();
    }
  }

  public void handleMouseReleased(RotateListener listener, MouseEvent event)
  {
    if ( listener.isDragging() )
    {
      if ( listener.isDragged() )
      {
        listener.graph.doneMemento();
        listener.controller.newUndo();
      }
      else
      {
        listener.graph.abortMemento();
      }
      listener.setDragged(false);
      listener.setDragging(false);
      listener.editor.stopRotate();
      if ( listener.graph.getNumNodes() > 1 )
      {
        listener.setRotatePivotPoint(null);
        listener.editor.repaint();
      }
    }
  }
}
