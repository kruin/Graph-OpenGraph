package userInterface.modes;

import java.awt.event.*;

import graphStructure.Location;

public class RotateListener extends GraphEditorListener
{
  private Location rotatePivotPoint;
  private Location rotateAxisPoint;
  private Location newRotateAxisPoint;
  private int minX, maxX, minY, maxY;
  private double totalAngle;
  private boolean dragged;
  private boolean dragging;
  private RotateListenerSupport rotateSupport;

  public RotateListener(GraphEditorListener listener)
  {
    super(listener);
    totalAngle = 0;
    graph.setDrawSelected(false);
    editor.changeToRotateCursor();
    dragged = false;
    dragging = false;
    rotateSupport = new RotateListenerSupport();
  }

  public boolean isRotateListener() { return true; }

  Location getRotatePivotPoint() { return rotatePivotPoint; }
  void setRotatePivotPoint(Location value) { rotatePivotPoint = value; }
  Location getRotateAxisPoint() { return rotateAxisPoint; }
  void setRotateAxisPoint(Location value) { rotateAxisPoint = value; }
  Location getNewRotateAxisPoint() { return newRotateAxisPoint; }
  void setNewRotateAxisPoint(Location value) { newRotateAxisPoint = value; }
  int getMinX() { return minX; }
  void setMinX(int value) { minX = value; }
  int getMaxX() { return maxX; }
  void setMaxX(int value) { maxX = value; }
  int getMinY() { return minY; }
  void setMinY(int value) { minY = value; }
  int getMaxY() { return maxY; }
  void setMaxY(int value) { maxY = value; }
  double getTotalAngle() { return totalAngle; }
  void setTotalAngle(double value) { totalAngle = value; }
  boolean isDragged() { return dragged; }
  void setDragged(boolean value) { dragged = value; }
  boolean isDragging() { return dragging; }
  void setDragging(boolean value) { dragging = value; }

  public void mousePressed(MouseEvent event)
  {
    rotateSupport.handleMousePressed(this, event);
  }

  public void mouseDragged(MouseEvent event)
  {
    rotateSupport.handleMouseDragged(this, event);
  }

  public void mouseReleased(MouseEvent event)
  {
    rotateSupport.handleMouseReleased(this, event);
  }

  public void mouseClicked(MouseEvent event)
  {
    super.mouseClicked(event);
  }

  // Unused event handlers
  public void keyPressed(KeyEvent event) {}
  public void keyTyped(KeyEvent event) {}
  public void keyReleased(KeyEvent event) {}
}
