package userInterface.modes;

import java.awt.*;
import java.awt.event.*;

public class ResizeListener extends GraphEditorListener
{
  private boolean horizontalResize, verticalResize;
  private boolean dragging;
  private boolean dragged;
  private Point lastPoint;
  private ResizeListenerSupport resizeSupport;

  public ResizeListener(GraphEditorListener listener)
  {
    super(listener);
    graph.setDrawSelected(false);
    horizontalResize = verticalResize = false;
    editor.changeToNormalCursor();
    dragging = false;
    dragged = false;
    resizeSupport = new ResizeListenerSupport();
  }

  public boolean isResizeListener() { return true; }

  boolean isHorizontalResize() { return horizontalResize; }
  void setHorizontalResize(boolean value) { horizontalResize = value; }
  boolean isVerticalResize() { return verticalResize; }
  void setVerticalResize(boolean value) { verticalResize = value; }
  boolean isDragging() { return dragging; }
  void setDragging(boolean value) { dragging = value; }
  boolean isDragged() { return dragged; }
  void setDragged(boolean value) { dragged = value; }
  Point getLastPoint() { return lastPoint; }
  void setLastPoint(Point value) { lastPoint = value; }

  void baseMouseMoved(MouseEvent event) { super.mouseMoved(event); }

  public void mousePressed(MouseEvent event)
  {
    resizeSupport.handleMousePressed(this, event);
  }

  public void mouseDragged(MouseEvent event)
  {
    resizeSupport.handleMouseDragged(this, event);
  }

  public void mouseReleased(MouseEvent event)
  {
    resizeSupport.handleMouseReleased(this, event);
  }

  public void mouseMoved(MouseEvent event)
  {
    resizeSupport.handleMouseMoved(this, event);
  }

  public void mouseClicked(MouseEvent event)
  {
    super.mouseClicked(event);
  }

  // Unused event handlers
  public void keyPressed(KeyEvent event) {}
  public void keyTyped(KeyEvent event) {}
  public void keyReleased(KeyEvent event) {}
}
