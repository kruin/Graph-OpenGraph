package userInterface.modes;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import userInterface.GraphEditor;

public class ResizeListenerSupport
{
  public void handleMousePressed(ResizeListener listener, MouseEvent event)
  {
    if ( listener.graph.getNumNodes() > 1 && event.getButton() != MouseEvent.BUTTON3 )
    {
      listener.setDragging(true);
      listener.graph.newMemento("Resize Graph");
      listener.graph.scaleTo(listener.graph.getBounds(), true); // memento
      listener.editor.startScaleTo();
      listener.setLastPoint(event.getPoint());
    }
  }

  public void handleMouseDragged(ResizeListener listener, MouseEvent event)
  {
    listener.baseMouseMoved(event);
    if ( listener.isDragging() && listener.graph.getNumNodes() > 1 )
    {
      Rectangle2D.Double bounds = listener.graph.getBounds();
      double width = bounds.width;
      double height = bounds.height;
      if ( listener.isHorizontalResize() )
      {
        width -= listener.getLastPoint().x - event.getPoint().x;
      }
      if ( listener.isVerticalResize() )
      {
        height -= listener.getLastPoint().y - event.getPoint().y;
      }

      Rectangle2D.Double rect = new Rectangle2D.Double(bounds.getMinX(),
                                                       bounds.getMinY(),
                                                       width,
                                                       height);
      listener.setLastPoint(event.getPoint());
      listener.editor.scaleTo(rect);
      listener.editor.updateShapes();
      listener.editor.setPreferredSize();
      listener.editor.repaint();
      listener.setDragged(true);
    }
  }

  public void handleMouseReleased(ResizeListener listener, MouseEvent event)
  {
    if ( listener.isDragging() )
    {
      if ( listener.graph.getNumNodes() > 1 )
      {
        listener.setDragging(false);
        listener.graph.updateEdgeCurveAngles();
        listener.baseMouseMoved(event);
        listener.editor.updateShapes();
        listener.editor.setPreferredSize();
        listener.editor.repaint();
      }
      if ( listener.isDragged() )
      {
        listener.graph.doneMemento();
        listener.controller.newUndo();
      }
      else
      {
        listener.graph.abortMemento();
      }
      listener.setDragged(false);
      listener.editor.stopScaleTo();
    }
  }

  public void handleMouseMoved(ResizeListener listener, MouseEvent event)
  {
    listener.baseMouseMoved(event);
    if ( !listener.isDragging() && listener.graph.getNumNodes() > 1 )
    {
      Rectangle2D.Double bounds = listener.graph.getBounds();
      if ( Math.abs( ((int)bounds.getMaxX() + GraphEditor.DRAW_BUFFER)
                     - event.getPoint().x ) <= 1 )
      {
        listener.setHorizontalResize(true);
        if ( Math.abs( ((int)bounds.getMaxY() + GraphEditor.DRAW_BUFFER)
                       - event.getPoint().y ) <= 1 )
        {
          listener.setVerticalResize(true);
          listener.editor.changeToDiagonalResizeCursor();
        }
        else
        {
          listener.setVerticalResize(false);
          listener.editor.changeToHorizontalResizeCursor();
        }
      }
      else
      {
        listener.setHorizontalResize(false);
        if ( Math.abs( ((int)bounds.getMaxY() + GraphEditor.DRAW_BUFFER)
                       - event.getPoint().y ) <= 1 )
        {
          listener.setVerticalResize(true);
          listener.editor.changeToVerticalResizeCursor();
        }
        else
        {
          listener.setVerticalResize(false);
          listener.editor.changeToNormalCursor();
        }
      }
    }
  }
}
