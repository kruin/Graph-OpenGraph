package userInterface.modes;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;

import userInterface.GraphEditor;

import graphStructure.Edge;
import graphStructure.Graph;
import graphStructure.Location;
import graphStructure.Node;

public class GridListenerSupport
{
  private boolean isInsideDrawableArea(GridListener listener, MouseEvent event)
  {
    return event.getPoint().x >= GraphEditor.DRAW_BUFFER - Node.RADIUS &&
           event.getPoint().x <= listener.editor.getWidth() - GraphEditor.DRAW_BUFFER + Node.RADIUS &&
           event.getPoint().y >= GraphEditor.DRAW_BUFFER - Node.RADIUS &&
           event.getPoint().y <= listener.editor.getHeight() - GraphEditor.DRAW_BUFFER + Node.RADIUS;
  }

  private Location getEventLocation(MouseEvent event)
  {
    return new Location(event.getPoint().x - GraphEditor.DRAW_BUFFER,
                        event.getPoint().y - GraphEditor.DRAW_BUFFER);
  }

  public boolean handleMouseClicked(GridListener listener, MouseEvent event)
  {
    Location ePoint = getEventLocation(event);
    Edge anEdge = listener.graph.edgeAt(ePoint);
    Node aNode = listener.graph.nodeAt(ePoint);
    if ( listener.numSpecialSelectionsAllowed == 0 &&
         event.getButton() != MouseEvent.BUTTON3 &&
         isInsideDrawableArea(listener, event) &&
         aNode == null && anEdge == null )
    {
      Node gridNode = listener.graph.nodeAt(listener.graph.getClosestGridLocation(ePoint));
      if ( gridNode == null )
      {
        listener.graph.newMemento("Create New Node");
        listener.graph.createNode(listener.graph.getClosestGridLocation(ePoint));
        listener.graph.doneMemento();
        listener.controller.newUndo();
        listener.editor.setPreferredSize();
        listener.editor.update();
      }
      else
      {
        listener.graph.toggleNodeSelection(gridNode);
        listener.editor.repaint();
      }
      return true;
    }
    return false;
  }

  public boolean handleMousePressed(GridListener listener, MouseEvent event)
  {
    Location ePoint = getEventLocation(event);
    Edge anEdge = listener.graph.edgeAt(ePoint);
    Node aNode = listener.graph.nodeAt(ePoint);
    if ( listener.numSpecialSelectionsAllowed == 0 &&
         event.getButton() != MouseEvent.BUTTON3 &&
         isInsideDrawableArea(listener, event) &&
         aNode == null && anEdge != null && anEdge.isSelected() )
    {
      listener.graph.newMemento("Orthogonalize Selected Edge");
      listener.setUndoOrthogonal(!anEdge.isOrthogonal());
      listener.graph.orthogonalizeEdge(anEdge, true);
      listener.editor.startTranslateEdge(anEdge);
      listener.dragStartLocation = new Location(event.getPoint());
      listener.dragEdge = anEdge;
      return true;
    }
    return false;
  }

  public boolean handleMouseDragged(GridListener listener, MouseEvent event)
  {
    if ( listener.numSpecialSelectionsAllowed == 0 &&
         (listener.dragNode != null || listener.dragEdge != null) )
    {
      listener.mouseMoved(event);
      listener.dragged = true;
      Location ePoint = getEventLocation(event);
      if ( listener.dragNode != null && listener.dragNode.isSelected() )
      {
        handleSelectedNodeDrag(listener, ePoint);
      }
      else if ( listener.dragNode != null && !listener.dragNode.isSelected() )
      {
        handleUnselectedNodeDrag(listener, event, ePoint);
      }
      else
      {
        handleEdgeDrag(listener, ePoint);
      }
      return true;
    }
    return false;
  }

  private void handleSelectedNodeDrag(GridListener listener, Location ePoint)
  {
    if ( ePoint.intX() < listener.editor.getWidth() - 2 * GraphEditor.DRAW_BUFFER &&
         ePoint.intY() < listener.editor.getHeight() - 2 * GraphEditor.DRAW_BUFFER )
    {
      listener.graph.relocateNode(listener.dragNode,
                                  listener.graph.getClosestGridLocation(ePoint),
                                  false);
      listener.graph.refreshOrthogonalEdges(listener.dragNode.incidentEdges());
      listener.editor.setPreferredSize();
      listener.editor.repaint();
    }
  }

  private void handleUnselectedNodeDrag(GridListener listener, MouseEvent event, Location ePoint)
  {
    listener.dragStartLocation = new Location(event.getPoint());
    Location gridLocation = listener.graph.getClosestGridLocation(ePoint);
    listener.editor.setLineToDraw(new Line2D.Double(listener.dragNode.getLocation().intX() +
                                                    GraphEditor.DRAW_BUFFER,
                                                    listener.dragNode.getLocation().intY() +
                                                    GraphEditor.DRAW_BUFFER,
                                                    gridLocation.intX() +
                                                    GraphEditor.DRAW_BUFFER,
                                                    gridLocation.intY() +
                                                    GraphEditor.DRAW_BUFFER));
    listener.dragStartLocation.translate(-1 * GraphEditor.DRAW_BUFFER,
                                         -1 * GraphEditor.DRAW_BUFFER);

    Node dragToNode = null;
    if ( event.isShiftDown() )
    {
      dragToNode = listener.graph.nodeAt(listener.dragStartLocation);
    }
    else
    {
      dragToNode = listener.nodeSplitTree.nodeAt(listener.dragStartLocation);
    }
    if ( dragToNode == null )
    {
      if ( event.isShiftDown() )
      {
        dragToNode = listener.graph.nodeAt(listener.graph.getClosestGridLocation(listener.dragStartLocation));
      }
      else
      {
        dragToNode = listener.nodeSplitTree.nodeAt(listener.graph.getClosestGridLocation(listener.dragStartLocation));
      }
    }

    if ( dragToNode != null )
    {
      listener.editor.setLineToDrawColor(Edge.DEFAULT_COLOR);
      if ( !listener.graph.isOnGrid(dragToNode.getLocation()) )
      {
        listener.editor.setLineToDraw(new Line2D.Double(listener.dragNode.getLocation().intX() +
                                                        GraphEditor.DRAW_BUFFER,
                                                        listener.dragNode.getLocation().intY() +
                                                        GraphEditor.DRAW_BUFFER,
                                                        ePoint.intX() + GraphEditor.DRAW_BUFFER,
                                                        ePoint.intY() + GraphEditor.DRAW_BUFFER));
      }
      Edge dragEdge = (Edge)listener.dragNode.incidentEdgeWith(dragToNode);
      if ( dragEdge != null )
      {
        listener.editor.setCurveToDrawColor(Color.green);
        if ( dragEdge.isCurved() )
        {
          listener.editor.setCurveToDraw(dragEdge.getCurve(GraphEditor.DRAW_BUFFER,
                                                           GraphEditor.DRAW_BUFFER));
        }
        if ( dragEdge.isDirected() )
        {
          if ( listener.dragNode == dragEdge.getDirectedSourceNode() )
          {
            listener.editor.setLineToDrawColor(new Color(155, 155, 255));
            listener.editor.setPolygonToDraw(null);
          }
          else
          {
            listener.editor.setPolygonToDrawColor(GraphEditor.backgroundColor);
            listener.editor.setPolygonToDraw(dragEdge.getDirectionArrow(dragToNode,
                                                                        GraphEditor.DRAW_BUFFER,
                                                                        GraphEditor.DRAW_BUFFER,
                                                                        1,
                                                                        1));
            listener.editor.setLineToDrawColor(Color.green);
          }
        }
        else
        {
          listener.editor.setPolygonToDrawColor(Color.green);
          listener.editor.setPolygonToDraw(dragEdge.getDirectionArrow(listener.dragNode,
                                                                      GraphEditor.DRAW_BUFFER,
                                                                      GraphEditor.DRAW_BUFFER,
                                                                      1,
                                                                      1));
          listener.editor.setLineToDrawColor(Color.green);
        }
      }
      else
      {
        listener.editor.setCurveToDraw(null);
      }
    }
    else
    {
      listener.editor.setLineToDrawColor(new Color(155, 155, 255));
      listener.editor.setPolygonToDraw(null);
      listener.editor.setCurveToDraw(null);
    }
    listener.editor.repaint();
  }

  private void handleEdgeDrag(GridListener listener, Location ePoint)
  {
    if ( ePoint.intX() < listener.editor.getWidth() - 2 * GraphEditor.DRAW_BUFFER &&
         ePoint.intY() < listener.editor.getHeight() - 2 * GraphEditor.DRAW_BUFFER )
    {
      listener.graph.relocateEdge(listener.dragEdge, ePoint, false);
      listener.graph.orthogonalizeEdge(listener.dragEdge, false);
      listener.editor.setPreferredSize();
      listener.editor.update();
    }
  }

  public boolean handleMouseReleased(GridListener listener, MouseEvent event)
  {
    if ( listener.numSpecialSelectionsAllowed == 0 &&
         (listener.dragNode != null || listener.dragEdge != null) )
    {
      if ( listener.dragNode != null )
      {
        finishNodeRelease(listener, event);
      }
      else if ( listener.dragEdge != null )
      {
        finishEdgeRelease(listener);
      }
      listener.dragStartLocation = null;
      listener.dragged = false;
      return true;
    }
    return false;
  }

  private void finishNodeRelease(GridListener listener, MouseEvent event)
  {
    if ( listener.dragged )
    {
      if ( listener.dragNode.isSelected() )
      {
        listener.graph.doneMemento();
        listener.controller.newUndo();
        listener.graph.markForRepaint();
        listener.editor.update();
        listener.editor.stopTranslateNodes();
      }
      else
      {
        Location ePoint = getEventLocation(event);
        Node aNode = listener.graph.nodeAt(ePoint);
        if ( aNode == null )
        {
          aNode = listener.graph.nodeAt(listener.graph.getClosestGridLocation(ePoint));
        }
        if ( aNode != listener.dragNode )
        {
          if ( aNode != null )
          {
            Edge tempEdge = (Edge)listener.dragNode.incidentEdgeWith(aNode);
            if ( tempEdge != null )
            {
              listener.graph.newMemento("Direct Edge");
              if ( tempEdge.getDirectedSourceNode() == aNode )
              {
                listener.graph.changeEdgeDirection(tempEdge, null, true);
              }
              else
              {
                listener.graph.changeEdgeDirection(tempEdge, listener.dragNode, true);
              }
              listener.graph.doneMemento();
              listener.controller.newUndo();
              listener.editor.update();
            }
            else
            {
              listener.graph.newMemento("Create New Edge");
              listener.graph.addEdge(listener.dragNode, aNode);
              listener.graph.doneMemento();
              listener.controller.newUndo();
              listener.editor.update();
            }
            listener.editor.setPolygonToDraw(null);
            listener.editor.setCurveToDraw(null);
          }
          else if ( listener.createNodeOnEdgeDrop &&
                    ePoint.intX() >= 0 &&
                    ePoint.intX() <= listener.editor.getWidth() - 2 * GraphEditor.DRAW_BUFFER &&
                    ePoint.intY() >= 0 &&
                    ePoint.intY() <= listener.editor.getHeight() - 2 * GraphEditor.DRAW_BUFFER )
          {
            listener.graph.newMemento("Create New Edge and End Node");
            aNode = listener.graph.createNode(listener.graph.getClosestGridLocation(ePoint));
            listener.graph.addEdge(listener.dragNode, aNode);
            listener.graph.doneMemento();
            listener.controller.newUndo();
            listener.editor.setPreferredSize();
            listener.editor.update();
          }
        }
      }
    }
    listener.nodeSplitTree = null;
    listener.editor.setLineToDraw(null);
    listener.dragNode = null;
    listener.editor.repaint();
  }

  private void finishEdgeRelease(GridListener listener)
  {
    if ( listener.dragged )
    {
      listener.graph.doneMemento();
      listener.controller.newUndo();
      listener.graph.markForRepaint();
      listener.editor.update();
    }
    else if ( listener.isUndoOrthogonal() )
    {
      listener.setUndoOrthogonal(false);
      listener.graph.undoMemento();
      listener.graph.abortMemento();
    }
    listener.editor.stopTranslateEdge();
    listener.dragEdge = null;
  }

  public boolean handleKeyPressed(GridListener listener, KeyEvent event)
  {
    if ( listener.numSpecialSelectionsAllowed == 0 &&
         (event.getKeyCode() == KeyEvent.VK_DELETE ||
          event.getKeyCode() == KeyEvent.VK_DECIMAL) )
    {
      listener.controller.removeSelected();
      listener.editor.update();
      return true;
    }
    return false;
  }

  public boolean handleActionPerformed(GridListener listener, ActionEvent event)
  {
    if ( event.getSource() == listener.gridButton )
    {
      if ( listener.aNode != null )
      {
        handleGridButtonNodeAction(listener);
      }
      else if ( listener.anEdge != null )
      {
        handleGridButtonEdgeAction(listener);
      }
      return true;
    }
    return false;
  }

  private void handleGridButtonNodeAction(GridListener listener)
  {
    if ( !listener.graph.isOnGrid(listener.aNode.getLocation()) )
    {
      listener.graph.newMemento("Snap Node To Grid");
      listener.graph.relocateNode(listener.aNode,
                                  listener.graph.getClosestGridLocation(listener.aNode.getLocation()),
                                  true);
      listener.graph.updateEdges(listener.aNode.incidentEdges(), true);
      listener.graph.doneMemento();
      listener.controller.newUndo();
      listener.editor.repaint();
      listener.popupLocation = new Point(listener.aNode.getLocation().intX() + GraphEditor.DRAW_BUFFER,
                                         listener.aNode.getLocation().intY() + GraphEditor.DRAW_BUFFER);
      listener.showPopup(listener.aNode, listener.popupLocation);
    }
  }

  private void handleGridButtonEdgeAction(GridListener listener)
  {
    listener.graph.newMemento("Make Edge Orthogonal");
    listener.graph.orthogonalizeEdge(listener.anEdge, true);
    listener.graph.doneMemento();
    listener.controller.newUndo();
    listener.editor.repaint();
    listener.popupLocation = new Point(listener.anEdge.getCenterLocation().intX() + GraphEditor.DRAW_BUFFER,
                                       listener.anEdge.getCenterLocation().intY() + GraphEditor.DRAW_BUFFER);
    listener.showPopup(listener.anEdge, listener.popupLocation);
  }
}
