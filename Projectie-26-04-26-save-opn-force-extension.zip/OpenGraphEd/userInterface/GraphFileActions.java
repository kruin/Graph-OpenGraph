package userInterface;

import javax.swing.*;
import java.io.*;
import graphStructure.*;
import userInterface.fileUtils.*;

public class GraphFileActions
{
  private static boolean lastStartInGraphDir = true;
  private static boolean lastGraphOnly = true;

  public void loadGraph(GraphWindow graphWindow, GraphController controller)
  {
    File baseDir = new File(System.getProperty("user.dir"));
    File graphDir = getPreferredGraphDirectory(controller);

    lastStartInGraphDir = controller.getLoadGraphFromGraphDir();
    JFileChooser fc = createGraphLoadChooser(lastStartInGraphDir ? graphDir : baseDir, lastGraphOnly);
    fc.setDialogTitle("Load GRAPH / OPN File");
    fc.setApproveButtonText("Load GRAPH / OPN");

    JPanel accessory = new JPanel();
    accessory.setLayout(new BoxLayout(accessory, BoxLayout.Y_AXIS));

    JCheckBox startInGraphDir = new JCheckBox("Start in Graph dir", lastStartInGraphDir);
    JCheckBox graphOnly = new JCheckBox("Only .graph", lastGraphOnly);
    JLabel currentDirLabel = new JLabel(shortDirectoryLabel(graphDir));
    JButton chooseGraphDirButton = new JButton("Set Default Graph Dir...");

    startInGraphDir.addActionListener(e ->
    {
      lastStartInGraphDir = startInGraphDir.isSelected();
      controller.setLoadGraphFromGraphDir(lastStartInGraphDir);
      fc.setCurrentDirectory(lastStartInGraphDir ? getPreferredGraphDirectory(controller) : baseDir);
      currentDirLabel.setText(shortDirectoryLabel(getPreferredGraphDirectory(controller)));
    });

    graphOnly.addActionListener(e ->
    {
      lastGraphOnly = graphOnly.isSelected();
      fc.setAcceptAllFileFilterUsed(!lastGraphOnly);
    });

    chooseGraphDirButton.addActionListener(e ->
    {
      chooseDefaultGraphDirectory(graphWindow, controller);
      File updatedGraphDir = getPreferredGraphDirectory(controller);
      currentDirLabel.setText(shortDirectoryLabel(updatedGraphDir));
      startInGraphDir.setSelected(true);
      lastStartInGraphDir = true;
      controller.setLoadGraphFromGraphDir(true);
      fc.setCurrentDirectory(updatedGraphDir);
    });

    accessory.add(startInGraphDir);
    accessory.add(graphOnly);
    accessory.add(Box.createVerticalStrut(8));
    accessory.add(new JLabel("Default Graph dir:"));
    accessory.add(currentDirLabel);
    accessory.add(Box.createVerticalStrut(6));
    accessory.add(chooseGraphDirButton);
    fc.setAccessory(accessory);

    loadGraphFromChooser(fc, graphWindow, controller, "Load GRAPH File");
  }


  public void loadOPN(GraphWindow graphWindow, GraphController controller)
  {
    File baseDir = new File(System.getProperty("user.dir"));
    File graphDir = getPreferredGraphDirectory(controller);
    JFileChooser fc = createOPNLoadChooser(lastStartInGraphDir ? graphDir : baseDir);
    fc.setDialogTitle("Open OPN File");
    fc.setApproveButtonText("Open OPN");

    JPanel accessory = new JPanel();
    accessory.setLayout(new BoxLayout(accessory, BoxLayout.Y_AXIS));

    JCheckBox startInGraphDir = new JCheckBox("Start in Graph dir", lastStartInGraphDir);
    JLabel currentDirLabel = new JLabel(shortDirectoryLabel(graphDir));
    JButton chooseGraphDirButton = new JButton("Set Default Graph Dir...");

    startInGraphDir.addActionListener(e ->
    {
      lastStartInGraphDir = startInGraphDir.isSelected();
      controller.setLoadGraphFromGraphDir(lastStartInGraphDir);
      fc.setCurrentDirectory(lastStartInGraphDir ? getPreferredGraphDirectory(controller) : baseDir);
      currentDirLabel.setText(shortDirectoryLabel(getPreferredGraphDirectory(controller)));
    });

    chooseGraphDirButton.addActionListener(e ->
    {
      chooseDefaultGraphDirectory(graphWindow, controller);
      File updatedGraphDir = getPreferredGraphDirectory(controller);
      currentDirLabel.setText(shortDirectoryLabel(updatedGraphDir));
      startInGraphDir.setSelected(true);
      lastStartInGraphDir = true;
      controller.setLoadGraphFromGraphDir(true);
      fc.setCurrentDirectory(updatedGraphDir);
    });

    accessory.add(startInGraphDir);
    accessory.add(Box.createVerticalStrut(8));
    accessory.add(new JLabel("Default Graph dir:"));
    accessory.add(currentDirLabel);
    accessory.add(Box.createVerticalStrut(6));
    accessory.add(chooseGraphDirButton);
    fc.setAccessory(accessory);

    loadGraphFromChooser(fc, graphWindow, controller, "Open OPN");
  }

  public void chooseDefaultGraphDirectory(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = new JFileChooser(getPreferredGraphDirectory(controller));
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setDialogTitle("Set Default Graph Directory");
    fc.setApproveButtonText("Set Graph Dir");

    int returnVal = fc.showDialog(graphWindow, "Set Graph Dir");
    if ( returnVal == JFileChooser.APPROVE_OPTION && fc.getSelectedFile() != null )
    {
      try
      {
        File selected = fc.getSelectedFile().getCanonicalFile();
        controller.setPreferredGraphDirectoryPath(selected.getPath());
        controller.setLoadGraphFromGraphDir(true);
      }
      catch ( IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to use the selected directory as the default Graph directory.",
                                      "Unable to Set Graph Directory",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void loadGraphFromDir(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = createGraphLoadChooser(getPreferredGraphDirectory(controller), true);
    fc.setDialogTitle("Load GRAPH / OPN from Graph directory");
    fc.setApproveButtonText("Load GRAPH / OPN");
    loadGraphFromChooser(fc, graphWindow, controller, "Load GRAPH File");
  }

  public boolean loadGraphFromPath(GraphWindow graphWindow, GraphController controller, String graphPath)
  {
    if ( graphPath == null || graphPath.trim().length() == 0 )
    {
      return false;
    }

    File selectedFile = new File(graphPath.trim());
    Graph graph = loadGraphFile(selectedFile, graphWindow);
    if ( graph == null )
    {
      return false;
    }

    return openGraphInEditor(graphWindow, controller, graph, selectedFile.getPath());
  }

  public void saveGraph(GraphWindow graphWindow, GraphEditorWindow editorWindow)
  {
    JFileChooser fc = createSaveChooser();
    GraphFilter graphFilter = getGraphFilter(fc);
    ImageFilter imageFilter = getImageFilter(fc);

    int returnVal = fc.showDialog(graphWindow, "Save Current Graph to File");

    if ( returnVal == JFileChooser.APPROVE_OPTION )
    {
      String savePath = "";
      try
      {
        savePath = fc.getSelectedFile().getCanonicalPath();
        String fileExt = Utils.getExtension(fc.getSelectedFile());
        if ( fc.getFileFilter() == graphFilter )
        {
          saveGraphFile(graphWindow, editorWindow, savePath, fileExt);
        }
        else if ( fc.getFileFilter() == imageFilter )
        {
          saveImageFile(graphWindow, editorWindow, savePath, fileExt);
        }
      }
      catch ( java.io.IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to write to the selected file.",
                                      "Unable to Save Graph",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  private void loadGraphFromChooser(JFileChooser fc,
                                    GraphWindow graphWindow,
                                    GraphController controller,
                                    String approveText)
  {
    int returnVal = fc.showDialog(graphWindow, approveText);

    if ( returnVal == JFileChooser.APPROVE_OPTION )
    {
      File selectedFile = fc.getSelectedFile();
      Graph graph = loadGraphFile(selectedFile, graphWindow);
      if ( graph != null )
      {
        openGraphInEditor(graphWindow, controller, graph, selectedFile.getPath());
      }
    }
  }

  private Graph loadGraphFile(File selectedFile, GraphWindow graphWindow)
  {
    String loadGraphPath = "";
    Graph graph = null;
    try
    {
      loadGraphPath = selectedFile.getCanonicalPath();
      if ( isOPNFile(selectedFile) )
      {
        graph = loadOPNFileAsGraph(selectedFile);
      }
      else
      {
        BufferedReader aReader = new BufferedReader(new FileReader(loadGraphPath));
        try
        {
          graph = Graph.loadFrom(aReader);
        }
        finally
        {
          aReader.close();
        }
      }
      graph.setFilePath(loadGraphPath);
      return graph;
    }
    catch ( java.io.IOException ioe )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The selected file could not be parsed as a GRAPH / OPN file.\n\n" +
                                    "Path: " + loadGraphPath + "\n" +
                                    "Reason: " + ioe.getMessage(),
                                    "Unable to load graph file",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
    catch ( Exception ex )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The selected file could not be loaded as a GRAPH / OPN file.\n\n" +
                                    "Path: " + loadGraphPath + "\n" +
                                    "Reason: " + ex.getClass().getName() +
                                    (ex.getMessage() != null ? ": " + ex.getMessage() : ""),
                                    "Unable to load graph file",
                                    JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
      return null;
    }
  }

  private boolean openGraphInEditor(GraphWindow graphWindow,
                                    GraphController controller,
                                    Graph graph,
                                    String loadGraphPath)
  {
    try
    {
      graphWindow.addGraphEditorWindow(controller, graph);
      return true;
    }
    catch ( Exception ex )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The GRAPH / OPN file was parsed, but the editor window could not be opened.\n\n" +
                                    "Path: " + loadGraphPath + "\n" +
                                    "Reason: " + ex.getClass().getName() +
                                    (ex.getMessage() != null ? ": " + ex.getMessage() : ""),
                                    "Unable to open loaded graph",
                                    JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
      return false;
    }
  }


  private boolean isOPNFile(File selectedFile)
  {
    String extension = Utils.getExtension(selectedFile);
    return extension != null && extension.equalsIgnoreCase(Utils.opn);
  }

  private Graph loadOPNFileAsGraph(File selectedFile) throws IOException
  {
    java.util.List lines = readAllLines(selectedFile);
    if ( containsTrimmedLine(lines, "structure:") )
    {
      return loadStructuredYamlOPN(lines, selectedFile);
    }
    if ( containsTrimmedLine(lines, "STRUCTURE_NODES:") )
    {
      return loadPipeStructureOPN(lines, selectedFile);
    }
    if ( containsLine(lines, "LEXICAL_ITEMS:") )
    {
      return loadFramePlacementDemoOPN(lines, selectedFile);
    }
    throw new IOException("No drawable OPN structure found. Expected structure.nodes/structure.edges or STRUCTURE_NODES/STRUCTURE_EDGES.");
  }

  private Graph loadStructuredYamlOPN(java.util.List lines, File selectedFile) throws IOException
  {
    Graph graph = new Graph(displayNameWithoutExtension(selectedFile));
    graph.setGrid(16, 20, 28, 20, false);
    java.util.Map idToNode = new java.util.LinkedHashMap();
    java.util.List edgeFrom = new java.util.ArrayList();
    java.util.List edgeTo = new java.util.ArrayList();
    boolean inStructure = false;
    boolean inNodes = false;
    boolean inEdges = false;
    java.util.Map currentNode = null;
    java.util.Map currentEdge = null;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.length() == 0 || line.startsWith("#") ) continue;
      if ( line.equals("structure:") ) { inStructure = true; inNodes = false; inEdges = false; continue; }
      if ( !inStructure ) continue;
      if ( line.equals("notes:") || line.equals("meta:") ) break;
      if ( line.equals("nodes:") )
      {
        if ( currentEdge != null ) { addStructuredEdgeLists(edgeFrom, edgeTo, currentEdge); currentEdge = null; }
        inNodes = true; inEdges = false; continue;
      }
      if ( line.equals("edges:") )
      {
        if ( currentNode != null ) { addStructuredNode(graph, idToNode, currentNode); currentNode = null; }
        inNodes = false; inEdges = true; continue;
      }
      if ( inNodes )
      {
        if ( line.startsWith("- ") )
        {
          if ( currentNode != null ) addStructuredNode(graph, idToNode, currentNode);
          currentNode = new java.util.LinkedHashMap();
          parseKeyValueInto(currentNode, line.substring(2).trim());
        }
        else if ( currentNode != null ) parseKeyValueInto(currentNode, line);
      }
      else if ( inEdges )
      {
        if ( line.startsWith("- ") )
        {
          if ( currentEdge != null ) addStructuredEdgeLists(edgeFrom, edgeTo, currentEdge);
          currentEdge = new java.util.LinkedHashMap();
          parseKeyValueInto(currentEdge, line.substring(2).trim());
        }
        else if ( currentEdge != null ) parseKeyValueInto(currentEdge, line);
      }
    }
    if ( currentNode != null ) addStructuredNode(graph, idToNode, currentNode);
    if ( currentEdge != null ) addStructuredEdgeLists(edgeFrom, edgeTo, currentEdge);
    connectStructuredEdges(graph, idToNode, edgeFrom, edgeTo);
    applyMappingV1Info(graph, lines);
    if ( idToNode.size() == 0 ) throw new IOException("OPN structure.nodes section contained no nodes.");
    return graph;
  }

  private Graph loadPipeStructureOPN(java.util.List lines, File selectedFile) throws IOException
  {
    Graph graph = new Graph(displayNameWithoutExtension(selectedFile));
    graph.setGrid(24, 20, 30, 20, false);
    java.util.Map idToNode = new java.util.LinkedHashMap();
    java.util.List edgeFrom = new java.util.ArrayList();
    java.util.List edgeTo = new java.util.ArrayList();
    boolean inNodes = false;
    boolean inEdges = false;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.length() == 0 || line.startsWith("#") ) continue;
      if ( line.equals("STRUCTURE_NODES:") ) { inNodes = true; inEdges = false; continue; }
      if ( line.equals("STRUCTURE_EDGES:") ) { inNodes = false; inEdges = true; continue; }
      if ( line.endsWith(":") ) { inNodes = false; inEdges = false; continue; }
      if ( inNodes )
      {
        String[] parts = splitPipe(line);
        if ( parts.length >= 4 )
        {
          String id = parts[0];
          String label = parts[1];
          int x = parseIntSafe(parts[2], 0) * 25 + 40;
          int y = parseIntSafe(parts[3], 0) * 25 + 40;
          Node node = labeledNode(x, y, label);
          graph.addNode(node, false);
          idToNode.put(id, node);
        }
      }
      else if ( inEdges )
      {
        String[] parts = splitPipe(line);
        if ( parts.length >= 2 ) { edgeFrom.add(parts[0]); edgeTo.add(parts[1]); }
      }
    }
    connectStructuredEdges(graph, idToNode, edgeFrom, edgeTo);
    applyMappingV1Info(graph, lines);
    if ( idToNode.size() == 0 ) throw new IOException("OPN STRUCTURE_NODES section contained no nodes.");
    return graph;
  }

  private void applyMappingV1Info(Graph graph, java.util.List lines)
  {
    if ( graph == null || lines == null ) return;
    boolean hasMapping = containsTrimmedLine(lines, "MAPPING_V3:") ||
      containsTrimmedLine(lines, "MAPPING_V2:") ||
      containsTrimmedLine(lines, "MAPPING_V1:") || containsTrimmedLine(lines, "MAPPING:");
    if ( !hasMapping ) return;

    String endMarker = getMappingEndMarker(lines);
    int lexicalItems = countPipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    int verbDomains = countPipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    int placementRules = countPipeSectionRows(lines, "PLACEMENT_RULES:", endMarker);
    graph.setOPNMappingInfo(getMappingVersionLabel(lines), lexicalItems, verbDomains, placementRules);
    applyMappingV1Validation(graph, lines);
    applyMappingV1Generation(graph, lines);
  }

  private String getMappingEndMarker(java.util.List lines)
  {
    if ( containsTrimmedLine(lines, "END_MAPPING_V3:") ) return "END_MAPPING_V3:";
    if ( containsTrimmedLine(lines, "END_MAPPING_V2:") ) return "END_MAPPING_V2:";
    return "END_MAPPING_V1:";
  }


  private String getMappingVersionLabel(java.util.List lines)
  {
    if ( containsTrimmedLine(lines, "MAPPING_V3:") ) return "v3";
    if ( containsTrimmedLine(lines, "MAPPING_V2:") ) return "v2";
    return "v1";
  }

  private int countPipeSectionRows(java.util.List lines, String startMarker, String endMarker)
  {
    boolean inSection = false;
    int count = 0;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.equals(startMarker) )
      {
        inSection = true;
        continue;
      }
      if ( inSection && line.equals(endMarker) ) break;
      if ( inSection )
      {
        if ( line.length() == 0 || line.startsWith("#") ) continue;
        if ( line.endsWith(":") ) break;
        if ( line.indexOf("|") >= 0 ) count++;
      }
    }
    return count;
  }


  private void applyMappingV1Validation(Graph graph, java.util.List lines)
  {
    java.util.Map roleToX = new java.util.HashMap();
    java.util.Map roleToWord = new java.util.HashMap();
    java.util.Map xToWord = new java.util.HashMap();
    java.util.Map verbDomain = new java.util.HashMap();
    java.util.List rules = new java.util.ArrayList();

    readLexicalItemsForValidation(lines, roleToX, roleToWord, xToWord);
    readVerbDomainForValidation(lines, verbDomain);
    readPlacementRulesForValidation(lines, rules);

    int passed = 0;
    int failed = 0;
    java.util.List failures = new java.util.ArrayList();
    int vAnchor = getVerbAnchorX(verbDomain);

    java.util.List validationRules = isMappingV3(lines) ? bestPlacementRules(rules) : rules;

    for ( int i=0; i<validationRules.size(); i++ )
    {
      String[] rule = (String[])validationRules.get(i);
      String role = rule[0];
      String relation = rule[1];
      String target = rule[2];
      boolean ok = validatePlacementRule(role, relation, target, roleToX, vAnchor);
      if ( ok ) passed++;
      else
      {
        failed++;
        failures.add(role + " " + relation + " " + target);
      }
    }

    String details = "";
    if ( failed > 0 ) details = joinFailureList(failures);
    else if ( validationRules.size() > 0 ) details = "best placement rules satisfied";
    graph.setOPNMappingV1Validation(passed, failed, details);
  }

  private void applyMappingV1Generation(Graph graph, java.util.List lines)
  {
    java.util.Map roleToWord = new java.util.HashMap();
    java.util.Map roleToX = new java.util.HashMap();
    readLexicalItemsForGenerator(lines, roleToWord, roleToX);

    java.util.Map verbDomain = new java.util.HashMap();
    readVerbDomainForValidation(lines, verbDomain);

    java.util.List rules = new java.util.ArrayList();
    readPlacementRulesForValidation(lines, rules);

    if ( isMappingV3(lines) )
    {
      String generated = generateV3UtteranceSummary(roleToWord, roleToX, verbDomain, rules);
      if ( generated.length() > 0 ) graph.setOPNMappingV1GeneratedUtterance(generated);
    }
    else
    {
      java.util.List generated = generateUtteranceFromPlacementRules(roleToWord, roleToX, verbDomain, rules);
      if ( generated.size() == 0 ) return;
      graph.setOPNMappingV1GeneratedUtterance(joinWords(generated));
    }
  }

  private boolean isMappingV3(java.util.List lines)
  {
    return containsTrimmedLine(lines, "MAPPING_V3:");
  }

  private java.util.List bestPlacementRules(java.util.List rules)
  {
    java.util.List filtered = new java.util.ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      if ( isCoreRule(rule) || getRuleRank(rule) == 1 ) filtered.add(rule);
    }
    return filtered;
  }

  private boolean isCoreRule(String[] rule)
  {
    if ( rule == null || rule.length < 4 ) return true;
    String marker = rule[3] == null ? "" : rule[3].trim();
    return marker.length() == 0 || marker.equalsIgnoreCase("core") || marker.equals("-");
  }

  private int getRuleRank(String[] rule)
  {
    if ( rule == null || rule.length < 4 ) return 0;
    String marker = rule[3] == null ? "" : rule[3].trim();
    if ( marker.startsWith("rank:") ) marker = marker.substring("rank:".length());
    if ( marker.startsWith("pref:") ) marker = marker.substring("pref:".length());
    try { return Integer.parseInt(marker); } catch ( Exception e ) { return 0; }
  }

  private String generateV3UtteranceSummary(java.util.Map roleToWord,
                                            java.util.Map roleToX,
                                            java.util.Map verbDomain,
                                            java.util.List rules)
  {
    java.util.List bestRules = bestPlacementRules(rules);
    java.util.List bestWords = generateUtteranceFromPlacementRules(roleToWord, roleToX, verbDomain, bestRules);
    if ( bestWords.size() == 0 ) return "";
    String best = joinWords(bestWords);

    java.util.List alternatives = new java.util.ArrayList();
    java.util.List optionRules = nonBestOptionRules(rules);
    for ( int i=0; i<optionRules.size(); i++ )
    {
      String[] option = (String[])optionRules.get(i);
      java.util.List candidateRules = replaceBestRuleForRole(bestRules, option);
      java.util.List candidateWords = generateUtteranceFromPlacementRules(roleToWord, roleToX, verbDomain, candidateRules);
      if ( candidateWords.size() == 0 ) continue;
      String candidate = joinWords(candidateWords);
      if ( !candidate.equals(best) && !alternatives.contains(candidate) ) alternatives.add(candidate);
      if ( alternatives.size() >= 3 ) break;
    }

    StringBuffer result = new StringBuffer();
    result.append("best: ").append(best);
    if ( alternatives.size() > 0 )
    {
      result.append("; alternatives: ");
      for ( int i=0; i<alternatives.size(); i++ )
      {
        if ( i > 0 ) result.append(" | ");
        result.append(alternatives.get(i).toString());
      }
    }
    return result.toString();
  }

  private java.util.List nonBestOptionRules(java.util.List rules)
  {
    java.util.List result = new java.util.ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      int rank = getRuleRank(rule);
      if ( rank > 1 ) result.add(rule);
    }
    java.util.Collections.sort(result, new java.util.Comparator() {
      public int compare(Object a, Object b)
      {
        return getRuleRank((String[])a) - getRuleRank((String[])b);
      }
    });
    return result;
  }

  private java.util.List replaceBestRuleForRole(java.util.List bestRules, String[] option)
  {
    java.util.List result = new java.util.ArrayList();
    String role = option != null && option.length > 0 ? option[0] : "";
    for ( int i=0; i<bestRules.size(); i++ )
    {
      String[] rule = (String[])bestRules.get(i);
      if ( rule.length > 0 && rule[0].equals(role) && !isCoreRule(rule) ) continue;
      result.add(rule);
    }
    result.add(option);
    return result;
  }


  private void readLexicalItemsForGenerator(java.util.List lines, java.util.Map roleToWord, java.util.Map roleToX)
  {
    java.util.Map xToWord = new java.util.HashMap();
    readLexicalItemsForValidation(lines, roleToX, roleToWord, xToWord);
  }

  private java.util.List generateUtteranceFromPlacementRules(java.util.Map roleToWord,
                                                            java.util.Map roleToX,
                                                            java.util.Map verbDomain,
                                                            java.util.List rules)
  {
    java.util.List roles = sortedRolesByX(roleToX);
    if ( roles.size() == 0 ) return new java.util.ArrayList();

    java.util.Map before = new java.util.HashMap();
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new java.util.ArrayList());

    String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      String role = rule[0];
      String relation = rule[1];
      String target = rule[2];
      if ( roleToWord.get(role) == null ) continue;

      if ( relation.equals("left_of") && target.equals("V") )
      {
        addOrderingConstraint(before, role, vAnchorRole);
      }
      else if ( relation.equals("right_of") && target.equals("V") )
      {
        addOrderingConstraint(before, vAnchorRole, role);
      }
      else if ( relation.equals("realizes_before") || relation.equals("before") )
      {
        addOrderingConstraint(before, role, target);
      }
      else if ( relation.equals("realizes_after") || relation.equals("after") )
      {
        addOrderingConstraint(before, target, role);
      }
      else if ( relation.equals("after_aux_before_object") )
      {
        addOrderingConstraint(before, "V-AUX", role);
        addOrderingConstraint(before, role, target);
      }
    }

    java.util.List orderedRoles = topologicalRoleOrder(roles, before);
    java.util.List words = new java.util.ArrayList();
    for ( int i=0; i<orderedRoles.size(); i++ )
    {
      Object word = roleToWord.get((String)orderedRoles.get(i));
      if ( word != null && word.toString().length() > 0 ) words.add(word.toString());
    }
    return words;
  }

  private java.util.List sortedRolesByX(final java.util.Map roleToX)
  {
    java.util.List roles = new java.util.ArrayList(roleToX.keySet());
    java.util.Collections.sort(roles, new java.util.Comparator() {
      public int compare(Object a, Object b)
      {
        Integer xa = (Integer)roleToX.get(a);
        Integer xb = (Integer)roleToX.get(b);
        int av = xa == null ? Integer.MAX_VALUE : xa.intValue();
        int bv = xb == null ? Integer.MAX_VALUE : xb.intValue();
        if ( av != bv ) return av - bv;
        return a.toString().compareTo(b.toString());
      }
    });
    return roles;
  }

  private String findVerbAnchorRole(java.util.Map roleToX, java.util.Map verbDomain)
  {
    Object value = verbDomain.get("V");
    if ( value == null ) return null;
    String[] xs = value.toString().split(",");
    int bestX = Integer.MAX_VALUE;
    String bestRole = null;
    for ( int i=0; i<xs.length; i++ )
    {
      int x = parseXIndex(xs[i].trim());
      if ( x < 0 ) continue;
      java.util.Iterator it = roleToX.keySet().iterator();
      while ( it.hasNext() )
      {
        String role = (String)it.next();
        Integer rx = (Integer)roleToX.get(role);
        if ( rx != null && rx.intValue() == x && x < bestX )
        {
          bestX = x;
          bestRole = role;
        }
      }
    }
    return bestRole;
  }

  private void addOrderingConstraint(java.util.Map before, String first, String second)
  {
    if ( first == null || second == null || first.equals(second) ) return;
    java.util.List list = (java.util.List)before.get(first);
    if ( list == null )
    {
      list = new java.util.ArrayList();
      before.put(first, list);
    }
    if ( !list.contains(second) ) list.add(second);
    if ( before.get(second) == null ) before.put(second, new java.util.ArrayList());
  }

  private java.util.List topologicalRoleOrder(java.util.List initialRoles, java.util.Map before)
  {
    java.util.List remaining = new java.util.ArrayList(initialRoles);
    java.util.List ordered = new java.util.ArrayList();
    while ( remaining.size() > 0 )
    {
      String candidate = null;
      for ( int i=0; i<remaining.size(); i++ )
      {
        String role = (String)remaining.get(i);
        if ( hasNoIncomingConstraints(role, remaining, before) )
        {
          candidate = role;
          break;
        }
      }
      if ( candidate == null )
      {
        ordered.addAll(remaining);
        break;
      }
      ordered.add(candidate);
      remaining.remove(candidate);
    }
    return ordered;
  }

  private boolean hasNoIncomingConstraints(String role, java.util.List remaining, java.util.Map before)
  {
    for ( int i=0; i<remaining.size(); i++ )
    {
      String other = (String)remaining.get(i);
      java.util.List list = (java.util.List)before.get(other);
      if ( list != null && list.contains(role) ) return false;
    }
    return true;
  }

  private void addGeneratedRole(java.util.List generated, java.util.Map roleToWord, String role)
  {
    Object word = roleToWord.get(role);
    if ( word != null && word.toString().length() > 0 ) generated.add(word.toString());
  }

  private String joinWords(java.util.List words)
  {
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<words.size(); i++ )
    {
      if ( i > 0 ) buffer.append(" ");
      buffer.append(words.get(i).toString());
    }
    return buffer.toString();
  }

  private void readLexicalItemsForValidation(java.util.List lines, java.util.Map roleToX,
                                             java.util.Map roleToWord, java.util.Map xToWord)
  {
    java.util.List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 ) continue;
      String xId = parts[0];
      String word = parts[1];
      int x = parseXIndex(xId);
      xToWord.put(xId, word);
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("role:") )
        {
          String role = part.substring("role:".length());
          roleToX.put(role, new Integer(x));
          roleToWord.put(role, word);
        }
      }
    }
  }

  private void readVerbDomainForValidation(java.util.List lines, java.util.Map verbDomain)
  {
    java.util.List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 3 ) verbDomain.put(parts[0], parts[2]);
    }
  }

  private void readPlacementRulesForValidation(java.util.List lines, java.util.List rules)
  {
    java.util.List rows = pipeSectionRows(lines, "PLACEMENT_RULES:", getMappingEndMarker(lines));
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 4 ) rules.add(new String[] { parts[0], parts[1], parts[2], parts[3] });
      else if ( parts.length >= 3 ) rules.add(new String[] { parts[0], parts[1], parts[2] });
    }
  }

  private java.util.List pipeSectionRows(java.util.List lines, String startMarker, String endMarker)
  {
    java.util.List rows = new java.util.ArrayList();
    boolean inSection = false;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.equals(startMarker) )
      {
        inSection = true;
        continue;
      }
      if ( inSection && line.equals(endMarker) ) break;
      if ( inSection )
      {
        if ( line.length() == 0 || line.startsWith("#") ) continue;
        if ( line.endsWith(":") ) break;
        if ( line.indexOf("|") >= 0 ) rows.add(line);
      }
    }
    return rows;
  }

  private boolean validatePlacementRule(String role, String relation, String target,
                                        java.util.Map roleToX, int vAnchor)
  {
    if ( relation.equals("left_of") && target.equals("V") )
    {
      Integer x = (Integer)roleToX.get(role);
      return x != null && vAnchor >= 0 && x.intValue() < vAnchor;
    }
    if ( relation.equals("right_of") && target.equals("V") )
    {
      Integer x = (Integer)roleToX.get(role);
      return x != null && vAnchor >= 0 && x.intValue() > vAnchor;
    }
    if ( relation.equals("realizes_before") )
    {
      Integer x = (Integer)roleToX.get(role);
      Integer y = (Integer)roleToX.get(target);
      return x != null && y != null && x.intValue() < y.intValue();
    }
    if ( relation.equals("realizes_after") )
    {
      Integer x = (Integer)roleToX.get(role);
      Integer y = (Integer)roleToX.get(target);
      return x != null && y != null && x.intValue() > y.intValue();
    }
    if ( relation.equals("after_aux_before_object") )
    {
      Integer x = (Integer)roleToX.get(role);
      Integer aux = (Integer)roleToX.get("V-AUX");
      Integer obj = (Integer)roleToX.get(target);
      return x != null && aux != null && obj != null &&
        aux.intValue() < x.intValue() && x.intValue() < obj.intValue();
    }
    return true;
  }

  private int getVerbAnchorX(java.util.Map verbDomain)
  {
    Object value = verbDomain.get("V");
    if ( value == null ) return -1;
    String text = value.toString();
    String[] parts = text.split(",");
    int best = Integer.MAX_VALUE;
    for ( int i=0; i<parts.length; i++ )
    {
      int x = parseXIndex(parts[i].trim());
      if ( x >= 0 && x < best ) best = x;
    }
    return best == Integer.MAX_VALUE ? -1 : best;
  }

  private int parseXIndex(String xId)
  {
    if ( xId == null ) return -1;
    String s = xId.trim();
    if ( s.length() > 0 && (s.charAt(0) == 'x' || s.charAt(0) == 'X') ) s = s.substring(1);
    return parseIntSafe(s, -1);
  }

  private String joinFailureList(java.util.List failures)
  {
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<failures.size(); i++ )
    {
      if ( i > 0 ) buffer.append(", ");
      buffer.append((String)failures.get(i));
      if ( i >= 2 && failures.size() > 3 )
      {
        buffer.append(", ...");
        break;
      }
    }
    return buffer.toString();
  }

  private void addStructuredNode(Graph graph, java.util.Map idToNode, java.util.Map nodeData) throws IOException
  {
    String id = (String)nodeData.get("id");
    if ( id == null || id.length() == 0 ) throw new IOException("OPN node without id.");
    String label = (String)nodeData.get("label");
    int x = parseIntSafe((String)nodeData.get("x"), 0);
    int y = parseIntSafe((String)nodeData.get("y"), 0);
    Node node = labeledNode(x, y, label == null ? id : label);
    graph.addNode(node, false);
    idToNode.put(id, node);
  }

  private void addStructuredEdgeLists(java.util.List edgeFrom, java.util.List edgeTo, java.util.Map edgeData)
  {
    String from = (String)edgeData.get("from");
    String to = (String)edgeData.get("to");
    if ( from != null && to != null ) { edgeFrom.add(from); edgeTo.add(to); }
  }

  private void connectStructuredEdges(Graph graph, java.util.Map idToNode, java.util.List edgeFrom, java.util.List edgeTo)
  {
    for ( int i=0; i<edgeFrom.size() && i<edgeTo.size(); i++ )
    {
      Node from = (Node)idToNode.get((String)edgeFrom.get(i));
      Node to = (Node)idToNode.get((String)edgeTo.get(i));
      if ( from != null && to != null ) graph.addEdgeNoCheck(from, to, false);
    }
  }

  private void parseKeyValueInto(java.util.Map map, String line)
  {
    int idx = line.indexOf(':');
    if ( idx < 0 ) return;
    String key = line.substring(0, idx).trim();
    String value = stripQuotes(line.substring(idx + 1).trim());
    map.put(key, value);
  }

  private String[] splitPipe(String line)
  {
    java.util.List parts = new java.util.ArrayList();
    String[] rawParts = line.split("\\|");
    for ( int i=0; i<rawParts.length; i++ ) parts.add(rawParts[i].trim());
    return (String[])parts.toArray(new String[parts.size()]);
  }

  private boolean containsTrimmedLine(java.util.List lines, String text)
  {
    for ( int i=0; i<lines.size(); i++ )
    {
      String line = (String)lines.get(i);
      if ( line != null && line.trim().equals(text) ) return true;
    }
    return false;
  }

  private int parseIntSafe(String value, int fallback)
  {
    if ( value == null ) return fallback;
    try { return Integer.parseInt(value.trim()); } catch ( Exception ex ) { return fallback; }
  }

  private String displayNameWithoutExtension(File selectedFile)
  {
    String name = selectedFile == null ? "OPN" : selectedFile.getName();
    int idx = name.lastIndexOf('.');
    if ( idx > 0 ) return name.substring(0, idx);
    return name;
  }

  private java.util.List readAllLines(File selectedFile) throws IOException
  {
    java.util.List lines = new java.util.ArrayList();
    BufferedReader reader = new BufferedReader(new FileReader(selectedFile));
    try
    {
      String line;
      while ( (line = reader.readLine()) != null )
      {
        lines.add(line);
      }
    }
    finally
    {
      reader.close();
    }
    return lines;
  }

  private boolean containsLine(java.util.List lines, String text)
  {
    for ( int i=0; i<lines.size(); i++ )
    {
      String line = (String)lines.get(i);
      if ( line != null && line.trim().equals(text) )
      {
        return true;
      }
    }
    return false;
  }

  private Graph loadFramePlacementDemoOPN(java.util.List lines, File selectedFile)
  {
    Graph graph = new Graph("OPN: " + selectedFile.getName());
    graph.setGrid(12, 50, 12, 90, false);

    java.util.Map forms = new java.util.LinkedHashMap();
    java.util.Map positions = new java.util.LinkedHashMap();
    java.util.Map roles = new java.util.LinkedHashMap();
    java.util.Map syns = new java.util.LinkedHashMap();
    String currentItem = null;

    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.startsWith("- id: w") )
      {
        currentItem = valueAfterColon(line);
      }
      else if ( currentItem != null && line.startsWith("form:") )
      {
        forms.put(currentItem, valueAfterColon(line));
      }
      else if ( currentItem != null && line.startsWith("lex_position:") )
      {
        positions.put(currentItem, valueAfterColon(line));
      }
      else if ( line.startsWith("lexical_item: w") )
      {
        currentItem = valueAfterColon(line);
      }
      else if ( currentItem != null && line.startsWith("syntactic_label:") )
      {
        syns.put(currentItem, valueAfterColon(line));
      }
      else if ( currentItem != null && line.startsWith("role_label:") )
      {
        roles.put(currentItem, valueAfterColon(line));
      }
    }

    java.util.Map lexNodes = new java.util.LinkedHashMap();
    int index = 0;
    java.util.Iterator it = forms.keySet().iterator();
    while ( it.hasNext() )
    {
      String id = (String)it.next();
      String form = (String)forms.get(id);
      int x = 120 + index * 140;

      Node lex = labeledNode(x, 420, form);
      graph.addNode(lex, false);
      lexNodes.put(id, lex);

      String syn = (String)syns.get(id);
      if ( syn != null )
      {
        Node synNode = labeledNode(x, 320, syn);
        graph.addNode(synNode, false);
        graph.addEdgeNoCheck(synNode, lex, false);
      }

      String role = (String)roles.get(id);
      if ( role != null )
      {
        Node roleNode = labeledNode(x, 220, role);
        graph.addNode(roleNode, false);
        Node target = syn != null ? graph.nodeNamed(syn) : lex;
        graph.addEdgeNoCheck(roleNode, lex, false);
      }
      index++;
    }

    Node frame = labeledNode(120, 80, "FRAME");
    Node bezield = labeledNode(260, 80, "BEZIELD");
    Node onbezield = labeledNode(400, 80, "ONBEZIELD");
    graph.addNode(frame, false);
    graph.addNode(bezield, false);
    graph.addNode(onbezield, false);
    graph.addEdgeNoCheck(bezield, frame, false);
    graph.addEdgeNoCheck(onbezield, frame, false);

    Node v = labeledNode(260, 160, "V-centered OPN");
    graph.addNode(v, false);
    graph.addEdgeNoCheck(v, frame, false);
    return graph;
  }

  private Graph loadGenericOPNSummary(java.util.List lines, File selectedFile)
  {
    Graph graph = new Graph("OPN: " + selectedFile.getName());
    graph.setGrid(10, 50, 10, 100, false);
    Node root = labeledNode(160, 80, "OPN");
    graph.addNode(root, false);

    int row = 0;
    for ( int i=0; i<lines.size() && row < 8; i++ )
    {
      String line = ((String)lines.get(i)).trim();
      if ( line.length() == 0 || line.startsWith("#") )
      {
        continue;
      }
      if ( line.startsWith("[") || line.indexOf("OPN_VERSION") >= 0 || line.indexOf("STRUCTURE_TYPE") >= 0 ||
           line.indexOf("PROJECTION_") >= 0 || line.indexOf("output:") >= 0 )
      {
        Node node = labeledNode(160 + (row % 2) * 220, 170 + row * 45, trimOPNLabel(line));
        graph.addNode(node, false);
        graph.addEdgeNoCheck(root, node, false);
        row++;
      }
    }
    return graph;
  }

  private Node labeledNode(int x, int y, String label)
  {
    Node node = new Node(x, y);
    node.setLabel(label == null ? "" : label);
    return node;
  }

  private String valueAfterColon(String line)
  {
    int idx = line.indexOf(':');
    if ( idx < 0 )
    {
      return line.trim();
    }
    return stripQuotes(line.substring(idx + 1).trim());
  }

  private String stripQuotes(String value)
  {
    if ( value == null )
    {
      return "";
    }
    if ( value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"") )
    {
      return value.substring(1, value.length() - 1);
    }
    return value;
  }

  private String trimOPNLabel(String line)
  {
    if ( line == null )
    {
      return "";
    }
    String label = stripQuotes(line.trim());
    if ( label.length() > 48 )
    {
      return label.substring(0, 45) + "...";
    }
    return label;
  }

  private JFileChooser createGraphLoadChooser(File currentDirectory, boolean graphOnly)
  {
    JFileChooser fc = new JFileChooser();
    GraphFilter graphFilter = new GraphFilter();
    fc.addChoosableFileFilter(graphFilter);
    fc.setFileFilter(graphFilter);
    fc.setAcceptAllFileFilterUsed(!graphOnly);
    fc.setFileView(new GraphFileView());
    fc.setCurrentDirectory(currentDirectory);
    return fc;
  }


  private JFileChooser createOPNLoadChooser(File currentDirectory)
  {
    JFileChooser fc = new JFileChooser();
    OPNFilter opnFilter = new OPNFilter();
    fc.addChoosableFileFilter(opnFilter);
    fc.setFileFilter(opnFilter);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setFileView(new GraphFileView());
    fc.setCurrentDirectory(currentDirectory);
    return fc;
  }

  private File getPreferredGraphDirectory(GraphController controller)
  {
    if ( controller != null )
    {
      String preferredPath = controller.getPreferredGraphDirectoryPath();
      if ( preferredPath != null && preferredPath.trim().length() > 0 )
      {
        File preferredDir = new File(preferredPath.trim());
        if ( preferredDir.exists() && preferredDir.isDirectory() )
        {
          return preferredDir;
        }
      }
    }

    File graphDir = new File(System.getProperty("user.dir"), "GRAPH");
    if ( graphDir.exists() && graphDir.isDirectory() )
    {
      return graphDir;
    }
    return new File(System.getProperty("user.dir"));
  }

  private String shortDirectoryLabel(File dir)
  {
    String path = dir.getPath();
    if ( path.length() > 36 )
    {
      return "..." + path.substring(path.length() - 33);
    }
    return path;
  }

  private JFileChooser createSaveChooser()
  {
    JFileChooser fc = new JFileChooser();
    GraphFilter graphFilter = new GraphFilter();
    ImageFilter imageFilter = new ImageFilter();
    fc.addChoosableFileFilter(graphFilter);
    fc.addChoosableFileFilter(imageFilter);
    fc.setFileFilter(graphFilter);
    fc.setFileView(new GraphFileView());
    File startDir = new File(System.getProperty("user.dir"));
    fc.setCurrentDirectory(startDir);
    fc.setSelectedFile(new File(startDir, "untitled.graph"));
    return fc;
  }

  private GraphFilter getGraphFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter filters[] = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof GraphFilter )
      {
        return (GraphFilter)filters[i];
      }
    }
    return null;
  }

  private ImageFilter getImageFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter filters[] = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof ImageFilter )
      {
        return (ImageFilter)filters[i];
      }
    }
    return null;
  }

  private void saveGraphFile(GraphWindow graphWindow, GraphEditorWindow editorWindow, String savePath, String fileExt) throws IOException
  {
    String targetPath = savePath;
    String targetExtension = fileExt;

    if ( targetExtension == null )
    {
      targetPath = targetPath + ".graph";
      targetExtension = Utils.graph;
    }

    if ( targetExtension != null && targetExtension.equalsIgnoreCase(Utils.graph) )
    {
      File aFile = new File(targetPath);
      if ( !aFile.exists() || confirmOverwrite(graphWindow, targetPath) )
      {
        PrintWriter aWriter = new PrintWriter(new FileWriter(targetPath));
        editorWindow.getGraphEditor().getGraph().saveTo(aWriter);
        aWriter.close();
      }
    }
    else
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Graphs may only be saved as .graph files.",
                                    "Unable to Save Graph",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private void saveImageFile(GraphWindow graphWindow, GraphEditorWindow editorWindow, String savePath, String fileExt)
  {
    if ( fileExt != null &&
         ( fileExt.equalsIgnoreCase(Utils.gif) ||
           fileExt.equalsIgnoreCase(Utils.jpg) ||
           fileExt.equalsIgnoreCase(Utils.jpeg) ) )
    {
      File aFile = new File(savePath);
      if ( !aFile.exists() || confirmOverwrite(graphWindow, savePath) )
      {
        editorWindow.getGraphEditor().saveImage(savePath);
      }
    }
    else
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Images may only be saved as .gif, .jpg, or .jpeg files.",
                                    "Unable to Save Graph Image",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private boolean confirmOverwrite(GraphWindow graphWindow, String targetPath)
  {
    int option = JOptionPane.showConfirmDialog(graphWindow,
                                               "Overwrite existing file?\n\n" + targetPath,
                                               "Confirm overwrite",
                                               JOptionPane.YES_NO_OPTION,
                                               JOptionPane.WARNING_MESSAGE);
    return option == JOptionPane.YES_OPTION;
  }
}
