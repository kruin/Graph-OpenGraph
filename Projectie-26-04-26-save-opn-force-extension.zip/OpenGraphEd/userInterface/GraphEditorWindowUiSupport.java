package userInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public final class GraphEditorWindowUiSupport
{
  private static final Insets DEFAULT_INSETS = new Insets(3,3,3,3);

  private GraphEditorWindowUiSupport()
  {
  }

  public static GridBagLayout installVerticalLayout(Container container)
  {
    GridBagLayout layout = new GridBagLayout();
    container.setLayout(layout);
    return layout;
  }

  public static void addFullWidth(Container container, GridBagLayout layout,
                                  Component component, int fill,
                                  double weightY)
  {
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.gridx = GridBagConstraints.RELATIVE;
    constraints.gridy = GridBagConstraints.RELATIVE;
    constraints.gridwidth = GridBagConstraints.REMAINDER;
    constraints.gridheight = 1;
    constraints.fill = fill;
    constraints.insets = DEFAULT_INSETS;
    constraints.anchor = GridBagConstraints.NORTH;
    constraints.weightx = 1.0;
    constraints.weighty = weightY;
    layout.setConstraints(component, constraints);
    container.add(component);
  }

  public static JScrollPane createScrollPane(Component component)
  {
    return new JScrollPane(component,
                           JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                           JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
  }

  public static JCheckBox createCheckBox(String text, boolean selected,
                                         ActionListener listener)
  {
    JCheckBox checkBox = new JCheckBox(text);
    checkBox.setSelected(selected);
    checkBox.addActionListener(listener);
    return checkBox;
  }
}
