package userInterface;

import javax.swing.*;
import java.awt.event.*;

public abstract class OpenGraphEdInternalFrame extends JInternalFrame
{
  protected JMenuItem menuItem;

  public OpenGraphEdInternalFrame( final GraphController controller, String title,
                                boolean resizable, boolean closable,
                                boolean maximizable, boolean iconifiable )
  {
    super(title, resizable, closable, maximizable, iconifiable);
    final OpenGraphEdInternalFrame thisCopy = this;
    menuItem = new JMenuItem(new OpenGraphEdInternalFrameAction( title, null,
                                   title, null, true )
    {
      public void actionPerformed(ActionEvent event)
      {
        controller.showWindow(thisCopy);
      }
    } );
    
    
  }

  public JMenuItem getMenuItem() { return menuItem; }
}

class OpenGraphEdInternalFrameAction extends AbstractAction
{

  public OpenGraphEdInternalFrameAction( String text, ImageIcon icon, String desc,
                                      Integer mnemonic, boolean enabled )
  {
    super(text, icon);
    setEnabled(enabled);
    putValue(SHORT_DESCRIPTION, desc);
    putValue(MNEMONIC_KEY, mnemonic);
  }

  public void actionPerformed(ActionEvent e)
  {
    // do nothing, overriden
  }
}