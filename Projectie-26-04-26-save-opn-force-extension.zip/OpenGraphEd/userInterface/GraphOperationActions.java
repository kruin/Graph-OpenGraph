package userInterface;

import javax.swing.*;
import java.awt.event.*;
import graphStructure.*;
import graphException.*;
import operation.*;

public class GraphOperationActions
{
  private static final String DEFAULT_RANDOM_NODES = "10";

  private final GraphWindow graphWindow;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;

  public GraphOperationActions(GraphWindow graphWindow,
                               GraphWindowCoordinator graphWindowCoordinator,
                               GraphEditorActions graphEditorActions)
  {
    this.graphWindow = graphWindow;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphEditorActions = graphEditorActions;
  }

  public void testConnectivity(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      if ( !editorWindow.getGraphEditor().getGraph().hasNodes() )
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Has No Nodes",
                                      "Connectivity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
      else if ( ConnectivityOperation.isConnected(editorWindow.getGraphEditor().getGraph()) )
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Is Connected",
                                      "Connectivity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
      else
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Is Not Connected",
                                      "Connectivity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
    }
  }

  public void testBiconnectivity(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      if ( !editorWindow.getGraphEditor().getGraph().hasNodes() )
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Has No Nodes",
                                      "Biconnectivity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
      else if ( BiconnectivityOperation.isBiconnected(editorWindow.getGraphEditor().getGraph()) )
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Is Biconnected",
                                      "Biconnectivity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
      else
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Is Not Biconnected",
                                      "Biconnectivity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
    }
  }

  public void testPlanarity(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      if ( !editorWindow.getGraphEditor().getGraph().hasNodes() )
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Has No Nodes.",
                                      "Planarity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
      else if ( PlanarityOperation.isPlanar(editorWindow.getGraphEditor().getGraph()) )
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Is Planar",
                                      "Planarity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
      else
      {
        JOptionPane.showMessageDialog(graphWindow, "The Graph Is Not Planar",
                                      "Planarity Test Results", JOptionPane.INFORMATION_MESSAGE);
      }
    }
  }

  public void createRandom(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      try
      {
        String numberString = (String)JOptionPane.showInputDialog(
                                      graphWindow,
                                      "Enter the number of random nodes to create",
                                      "Create X Random Nodes",
                                      JOptionPane.PLAIN_MESSAGE,
                                      null,
                                      null,
                                      DEFAULT_RANDOM_NODES);
        try
        {
          if ( numberString != null )
          {
            final int number = Integer.parseInt(numberString);
            if ( number < 0 )
            {
              throw new NumberFormatException("Value must be positive");
            }
            performMementoOperation(editorWindow,
                                    "Create Random",
                                    "Error During Create Random Operation",
                                    new GraphEditorMutation()
                                    {
                                      public void apply(GraphEditorWindow window) throws Exception
                                      {
                                        CreateRandomGraphOperation.createRandomNodes(
                                          window.getGraphEditor().getGraph(),
                                          number,
                                          window.getGraphEditor().getDrawWidth(),
                                          window.getGraphEditor().getDrawHeight());
                                      }
                                    },
                                    false,
                                    false,
                                    null);
          }
        }
        catch ( NumberFormatException nfe )
        {
          JOptionPane.showMessageDialog(graphWindow,
                                        "Please enter a positive whole number for the number of random nodes to create",
                                        "Invalid Input",
                                        JOptionPane.ERROR_MESSAGE);
        }
      }
      catch( Exception e )
      {
        showOperationError(e, "Error During Create Random Operation");
      }
    }
  }

  public void embedding(GraphEditorWindow editorWindow)
  {
    performMementoOperation(editorWindow,
                            "Embed",
                            "Error During Embedding Operation",
                            new GraphEditorMutation()
                            {
                              public void apply(GraphEditorWindow window) throws Exception
                              {
                                EmbedOperation.embed(window.getGraphEditor().getGraph());
                              }
                            },
                            false,
                            true,
                            "Hold down Control (or Control-Shift) and click on a Node or Edge");
  }

  public void makeConnected(GraphEditorWindow editorWindow)
  {
    performMementoOperation(editorWindow,
                            "Make Connected",
                            "Error During Make Connected Operation",
                            new GraphEditorMutation()
                            {
                              public void apply(GraphEditorWindow window) throws Exception
                              {
                                ConnectivityOperation.makeConnected(window.getGraphEditor().getGraph());
                              }
                            },
                            false,
                            false,
                            null);
  }

  public void makeBiconnected(GraphEditorWindow editorWindow)
  {
    performMementoOperation(editorWindow,
                            "Make Biconnected",
                            "Error During Make Biconnected Operation",
                            new GraphEditorMutation()
                            {
                              public void apply(GraphEditorWindow window) throws Exception
                              {
                                BiconnectivityOperation.makeBiconnected(window.getGraphEditor().getGraph());
                              }
                            },
                            false,
                            false,
                            null);
  }

  public void makeMaximal(GraphEditorWindow editorWindow)
  {
    performMementoOperation(editorWindow,
                            "Make Maximal",
                            "Error During Make Maximal Operation",
                            new GraphEditorMutation()
                            {
                              public void apply(GraphEditorWindow window) throws Exception
                              {
                                MakeMaximalOperation.makeMaximal(window.getGraphEditor().getGraph());
                              }
                            },
                            false,
                            false,
                            null);
  }

  public void straightLineEmbed(GraphEditorWindow editorWindow, final boolean clearGenerated)
  {
    performMementoOperation(editorWindow,
                            "Straight Line Embed",
                            "Error During Straight Line Embedding Operation",
                            new GraphEditorMutation()
                            {
                              public void apply(GraphEditorWindow window) throws Exception
                              {
                                SchnyderEmbeddingOperation.straightLineGridEmbed(
                                  window.getGraphEditor().getGraph(),
                                  window.getGraphEditor().getDrawWidth(),
                                  window.getGraphEditor().getDrawHeight() );
                                if ( clearGenerated )
                                {
                                  window.getGraphEditor().getGraph().deleteGeneratedEdges();
                                }
                              }
                            },
                            true,
                            false,
                            null);
  }

  public void displayST(GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      graphEditorActions.showLabels(editorWindow);
      performMementoOperation(editorWindow,
                              "Display ST Numbering",
                              "Error During ST Number Display",
                              new GraphEditorMutation()
                              {
                                public void apply(GraphEditorWindow window) throws Exception
                                {
                                  STNumberOperation.displayStNumbering(window.getGraphEditor().getGraph());
                                }
                              },
                              false,
                              false,
                              null);
    }
  }

  public void displayDijkstra(final GraphController controller, GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      editorWindow.getGraphEditor().update();

      SchnyderDialog dialog = new SchnyderDialog( controller,
        editorWindow,
        "Dijkstra Shortest Path",
        "Please Select a Source and Destination Node" )
      {
        public void actionPerformed(ActionEvent e)
        {
          GraphEditorWindow owner = getOwner();
          Graph graph = owner.getGraphEditor().getGraph();
          graph.newMemento("Display Dijkstra Shortest Path");
          try
          {
            Node[] nodeSelections = owner.getGraphEditor().getSpecialNodeSelections();
            DijkstraShortestPathOperation.drawShortestPath(graph,
              nodeSelections[0], nodeSelections[1]);
            owner.getGraphEditor().update();
            owner.getGraphEditor().allowNodeSelection(0);
            graphWindowCoordinator.closeDialogAndClearOwner(owner);
            graph.doneMemento();
            graphEditorActions.updateUndo(owner);
          }
          catch ( Exception ex )
          {
            graph.abortMemento();
            showOperationError(ex, "Error During Dijkstra Shortest Path Display");
          }
        }
      };
      dialog.disableRunButton();
      editorWindow.getGraphEditor().allowNodeSelection(2);
      graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
    }
  }

  private void performMementoOperation(GraphEditorWindow editorWindow,
                                       String mementoName,
                                       String errorTitle,
                                       GraphEditorMutation mutation,
                                       boolean setPreferredSize,
                                       boolean repaintOnly,
                                       String infoMessage)
  {
    if ( editorWindow != null )
    {
      Graph graph = editorWindow.getGraphEditor().getGraph();
      try
      {
        graph.newMemento(mementoName);
        mutation.apply(editorWindow);
        graph.doneMemento();
        graphEditorActions.updateUndo(editorWindow);
        if ( setPreferredSize )
        {
          editorWindow.getGraphEditor().setPreferredSize();
        }
        if ( repaintOnly )
        {
          editorWindow.getGraphEditor().repaint();
        }
        else
        {
          editorWindow.getGraphEditor().update();
        }
        if ( infoMessage != null )
        {
          JOptionPane.showMessageDialog(graphWindow, infoMessage,
                                        mementoName, JOptionPane.INFORMATION_MESSAGE);
        }
      }
      catch ( Exception e )
      {
        graph.abortMemento();
        showOperationError(e, errorTitle);
      }
    }
  }

  private void showOperationError(Exception e, String errorTitle)
  {
    JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                  errorTitle, JOptionPane.ERROR_MESSAGE);
    if ( !(e instanceof GraphException) )
    {
      e.printStackTrace();
    }
  }

  private static interface GraphEditorMutation
  {
    void apply(GraphEditorWindow editorWindow) throws Exception;
  }
}
