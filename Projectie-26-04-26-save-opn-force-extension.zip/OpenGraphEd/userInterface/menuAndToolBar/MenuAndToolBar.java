package userInterface.menuAndToolBar;

import javax.swing.*;
import userInterface.GraphController;
import userInterface.GraphEditor;
import graphStructure.Graph;
import java.awt.*;
import java.util.Vector;
import java.util.HashMap;

public class MenuAndToolBar
{
  private GraphController controller;
  private Vector actions;
  private HashMap groups;
  private JMenu fileMenu;
  private MenuAndToolBarAction saveOPNAction;

  private JMenuBar menuBar;
  private JToolBar toolBar;
  private JLabel cursorLocationLabel;
  private Point cursorPoint;
  private JMenu windowMenu;
  private JMenuItem noWindowItem;

  private MenuAndToolBarBuildSupport buildSupport;
  private MenuAndToolBarWindowSupport windowSupport;
  private MenuAndToolBarStateSupport stateSupport;

  public MenuAndToolBar(GraphController controller)
  {
    this.controller = controller;
    actions = new Vector();
    groups = new HashMap();
    cursorPoint = null;
    buildSupport = new MenuAndToolBarBuildSupport(this, controller);
    windowSupport = new MenuAndToolBarWindowSupport(this, controller);
    stateSupport = new MenuAndToolBarStateSupport(this, controller);
    buildSupport.createControls(MenuAndToolBarControlCatalog.loadControls());
    windowSupport.createSaveOPNAction();
    windowSupport.showSaveOPN();
    windowSupport.setSaveOPNEnabled(false);
    stateSupport.hideControls();
  }

  GraphController getController() { return controller; }

  Vector getActions() { return actions; }

  void addAction(MenuAndToolBarAction action)
  {
    actions.addElement(action);
  }

  void setMenuBar(JMenuBar menuBar) { this.menuBar = menuBar; }

  void setToolBar(JToolBar toolBar) { this.toolBar = toolBar; }

  void setCursorLocationLabel(JLabel cursorLocationLabel)
  {
    this.cursorLocationLabel = cursorLocationLabel;
  }

  void setFileMenu(JMenu fileMenu) { this.fileMenu = fileMenu; }

  JMenu getFileMenu() { return fileMenu; }

  void setWindowMenu(JMenu windowMenu) { this.windowMenu = windowMenu; }

  JMenu getWindowMenu() { return windowMenu; }

  void setNoWindowItem(JMenuItem noWindowItem) { this.noWindowItem = noWindowItem; }

  JMenuItem getNoWindowItem() { return noWindowItem; }

  void setSaveOPNAction(MenuAndToolBarAction saveOPNAction)
  {
    this.saveOPNAction = saveOPNAction;
  }

  MenuAndToolBarAction getSaveOPNAction() { return saveOPNAction; }

  void addToGroup(String group, MenuAndToolBarAction action)
  {
    if ( !groups.containsKey(group) )
    {
      groups.put(group, new Vector());
    }
    getGroup(group).add(action);
  }

  Vector getGroup(String group)
  {
    if ( groups.containsKey(group) )
    {
      return (Vector)groups.get(group);
    }
    else
    {
      return null;
    }
  }

  public JToolBar getToolBar() { return toolBar; }

  public JMenuBar getMenuBar() { return menuBar; }

  public void updateCursorLocation(Point cursorPoint)
  {
    this.cursorPoint = cursorPoint;
  }

  public Point getCursorPoint() { return cursorPoint; }

  public void setCursorLocationText(String text)
  {
    cursorLocationLabel.setText(text);
  }

  public void removeWindow(JMenuItem menuItem)
  {
    windowSupport.removeWindow(menuItem);
  }

  public void addWindow(JMenuItem menuItem)
  {
    windowSupport.addWindow(menuItem);
  }

  public void showControls(GraphEditor graphEditor)
  {
    stateSupport.showControls(graphEditor);
  }

  public void hideControls()
  {
    stateSupport.hideControls();
  }

  public void syncOptionStates()
  {
    stateSupport.syncOptionStates();
  }

  MenuAndToolBarAction getActionWithText(String text)
  {
    return stateSupport.getActionWithText(text);
  }

  public void showSaveOPN()
  {
    windowSupport.showSaveOPN();
  }

  public void hideSaveOPN()
  {
    windowSupport.hideSaveOPN();
  }

  public void setSaveOPNEnabled(boolean enabled)
  {
    windowSupport.setSaveOPNEnabled(enabled);
  }

  public void updateUndo(Graph g)
  {
    stateSupport.updateUndo(g);
  }
}
