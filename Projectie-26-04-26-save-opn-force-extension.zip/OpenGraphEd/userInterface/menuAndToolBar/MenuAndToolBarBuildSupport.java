package userInterface.menuAndToolBar;

import java.util.StringTokenizer;
import java.lang.reflect.Method;
import javax.swing.*;
import userInterface.GraphController;
import java.awt.*;
import java.util.Vector;

public class MenuAndToolBarBuildSupport
{
  private MenuAndToolBar owner;
  private GraphController controller;

  public MenuAndToolBarBuildSupport(MenuAndToolBar owner, GraphController controller)
  {
    this.owner = owner;
    this.controller = controller;
  }

  public void createControls(Vector controls)
  {
    JToolBar toolBar = new JToolBar();
    toolBar.setFloatable(false);
    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    toolBar.setLayout(layout);
    JMenuBar menuBar = new JMenuBar();

    JMenu menu = null;
    MenuAndToolBarAction action;
    for ( int i=0; i<controls.size(); i++ )
    {
      String current = (String)controls.elementAt(i);
      if ( isSeparator(current) )
      {
        addSeparator(toolBar, layout, layoutCons, current);
      }
      else if ( isMenu(current) )
      {
        menu = createMenu(current);
        menuBar.add(menu);
        if ( menu.getText().equals("File") )
        {
          owner.setFileMenu(menu);
        }
        if ( menu.getText().equals("Windows") )
        {
          owner.setWindowMenu(menu);
        }
      }
      else if ( isAction(current) )
      {
        action = createMenuAndToolbarAction(current);
        owner.addAction(action);
        addActionControls(toolBar, layout, layoutCons, menu, action);
      }
      else if ( isCursorLocationLabel(current) )
      {
        JLabel cursorLocationLabel = createCursorLocationLabel();
        owner.setCursorLocationLabel(cursorLocationLabel);
        addToolbarComponent(toolBar, layout, layoutCons, cursorLocationLabel, 2, new Insets(1,1,1,1), 0.01, 0.01);
      }
      else
      {
        // error
      }
    }

    owner.setToolBar(toolBar);
    owner.setMenuBar(menuBar);
  }

  private void addSeparator(JToolBar toolBar, GridBagLayout layout,
                            GridBagConstraints layoutCons, String current)
  {
    JPanel panel = new JPanel();
    int gridwidth = isNewLineSeparator(current) ? GridBagConstraints.REMAINDER : 1;
    addToolbarComponent(toolBar, layout, layoutCons, panel, gridwidth, new Insets(0,0,0,0), 0.0, 0.0);
  }

  private void addActionControls(JToolBar toolBar, GridBagLayout layout,
                                 GridBagConstraints layoutCons, JMenu menu,
                                 MenuAndToolBarAction action)
  {
    if ( !action.isCompound() )
    {
      if ( action.getText().equals("None") )
      {
        owner.setNoWindowItem(action.getMenuItem());
      }
      else if ( action.getButton() != null )
      {
        addToolbarComponent(toolBar, layout, layoutCons, action.getButton(), action.getWidth(), new Insets(1,1,1,1), 0.0, 0.0);
      }
      menu.add(action.getMenuItem());
    }
    else
    {
      CompoundMenuAndToolBarAction cAction = (CompoundMenuAndToolBarAction)action;
      Vector menuItems = cAction.getMenuItems();
      for ( int j=0; j<menuItems.size(); j++ )
      {
        menu.add((JRadioButtonMenuItem)menuItems.elementAt(j));
      }
      addToolbarComponent(toolBar, layout, layoutCons, cAction.getButtonChooser(), action.getWidth(), new Insets(1,1,1,1), 0.0, 0.0);
    }
  }

  private void addToolbarComponent(JToolBar toolBar, GridBagLayout layout,
                                   GridBagConstraints layoutCons,
                                   Component component, int gridwidth,
                                   Insets insets, double weightx,
                                   double weighty)
  {
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = gridwidth;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.NONE;
    layoutCons.insets = insets;
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = weightx;
    layoutCons.weighty = weighty;
    layout.setConstraints(component, layoutCons);
    toolBar.add(component);
  }

  private JLabel createCursorLocationLabel()
  {
    return new JLabel();
  }

  private boolean isSeparator(String s)
  {
    return s.startsWith("separator");
  }

  private boolean isNewLineSeparator(String s)
  {
    return isSeparator(s) && s.endsWith(",newline");
  }

  private boolean isMenu(String s)
  {
    return s.startsWith("M");
  }

  private boolean isAction(String s)
  {
    return s.startsWith("S") || s.startsWith("P") || s.startsWith("K");
  }

  private boolean isCursorLocationLabel(String s)
  {
    return s.equals("cursorLocationLabel");
  }

  private JMenu createMenu(String s)
  {
    StringTokenizer tok = new StringTokenizer(s,",");
    JMenu menu = null;
    if ( tok.countTokens() == 4 )
    {
      tok.nextToken();
      menu = new JMenu(tok.nextToken());
      menu.setMnemonic(getKeyCode(tok.nextToken()));
      menu.getAccessibleContext().setAccessibleDescription(tok.nextToken());
    }
    else
    {
      // error
    }
    return menu;
  }

  private MenuAndToolBarAction createMenuAndToolbarAction(String s)
  {
    return createMenuAndToolbarAction(new StringTokenizer(s,","));
  }

  private MenuAndToolBarAction createMenuAndToolbarAction(StringTokenizer tok)
  {
    MenuAndToolBarAction action = null;
    String type = tok.nextToken();
    if ( ( type.equals("S") && tok.countTokens() == 8 ) ||
         ( type.equals("C") && tok.countTokens() >= 8 ) ||
         ( type.equals("K") && tok.countTokens() == 8 ) )
    {
      String group = tok.nextToken();
      String text = tok.nextToken();
      String iconString = tok.nextToken();
      ImageIcon icon = null;
      if ( !iconString.equals("null") )
      {
        icon = new ImageIcon(MenuAndToolBar.class.getResource(iconString));
      }
      String desc = tok.nextToken();
      Integer mnemonic = Integer.valueOf(getKeyCode(tok.nextToken()));
      String enabledString = tok.nextToken();
      boolean enabled;
      if ( enabledString.equals("isApplication") )
      {
        enabled = controller.isApplication();
      }
      else
      {
        enabled = Boolean.valueOf(enabledString).booleanValue();
      }
      int width = Integer.parseInt(tok.nextToken());
      Method method = null;
      try
      {
        method = GraphController.class.getDeclaredMethod(tok.nextToken());
      }
      catch (NoSuchMethodException nsme)
      {
        // error
      }
      boolean isCheckBox = type.equals("K");
      boolean showToolbarButton = !isCheckBox;
      action = new MenuAndToolBarAction(text, icon, desc, mnemonic, enabled,
                                        width, method, type.equals("C"),
                                        isCheckBox, showToolbarButton,
                                        controller);
      owner.addToGroup(group, action);
    }
    else if ( type.equals("P") )
    {
      if ( tok.countTokens() > 8 )
      {
        String group = tok.nextToken();
        String text = tok.nextToken();
        ImageIcon icon = new ImageIcon(MenuAndToolBar.class.getResource(tok.nextToken()));
        String desc = tok.nextToken();
        Integer mnemonic = Integer.valueOf(getKeyCode(tok.nextToken()));
        boolean enabled = Boolean.valueOf(tok.nextToken()).booleanValue();
        int width = Integer.parseInt(tok.nextToken());
        int numChildren = Integer.parseInt(tok.nextToken());
        if ( tok.countTokens() == numChildren * 9 )
        {
          Vector v = new Vector(numChildren);
          for ( int j=0; j<numChildren; j++ )
          {
            v.addElement(createMenuAndToolbarAction(tok));
          }
          action = new CompoundMenuAndToolBarAction(text, icon, desc, mnemonic,
                                                    enabled, width, v,
                                                    controller);
          owner.addToGroup(group, action);
        }
        else
        {
          // error
        }
      }
      else
      {
        // error
      }
    }
    else
    {
      // error
    }
    return action;
  }

  private int getKeyCode(String ch)
  {
    if ( ch.length() != 1 )
    {
      return -1;
    }
    else
    {
      return (int)ch.charAt(0);
    }
  }
}
