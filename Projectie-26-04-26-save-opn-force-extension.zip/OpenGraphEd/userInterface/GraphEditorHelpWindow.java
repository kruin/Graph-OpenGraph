package userInterface;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class GraphEditorHelpWindow extends OpenGraphEdInternalFrame
  implements HyperlinkListener, TreeSelectionListener, ActionListener
{
  public static int WIDTH = 700;
  public static int HEIGHT = 400;

  private final GraphEditorHelpSupport helpSupport;

  public GraphEditorHelpWindow(GraphController controller)
  {
    super(controller, OpenGraphEdAppInfo.HELP_TITLE,
          true, //resizable
          true, //closable
          true, //maximizable
          false);//iconifiable

    helpSupport = new GraphEditorHelpSupport(this, this, this);

    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(helpSupport.getToolBar(), BorderLayout.NORTH);
    getContentPane().add(helpSupport.createSplitPane(), BorderLayout.CENTER);

    addInternalFrameListener(controller);

    setSize(WIDTH, HEIGHT);
    setVisible(true);
  }

  public void hyperlinkUpdate(HyperlinkEvent e)
  {
    helpSupport.handleHyperlinkUpdate(e);
  }

  public void valueChanged(TreeSelectionEvent e)
  {
    helpSupport.handleValueChanged();
  }

  public void actionPerformed(ActionEvent e)
  {
    helpSupport.handleAction(e.getSource());
  }
}
