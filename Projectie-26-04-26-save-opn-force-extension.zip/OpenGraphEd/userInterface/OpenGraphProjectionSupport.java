package userInterface;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.util.Collections;
import java.util.Comparator;
import java.util.Properties;
import java.util.Vector;
import graphStructure.Graph;
import graphStructure.Node;
import graphStructure.ProjectionDirection;
import graphStructure.ProjectionLayoutConfig;
import graphStructure.ProjectionLink;
import graphStructure.ProjectionType;

/**
 * Computes and renders the currently implemented OpenGraph projections.
 *
 * <p>The current first slice focuses on a static phrase/frame tree and renders
 * lexical projections on the left and syntactic projections on the right.
 * Bottom logical projections are shown only when the source node already
 * carries an explicit logical label. Projection labels stay outside the
 * visible OpenGraphGrid.</p>
 */
public final class OpenGraphProjectionSupport
{
  private static final int PROJECTION_BAND_CELLS = 1;
  private static final int LABEL_GAP = 6;
  private static final float PROJECTION_LINE_WIDTH = 2.0f;
  private static final int PROJECTION_AXIS_NODE_RADIUS = Node.RADIUS;
  private static final int RIGHT_LABEL_EXTRA_GAP = PROJECTION_AXIS_NODE_RADIUS + 4;
  private static final Color PROJECTION_AXIS_NODE_FILL_COLOR = Color.white;
  private static final Color PROJECTION_AXIS_NODE_BORDER_COLOR = GraphEditor.borderColor.darker();
  private static final String LEFT_PROJECTION_NAME = "LEX";
  private static final String RIGHT_PROJECTION_NAME = "SYN";
  private static final String TOP_PROJECTION_NAME = "PM";
  private static final String BOTTOM_PROJECTION_NAME = "LF";

  private OpenGraphProjectionSupport()
  {
  }

  public static OpenGraphProjectionSettings loadBestAvailable()
  {
    OpenGraphProjectionSettings settings = loadFromPath(OpenGraphGridSettingsIO.USER_SETTINGS_PATH);
    if ( settings != null )
    {
      return settings;
    }
    settings = loadFromPath(OpenGraphGridSettingsIO.DEFAULTS_PATH);
    if ( settings != null )
    {
      return settings;
    }
    return new OpenGraphProjectionSettings();
  }

  public static OpenGraphProjectionSettings fromDialog(OpenGraphDialog dialog)
  {
    OpenGraphProjectionSettings settings = new OpenGraphProjectionSettings();
    if ( dialog == null )
    {
      return settings;
    }

    settings.setStructureType(dialog.getStructureType());
    settings.setShowProjections(dialog.getShowProjections());
    settings.setLeftProjectionEnabled(dialog.getLeftProjectionEnabled());
    settings.setRightProjectionEnabled(dialog.getRightProjectionEnabled());
    settings.setTopProjectionEnabled(dialog.getTopProjectionEnabled());
    settings.setBottomProjectionEnabled(dialog.getBottomProjectionEnabled());
    settings.setLeftProjectionPosition(dialog.getLeftProjectionPosition());
    settings.setRightProjectionPosition(dialog.getRightProjectionPosition());
    settings.setTopProjectionPosition(dialog.getTopProjectionPosition());
    settings.setBottomProjectionPosition(dialog.getBottomProjectionPosition());
    settings.normalize();
    return settings;
  }

  public static boolean hasReservedLexicalProjection(OpenGraphProjectionSettings settings)
  {
    return hasProjectionFootprint(settings);
  }

  public static boolean hasRenderableProjectionContext(GraphEditor editor)
  {
    return editor != null && editor.isOpenGraphProjectionContextActive();
  }

  public static boolean syncProjectionModel(GraphEditor editor)
  {
    return ensureProjectionModel(editor, true);
  }

  public static Rectangle2D.Double expandStructureBoundsForProjectionBands(GraphEditor editor,
                                                                           Rectangle2D.Double structureBounds,
                                                                           OpenGraphGridSettings gridSettings)
  {
    return copyBounds(structureBounds);
  }

  public static Rectangle2D.Double expandBoundsForProjectionLabels(GraphEditor editor,
                                                                   Rectangle2D.Double currentBounds)
  {
    return expandBoundsForProjectionLabels(editor, currentBounds, false);
  }

  public static Rectangle2D.Double expandBoundsForReservedProjectionLabels(GraphEditor editor,
                                                                           Rectangle2D.Double currentBounds)
  {
    return expandBoundsForProjectionLabels(editor, currentBounds, true);
  }

  private static Rectangle2D.Double expandBoundsForProjectionLabels(GraphEditor editor,
                                                                    Rectangle2D.Double currentBounds,
                                                                    boolean reserveSpaceEvenWhenHidden)
  {
    Rectangle2D.Double expanded = copyBounds(currentBounds);
    ProjectionGeometry geometry = getProjectionGeometry(editor, reserveSpaceEvenWhenHidden);
    if ( geometry == null )
    {
      return expanded;
    }

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        expanded = union(expanded, labelBounds);
      }
      Rectangle2D.Double lineBounds = item.getLineBounds();
      if ( lineBounds != null )
      {
        expanded = union(expanded, lineBounds);
      }
      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        expanded = union(expanded, markerBounds);
      }
    }
    return expanded;
  }

  public static Rectangle2D.Double expandBoundsForProjectionLabelsForFit(GraphEditor editor,
                                                                         Rectangle2D.Double currentBounds,
                                                                         OpenGraphGridSettings gridSettings)
  {
    Rectangle2D.Double expanded = copyBounds(currentBounds);
    if ( editor == null || currentBounds == null )
    {
      return expanded;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( !hasRenderableProjectionContext(editor) ||
         !hasProjectionFootprint(settings) )
    {
      return expanded;
    }

    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 )
    {
      return expanded;
    }

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    ProjectionGeometry geometry = new ProjectionGeometry(fm);

    int gridMinX = (int)Math.floor(currentBounds.getMinX());
    int gridMaxX = (int)Math.ceil(currentBounds.getMaxX());
    int gridMinY = (int)Math.floor(currentBounds.getMinY());
    int gridMaxY = (int)Math.ceil(currentBounds.getMaxY());

    populateProjectionItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      Rectangle2D.Double labelBounds = item.getLabelBounds(geometry.fontMetrics);
      if ( labelBounds != null )
      {
        expanded = union(expanded, labelBounds);
      }
      Rectangle2D.Double lineBounds = item.getLineBounds();
      if ( lineBounds != null )
      {
        expanded = union(expanded, lineBounds);
      }
      Rectangle2D.Double markerBounds = item.getMarkerBounds();
      if ( markerBounds != null )
      {
        expanded = union(expanded, markerBounds);
      }
    }

    return expanded;
  }

  public static void draw(Graphics2D g2, GraphEditor editor)
  {
    ProjectionGeometry geometry = getProjectionGeometry(editor, false);
    if ( geometry == null )
    {
      return;
    }

    Stroke oldStroke = g2.getStroke();
    Color oldColor = g2.getColor();
    g2.setStroke(new BasicStroke(PROJECTION_LINE_WIDTH));

    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.drawLine )
      {
        g2.setColor(GraphEditor.borderColor.darker());
        g2.drawLine(item.fromX + GraphEditor.DRAW_BUFFER,
                    item.fromY + GraphEditor.DRAW_BUFFER,
                    item.toX + GraphEditor.DRAW_BUFFER,
                    item.toY + GraphEditor.DRAW_BUFFER);
      }
      if ( item.drawMarker )
      {
        int diameter = item.markerRadius * 2;
        int markerX = item.markerX - item.markerRadius + GraphEditor.DRAW_BUFFER;
        int markerY = item.markerY - item.markerRadius + GraphEditor.DRAW_BUFFER;
        g2.setColor(PROJECTION_AXIS_NODE_FILL_COLOR);
        g2.fillOval(markerX, markerY, diameter, diameter);
        g2.setColor(PROJECTION_AXIS_NODE_BORDER_COLOR);
        g2.drawOval(markerX, markerY, diameter, diameter);
      }
      if ( item.text != null && item.text.length() > 0 )
      {
        g2.setColor(Color.black);
        drawProjectionLabel(g2, geometry.fontMetrics, item);
      }
    }

    g2.setStroke(oldStroke);
    g2.setColor(oldColor);
  }

  private static ProjectionGeometry getProjectionGeometry(GraphEditor editor, boolean reserveSpaceEvenWhenHidden)
  {
    if ( editor == null )
    {
      return null;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( settings == null )
    {
      return null;
    }

    if ( !ensureProjectionModel(editor, reserveSpaceEvenWhenHidden) )
    {
      return null;
    }

    Graph graph = editor.getGraph();

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    ProjectionGeometry geometry = new ProjectionGeometry(fm);

    int gridMinX = graph.getGridDisplayMinX();
    int gridMaxX = graph.getGridDisplayMaxX();
    int gridMinY = graph.getGridDisplayMinY();
    int gridMaxY = graph.getGridDisplayMaxY();

    populateProjectionItems(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);

    if ( geometry.items.isEmpty() )
    {
      return null;
    }

    return geometry;
  }

  private static boolean ensureProjectionModel(GraphEditor editor, boolean reserveSpaceEvenWhenHidden)
  {
    if ( editor == null )
    {
      return false;
    }

    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    if ( settings == null )
    {
      return false;
    }

    if ( !hasRenderableProjectionContext(editor) )
    {
      return false;
    }

    if ( reserveSpaceEvenWhenHidden )
    {
      if ( !hasProjectionFootprint(settings) )
      {
        return false;
      }
    }
    else if ( !settings.isLexicalProjectionActive() )
    {
      return false;
    }

    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graph.getDrawGrid() )
    {
      return false;
    }

    applyProjectionSettingsToGraph(graph, settings);
    graph.rebuildProjections();
    return true;
  }

  private static void applyProjectionSettingsToGraph(Graph graph,
                                                   OpenGraphProjectionSettings settings)
  {
    if ( graph == null )
    {
      return;
    }

    ProjectionLayoutConfig config = graph.getProjectionLayoutConfig();
    boolean show = settings != null && settings.getShowProjections();

    config.lex.enabled = show && settings.getLeftProjectionEnabled();
    config.lex.direction = ProjectionDirection.LEFT;

    config.syn.enabled = show && settings.getRightProjectionEnabled();
    config.syn.direction = ProjectionDirection.RIGHT;

    config.log.enabled = false;
    graph.setProjectionLayoutConfig(config);
  }

  private static void populateProjectionItems(ProjectionGeometry geometry,
                                             Graph graph,
                                             OpenGraphProjectionSettings settings,
                                             int gridMinX,
                                             int gridMinY,
                                             int gridMaxX,
                                             int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null )
    {
      return;
    }

    addProjectionItemsFromGraphModel(geometry, graph, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addProjectionItemsForSide(geometry, graph, settings, SIDE_TOP, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addProjectionItemsForSide(geometry, graph, settings, SIDE_BOTTOM, gridMinX, gridMinY, gridMaxX, gridMaxY);
    addSideCaptionItems(geometry, geometry.fontMetrics, settings, gridMinX, gridMinY, gridMaxX, gridMaxY);
  }

  private static void addProjectionItemsFromGraphModel(ProjectionGeometry geometry,
                                                     Graph graph,
                                                     OpenGraphProjectionSettings settings,
                                                     int gridMinX,
                                                     int gridMinY,
                                                     int gridMaxX,
                                                     int gridMaxY)
  {
    if ( geometry == null || graph == null || settings == null )
    {
      return;
    }

    Vector links = graph.getProjectionLinks();
    for ( int i=0; i<links.size(); i++ )
    {
      ProjectionLink link = (ProjectionLink)links.elementAt(i);
      if ( link == null || link.sourceNode == null || link.projectionNode == null )
      {
        continue;
      }

      int side = sideForProjectionType(link.projectionType);
      if ( !isSideEnabled(settings, side) )
      {
        continue;
      }

      int nodeX = link.sourceNode.getLocation().intX();
      int nodeY = link.sourceNode.getLocation().intY();
      int axisX = link.projectionNode.getLocation().intX();
      int axisY = link.projectionNode.getLocation().intY();

      geometry.items.addElement(ProjectionItem.createLineWithAxisNode(side, nodeX, nodeY, axisX, axisY));

      String projectionLabel = link.projectedLabel == null ? "" : trimmedLabel(link.projectedLabel.text);
      if ( projectionLabel.length() > 0 )
      {
        addNodeProjectionLabel(geometry, geometry.fontMetrics, side, projectionLabel, axisX, axisY, gridMinX, gridMinY, gridMaxX, gridMaxY);
      }
    }
  }

  private static int sideForProjectionType(ProjectionType type)
  {
    if ( type == ProjectionType.LEX )
    {
      return SIDE_LEFT;
    }
    if ( type == ProjectionType.SYN )
    {
      return SIDE_RIGHT;
    }
    if ( type == ProjectionType.LOG )
    {
      return SIDE_BOTTOM;
    }
    return SIDE_TOP;
  }

  private static void addProjectionItemsForSide(ProjectionGeometry geometry,
                                                Graph graph,
                                                OpenGraphProjectionSettings settings,
                                                int side,
                                                int gridMinX,
                                                int gridMinY,
                                                int gridMaxX,
                                                int gridMaxY)
  {
    if ( !isSideEnabled(settings, side) )
    {
      return;
    }
    if ( side == SIDE_LEFT || side == SIDE_RIGHT )
    {
      return;
    }

    Vector sourceNodes = getProjectionSourceNodes(graph, side);
    for ( int i=0; i<sourceNodes.size(); i++ )
    {
      Node sourceNode = (Node)sourceNodes.elementAt(i);
      int nodeX = sourceNode.getLocation().intX();
      int nodeY = sourceNode.getLocation().intY();
      int axisX = nodeX;
      int axisY = nodeY;

      if ( side == SIDE_LEFT )
      {
        axisX = gridMinX;
      }
      else if ( side == SIDE_RIGHT )
      {
        axisX = gridMaxX;
      }
      else if ( side == SIDE_TOP )
      {
        axisY = gridMinY;
      }
      else if ( side == SIDE_BOTTOM )
      {
        axisY = gridMaxY;
      }

      geometry.items.addElement(ProjectionItem.createLineWithAxisNode(side, nodeX, nodeY, axisX, axisY));

      String projectionLabel = getProjectedLabelForSide(sourceNode, side);
      if ( projectionLabel.length() > 0 )
      {
        addNodeProjectionLabel(geometry, geometry.fontMetrics, side, projectionLabel, axisX, axisY, gridMinX, gridMinY, gridMaxX, gridMaxY);
      }
    }
  }

  private static boolean isSideEnabled(OpenGraphProjectionSettings settings, int side)
  {
    if ( settings == null )
    {
      return false;
    }
    if ( side == SIDE_LEFT )
    {
      return settings.getLeftProjectionEnabled();
    }
    if ( side == SIDE_RIGHT )
    {
      return settings.getRightProjectionEnabled();
    }
    if ( side == SIDE_TOP )
    {
      return settings.getTopProjectionEnabled();
    }
    if ( side == SIDE_BOTTOM )
    {
      return settings.getBottomProjectionEnabled();
    }
    return false;
  }

  private static void addSideCaptionItems(ProjectionGeometry geometry,
                                          FontMetrics fm,
                                          OpenGraphProjectionSettings settings,
                                          int gridMinX,
                                          int gridMinY,
                                          int gridMaxX,
                                          int gridMaxY)
  {
    if ( geometry == null || fm == null || settings == null )
    {
      return;
    }

    int centerY = gridMinY + ((gridMaxY - gridMinY) / 2);
    int centerX = gridMinX + ((gridMaxX - gridMinX) / 2);

    if ( settings.getLeftProjectionEnabled() && hasProjectionSourcesForSide(geometry, SIDE_LEFT) )
    {
      addLeftVerticalCaptionItem(geometry, fm, LEFT_PROJECTION_NAME, gridMinX, centerY);
    }
    if ( settings.getRightProjectionEnabled() && hasProjectionSourcesForSide(geometry, SIDE_RIGHT) )
    {
      addRightVerticalCaptionItem(geometry, fm, RIGHT_PROJECTION_NAME, gridMaxX, centerY);
    }
    if ( settings.getTopProjectionEnabled() && hasProjectionSourcesForSide(geometry, SIDE_TOP) )
    {
      addVerticalCaptionItem(geometry, fm, SIDE_TOP, TOP_PROJECTION_NAME, centerX, gridMinY, LABEL_ORIENTATION_UP);
    }
    if ( settings.getBottomProjectionEnabled() && hasProjectionSourcesForSide(geometry, SIDE_BOTTOM) )
    {
      addBottomHorizontalCaptionItem(geometry, fm, BOTTOM_PROJECTION_NAME, centerX, gridMaxY);
    }
  }

  private static boolean hasProjectionSourcesForSide(ProjectionGeometry geometry, int side)
  {
    if ( geometry == null )
    {
      return false;
    }
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side == side && (item.drawLine || item.drawMarker) )
      {
        return true;
      }
    }
    return false;
  }

  private static void addLeftVerticalCaptionItem(ProjectionGeometry geometry,
                                               FontMetrics fm,
                                               String text,
                                               int gridMinX,
                                               int centerY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelColumnX = getSideLabelMinX(geometry, fm, SIDE_LEFT);
    int maxCharWidth = getMaxCharWidth(fm, text);
    int labelX = Math.min(gridMinX - LABEL_GAP - maxCharWidth, labelColumnX - LABEL_GAP - maxCharWidth);
    int baselineY = centerY - (((text.length() - 1) * fm.getHeight()) / 2) + fm.getAscent();
    geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_LEFT, text, labelX, baselineY, LABEL_ORIENTATION_DOWN));
  }

  private static void addRightVerticalCaptionItem(ProjectionGeometry geometry,
                                                FontMetrics fm,
                                                String text,
                                                int gridMaxX,
                                                int centerY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelColumnX = getRightSideVerticalLabelX(geometry, fm, gridMaxX);
    int baselineY = centerY - (((text.length() - 1) * fm.getHeight()) / 2) + fm.getAscent();
    geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_RIGHT, text, labelColumnX, baselineY, LABEL_ORIENTATION_DOWN));
  }

  private static void addBottomHorizontalCaptionItem(ProjectionGeometry geometry,
                                                     FontMetrics fm,
                                                     String text,
                                                     int centerX,
                                                     int gridMaxY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelWidth = fm.stringWidth(text);
    int labelX = centerX - (labelWidth / 2);
    int labelTopY = getSideLabelMaxY(geometry, fm, SIDE_BOTTOM) + LABEL_GAP;
    int baselineY = Math.max(gridMaxY + LABEL_GAP + fm.getAscent(), labelTopY + fm.getAscent());
    geometry.items.addElement(ProjectionItem.createLabelOnly(SIDE_BOTTOM, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
  }

  private static void addHorizontalCaptionItem(ProjectionGeometry geometry,
                                               FontMetrics fm,
                                               int side,
                                               String text,
                                               int gridEdgeX,
                                               int centerY,
                                               boolean left)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int labelWidth = fm.stringWidth(text);
    int labelX = left ? gridEdgeX - LABEL_GAP - labelWidth : gridEdgeX + LABEL_GAP;
    int baselineY = centerY + (fm.getAscent() / 2);
    geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
  }

  private static void addVerticalCaptionItem(ProjectionGeometry geometry,
                                             FontMetrics fm,
                                             int side,
                                             String text,
                                             int centerX,
                                             int gridEdgeY,
                                             int orientation)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    int maxCharWidth = getMaxCharWidth(fm, text);
    int labelX = centerX - (maxCharWidth / 2);
    int baselineY = (orientation == LABEL_ORIENTATION_DOWN)
                    ? gridEdgeY + LABEL_GAP + fm.getAscent()
                    : gridEdgeY - LABEL_GAP - ((text.length() - 1) * fm.getHeight());
    geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, orientation));
  }

  private static void addNodeProjectionLabel(ProjectionGeometry geometry,
                                             FontMetrics fm,
                                             int side,
                                             String text,
                                             int axisX,
                                             int axisY,
                                             int gridMinX,
                                             int gridMinY,
                                             int gridMaxX,
                                             int gridMaxY)
  {
    if ( text == null || text.length() == 0 )
    {
      return;
    }

    if ( side == SIDE_LEFT )
    {
      int labelX = gridMinX - LABEL_GAP - fm.stringWidth(text);
      int baselineY = axisY + (fm.getAscent() / 2);
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
    }
    else if ( side == SIDE_RIGHT )
    {
      int labelX = axisX + LABEL_GAP + RIGHT_LABEL_EXTRA_GAP;
      int baselineY = axisY + (fm.getAscent() / 2);
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_HORIZONTAL));
    }
    else if ( side == SIDE_TOP )
    {
      int labelX = axisX - (getMaxCharWidth(fm, text) / 2);
      int baselineY = gridMinY - LABEL_GAP - ((text.length() - 1) * fm.getHeight());
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_UP));
    }
    else if ( side == SIDE_BOTTOM )
    {
      int labelX = axisX - (getMaxCharWidth(fm, text) / 2);
      int baselineY = gridMaxY + LABEL_GAP + fm.getAscent();
      geometry.items.addElement(ProjectionItem.createLabelOnly(side, text, labelX, baselineY, LABEL_ORIENTATION_DOWN));
    }
  }

  private static Vector getProjectionSourceNodes(Graph graph, int side)
  {
    if ( side == SIDE_LEFT )
    {
      return getLeafNodes(graph);
    }
    if ( side == SIDE_RIGHT )
    {
      return getBranchingNodes(graph, false);
    }
    if ( side == SIDE_BOTTOM )
    {
      return getBranchingNodes(graph, true);
    }
    return new Vector();
  }

  private static Vector getLeafNodes(Graph graph)
  {
    Vector leaves = new Vector();
    Vector nodes = graph.getNodes();

    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( isLeafNode(node) )
      {
        leaves.addElement(node);
      }
    }

    sortNodesByPosition(leaves);
    return leaves;
  }

  private static Vector getBranchingNodes(Graph graph, boolean requireExplicitLogicalLabel)
  {
    Vector branching = new Vector();
    if ( graph == null )
    {
      return branching;
    }

    Vector nodes = graph.getNodes();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( isBranchingNode(node) &&
           (!requireExplicitLogicalLabel || hasExplicitLogicalProjectionLabel(node)) )
      {
        branching.addElement(node);
      }
    }

    sortNodesByPosition(branching);
    return branching;
  }

  private static void sortNodesByPosition(Vector nodes)
  {
    Collections.sort(nodes, new Comparator()
    {
      public int compare(Object leftObj, Object rightObj)
      {
        Node left = (Node)leftObj;
        Node right = (Node)rightObj;
        int xCompare = left.getLocation().intX() - right.getLocation().intX();
        if ( xCompare != 0 )
        {
          return xCompare;
        }
        return left.getLocation().intY() - right.getLocation().intY();
      }
    });
  }

  private static boolean isLeafNode(Node node)
  {
    if ( node == null )
    {
      return false;
    }

    Vector neighbours = node.neighbours();
    if ( neighbours.isEmpty() )
    {
      return true;
    }

    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        return false;
      }
    }
    return true;
  }

  private static boolean isBranchingNode(Node node)
  {
    if ( node == null )
    {
      return false;
    }
    return countChildrenBelow(node) >= 2;
  }


  private static String getProjectedLabelForSide(Node sourceNode, int side)
  {
    if ( sourceNode == null )
    {
      return "";
    }
    if ( side == SIDE_RIGHT )
    {
      return formatSynProjectionLabel(sourceNode);
    }
    return trimmedLabel(sourceNode.getLabel());
  }

  private static String formatSynProjectionLabel(Node sourceNode)
  {
    Vector children = getChildrenBelowSortedLeftToRight(sourceNode);
    if ( children.isEmpty() )
    {
      return "";
    }

    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<children.size(); i++ )
    {
      Node child = (Node)children.elementAt(i);
      String label = trimmedLabel(child.getLabel());
      if ( label.length() == 0 )
      {
        continue;
      }
      if ( buffer.length() > 0 )
      {
        buffer.append(", ");
      }
      buffer.append(label);
    }
    return buffer.toString();
  }

  private static Vector getChildrenBelowSortedLeftToRight(Node node)
  {
    Vector children = new Vector();
    if ( node == null )
    {
      return children;
    }

    Vector neighbours = node.neighbours();
    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        children.addElement(neighbour);
      }
    }

    sortNodesByPosition(children);
    return children;
  }

  private static boolean hasExplicitLogicalProjectionLabel(Node node)
  {
    String label = trimmedLabel(node == null ? null : node.getLabel());
    if ( label.length() == 0 )
    {
      return false;
    }

    String upper = label.toUpperCase();
    return upper.equals("S") ||
           upper.equals("O") ||
           upper.equals("V") ||
           upper.equals("SUBJECT") ||
           upper.equals("OBJECT") ||
           upper.equals("VERB") ||
           upper.equals("LF") ||
           upper.equals("LOG");
  }

  private static int countChildrenBelow(Node node)
  {
    Vector neighbours = node.neighbours();
    int count = 0;
    int nodeY = node.getLocation().intY();
    for ( int i=0; i<neighbours.size(); i++ )
    {
      Node neighbour = (Node)neighbours.elementAt(i);
      if ( neighbour.getLocation().intY() > nodeY )
      {
        count++;
      }
    }
    return count;
  }

  private static int getRightSideVerticalLabelX(ProjectionGeometry geometry, FontMetrics fm, int gridMaxX)
  {
    int markerExtentX = getSideMarkerMaxX(geometry, SIDE_RIGHT);
    int labelExtentX = getSideLabelMaxX(geometry, fm, SIDE_RIGHT);
    int baseX = Math.max(gridMaxX, markerExtentX);
    int candidateX = baseX + PROJECTION_AXIS_NODE_RADIUS + LABEL_GAP + RIGHT_LABEL_EXTRA_GAP;
    if ( labelExtentX != Integer.MIN_VALUE )
    {
      candidateX = Math.max(candidateX, labelExtentX + LABEL_GAP);
    }
    return candidateX;
  }

  private static int getSideMarkerMaxX(ProjectionGeometry geometry, int side)
  {
    if ( geometry == null )
    {
      return Integer.MIN_VALUE;
    }

    int maxX = Integer.MIN_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side || !item.drawMarker )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getMarkerBounds();
      if ( bounds != null )
      {
        maxX = Math.max(maxX, (int)Math.ceil(bounds.getMaxX()));
      }
    }
    return maxX == Integer.MIN_VALUE ? Integer.MIN_VALUE : maxX;
  }


  private static int getSideLabelMaxX(ProjectionGeometry geometry, FontMetrics fm, int side)
  {
    if ( geometry == null || fm == null )
    {
      return Integer.MIN_VALUE;
    }

    int maxX = Integer.MIN_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getLabelBounds(fm);
      if ( bounds != null )
      {
        maxX = Math.max(maxX, (int)Math.ceil(bounds.getMaxX()));
      }
    }
    return maxX;
  }

  private static int getSideLabelMinX(ProjectionGeometry geometry, FontMetrics fm, int side)
  {
    if ( geometry == null || fm == null )
    {
      return Integer.MAX_VALUE;
    }

    int minX = Integer.MAX_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getLabelBounds(fm);
      if ( bounds != null )
      {
        minX = Math.min(minX, (int)Math.floor(bounds.getMinX()));
      }
    }
    return minX;
  }

  private static int getSideLabelMaxY(ProjectionGeometry geometry, FontMetrics fm, int side)
  {
    if ( geometry == null || fm == null )
    {
      return Integer.MIN_VALUE;
    }

    int maxY = Integer.MIN_VALUE;
    for ( int i=0; i<geometry.items.size(); i++ )
    {
      ProjectionItem item = (ProjectionItem)geometry.items.elementAt(i);
      if ( item.side != side )
      {
        continue;
      }
      Rectangle2D.Double bounds = item.getLabelBounds(fm);
      if ( bounds != null )
      {
        maxY = Math.max(maxY, (int)Math.ceil(bounds.getMaxY()));
      }
    }
    return maxY;
  }

  private static String trimmedLabel(String text)
  {
    if ( text == null )
    {
      return "";
    }
    return text.trim();
  }

  private static int getMaxCharWidth(FontMetrics fm, String text)
  {
    int width = 1;
    if ( fm == null || text == null )
    {
      return width;
    }
    for ( int i=0; i<text.length(); i++ )
    {
      width = Math.max(width, fm.charWidth(text.charAt(i)));
    }
    return width;
  }

  private static int safeCellWidth(OpenGraphGridSettings gridSettings, Graph graph)
  {
    if ( gridSettings != null )
    {
      return Math.max(2, gridSettings.getCellWidth());
    }
    if ( graph != null )
    {
      return Math.max(2, graph.getGridColWidth());
    }
    return 20;
  }

  private static int safeCellHeight(OpenGraphGridSettings gridSettings, Graph graph)
  {
    if ( gridSettings != null )
    {
      return Math.max(2, gridSettings.getCellHeight());
    }
    if ( graph != null )
    {
      return Math.max(2, graph.getGridRowHeight());
    }
    return 20;
  }

  private static boolean hasProjectionFootprint(OpenGraphProjectionSettings settings)
  {
    return settings != null &&
           OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) &&
           (settings.getLeftProjectionEnabled() ||
            settings.getRightProjectionEnabled() ||
            settings.getTopProjectionEnabled() ||
            settings.getBottomProjectionEnabled());
  }

  private static OpenGraphProjectionSettings loadFromPath(String path)
  {
    try
    {
      Properties props = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( props == null )
      {
        return null;
      }
      OpenGraphDialogSettingsState state = OpenGraphDialogSettingsSupport.fromProperties(props);
      OpenGraphDialogSettingsSupport.applyPostLoadRules(state);
      OpenGraphProjectionSettings settings = new OpenGraphProjectionSettings();
      settings.setStructureType(state.structureType);
      settings.setShowProjections(state.showProjections);
      settings.setLeftProjectionEnabled(state.leftProjectionEnabled);
      settings.setRightProjectionEnabled(state.rightProjectionEnabled);
      settings.setTopProjectionEnabled(state.topProjectionEnabled);
      settings.setBottomProjectionEnabled(state.bottomProjectionEnabled);
      settings.setLeftProjectionPosition(state.leftProjectionPosition);
      settings.setRightProjectionPosition(state.rightProjectionPosition);
      settings.setTopProjectionPosition(state.topProjectionPosition);
      settings.setBottomProjectionPosition(state.bottomProjectionPosition);
      settings.normalize();
      return settings;
    }
    catch (Exception e)
    {
      return null;
    }
  }

  private static Rectangle2D.Double copyBounds(Rectangle2D.Double bounds)
  {
    if ( bounds == null )
    {
      return new Rectangle2D.Double();
    }
    return new Rectangle2D.Double(bounds.getX(), bounds.getY(), bounds.getWidth(), bounds.getHeight());
  }

  private static Rectangle2D.Double createBounds(double minX, double minY, double maxX, double maxY)
  {
    return new Rectangle2D.Double(minX, minY, Math.max(0, maxX - minX), Math.max(0, maxY - minY));
  }

  private static Rectangle2D.Double union(Rectangle2D.Double base, Rectangle2D.Double addition)
  {
    if ( base == null )
    {
      return copyBounds(addition);
    }
    if ( addition == null )
    {
      return copyBounds(base);
    }
    Rectangle2D rect = base.createUnion(addition);
    return new Rectangle2D.Double(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
  }

  private static void drawProjectionLabel(Graphics2D g2, FontMetrics fm, ProjectionItem item)
  {
    if ( g2 == null || fm == null || item == null || item.text == null || item.text.length() == 0 )
    {
      return;
    }

    if ( item.labelOrientation == LABEL_ORIENTATION_HORIZONTAL )
    {
      g2.drawString(item.text,
                    item.labelX + GraphEditor.DRAW_BUFFER,
                    item.labelBaselineY + GraphEditor.DRAW_BUFFER);
      return;
    }

    int x = item.labelX + GraphEditor.DRAW_BUFFER;
    if ( item.labelOrientation == LABEL_ORIENTATION_DOWN )
    {
      for ( int i=0; i<item.text.length(); i++ )
      {
        String glyph = String.valueOf(item.text.charAt(i));
        int baselineY = item.labelBaselineY + (i * fm.getHeight()) + GraphEditor.DRAW_BUFFER;
        g2.drawString(glyph, x, baselineY);
      }
    }
    else if ( item.labelOrientation == LABEL_ORIENTATION_UP )
    {
      for ( int i=0; i<item.text.length(); i++ )
      {
        String glyph = String.valueOf(item.text.charAt(i));
        int baselineY = item.labelBaselineY + ((item.text.length() - 1 - i) * fm.getHeight()) + GraphEditor.DRAW_BUFFER;
        g2.drawString(glyph, x, baselineY);
      }
    }
  }

  private static final class ProjectionGeometry
  {
    private final FontMetrics fontMetrics;
    private final Vector items = new Vector();

    private ProjectionGeometry(FontMetrics fontMetrics)
    {
      this.fontMetrics = fontMetrics;
    }
  }

  private static final int SIDE_LEFT = 1;
  private static final int SIDE_RIGHT = 2;
  private static final int SIDE_TOP = 3;
  private static final int SIDE_BOTTOM = 4;

  private static final int LABEL_ORIENTATION_HORIZONTAL = 0;
  private static final int LABEL_ORIENTATION_DOWN = 1;
  private static final int LABEL_ORIENTATION_UP = 2;

  private static final class ProjectionItem
  {
    private final int side;
    private final int fromX;
    private final int fromY;
    private final int toX;
    private final int toY;
    private final boolean drawLine;
    private final boolean drawMarker;
    private final int markerX;
    private final int markerY;
    private final int markerRadius;
    private final String text;
    private final int labelX;
    private int labelBaselineY;
    private final int labelOrientation;

    private ProjectionItem(int side, int fromX, int fromY, int toX, int toY,
                           boolean drawLine, boolean drawMarker, int markerX, int markerY, int markerRadius,
                           String text, int labelX, int labelBaselineY, int labelOrientation)
    {
      this.side = side;
      this.fromX = fromX;
      this.fromY = fromY;
      this.toX = toX;
      this.toY = toY;
      this.drawLine = drawLine;
      this.drawMarker = drawMarker;
      this.markerX = markerX;
      this.markerY = markerY;
      this.markerRadius = markerRadius;
      this.text = text;
      this.labelX = labelX;
      this.labelBaselineY = labelBaselineY;
      this.labelOrientation = labelOrientation;
    }

    private static ProjectionItem createLineOnly(int side, int fromX, int fromY, int toX, int toY)
    {
      return new ProjectionItem(side, fromX, fromY, toX, toY, true, false, 0, 0, 0, null, 0, 0, LABEL_ORIENTATION_HORIZONTAL);
    }

    private static ProjectionItem createLineWithAxisNode(int side, int fromX, int fromY, int toX, int toY)
    {
      return new ProjectionItem(side, fromX, fromY, toX, toY, true, true, toX, toY,
                                PROJECTION_AXIS_NODE_RADIUS, null, 0, 0, LABEL_ORIENTATION_HORIZONTAL);
    }

    private static ProjectionItem createLabelOnly(int side, String text, int labelX, int labelBaselineY, int labelOrientation)
    {
      return new ProjectionItem(side, 0, 0, 0, 0, false, false, 0, 0, 0, text, labelX, labelBaselineY, labelOrientation);
    }

    private Rectangle2D.Double getLineBounds()
    {
      if ( !drawLine )
      {
        return null;
      }
      int minX = Math.min(fromX, toX);
      int maxX = Math.max(fromX, toX);
      int minY = Math.min(fromY, toY);
      int maxY = Math.max(fromY, toY);
      return new Rectangle2D.Double(minX, minY, Math.max(1, maxX - minX), Math.max(1, maxY - minY));
    }

    private Rectangle2D.Double getMarkerBounds()
    {
      if ( !drawMarker || markerRadius <= 0 )
      {
        return null;
      }
      int diameter = markerRadius * 2;
      return new Rectangle2D.Double(markerX - markerRadius, markerY - markerRadius, diameter, diameter);
    }

    private Rectangle2D.Double getLabelBounds(FontMetrics fm)
    {
      if ( text == null || text.length() == 0 || fm == null )
      {
        return null;
      }
      int width;
      int height;
      if ( labelOrientation == LABEL_ORIENTATION_HORIZONTAL )
      {
        width = Math.max(1, fm.stringWidth(text));
        height = Math.max(1, fm.getHeight());
        int y = labelBaselineY - fm.getAscent();
        return new Rectangle2D.Double(labelX, y, width, height);
      }

      width = Math.max(1, getMaxCharWidth(fm, text));
      height = Math.max(1, text.length() * fm.getHeight());
      int y = labelBaselineY - fm.getAscent();
      return new Rectangle2D.Double(labelX, y, width, height);
    }
  }
}
