package userInterface;

import java.awt.Color;
import java.awt.Polygon;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.QuadCurve2D;
import java.awt.geom.Rectangle2D;

/**
 * Mutable overlay drawing state for {@link GraphEditor}.
 *
 * <p>This keeps transient preview shapes and their colors out of the editor
 * while preserving the original behaviour of edit, grid, resize and rotate
 * modes.</p>
 */
public class GraphEditorOverlayState
{
  private Line2D.Double lineToDraw;
  private Ellipse2D.Double pointToDraw;
  private Rectangle2D.Double rectangleToDraw;
  private Polygon polygonToDraw;
  private QuadCurve2D.Double curveToDraw;
  private Color lineToDrawColor;
  private Color polygonToDrawColor;
  private Color curveToDrawColor;

  public Line2D.Double getLineToDraw() { return lineToDraw; }
  public void setLineToDraw(Line2D.Double lineToDraw) { this.lineToDraw = lineToDraw; }

  public Ellipse2D.Double getPointToDraw() { return pointToDraw; }
  public void setPointToDraw(Ellipse2D.Double pointToDraw) { this.pointToDraw = pointToDraw; }

  public Rectangle2D.Double getRectangleToDraw() { return rectangleToDraw; }
  public void setRectangleToDraw(Rectangle2D.Double rectangleToDraw) { this.rectangleToDraw = rectangleToDraw; }

  public Polygon getPolygonToDraw() { return polygonToDraw; }
  public void setPolygonToDraw(Polygon polygonToDraw) { this.polygonToDraw = polygonToDraw; }

  public QuadCurve2D.Double getCurveToDraw() { return curveToDraw; }
  public void setCurveToDraw(QuadCurve2D.Double curveToDraw) { this.curveToDraw = curveToDraw; }

  public Color getLineToDrawColor() { return lineToDrawColor; }
  public void setLineToDrawColor(Color lineToDrawColor) { this.lineToDrawColor = lineToDrawColor; }

  public Color getPolygonToDrawColor() { return polygonToDrawColor; }
  public void setPolygonToDrawColor(Color polygonToDrawColor) { this.polygonToDrawColor = polygonToDrawColor; }

  public Color getCurveToDrawColor() { return curveToDrawColor; }
  public void setCurveToDrawColor(Color curveToDrawColor) { this.curveToDrawColor = curveToDrawColor; }
}
