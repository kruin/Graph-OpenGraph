package userInterface;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.Vector;
import graphStructure.LogEntry;

public class GraphEditorLogSupport
{
  private final JTree logEntryTree;

  public GraphEditorLogSupport(Container container)
  {
    GridBagLayout layout = GraphEditorWindowUiSupport.installVerticalLayout(container);
    logEntryTree = new JTree();
    logEntryTree.setShowsRootHandles(true);
    GraphEditorWindowUiSupport.addFullWidth(container, layout,
      GraphEditorWindowUiSupport.createScrollPane(logEntryTree),
      GridBagConstraints.BOTH, 1.0);
  }

  public void update(Vector logEntries)
  {
    if ( logEntries.size() == 0 )
    {
      logEntryTree.setModel(new DefaultTreeModel(
        new DefaultMutableTreeNode("No Log Entries")));
      logEntryTree.setRootVisible(true);
    }
    else
    {
      LogEntry root = new LogEntry();
      root.setSubEntries(logEntries);
      logEntryTree.setModel(new DefaultTreeModel(root));
      logEntryTree.setRootVisible(false);
    }
    logEntryTree.repaint();
    logEntryTree.validate();
  }
}
