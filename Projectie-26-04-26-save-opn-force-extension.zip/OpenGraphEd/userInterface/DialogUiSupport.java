package userInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public final class DialogUiSupport
{
  private DialogUiSupport() {}

  public static JButton createActionButton(String text, ActionListener listener)
  {
    JButton button = new JButton(text);
    button.addActionListener(listener);
    return button;
  }

  public static JLabel createMessageLabel(String message)
  {
    return new JLabel(message);
  }

  public static void showInfoMessage(Component parent, String title, String message)
  {
    JOptionPane.showMessageDialog(parent,
      message,
      title,
      JOptionPane.INFORMATION_MESSAGE);
  }

  public static void showErrorMessage(Component parent, String title, String message)
  {
    JOptionPane.showMessageDialog(parent,
      message,
      title,
      JOptionPane.ERROR_MESSAGE);
  }
}
