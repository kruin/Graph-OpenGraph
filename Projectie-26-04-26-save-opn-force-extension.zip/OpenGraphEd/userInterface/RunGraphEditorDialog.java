package userInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public abstract class RunGraphEditorDialog extends GraphEditorDialog implements ActionListener
{
  private static final Insets DEFAULT_INSETS = new Insets(3, 3, 3, 3);

  private final GridBagLayout layout;
  private final GridBagConstraints layoutCons;
  private GraphEditorWindow owner;
  private JButton runButton;

  public RunGraphEditorDialog(GraphController controller, GraphEditorWindow owner,
                              String title, String message)
  {
    super(controller, owner.getTitle() + " - " + title,
          true,  // resizable
          true,  // closable
          true,  // maximizable
          false);// iconifiable
    this.owner = owner;

    layout = new GridBagLayout();
    layoutCons = createDefaultConstraints();
    getContentPane().setLayout(layout);

    addFullWidth(DialogUiSupport.createMessageLabel(message));
  }

  protected void addFullWidth(Component component)
  {
    layout.setConstraints(component, layoutCons);
    getContentPane().add(component);
  }

  protected JButton createActionButton(String text)
  {
    return DialogUiSupport.createActionButton(text, this);
  }

  protected void setRunButton(JButton button)
  {
    runButton = button;
    addFullWidth(runButton);
  }

  protected JButton getRunButton()
  {
    return runButton;
  }

  public void enableRunButton()
  {
    if ( runButton != null )
    {
      runButton.setEnabled(true);
    }
  }

  public void disableRunButton()
  {
    if ( runButton != null )
    {
      runButton.setEnabled(false);
    }
  }

  public GraphEditorWindow getOwner()
  {
    return owner;
  }

  public void setOwner(GraphEditorWindow o)
  {
    owner = o;
  }

  private GridBagConstraints createDefaultConstraints()
  {
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.gridx = GridBagConstraints.RELATIVE;
    constraints.gridy = GridBagConstraints.RELATIVE;
    constraints.gridwidth = GridBagConstraints.REMAINDER;
    constraints.gridheight = 1;
    constraints.fill = GridBagConstraints.BOTH;
    constraints.insets = DEFAULT_INSETS;
    constraints.anchor = GridBagConstraints.NORTH;
    constraints.weightx = 1.0;
    constraints.weighty = 1.0;
    return constraints;
  }
}
