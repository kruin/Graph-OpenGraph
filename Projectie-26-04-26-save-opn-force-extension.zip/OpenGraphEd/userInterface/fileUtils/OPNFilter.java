package userInterface.fileUtils;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/** File filter for OpenGraphEd .opn files. */
public class OPNFilter extends FileFilter {
  public boolean accept(File f) {
    if (f.isDirectory()) {
      return true;
    }
    String extension = Utils.getExtension(f);
    return extension != null && extension.equalsIgnoreCase(Utils.opn);
  }

  public String getDescription() {
    return "OPN files (*.opn)";
  }
}
