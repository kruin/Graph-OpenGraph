package userInterface.fileUtils;

import java.util.Enumeration;
import java.util.Hashtable;

final class GIFPaletteSupport
{
  private GIFPaletteSupport() {}

  static Hashtable getColorSet(int[] pixels)
  {
    Hashtable colorSet = new Hashtable();
    boolean[] checked = new boolean[pixels.length];
    int needsChecking = pixels.length;
    int color;
    int colorIndex = 0;
    Integer key;

    for (int j = 0; j < pixels.length && needsChecking > 0; ++j) {
      if (!checked[j]) {
        color = pixels[j] & 0x00FFFFFF;
        checked[j] = true;
        --needsChecking;

        key = Integer.valueOf(color);
        colorSet.put(key, Integer.valueOf(colorIndex));
        if (++colorIndex > 256)
          break;

        for (int j2 = j + 1; j2 < pixels.length; ++j2) {
          if ((pixels[j2] & 0x00FFFFFF) == color) {
            checked[j2] = true;
            --needsChecking;
          }
        }
      }
    }

    if (colorIndex == 1) {
      if (colorSet.get(Integer.valueOf(0)) == null)
        colorSet.put(Integer.valueOf(0), Integer.valueOf(1));
      else
        colorSet.put(Integer.valueOf(0xFFFFFF), Integer.valueOf(1));
    }

    return colorSet;
  }

  static int[] createColorTable(Hashtable colorSet, int colorCount)
  {
    int[] colorTable = new int[colorCount];
    Integer key;

    for (Enumeration e = colorSet.keys(); e.hasMoreElements(); ) {
      key = (Integer) e.nextElement();
      colorTable[((Integer) colorSet.get(key)).intValue()] = key.intValue();
    }

    return colorTable;
  }

  static byte[] createBytePixels(int[] pixels, Hashtable colorSet)
  {
    byte[] bytePixels = new byte[pixels.length];
    Integer key;
    int colorIndex;

    for (int j = 0; j < pixels.length; ++j) {
      key = Integer.valueOf(pixels[j] & 0x00FFFFFF);
      colorIndex = ((Integer) colorSet.get(key)).intValue();
      bytePixels[j] = (byte) colorIndex;
    }

    return bytePixels;
  }

  static int[] createBWTable()
  {
    int[] colorTable = new int[2];
    colorTable[GIFOutputStream.BLACK_INDEX] = 0x000000;
    colorTable[GIFOutputStream.WHITE_INDEX] = 0xFFFFFF;
    return colorTable;
  }

  static byte[] createBWBytePixels(int[] pixels)
  {
    byte[] bytePixels = new byte[pixels.length];
    for (int j = 0; j < pixels.length; ++j) {
      if (grayscaleValue(pixels[j]) < 0x80)
        bytePixels[j] = (byte) GIFOutputStream.BLACK_INDEX;
      else
        bytePixels[j] = (byte) GIFOutputStream.WHITE_INDEX;
    }
    return bytePixels;
  }

  static int[] create16GrayTable()
  {
    int[] colorTable = new int[16];
    for (int j = 0; j < 16; ++j)
      colorTable[j] = 0x111111 * j;
    return colorTable;
  }

  static byte[] create16GrayBytePixels(int[] pixels)
  {
    byte[] bytePixels = new byte[pixels.length];
    for (int j = 0; j < pixels.length; ++j) {
      bytePixels[j] = (byte) (grayscaleValue(pixels[j]) / 16);
    }
    return bytePixels;
  }

  static int[] create256GrayTable()
  {
    int[] colorTable = new int[256];
    for (int j = 0; j < 256; ++j)
      colorTable[j] = 0x010101 * j;
    return colorTable;
  }

  static byte[] create256GrayBytePixels(int[] pixels)
  {
    byte[] bytePixels = new byte[pixels.length];
    for (int j = 0; j < pixels.length; ++j) {
      bytePixels[j] = (byte) grayscaleValue(pixels[j]);
    }
    return bytePixels;
  }

  static int[] createStd16ColorTable()
  {
    int[] colorTable = new int[16];
    for (int j = 0; j < 16; ++j)
      colorTable[j] = GIFOutputStream.standard16[j];
    return colorTable;
  }

  static byte[] createStd16ColorBytePixels(int[] pixels)
  {
    byte[] bytePixels = new byte[pixels.length];
    int color;
    int minError = 0;
    int error;
    int minIndex;

    for (int j = 0; j < pixels.length; ++j) {
      color = pixels[j] & 0xFFFFFF;
      minIndex = -1;

      for (int k = 0; k < 16; ++k) {
        error = colorMatchError(color, GIFOutputStream.standard16[k]);
        if (error < minError || minIndex < 0) {
          minError = error;
          minIndex = k;
        }
      }

      bytePixels[j] = (byte) minIndex;
    }

    return bytePixels;
  }

  static int[] createStd256ColorTable()
  {
    int[] colorTable = new int[256];
    for (int j = 0; j < 256; ++j)
      colorTable[j] = GIFOutputStream.standard256[j];
    return colorTable;
  }

  static int[] createStd216ColorTable()
  {
    int[] colorTable = new int[216];
    colorTable[0] = 0x000000;
    for (int j = 1; j < 216; ++j)
      colorTable[j] = GIFOutputStream.standard256[j + 40];
    return colorTable;
  }

  static byte[] createStd256ColorBytePixels(int[] pixels, int width, boolean dither)
  {
    byte[] bytePixels = new byte[pixels.length];
    int color;
    int minError = 0;
    int error;
    int minIndex;
    int sampleIndex;
    int r, g, b;
    int r2, g2, b2;
    int x, y;
    int threshold;

    for (int j = 0; j < pixels.length; ++j) {
      color = pixels[j] & 0xFFFFFF;
      minIndex = -1;

      r = (color & 0xFF0000) >> 16;
      g = (color & 0x00FF00) >> 8;
      b =  color & 0x0000FF;

      r2 = r / 0x33;
      g2 = g / 0x33;
      b2 = b / 0x33;

      if (dither) {
        x = j % width;
        y = j / width;
        threshold = GIFOutputStream.ditherPattern[x % 4][y % 4] / 5;

        if (r2 < 5 && r % 0x33 >= threshold)
          ++r2;

        if (g2 < 5 && g % 0x33 >= threshold)
          ++g2;

        if (b2 < 5 && b % 0x33 >= threshold)
          ++b2;

        bytePixels[j] = (byte) (r2 * 36 + g2 * 6 + b2);
      }
      else {
        for (int r0 = r2; r0 <= r2 + 1 && r0 < 6; ++r0) {
          for (int g0 = g2; g0 <= g2 + 1 && g0 < 6; ++g0) {
            for (int b0 = b2; b0 <= b2 + 1 && b0 < 6; ++b0) {
              sampleIndex = 40 + r0 * 36 + g0 * 6 + b0;
              if (sampleIndex == 40)
                sampleIndex = 0;

              error = colorMatchError(color, GIFOutputStream.standard256[sampleIndex]);
              if (error < minError || minIndex < 0) {
                minError = error;
                minIndex = sampleIndex;
              }
            }
          }
        }

        int shadeBase;
        int shadeIndex;

        if (r > g && r > b) {
          shadeBase = 30;
          shadeIndex = (r + 8) / 0x11;
        }
        else if (g > r && g > b) {
          shadeBase = 20;
          shadeIndex = (g + 8) / 0x11;
        }
        else {
          shadeBase = 10;
          shadeIndex = (b + 8) / 0x11;
        }

        if (shadeIndex > 0) {
          shadeIndex -= (shadeIndex / 3);
          sampleIndex = shadeBase + shadeIndex;
          error = colorMatchError(color, GIFOutputStream.standard256[sampleIndex]);
          if (error < minError || minIndex < 0) {
            minError = error;
            minIndex = sampleIndex;
          }
        }

        shadeIndex = (grayscaleValue(color) + 8) / 0x11;
        if (shadeIndex > 0) {
          shadeIndex -= (shadeIndex / 3);
          sampleIndex = shadeIndex;
          error = colorMatchError(color, GIFOutputStream.standard256[sampleIndex]);
          if (error < minError || minIndex < 0) {
            minError = error;
            minIndex = sampleIndex;
          }
        }

        bytePixels[j] = (byte) minIndex;
      }
    }

    return bytePixels;
  }

  static int grayscaleValue(int color)
  {
    int r = (color & 0xFF0000) >> 16;
    int g = (color & 0x00FF00) >> 8;
    int b = color & 0x0000FF;
    return (r * 30 + g * 59 + b * 11) / 100;
  }

  static int colorMatchError(int color1, int color2)
  {
    int r1 = (color1 & 0xFF0000) >> 16;
    int g1 = (color1 & 0x00FF00) >> 8;
    int b1 = color1 & 0x0000FF;
    int r2 = (color2 & 0xFF0000) >> 16;
    int g2 = (color2 & 0x00FF00) >> 8;
    int b2 = color2 & 0x0000FF;
    int dr = (r2 - r1) * 30;
    int dg = (g2 - g1) * 59;
    int db = (b2 - b1) * 11;
    return (dr * dr + dg * dg + db * db) / 100;
  }
}
