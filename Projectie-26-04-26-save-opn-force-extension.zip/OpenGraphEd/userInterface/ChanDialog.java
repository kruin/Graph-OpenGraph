package userInterface;

import javax.swing.*;
import java.awt.event.*;

public class ChanDialog extends RunGraphEditorDialog
{
  public static int WIDTH = 400;
  public static int HEIGHT = 200;

  private ButtonGroup buttonGroup;
  private JRadioButton button1;
  private JRadioButton button2;
  private JRadioButton button3;

  public ChanDialog( GraphController controller,GraphEditorWindow owner,
                     String title, String message )
  {
    super(controller, owner, title, message);

    button1 = new JRadioButton("Method 1");
    addFullWidth(button1);

    button2 = new JRadioButton("Method 2");
    addFullWidth(button2);

    button3 = new JRadioButton("Method 3");
    addFullWidth(button3);

    buttonGroup = new ButtonGroup();
    button1.setSelected(true);
    buttonGroup.add(button1);
    buttonGroup.add(button2);
    buttonGroup.add(button3);

    setRunButton(createActionButton("Run"));

    addInternalFrameListener(controller);

    setSize(WIDTH, HEIGHT);
    setVisible(true);
  }

  public int getSelectedMethodNumber()
  {
    if ( button1.isSelected() )
    {
      return 1;
    }
    else if ( button2.isSelected() )
    {
      return 2;
    }
    else if ( button3.isSelected() )
    {
      return 3;
    }
    else
    {
      // this case can never happen if a button is initially selected...
      return -1;
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    // do nothing, let this be overriden...
  }
}
