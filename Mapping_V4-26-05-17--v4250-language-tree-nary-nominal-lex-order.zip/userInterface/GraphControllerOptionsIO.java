package userInterface;

import java.io.*;
import java.util.Properties;

public final class GraphControllerOptionsIO
{
  private static final String USER_SETTINGS_PATH = "config/opengraphed_user.properties";
  private static final String KEY_LOAD_FROM_GRAPH_DIR = "graph.load.from.default.dir";
  private static final String KEY_DEFAULT_GRAPH_DIR = "graph.default.dir";
  private static final String KEY_LOAD_FROM_OPN_DIR = "opn.load.from.default.dir";
  private static final String KEY_DEFAULT_OPN_DIR = "opn.default.dir";

  private GraphControllerOptionsIO() {}

  public static void load(GraphControllerOptions options)
  {
    if ( options == null )
    {
      return;
    }

    File file = new File(USER_SETTINGS_PATH);
    if ( !file.exists() )
    {
      return;
    }

    FileInputStream fis = null;
    try
    {
      Properties props = new Properties();
      fis = new FileInputStream(file);
      props.load(fis);

      String loadFromGraphDir = props.getProperty(KEY_LOAD_FROM_GRAPH_DIR);
      if ( loadFromGraphDir != null )
      {
        options.setLoadGraphFromGraphDir(Boolean.valueOf(loadFromGraphDir).booleanValue());
      }

      String defaultGraphDir = props.getProperty(KEY_DEFAULT_GRAPH_DIR);
      if ( defaultGraphDir != null && defaultGraphDir.trim().length() > 0 )
      {
        options.setPreferredGraphDirectoryPath(defaultGraphDir.trim());
      }

      String loadFromOPNDir = props.getProperty(KEY_LOAD_FROM_OPN_DIR);
      if ( loadFromOPNDir != null )
      {
        options.setLoadOPNFromOPNDir(Boolean.valueOf(loadFromOPNDir).booleanValue());
      }

      String defaultOPNDir = props.getProperty(KEY_DEFAULT_OPN_DIR);
      if ( defaultOPNDir != null && defaultOPNDir.trim().length() > 0 )
      {
        options.setPreferredOPNDirectoryPath(defaultOPNDir.trim());
      }
    }
    catch ( IOException ioe )
    {
      // Ignore unreadable user settings and continue with defaults.
    }
    finally
    {
      if ( fis != null )
      {
        try
        {
          fis.close();
        }
        catch ( IOException ioe )
        {
          // ignore
        }
      }
    }
  }

  public static void save(GraphControllerOptions options)
  {
    if ( options == null )
    {
      return;
    }

    FileOutputStream fos = null;
    try
    {
      File file = new File(USER_SETTINGS_PATH);
      File parent = file.getParentFile();
      if ( parent != null && !parent.exists() )
      {
        parent.mkdirs();
      }

      Properties props = new Properties();
      props.setProperty(KEY_LOAD_FROM_GRAPH_DIR,
                        String.valueOf(options.getLoadGraphFromGraphDir()));

      String defaultGraphDir = options.getPreferredGraphDirectoryPath();
      if ( defaultGraphDir != null && defaultGraphDir.trim().length() > 0 )
      {
        props.setProperty(KEY_DEFAULT_GRAPH_DIR, defaultGraphDir.trim());
      }

      props.setProperty(KEY_LOAD_FROM_OPN_DIR,
                        String.valueOf(options.getLoadOPNFromOPNDir()));

      String defaultOPNDir = options.getPreferredOPNDirectoryPath();
      if ( defaultOPNDir != null && defaultOPNDir.trim().length() > 0 )
      {
        props.setProperty(KEY_DEFAULT_OPN_DIR, defaultOPNDir.trim());
      }

      fos = new FileOutputStream(file);
      props.store(fos, "OpenGraphEd user settings");
    }
    catch ( IOException ioe )
    {
      // Ignore unwritable user settings and continue.
    }
    finally
    {
      if ( fos != null )
      {
        try
        {
          fos.close();
        }
        catch ( IOException ioe )
        {
          // ignore
        }
      }
    }
  }
}
