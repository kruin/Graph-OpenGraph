package userInterface;

import graphStructure.*;
import userInterface.modes.*;

class GraphEditorModeSupport
{
  private final GraphEditor editor;

  GraphEditorModeSupport(GraphEditor editor)
  {
    this.editor = editor;
  }

  public GraphEditorListener createInitialListener(GraphController controller, Graph graph)
  {
    return new EditListener(graph, editor, controller);
  }

  public void changeToEditMode()
  {
    if ( !isInEditMode() )
    {
      switchListener(new EditListener(editor.getEditorListener()), true);
    }
  }

  public boolean isInEditMode() { return editor.getEditorListener().isEditListener(); }

  public void changeToMoveMode()
  {
    if ( !isInMoveMode() )
    {
      switchListener(new MoveListener(editor.getEditorListener()), true);
    }
  }

  public boolean isInMoveMode() { return editor.getEditorListener().isMoveListener(); }

  public void changeToRotateMode()
  {
    if ( !isInRotateMode() )
    {
      switchListener(new RotateListener(editor.getEditorListener()), true);
    }
  }

  public boolean isInRotateMode() { return editor.getEditorListener().isRotateListener(); }

  public void changeToResizeMode()
  {
    if ( !isInResizeMode() )
    {
      switchListener(new ResizeListener(editor.getEditorListener()), true);
    }
  }

  public boolean isInResizeMode() { return editor.getEditorListener().isResizeListener(); }

  public boolean isInGridMode() { return editor.getEditorListener().isGridListener(); }

  public void ensureGridListener()
  {
    if ( !isInGridMode() )
    {
      switchListener(new GridListener(editor.getEditorListener()), false);
    }
  }

  public String getModeString() { return editor.getEditorListener().getModeString(); }

  public void allowNodeSelection(int numSelectionsAllowed)
  {
    editor.getEditorListener().allowNodeSelection(numSelectionsAllowed);
  }

  public void allowTriangleSelection()
  {
    editor.getEditorListener().allowTriangleSelection();
  }

  public Node[] getSpecialNodeSelections()
  {
    if ( editor == null || editor.getEditorListener() == null ||
         editor.getEditorListener().getSpecialNodeSelections() == null )
    {
      return new Node[0];
    }
    Node specialNodeSelections[] = new Node[editor.getEditorListener().getSpecialNodeSelections().size()];
    editor.getEditorListener().getSpecialNodeSelections().toArray(specialNodeSelections);
    return specialNodeSelections;
  }

  public void prepareForClose()
  {
    editor.getEditorListener().prepareForClose();
  }

  private void switchListener(GraphEditorListener replacement, boolean refreshDisplay)
  {
    editor.unregisterCurrentListener();
    editor.clearTransientShapes();
    editor.setEditorListener(replacement);
    editor.registerCurrentListener();
    if ( refreshDisplay )
    {
      editor.updateShapes();
      editor.repaint();
    }
  }
}
