package userInterface.fileUtils;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/** File filter for JGraphEd .graph files only. */
public class GraphOnlyFilter extends FileFilter {
  public boolean accept(File f) {
    if (f.isDirectory()) {
      return true;
    }
    String extension = Utils.getExtension(f);
    return extension != null && extension.equalsIgnoreCase(Utils.graph);
  }

  public String getDescription() {
    return "GRAPH files (*.graph)";
  }
}
