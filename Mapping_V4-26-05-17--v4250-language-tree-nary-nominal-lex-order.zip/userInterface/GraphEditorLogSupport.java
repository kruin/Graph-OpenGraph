package userInterface;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.Vector;
import graphStructure.Graph;
import graphStructure.LogEntry;

public class GraphEditorLogSupport
{
  private final JLabel versionLabel;
  private final JLabel treeTypeLabel;
  private final JTree logEntryTree;

  public GraphEditorLogSupport(Container container)
  {
    GridBagLayout layout = GraphEditorWindowUiSupport.installVerticalLayout(container);
    versionLabel = new JLabel();
    treeTypeLabel = new JLabel();
    GraphEditorWindowUiSupport.addFullWidth(container, layout, versionLabel,
                                            GridBagConstraints.BOTH, 0.0);
    GraphEditorWindowUiSupport.addFullWidth(container, layout, treeTypeLabel,
                                            GridBagConstraints.BOTH, 0.0);
    logEntryTree = new JTree();
    logEntryTree.setShowsRootHandles(true);
    GraphEditorWindowUiSupport.addFullWidth(container, layout,
      GraphEditorWindowUiSupport.createScrollPane(logEntryTree),
      GridBagConstraints.BOTH, 1.0);
  }

  public void update(Graph graph, Vector logEntries)
  {
    versionLabel.setText(OpenGraphEdAppInfo.getJarVersionLine());
    if ( graph != null && graph.hasOPNLanguageTreeTypeInfo() )
    {
      treeTypeLabel.setText(graph.getOPNLanguageTreeTypeSummary());
    }
    else
    {
      treeTypeLabel.setText("Language Tree: none / not detected");
    }

    if ( logEntries.size() == 0 )
    {
      logEntryTree.setModel(new DefaultTreeModel(
        new DefaultMutableTreeNode("No Log Entries")));
      logEntryTree.setRootVisible(true);
    }
    else
    {
      LogEntry root = new LogEntry();
      root.setSubEntries(logEntries);
      logEntryTree.setModel(new DefaultTreeModel(root));
      logEntryTree.setRootVisible(false);
    }
    logEntryTree.repaint();
    logEntryTree.validate();
  }
}
