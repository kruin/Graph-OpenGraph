package userInterface;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Properties;
import graphStructure.*;

public class GraphEditorWindow extends OpenGraphEdInternalFrame
{
  public static int WIDTH = 1150;//400;//SET MAX, see below:setSize
  public static int HEIGHT = 750;//400;

  private GraphController graphController;
  private GraphEditor graphEditor;
  private static int newCount = 0;
  private GraphEditorDialog ged;
  private GraphEditorInfoWindow infoWindow;
  private GraphEditorLogWindow logWindow;
  private ButtonGroup zinstypeButtonGroup;
  private JToggleButton basisZinstypeButton;
  private JToggleButton bijzinZinstypeButton;
  private JToggleButton stellendZinstypeButton;
  private JToggleButton jaNeeZinstypeButton;
  private JToggleButton whZinstypeButton;
  private JToggleButton topicalisatieZinstypeButton;
  private JComboBox structureTypeCombo;
  private JButton openGraphDrawButton;
  private JLabel zinstypeLabel;
  private JPanel zinstypePanel;
  private JPanel verbClusterPanel;
  private JButton languageTreeSettingsButton;
  private ButtonGroup verbClusterButtonGroup;
  private JToggleButton pvVdVerbClusterButton;
  private JToggleButton vdPvVerbClusterButton;
  private JPanel projectionProfilePanel;
  private JCheckBox projectionShowCheckBox;
  private JCheckBox projectionLeftCheckBox;
  private JCheckBox projectionRightCheckBox;
  private JCheckBox projectionTopCheckBox;
  private JCheckBox projectionBottomCheckBox;
  private JTextField projectionLeftCaptionField;
  private JTextField projectionRightCaptionField;
  private JTextField projectionTopCaptionField;
  private JTextField projectionBottomCaptionField;
  private JButton projectionSaveProfileButton;
  private boolean updatingStructureTypeCombo = false;
  private boolean updatingProjectionProfileControls = false;

  public GraphEditorWindow(GraphController graphController, Graph graph)
  {
    super(graphController, graph.getFileName(),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    if ( graph.getLabel().length() == 0 )
    {
      setTitle(graph.getFileName());
    }
    init(graphController);
    graphEditor.setGraph(graph);
    if ( graph != null && graph.isOPNLanguageTreePreferred() )
    {
      OpenGraphProjectionSettings settings = OpenGraphProjectionSupport.loadBestAvailableForStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
      graphEditor.setOpenGraphProjectionSettings(settings);
      graphEditor.rememberLanguageProjectionSettings(settings);
      graphEditor.setOpenGraphProjectionContextActive(true);
    }
    updateOpenGraphHeaderControls();
  }

  public GraphEditorWindow(GraphController graphController)
  {
    super(graphController, "Untitled " + ++newCount,
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    init(graphController);
  }

  private void init(GraphController graphController)
  {
    this.graphController = graphController;
    infoWindow = new GraphEditorInfoWindow(graphController, this);
    logWindow = new GraphEditorLogWindow(graphController, this);
    graphEditor = new GraphEditor(graphController, infoWindow, logWindow);
    ged = null;
    installImmediateZinstypeToolTips();

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    getContentPane().setLayout(layout);

    JPanel openGraphActionBar = createOpenGraphActionBar();
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.HORIZONTAL;
    layoutCons.insets = new Insets(3,3,0,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 0.0;
    layout.setConstraints(openGraphActionBar, layoutCons);
    getContentPane().add(openGraphActionBar);

    JScrollPane scrollPane = new JScrollPane(graphEditor,
                                             JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = GridBagConstraints.REMAINDER;
    layoutCons.fill = GridBagConstraints.BOTH;
    layoutCons.insets = new Insets(3,3,3,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 1.0;
    layout.setConstraints(scrollPane, layoutCons);
    getContentPane().add(scrollPane);

    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    addInternalFrameListener(graphController);

  //  setSize(WIDTH, HEIGHT);
    
    setSize(graphController.getGraphWindow().getWidth(), graphController.getGraphWindow().getHeight());
    setVisible(true);
  }

  private void installImmediateZinstypeToolTips()
  {
    ToolTipManager manager = ToolTipManager.sharedInstance();
    manager.setInitialDelay(0);
    manager.setReshowDelay(0);
    manager.setDismissDelay(15000);
  }

  private JPanel createOpenGraphActionBar()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 2));
    panel.setBorder(BorderFactory.createEtchedBorder());

    JLabel structureTypeLabel = new JLabel("Type:");
    structureTypeLabel.setToolTipText("OpenGraph structure type. LT = Language Tree / Phrase: DS-boom, LEX-as, zinstypeprofielen en V-cluster.");
    panel.add(structureTypeLabel);
    structureTypeCombo = createStructureTypeCombo();
    panel.add(structureTypeCombo);

    languageTreeSettingsButton = createOpenGraphButton("Settings...", "Language Tree settings: V-cluster en projectieprofiel voor de gebruiker. Alleen zichtbaar bij Type = LT (Language Tree / Phrase).", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        openLanguageTreeSettingsDialog();
      }
    });
    /* Keep the settings button directly next to Structure type. It must be
     * findable before the wide Zinstype/V-cluster/projection groups on
     * narrow screens. */
    panel.add(languageTreeSettingsButton);

    /* Keep Zinstype close to Structure type, but after LT Settings. */
    zinstypePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    zinstypePanel.setOpaque(false);
    zinstypeLabel = new JLabel("Zin:");
    zinstypeLabel.setToolTipText("Zinstype voor Language Tree / Phrase. De knoppen voeren direct Draw/Redraw uit; de DS-boom blijft ongewijzigd.");
    zinstypePanel.add(zinstypeLabel);
    zinstypeButtonGroup = new ButtonGroup();
    basisZinstypeButton = createZinstypeButton("Basis", OpenGraphProjectionSettings.ZINSTYPE_BASIS);
    bijzinZinstypeButton = createZinstypeButton("Bijzin", OpenGraphProjectionSettings.ZINSTYPE_BIJZIN);
    stellendZinstypeButton = createZinstypeButton("Stell.", OpenGraphProjectionSettings.ZINSTYPE_STELLEND);
    jaNeeZinstypeButton = createZinstypeButton("Ja/nee", OpenGraphProjectionSettings.ZINSTYPE_JA_NEE);
    whZinstypeButton = createZinstypeButton("WH", OpenGraphProjectionSettings.ZINSTYPE_WH);
    topicalisatieZinstypeButton = createZinstypeButton("Topic", OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE);
    zinstypePanel.add(basisZinstypeButton);
    zinstypePanel.add(bijzinZinstypeButton);
    zinstypePanel.add(stellendZinstypeButton);
    zinstypePanel.add(jaNeeZinstypeButton);
    zinstypePanel.add(whZinstypeButton);
    zinstypePanel.add(topicalisatieZinstypeButton);
    panel.add(zinstypePanel);

    verbClusterPanel = createVerbClusterPanel();
    panel.add(verbClusterPanel);

    projectionProfilePanel = createProjectionProfilePanel();
    panel.add(projectionProfilePanel);

    openGraphDrawButton = createOpenGraphButton("Draw", "Draw/Redraw using the selected Structure type. Structure type selection alone does not draw.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.drawSelectedOpenGraphStructure(GraphEditorWindow.this);
      }
    });
    panel.add(openGraphDrawButton);

    panel.add(createOpenGraphButton("Grid", "Set or reapply the OpenGraph grid without clearing the current OPN result", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.openGraphGridMode(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Toggle Proj.", "Show or hide OpenGraph projections without moving the structure grid", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.toggleLexicalProjection(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Save OPN", "Save the current OpenGraph result as .opn", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.saveOPN(GraphEditorWindow.this);
      }
    }));

    updateZinstypeButtonSelection();
    updateVerbClusterButtonSelection();
    updateStructureTypeComboSelection();
    updateOpenGraphHeaderControlsVisibility();
    return panel;
  }


  private void openLanguageTreeSettingsDialog()
  {
    if ( graphEditor == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      settings = OpenGraphProjectionSupport.loadBestAvailableForStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    }
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);

    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

    JTextArea intro = new JTextArea(
      "Language Tree settings\n" +
      "Deze instellingen gelden specifiek voor Language Tree / Phrase.\n" +
      "Zinstypeknoppen tekenen direct; deze settings worden opgeslagen en gebruikt bij de volgende Language Tree draw."
    );
    intro.setEditable(false);
    intro.setOpaque(false);
    intro.setLineWrap(true);
    intro.setWrapStyleWord(true);
    root.add(intro, BorderLayout.NORTH);

    JPanel form = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(3, 3, 3, 3);
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 1.0;

    int row = 0;
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 1;
    form.add(new JLabel("V-cluster:"), c);

    JPanel verbPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    final JRadioButton pvVd = new JRadioButton("pv-VD  heeft gebeten");
    final JRadioButton vdPv = new JRadioButton("VD-pv  gebeten heeft");
    ButtonGroup group = new ButtonGroup();
    group.add(pvVd);
    group.add(vdPv);
    if ( OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV.equals(settings.getLanguageTreeVerbClusterOrder()) )
    {
      vdPv.setSelected(true);
    }
    else
    {
      pvVd.setSelected(true);
    }
    verbPanel.add(pvVd);
    verbPanel.add(vdPv);
    c.gridx = 1;
    c.gridy = row++;
    form.add(verbPanel, c);

    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("Projecties:"), c);
    final JCheckBox show = new JCheckBox("toon projecties", settings.getShowProjections());
    c.gridx = 1;
    c.gridy = row++;
    form.add(show, c);

    final JCheckBox leftEnabled = new JCheckBox("links", settings.getLeftProjectionEnabled());
    final JTextField leftCaption = new JTextField(settings.getLeftProjectionCaption(), 8);
    JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    leftPanel.add(leftEnabled);
    leftPanel.add(new JLabel("caption:"));
    leftPanel.add(leftCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("LEX-as:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(leftPanel, c);

    final JCheckBox rightEnabled = new JCheckBox("rechts", settings.getRightProjectionEnabled());
    final JTextField rightCaption = new JTextField(settings.getRightProjectionCaption(), 8);
    JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    rightPanel.add(rightEnabled);
    rightPanel.add(new JLabel("caption:"));
    rightPanel.add(rightCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("SYNT-as:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(rightPanel, c);

    final JCheckBox topEnabled = new JCheckBox("boven", settings.getTopProjectionEnabled());
    final JTextField topCaption = new JTextField(settings.getTopProjectionCaption(), 8);
    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    topPanel.add(topEnabled);
    topPanel.add(new JLabel("caption:"));
    topPanel.add(topCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("boven:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(topPanel, c);

    final JCheckBox bottomEnabled = new JCheckBox("onder", settings.getBottomProjectionEnabled());
    final JTextField bottomCaption = new JTextField(settings.getBottomProjectionCaption(), 8);
    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    bottomPanel.add(bottomEnabled);
    bottomPanel.add(new JLabel("caption:"));
    bottomPanel.add(bottomCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("onder:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(bottomPanel, c);

    root.add(form, BorderLayout.CENTER);

    int answer = JOptionPane.showConfirmDialog(this, root, "Language Tree settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if ( answer != JOptionPane.OK_OPTION )
    {
      return;
    }

    settings.setLanguageTreeVerbClusterOrder(vdPv.isSelected() ? OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV : OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD);
    settings.setShowProjections(show.isSelected());
    settings.setLeftProjectionEnabled(leftEnabled.isSelected());
    settings.setRightProjectionEnabled(rightEnabled.isSelected());
    settings.setTopProjectionEnabled(topEnabled.isSelected());
    settings.setBottomProjectionEnabled(bottomEnabled.isSelected());
    settings.setLeftProjectionCaption(leftCaption.getText());
    settings.setRightProjectionCaption(rightCaption.getText());
    settings.setTopProjectionCaption(topCaption.getText());
    settings.setBottomProjectionCaption(bottomCaption.getText());
    settings.normalize();

    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(true);
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.update();
    updateOpenGraphHeaderControls();
    saveProjectionProfile(settings);
  }

  private JPanel createProjectionProfilePanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
    panel.setOpaque(false);
    panel.add(new JLabel("Projecties:"));

    projectionShowCheckBox = createProjectionCheckBox("aan", "Toon/verberg projecties voor het gekozen Structure type.");
    panel.add(projectionShowCheckBox);

    projectionLeftCheckBox = createProjectionCheckBox("L", "Linkerprojectie aan/uit.");
    projectionLeftCaptionField = createProjectionCaptionField("LEX", "Caption voor de linkerprojectie.");
    panel.add(projectionLeftCheckBox);
    panel.add(projectionLeftCaptionField);

    projectionRightCheckBox = createProjectionCheckBox("R", "Rechterprojectie aan/uit.");
    projectionRightCaptionField = createProjectionCaptionField("SYNT", "Caption voor de rechterprojectie.");
    panel.add(projectionRightCheckBox);
    panel.add(projectionRightCaptionField);

    projectionTopCheckBox = createProjectionCheckBox("Boven", "Bovenprojectie aan/uit.");
    projectionTopCaptionField = createProjectionCaptionField("pm", "Caption voor de bovenprojectie.");
    panel.add(projectionTopCheckBox);
    panel.add(projectionTopCaptionField);

    projectionBottomCheckBox = createProjectionCheckBox("Onder", "Onderprojectie aan/uit.");
    projectionBottomCaptionField = createProjectionCaptionField("LF", "Caption voor de onderprojectie.");
    panel.add(projectionBottomCheckBox);
    panel.add(projectionBottomCaptionField);

    projectionSaveProfileButton = createOpenGraphButton("Save profile", "Sla deze projectieconfig op voor het gekozen Structure type in config/opengraph_user.properties.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveProjectionProfileFromHeader();
      }
    });
    panel.add(projectionSaveProfileButton);

    updateProjectionProfileControlsFromEditor();
    return panel;
  }

  private JCheckBox createProjectionCheckBox(String text, String toolTip)
  {
    JCheckBox box = new JCheckBox(text);
    box.setFocusable(false);
    box.setOpaque(false);
    box.setToolTipText(toolTip);
    box.setMargin(new Insets(0, 0, 0, 0));
    box.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    return box;
  }

  private JTextField createProjectionCaptionField(String text, String toolTip)
  {
    final JTextField field = new JTextField(text, 4);
    field.setToolTipText(toolTip);
    field.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    field.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    return field;
  }

  private void updateProjectionProfileControlsFromEditor()
  {
    if ( graphEditor == null || projectionShowCheckBox == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    updatingProjectionProfileControls = true;
    try
    {
      projectionShowCheckBox.setSelected(settings.getShowProjections());
      projectionLeftCheckBox.setSelected(settings.getLeftProjectionEnabled());
      projectionRightCheckBox.setSelected(settings.getRightProjectionEnabled());
      projectionTopCheckBox.setSelected(settings.getTopProjectionEnabled());
      projectionBottomCheckBox.setSelected(settings.getBottomProjectionEnabled());

      projectionLeftCaptionField.setText(settings.getLeftProjectionCaption());
      projectionRightCaptionField.setText(settings.getRightProjectionCaption());
      projectionTopCaptionField.setText(settings.getTopProjectionCaption());
      projectionBottomCaptionField.setText(settings.getBottomProjectionCaption());

      boolean enabled = OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType());
      projectionShowCheckBox.setEnabled(enabled);
      projectionLeftCheckBox.setEnabled(enabled);
      projectionRightCheckBox.setEnabled(enabled);
      projectionTopCheckBox.setEnabled(enabled);
      projectionBottomCheckBox.setEnabled(enabled);
      projectionLeftCaptionField.setEnabled(enabled);
      projectionRightCaptionField.setEnabled(enabled);
      projectionTopCaptionField.setEnabled(enabled);
      projectionBottomCaptionField.setEnabled(enabled);
      projectionSaveProfileButton.setEnabled(enabled);
    }
    finally
    {
      updatingProjectionProfileControls = false;
    }
  }

  private void applyProjectionProfileControlsToEditor(boolean persist)
  {
    if ( updatingProjectionProfileControls || graphEditor == null || projectionShowCheckBox == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) )
    {
      updateProjectionProfileControlsFromEditor();
      return;
    }

    settings.setShowProjections(projectionShowCheckBox.isSelected());
    settings.setLeftProjectionEnabled(projectionLeftCheckBox.isSelected());
    settings.setRightProjectionEnabled(projectionRightCheckBox.isSelected());
    settings.setTopProjectionEnabled(projectionTopCheckBox.isSelected());
    settings.setBottomProjectionEnabled(projectionBottomCheckBox.isSelected());

    settings.setLeftProjectionCaption(projectionLeftCaptionField.getText());
    settings.setRightProjectionCaption(projectionRightCaptionField.getText());
    settings.setTopProjectionCaption(projectionTopCaptionField.getText());
    settings.setBottomProjectionCaption(projectionBottomCaptionField.getText());
    settings.normalize();

    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()));
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.update();

    if ( persist )
    {
      saveProjectionProfile(settings);
    }
  }

  private void saveProjectionProfileFromHeader()
  {
    applyProjectionProfileControlsToEditor(false);
    if ( graphEditor == null )
    {
      return;
    }
    saveProjectionProfile(graphEditor.getOpenGraphProjectionSettings());
  }

  private void saveProjectionProfile(OpenGraphProjectionSettings settings)
  {
    if ( settings == null || !OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) )
    {
      return;
    }

    try
    {
      Properties props = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(OpenGraphGridSettingsIO.USER_SETTINGS_PATH);
      if ( props == null )
      {
        props = new Properties();
      }

      String prefix = "projection.profile." + OpenGraphDialogSettingsSupport.projectionProfileName(settings.getStructureType()) + ".";
      props.setProperty("structure.type", String.valueOf(settings.getStructureType()));
      props.setProperty(prefix + "show", String.valueOf(settings.getShowProjections()));
      props.setProperty(prefix + "left.enabled", String.valueOf(settings.getLeftProjectionEnabled()));
      props.setProperty(prefix + "right.enabled", String.valueOf(settings.getRightProjectionEnabled()));
      props.setProperty(prefix + "top.enabled", String.valueOf(settings.getTopProjectionEnabled()));
      props.setProperty(prefix + "bottom.enabled", String.valueOf(settings.getBottomProjectionEnabled()));
      props.setProperty(prefix + "left.caption", settings.getLeftProjectionCaption());
      props.setProperty(prefix + "right.caption", settings.getRightProjectionCaption());
      props.setProperty(prefix + "top.caption", settings.getTopProjectionCaption());
      props.setProperty(prefix + "bottom.caption", settings.getBottomProjectionCaption());
      props.setProperty(prefix + "left.position", String.valueOf(settings.getLeftProjectionPosition()));
      props.setProperty(prefix + "right.position", String.valueOf(settings.getRightProjectionPosition()));
      props.setProperty(prefix + "top.position", String.valueOf(settings.getTopProjectionPosition()));
      props.setProperty(prefix + "bottom.position", String.valueOf(settings.getBottomProjectionPosition()));
      if ( settings.getStructureType() == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
      {
        props.setProperty(prefix + "verbcluster.order", settings.getLanguageTreeVerbClusterOrder());
        props.setProperty("language.verbcluster.order", settings.getLanguageTreeVerbClusterOrder());
      }

      OpenGraphDialogSettingsSupport.saveProperties(OpenGraphGridSettingsIO.USER_SETTINGS_PATH, props,
        "OpenGraphEd user settings - projection profile updated from header UI");
      JOptionPane.showMessageDialog(this,
        "Projectieprofiel opgeslagen voor " + currentStructureTypeLabel(settings.getStructureType()) + ".",
        "Projection profile", JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( IOException ex )
    {
      System.err.println("[OpenGraph] Could not save projection profile: " + ex);
      ex.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this,
        "Projectieprofiel kon niet worden opgeslagen:\n" + ex.getMessage(),
        "Projection profile", JOptionPane.ERROR_MESSAGE);
    }
  }

  private String currentStructureTypeLabel(int structureType)
  {
    if ( structureTypeCombo != null )
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          return item.toString();
        }
      }
    }
    return "structure type " + structureType;
  }

  private JComboBox createStructureTypeCombo()
  {
    final StructureTypeItem[] items = new StructureTypeItem[]
    {
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_SIMPLE_TREE, "Simple", "Simple tree: gewone draw, geen Language Tree-profiel."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE, "LT", "LT = Language Tree / Phrase: DS-boom, LEX-as, zinstypeprofielen, V-cluster en projectieprofiel."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_ANAPHOR_TREE, "Anaf.", "Anafoor: anaforische/projectieve structuur."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_FRAME, "Frame", "Frame: rol-/functiestructuur met eigen projectieprofiel.")
    };
    final JComboBox combo = new JComboBox(items);
    combo.setFocusable(false);
    combo.setToolTipText("Type. LT = Language Tree / Phrase. Deze keuze tekent niet direct; gebruik Draw bij Simple/Frame/Anafoor of een Zinstypeknop bij LT.");
    combo.setRenderer(new DefaultListCellRenderer()
    {
      public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
      {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if ( value instanceof StructureTypeItem )
        {
          StructureTypeItem item = (StructureTypeItem)value;
          setText(item.toString());
          list.setToolTipText(item.getToolTip());
        }
        return this;
      }
    });
    combo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if ( updatingStructureTypeCombo )
        {
          return;
        }
        Object selected = combo.getSelectedItem();
        if ( selected instanceof StructureTypeItem )
        {
          graphController.applyOpenGraphStructureType(GraphEditorWindow.this, ((StructureTypeItem)selected).getValue());
        }
      }
    });
    return combo;
  }

  private static class StructureTypeItem
  {
    private final int value;
    private final String label;
    private final String toolTip;

    StructureTypeItem(int value, String label, String toolTip)
    {
      this.value = value;
      this.label = label;
      this.toolTip = toolTip;
    }

    int getValue()
    {
      return value;
    }

    String getToolTip()
    {
      return toolTip;
    }

    public String toString()
    {
      return label;
    }
  }

  private JToggleButton createZinstypeButton(String text, final String zinstype)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 6, 2, 6));
    button.setFocusable(false);
    button.setToolTipText(buildZinstypeToolTip(zinstype));
    if ( zinstypeButtonGroup != null )
    {
      zinstypeButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeZinstype(GraphEditorWindow.this, zinstype);
          updateZinstypeButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  private String buildZinstypeToolTip(String zinstype)
  {
    OpenGraphProjectionSettings settings = graphEditor == null ? new OpenGraphProjectionSettings() : new OpenGraphProjectionSettings(graphEditor.getOpenGraphProjectionSettings());
    settings.setLanguageTreeZinstype(zinstype);
    String[] lines = settings.getLanguageTreeZinstypeRulePreviewLines();
    StringBuffer html = new StringBuffer("<html><b>Zinstype: ");
    html.append(settings.getLanguageTreeZinstypeDisplayName());
    html.append("</b><br>");
    html.append("Language Tree / Phrase; geen Frame. DS blijft staan, regels werken op de LEX-as.<br><br>");
    for ( int i=0; i<lines.length; i++ )
    {
      if ( lines[i] != null && lines[i].trim().length() > 0 )
      {
        html.append("&#8226; ").append(lines[i]).append("<br>");
      }
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) )
    {
      html.append("<br>Klik eerst een categoriale knoop, bijvoorbeeld NP of DP.<br>");
      html.append("De lexicale vorm wordt als frase getoond, bijvoorbeeld NP(de man).");
    }
    html.append("</html>");
    return html.toString();
  }

  private JPanel createVerbClusterPanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    panel.setOpaque(false);
    JLabel label = new JLabel("V:");
    label.setToolTipText("V-cluster voor Language Tree: lokale vertakking/volgorde binnen V. Projectie blijft terminale knoop -> LEX-as.");
    panel.add(label);

    verbClusterButtonGroup = new ButtonGroup();
    pvVdVerbClusterButton = createVerbClusterButton("pv-VD", OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD,
      "heeft gebeten: pv kort/eerst, VD lang/tweede");
    vdPvVerbClusterButton = createVerbClusterButton("VD-pv", OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV,
      "gebeten heeft: VD kort/eerst, pv lang/tweede");
    panel.add(pvVdVerbClusterButton);
    panel.add(vdPvVerbClusterButton);
    return panel;
  }

  private JToggleButton createVerbClusterButton(String text, final String order, String toolTip)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 6, 2, 6));
    button.setFocusable(false);
    button.setToolTipText("<html><b>V-cluster " + text + "</b><br>" + toolTip + "<br>Alleen Language Tree / Phrase. De DS-projecties blijven onveranderd.</html>");
    if ( verbClusterButtonGroup != null )
    {
      verbClusterButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeVerbClusterOrder(GraphEditorWindow.this, order);
          updateVerbClusterButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  public void updateVerbClusterButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String order = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeVerbClusterOrder();
    if ( OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV.equals(order) && vdPvVerbClusterButton != null )
    {
      vdPvVerbClusterButton.setSelected(true);
    }
    else if ( pvVdVerbClusterButton != null )
    {
      pvVdVerbClusterButton.setSelected(true);
    }
  }

  public void updateZinstypeButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String zinstype = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeZinstype();
    if ( OpenGraphProjectionSettings.ZINSTYPE_BIJZIN.equals(zinstype) && bijzinZinstypeButton != null )
    {
      bijzinZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) && stellendZinstypeButton != null )
    {
      stellendZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) && jaNeeZinstypeButton != null )
    {
      jaNeeZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype) && whZinstypeButton != null )
    {
      whZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) && topicalisatieZinstypeButton != null )
    {
      topicalisatieZinstypeButton.setSelected(true);
    }
    else if ( basisZinstypeButton != null )
    {
      basisZinstypeButton.setSelected(true);
    }
  }

  public void updateStructureTypeComboSelection()
  {
    if ( graphEditor == null || structureTypeCombo == null )
    {
      return;
    }
    int structureType = graphEditor.getOpenGraphProjectionSettings().getStructureType();
    updatingStructureTypeCombo = true;
    try
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          structureTypeCombo.setSelectedIndex(i);
          return;
        }
      }
    }
    finally
    {
      updatingStructureTypeCombo = false;
    }
  }

  public void updateOpenGraphHeaderControls()
  {
    updateZinstypeButtonSelection();
    updateVerbClusterButtonSelection();
    updateStructureTypeComboSelection();
    updateProjectionProfileControlsFromEditor();
    updateOpenGraphHeaderControlsVisibility();
  }

  private void updateOpenGraphHeaderControlsVisibility()
  {
    if ( graphEditor == null )
    {
      return;
    }
    int structureType = graphEditor.getOpenGraphProjectionSettings().getStructureType();
    boolean isLanguageTree = structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    if ( zinstypePanel != null )
    {
      zinstypePanel.setVisible(isLanguageTree);
    }
    if ( verbClusterPanel != null )
    {
      verbClusterPanel.setVisible(isLanguageTree);
    }
    if ( languageTreeSettingsButton != null )
    {
      languageTreeSettingsButton.setVisible(isLanguageTree);
    }
    if ( projectionProfilePanel != null )
    {
      projectionProfilePanel.setVisible(OpenGraphProjectionSettings.isProjectionCapableStructureType(structureType));
    }
    if ( openGraphDrawButton != null )
    {
      openGraphDrawButton.setVisible(!isLanguageTree);
    }
    revalidate();
    repaint();
  }


  private JButton createOpenGraphButton(String text, String toolTip, ActionListener listener)
  {
    JButton button = new JButton(text);
    button.setMargin(new Insets(2, 8, 2, 8));
    button.setFocusable(false);
    button.setToolTipText(toolTip);
    button.addActionListener(listener);
    return button;
  }

  public void dispose()
  {
    graphEditor.prepareForClose();
    super.dispose();
  }

  public GraphEditor getGraphEditor()
  {
    return graphEditor;
  }

  public GraphEditorDialog getDialog() { return ged; }

  public void setDialog(GraphEditorDialog d) { ged = d; }

  public GraphEditorInfoWindow getInfoWindow()
  {
    return infoWindow;
  }
  
  public GraphEditorLogWindow getLogWindow()
  {
    return logWindow;
  }  
}