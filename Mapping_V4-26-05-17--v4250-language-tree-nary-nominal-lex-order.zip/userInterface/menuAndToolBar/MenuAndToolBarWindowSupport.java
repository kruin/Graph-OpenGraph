package userInterface.menuAndToolBar;

import java.lang.reflect.Method;
import javax.swing.*;
import userInterface.GraphController;

public class MenuAndToolBarWindowSupport
{
  private MenuAndToolBar owner;
  private GraphController controller;

  public MenuAndToolBarWindowSupport(MenuAndToolBar owner, GraphController controller)
  {
    this.owner = owner;
    this.controller = controller;
  }

  public void removeWindow(JMenuItem menuItem)
  {
    JMenu windowMenu = owner.getWindowMenu();
    windowMenu.remove(menuItem);
    if ( windowMenu.getItemCount() == 0 )
    {
      windowMenu.add(owner.getNoWindowItem());
    }
  }

  public void addWindow(JMenuItem menuItem)
  {
    JMenu windowMenu = owner.getWindowMenu();
    if ( !windowContainsMenuItem(menuItem) )
    {
      if ( windowMenu.getItemCount() > 0 &&
           windowMenu.getItem(0) == owner.getNoWindowItem() )
      {
        windowMenu.remove(owner.getNoWindowItem());
      }
      windowMenu.add(menuItem);
    }
  }

  private boolean windowContainsMenuItem(JMenuItem item)
  {
    boolean found = false;
    JMenu windowMenu = owner.getWindowMenu();
    if ( item == null )
    {
      return true;
    }
    for ( int i=0; i<windowMenu.getItemCount(); i++ )
    {
      if ( windowMenu.getItem(i) == item )
      {
        found = true;
        break;
      }
    }
    return found;
  }

  public void createSaveOPNAction()
  {
    Method method = null;
    try
    {
      method = GraphController.class.getDeclaredMethod("saveOPN");
    }
    catch (NoSuchMethodException nsme)
    {
      // error
    }
    MenuAndToolBarAction saveOPNAction = new MenuAndToolBarAction(
      "Save OPN",
      new ImageIcon(MenuAndToolBar.class.getResource("/images/Save.gif")),
      "Save the current Open format result",
      Integer.valueOf((int)'O'),
      false,
      1,
      method,
      false,
      controller
    );
    owner.setSaveOPNAction(saveOPNAction);
    owner.addAction(saveOPNAction);
    saveOPNAction.setEnabled(false);
  }

  private boolean fileContainsMenuItem(JMenuItem item)
  {
    JMenu fileMenu = owner.getFileMenu();
    if ( fileMenu == null || item == null )
    {
      return false;
    }
    for ( int i=0; i<fileMenu.getItemCount(); i++ )
    {
      if ( fileMenu.getItem(i) == item )
      {
        return true;
      }
    }
    return false;
  }

  private int getFileMenuIndexAfterSaveGraph()
  {
    JMenu fileMenu = owner.getFileMenu();
    if ( fileMenu == null )
    {
      return -1;
    }
    for ( int i=0; i<fileMenu.getItemCount(); i++ )
    {
      JMenuItem item = fileMenu.getItem(i);
      if ( item != null && "Save Graph".equals(item.getText()) )
      {
        return i + 1;
      }
    }
    return fileMenu.getItemCount();
  }

  public void showSaveOPN()
  {
    JMenu fileMenu = owner.getFileMenu();
    MenuAndToolBarAction saveOPNAction = owner.getSaveOPNAction();
    if ( fileMenu == null || saveOPNAction == null )
    {
      return;
    }
    JMenuItem item = saveOPNAction.getMenuItem();
    if ( item.getParent() != null && item.getParent() != fileMenu )
    {
      return;
    }
    if ( !fileContainsMenuItem(item) )
    {
      int index = getFileMenuIndexAfterSaveGraph();
      if ( index < 0 || index > fileMenu.getItemCount() )
      {
        fileMenu.add(item);
      }
      else
      {
        fileMenu.insert(item, index);
      }
    }
  }

  public void hideSaveOPN()
  {
    JMenu fileMenu = owner.getFileMenu();
    MenuAndToolBarAction saveOPNAction = owner.getSaveOPNAction();
    if ( fileMenu == null || saveOPNAction == null )
    {
      return;
    }
    JMenuItem item = saveOPNAction.getMenuItem();
    if ( item.getParent() != null && item.getParent() != fileMenu )
    {
      return;
    }
    if ( fileContainsMenuItem(item) )
    {
      fileMenu.remove(item);
      fileMenu.revalidate();
      fileMenu.repaint();
    }
  }

  public void setSaveOPNEnabled(boolean enabled)
  {
    MenuAndToolBarAction saveOPNAction = owner.getSaveOPNAction();
    if ( saveOPNAction != null )
    {
      saveOPNAction.setEnabled(enabled);
      if ( saveOPNAction.getMenuItem() != null )
      {
        saveOPNAction.getMenuItem().setEnabled(enabled);
      }
      if ( saveOPNAction.getButton() != null )
      {
        saveOPNAction.getButton().setEnabled(enabled);
      }
    }
  }
}
