package userInterface;

public class GraphControllerOptions
{
  private boolean drawOnEmbedding;
  private boolean clearGenerated;
  private boolean testFeaturesEnabled;
  private boolean loadGraphFromGraphDir;
  private boolean loadOPNFromOPNDir;
  private String preferredGraphDirectoryPath;
  private String preferredOPNDirectoryPath;

  public GraphControllerOptions()
  {
    drawOnEmbedding = true;
    clearGenerated = false;
    testFeaturesEnabled = false;
    loadGraphFromGraphDir = true;
    loadOPNFromOPNDir = true;
    preferredGraphDirectoryPath = null;
    preferredOPNDirectoryPath = null;
  }

  public void setDrawOnEmbedding(boolean drawOnEmbedding)
  {
    this.drawOnEmbedding = drawOnEmbedding;
  }

  public boolean getDrawOnEmbedding()
  {
    return drawOnEmbedding;
  }

  public void toggleDrawOnEmbedding()
  {
    drawOnEmbedding = !drawOnEmbedding;
  }

  public void setClearGenerated(boolean clearGenerated)
  {
    this.clearGenerated = clearGenerated;
  }

  public boolean getClearGenerated()
  {
    return clearGenerated;
  }

  public void toggleClearGenerated()
  {
    clearGenerated = !clearGenerated;
  }

  public boolean getTestFeaturesEnabled()
  {
    return testFeaturesEnabled;
  }

  public void toggleTestFeaturesEnabled()
  {
    testFeaturesEnabled = !testFeaturesEnabled;
  }

  public boolean getLoadGraphFromGraphDir()
  {
    return loadGraphFromGraphDir;
  }

  public void setLoadGraphFromGraphDir(boolean loadGraphFromGraphDir)
  {
    this.loadGraphFromGraphDir = loadGraphFromGraphDir;
  }

  public void toggleLoadGraphFromGraphDir()
  {
    loadGraphFromGraphDir = !loadGraphFromGraphDir;
  }

  public boolean getLoadOPNFromOPNDir()
  {
    return loadOPNFromOPNDir;
  }

  public void setLoadOPNFromOPNDir(boolean loadOPNFromOPNDir)
  {
    this.loadOPNFromOPNDir = loadOPNFromOPNDir;
  }

  public void toggleLoadOPNFromOPNDir()
  {
    loadOPNFromOPNDir = !loadOPNFromOPNDir;
  }

  public String getPreferredGraphDirectoryPath()
  {
    return preferredGraphDirectoryPath;
  }

  public void setPreferredGraphDirectoryPath(String preferredGraphDirectoryPath)
  {
    this.preferredGraphDirectoryPath = preferredGraphDirectoryPath;
  }


  public String getPreferredOPNDirectoryPath()
  {
    return preferredOPNDirectoryPath;
  }

  public void setPreferredOPNDirectoryPath(String preferredOPNDirectoryPath)
  {
    this.preferredOPNDirectoryPath = preferredOPNDirectoryPath;
  }
}
