package userInterface;

import java.util.Vector;

public class GraphEditorLogWindow extends OpenGraphEdInternalFrame
{
  public static int WIDTH = 400;
  public static int HEIGHT = 400;

  private final GraphEditorWindow editorWindow;
  private final GraphEditorLogSupport logSupport;

  public GraphEditorLogWindow(GraphController controller,
                              GraphEditorWindow editorWindow)
  {
    super(controller, editorWindow.getTitle() + " - Log",
          true, true, true, true);
    this.editorWindow = editorWindow;
    logSupport = new GraphEditorLogSupport(getContentPane());

    update();
    addInternalFrameListener(controller);
    setSize(WIDTH, HEIGHT);
  }

  public void update()
  {
    if ( isVisible() )
    {
      graphStructure.Graph graph = editorWindow.getGraphEditor().getGraph();
      Vector logEntries = graph.getLogEntries();
      logSupport.update(graph, logEntries);
    }
  }
}
