# v4.24.9 — Language Tree n-ary terminal diagonal clearance

## v4.25.0 — Language Tree n-ary nominal lexical order

- Normalizes terminal-only n-ary NP/DP projections before corridor placement.
- Fixes incorrect nominal order such as `kleine de man` to `de kleine man`.
- Keeps n-ary layout direct, with corridor placement after lexical order normalization.
- Compile and dry-run checks passed.


## Fixed

- n-ary lexical child edges such as `NP-de` and `NP-grote` no longer start in the first adjacent column from the parent.
- Terminal children get one extra horizontal clearance column before same-side corridor numbering is applied.
- This keeps n-ary child edges diagonally free while retaining source-order vertical stacking.

## Kept

- direct n-ary placement for 3, 4, 5, ... children
- unary-aware subtree boxes
- terminal-aware stacking
- structural `VP -> NP V`
- toolbar-controlled `pv-VD` / `VD-pv`
- no RR/LL cascade

## Checks

- Java compile: OK
- Fresh jar: OK
- `java --dry-run -cp out:. OpenGraphEdFrame`: OK
- `java --dry-run -jar dist/OpenGraphEd.jar`: OK

# v4.24.8 — Language Tree n-ary same-side terminal corridor fix

## Fixed

- n-ary fan-out no longer places repeated same-side lexical children in the same terminal corridor.
- Examples: `de` / `hond` and `kleine` / `man` are now separated horizontally while retaining source-order vertical stacking.
- Same-side n-ary children are widened as `L1, R1, L2, R2, ...`.

## Kept

- unary-aware subtree boxes
- terminal-aware vertical stacking
- direct n-ary placement for 3, 4, 5, ... children
- structural `VP -> NP V`
- toolbar-controlled `pv-VD` / `VD-pv`
- no RR/LL cascade

## Checks

- Java compile: OK
- Fresh jar: OK
- `java --dry-run -cp out:. OpenGraphEdFrame`: OK
- `java --dry-run -jar dist/OpenGraphEd.jar`: OK