- `PATCH-MANIFEST-v4248-language-tree-nary-same-side-terminal-corridor-fix.md` — n-ary same-side terminal corridor fix for repeated same-side lexical children.
- `CHANGELOG.md` — current project changelog.

- PATCH-MANIFEST-v4249-language-tree-nary-terminal-diagonal-clearance.md
- [PATCH-MANIFEST-v4250-language-tree-nary-nominal-lex-order.md](PATCH-MANIFEST-v4250-language-tree-nary-nominal-lex-order.md) — Language Tree n-ary nominal lexical order fix.
