package operation;

import graphException.*;
import graphStructure.*;
import java.util.Vector;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import operation.extenders.*;

public class OpenGraphTreeDrawOperation
{
  private static final int DEFAULT_DRAWING_OFFSET_X = 4;
  private static final int DEFAULT_DRAWING_OFFSET_Y = 4;
  private static final int DEFAULT_CELL_WIDTH = 20;
  private static final int DEFAULT_CELL_HEIGHT = 20;

  /**
   * Keep one empty grid column between the root axis and each child box.
   * This preserves the open-tree character while keeping the reserved box minimal.
   */
  private static final int ROOT_SIDE_GAP = 1;
  private static final int LANGUAGE_TREE_TOP_SLOT_ROWS = 1;
  private static final String LAYOUT_FREE_D_LITE = "free_d_lite";
  private static final String LAYOUT_NARY_COMPACT_LR = "nary_compact_lr";
  private static final int SIDE_LEFT = -1;
  private static final int SIDE_NEUTRAL = 0;
  private static final int SIDE_RIGHT = 1;

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                            int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method,
                            DEFAULT_DRAWING_OFFSET_X,
                            DEFAULT_DRAWING_OFFSET_Y,
                            DEFAULT_CELL_WIDTH, DEFAULT_CELL_HEIGHT,
                            width, height, false);
  }


  /**
   * Compatibility overload for older callers. Right and bottom structure offsets
   * are intentionally ignored: tree positioning is anchored by left/top only.
   */
  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int rightOffset,
                                             int topOffset, int bottomOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method,
                            leftOffset, topOffset,
                            cellWidth, cellHeight,
                            width, height, false);
  }
  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height, false);
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height,
                                reserveLanguageSlots, false);
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots,
                                             boolean lengthenLanguageTreeRootBranch) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height,
                                reserveLanguageSlots, lengthenLanguageTreeRootBranch,
                                "pv_vd");
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots,
                                             boolean lengthenLanguageTreeRootBranch,
                                             String languageTreeVerbClusterOrder) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height,
                                reserveLanguageSlots, lengthenLanguageTreeRootBranch,
                                languageTreeVerbClusterOrder, LAYOUT_FREE_D_LITE);
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots,
                                             boolean lengthenLanguageTreeRootBranch,
                                             String languageTreeVerbClusterOrder,
                                             String languageTreeLayoutStrategy) throws Exception
  {
    boolean oldSpecialSelected = root.isSpecialSelected();
    root.setSpecialSelected(true);
    LogEntry logEntry = g.startLogEntry("OpenGraph Tree Drawing");
    try
    {
      if ( !ConnectivityOperation.isConnected(g) )
      {
        logEntry.setData("Graph was not connected");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph is not connected!");
      }
      else if ( TreeOperation.hasCycles(g) )
      {
        logEntry.setData("Graph had cycles");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph has Cycles!");
      }
      else
      {
        Vector nodes = g.createNodeExtenders(OpenGraphNodeEx.class);
        Vector edges = g.createEdgeExtenders(OpenGraphEdgeEx.class);
        OpenGraphNodeEx rootEx = (OpenGraphNodeEx)root.getExtender();
        rootEx.setParent(null);

        buildTree(rootEx);

        if ( method == 1 )
        {
          domainTreeMethod(rootEx, languageTreeVerbClusterOrder,
                           normalizeLanguageTreeLayoutStrategy(languageTreeLayoutStrategy),
                           lengthenLanguageTreeRootBranch);
          if ( lengthenLanguageTreeRootBranch )
          {
            lengthenFirstRootBranch(rootEx);
          }
        }
        else if ( method == 5 )
        {
          logEntry.setData("Method 5 is not implemented reliably");
          g.stopLogEntry(logEntry);
          throw new GraphException("OpenGraph method 5 is not implemented reliably. Use the Simple open-tree renderer.");
        }
        else
        {
          logEntry.setData("Unsupported OpenGraph method: " + method);
          g.stopLogEntry(logEntry);
          throw new GraphException("Unsupported OpenGraph drawing method: " + method);
        }

        int gridWidth = rootEx.getBoundWidth();
        int gridHeight = rootEx.getBoundHeight();

        leftOffset = Math.max(0, leftOffset);
        topOffset = Math.max(0, topOffset);
        if ( reserveLanguageSlots )
        {
          topOffset += LANGUAGE_TREE_TOP_SLOT_ROWS;
        }
        cellWidth = Math.max(2, cellWidth);
        cellHeight = Math.max(2, cellHeight);

        correctGridCoordinates(rootEx, leftOffset + rootEx.getBoundX(), topOffset);

        int totalGridCols = gridWidth + leftOffset + 1;
        int totalGridRows = gridHeight + topOffset + 1;

        g.setGrid(totalGridRows, cellHeight,
                  totalGridCols, cellWidth, true);

        OpenGraphNodeEx aNode;
        OpenGraphEdgeEx anEdge;
        for ( int i=0; i<nodes.size(); i++ )
        {
          aNode = (OpenGraphNodeEx)nodes.elementAt(i);
          g.relocateNode(aNode.getRef(),
                         new Location(aNode.getGridX()*cellWidth,
                                      aNode.getGridY()*cellHeight),
                         true);
        }

        for ( int i=0; i<edges.size(); i++ )
        {
          anEdge = (OpenGraphEdgeEx)edges.elementAt(i);
          g.straightenEdge(anEdge.getRef(), true);
        }

        g.stopLogEntry(logEntry);
      }
    }
    finally
    {
      root.setSpecialSelected(oldSpecialSelected);
    }
  }

  private static int buildTree(OpenGraphNodeEx root)
  {
    Vector children = root.getChildren();
    OpenGraphNodeEx child;
    int size = 1;
    for ( int i=0; i<children.size(); i++ )
    {
      child = (OpenGraphNodeEx)children.elementAt(i);
      if ( child != root.getParent() )
      {
        child.setParent(root);
        size += buildTree(child);
      }
    }
    root.setSubTreeSize(size);
    root.setSubTreeDone(false);
    return size;
  }

  private static void domainTreeMethod(OpenGraphNodeEx root, String languageTreeVerbClusterOrder,
                                       String languageTreeLayoutStrategy,
                                       boolean freeLanguageLayout)
  {
    domainTreeMethod(root, languageTreeVerbClusterOrder, languageTreeLayoutStrategy,
                     freeLanguageLayout, SIDE_NEUTRAL);
  }

  /**
   * Recursive Language Tree/OpenGraph layout.
   *
   * v4.24.5 correction: binary and n-ary vertical stacking is now based on
   * actual subtree boxes, not cached boundHeight values.  A second subtree
   * root is placed below the real bottom of the previous subtree box, so a
   * terminal such as man cannot share a row with the following V node.
   * Unary descendants and true n-ary children remain part of the subtree box.
   */
  private static void domainTreeMethod(OpenGraphNodeEx root, String languageTreeVerbClusterOrder,
                                       String languageTreeLayoutStrategy,
                                       boolean freeLanguageLayout,
                                       int sidePreference)
  {
    Vector children = root.getChildren();

    if ( children.size() == 0 )
    {
      initializeLeaf(root);
      return;
    }

    if ( children.size() == 1 )
    {
      OpenGraphNodeEx child = (OpenGraphNodeEx)children.elementAt(0);
      int childSide = freeLanguageLayout ? preferredUnaryDirection(root, child, sidePreference)
                                         : SIDE_NEUTRAL;
      domainTreeMethod(child, languageTreeVerbClusterOrder,
                       languageTreeLayoutStrategy, freeLanguageLayout, childSide);

      if ( freeLanguageLayout )
      {
        freeUnaryRule(root, child, childSide);
      }
      else
      {
        otherRule(root, child);
      }
      return;
    }

    if ( children.size() == 2 )
    {
      OpenGraphNodeEx leftChild = (OpenGraphNodeEx)children.elementAt(0);
      OpenGraphNodeEx rightChild = (OpenGraphNodeEx)children.elementAt(1);
      int structuralFirstSide = SIDE_LEFT;

      if ( isVerbClusterNode(root) )
      {
        OpenGraphNodeEx[] ordered = orderVerbClusterChildren(leftChild, rightChild, languageTreeVerbClusterOrder);
        if ( ordered != null )
        {
          /*
           * V-cluster order is visual/structural order: pv-VD means pv left,
           * VD right.  The surrounding right/left context may enlarge the
           * reserved box later, but must not flip the cluster into VD-pv.
           */
          domainTreeMethod(leftChild, languageTreeVerbClusterOrder,
                           languageTreeLayoutStrategy, freeLanguageLayout,
                           childExpansionSideForOrderedBinary(leftChild, ordered[0], ordered[1]));
          domainTreeMethod(rightChild, languageTreeVerbClusterOrder,
                           languageTreeLayoutStrategy, freeLanguageLayout,
                           childExpansionSideForOrderedBinary(rightChild, ordered[0], ordered[1]));
          verbClusterRule(root, ordered[0], ordered[1], leftChild, rightChild, structuralFirstSide);
          return;
        }
      }

      if ( !(root.getNode().isSelected()) )
      {
        domainTreeMethod(leftChild, languageTreeVerbClusterOrder,
                         languageTreeLayoutStrategy, freeLanguageLayout, SIDE_LEFT);
        domainTreeMethod(rightChild, languageTreeVerbClusterOrder,
                         languageTreeLayoutStrategy, freeLanguageLayout, SIDE_RIGHT);

        if ( freeLanguageLayout )
        {
          freeBinaryRule(root, leftChild, rightChild, structuralFirstSide);
        }
        else
        {
          domainRule(root, leftChild, rightChild);
        }
      }
      else
      {
        /*
         * Do not mutate the actual node label during rendering.
         * Focus still affects the binary subtree ordering, but the visual
         * label is left untouched.
         */
        domainTreeMethod(rightChild, languageTreeVerbClusterOrder,
                         languageTreeLayoutStrategy, freeLanguageLayout, SIDE_LEFT);
        domainTreeMethod(leftChild, languageTreeVerbClusterOrder,
                         languageTreeLayoutStrategy, freeLanguageLayout, SIDE_RIGHT);

        if ( freeLanguageLayout )
        {
          freeBinaryRule(root, rightChild, leftChild, structuralFirstSide);
        }
        else
        {
          domainRule(root, rightChild, leftChild);
        }
      }
      return;
    }

    /*
     * v4.25.0: n-ary nominal projections must preserve/correct lexical
     * phrase order before corridor placement.  In particular, a flat NP/DP
     * produced as kleine,de,man is an incorrect Dutch nominal projection;
     * the layout pass normalizes terminal-only nominal sequences to
     * Det + adjective(s) + noun/rest, yielding de,kleine,man.
     * Corridor choice is then only a drawing decision, not a word-order rule.
     */
    Vector layoutChildren = orderNaryChildrenForLanguageTree(root, children);

    int firstSide = firstSideFor(sidePreference);
    for ( int i=0; i<layoutChildren.size(); i++ )
    {
      int childSide = (i % 2) == 0 ? firstSide : -firstSide;
      domainTreeMethod((OpenGraphNodeEx)layoutChildren.elementAt(i), languageTreeVerbClusterOrder,
                       languageTreeLayoutStrategy, freeLanguageLayout, childSide);
    }

    if ( freeLanguageLayout && isNaryCompactLR(languageTreeLayoutStrategy) )
    {
      nAryCompactLRRule(root, layoutChildren, firstSide);
    }
    else
    {
      nAryRule(root, layoutChildren);
    }
  }

  private static int firstSideFor(int sidePreference)
  {
    return sidePreference == SIDE_RIGHT ? SIDE_RIGHT : SIDE_LEFT;
  }

  private static Vector orderNaryChildrenForLanguageTree(OpenGraphNodeEx root, Vector children)
  {
    Vector ordered = new Vector();
    if ( children == null )
    {
      return ordered;
    }
    for ( int i=0; i<children.size(); i++ )
    {
      ordered.addElement(children.elementAt(i));
    }

    if ( !isNominalProjectionNode(root) || !allTerminalNodes(ordered) )
    {
      return ordered;
    }

    for ( int i=1; i<ordered.size(); i++ )
    {
      Object value = ordered.elementAt(i);
      int valueRank = nominalTerminalRank((OpenGraphNodeEx)value);
      int j = i - 1;
      while ( j >= 0 && nominalTerminalRank((OpenGraphNodeEx)ordered.elementAt(j)) > valueRank )
      {
        ordered.setElementAt(ordered.elementAt(j), j + 1);
        j--;
      }
      ordered.setElementAt(value, j + 1);
    }
    return ordered;
  }

  private static boolean isNominalProjectionNode(OpenGraphNodeEx node)
  {
    String label = cleanLabel(node == null || node.getNode() == null ? null : node.getNode().getLabel());
    return label.equals("np") || label.equals("dp");
  }

  private static boolean allTerminalNodes(Vector nodes)
  {
    if ( nodes == null || nodes.size() == 0 )
    {
      return false;
    }
    for ( int i=0; i<nodes.size(); i++ )
    {
      if ( !isTerminalNode((OpenGraphNodeEx)nodes.elementAt(i)) )
      {
        return false;
      }
    }
    return true;
  }

  private static int nominalTerminalRank(OpenGraphNodeEx node)
  {
    String label = cleanLabel(node == null || node.getNode() == null ? null : node.getNode().getLabel());
    if ( isDutchDeterminerLabel(label) ) return 0;
    if ( isDutchAdjectiveLabel(label) ) return 1;
    return 2;
  }

  private static boolean isDutchDeterminerLabel(String label)
  {
    if ( label == null ) return false;
    String value = label.trim().toLowerCase();
    return value.equals("de") || value.equals("het") || value.equals("een") ||
           value.equals("dit") || value.equals("dat") || value.equals("deze") ||
           value.equals("die") || value.equals("mijn") || value.equals("jouw") ||
           value.equals("zijn") || value.equals("haar") || value.equals("ons") ||
           value.equals("onze") || value.equals("hun") || value.equals("geen") ||
           value.equals("elk") || value.equals("elke") || value.equals("ieder") ||
           value.equals("iedere") || value.equals("welk") || value.equals("welke");
  }

  private static boolean isDutchAdjectiveLabel(String label)
  {
    if ( label == null ) return false;
    String value = label.trim().toLowerCase();
    return value.equals("klein") || value.equals("kleine") ||
           value.equals("groot") || value.equals("grote") ||
           value.equals("oud") || value.equals("oude") ||
           value.equals("jong") || value.equals("jonge") ||
           value.equals("dik") || value.equals("dikke") ||
           value.equals("mooi") || value.equals("mooie") ||
           value.equals("nieuw") || value.equals("nieuwe") ||
           value.equals("bijzonder") || value.equals("bijzondere");
  }

  private static int childExpansionSideForOrderedBinary(OpenGraphNodeEx child,
                                                        OpenGraphNodeEx visualLeft,
                                                        OpenGraphNodeEx visualRight)
  {
    return child == visualRight ? SIDE_RIGHT : SIDE_LEFT;
  }

  private static String normalizeLanguageTreeLayoutStrategy(String value)
  {
    if ( value == null ) return LAYOUT_NARY_COMPACT_LR;
    String v = value.trim().toLowerCase();
    v = v.replace('-', '_').replace(' ', '_');
    if ( v.equals("free") || v.equals("d_lite") || v.equals("free_d_lite") )
    {
      return LAYOUT_FREE_D_LITE;
    }
    if ( v.equals("compact") || v.equals("lr") || v.equals("compact_lr") ||
         v.equals("nary_compact_lr") || v.equals("n_ary_compact_lr") ||
         v.equals("n_binair") || v.equals("n_binair_compact_lr") ||
         v.equals("nbinair") || v.equals("non_binary") || v.equals("nonbinary") )
    {
      return LAYOUT_NARY_COMPACT_LR;
    }
    return LAYOUT_NARY_COMPACT_LR;
  }

  private static boolean isNaryCompactLR(String strategy)
  {
    return LAYOUT_NARY_COMPACT_LR.equals(normalizeLanguageTreeLayoutStrategy(strategy));
  }

  private static boolean isVerbClusterNode(OpenGraphNodeEx root)
  {
    String label = cleanLabel(root == null || root.getNode() == null ? null : root.getNode().getLabel());
    return label.equals("v") || label.equals("v-cluster") || label.equals("vcluster") ||
           label.equals("werkwoordgroep") || label.equals("wwgroep");
  }

  private static OpenGraphNodeEx[] orderVerbClusterChildren(OpenGraphNodeEx a,
                                                            OpenGraphNodeEx b,
                                                            String order)
  {
    int aKind = verbClusterKind(a);
    int bKind = verbClusterKind(b);
    if ( aKind == 0 || bKind == 0 || aKind == bKind )
    {
      return null;
    }

    OpenGraphNodeEx pv = aKind == 1 ? a : b;
    OpenGraphNodeEx vd = aKind == 2 ? a : b;
    if ( isVdPvOrder(order) )
    {
      return new OpenGraphNodeEx[] { vd, pv };
    }
    return new OpenGraphNodeEx[] { pv, vd };
  }

  private static boolean isVdPvOrder(String order)
  {
    if ( order == null )
    {
      return false;
    }
    String value = order.trim().toLowerCase();
    return value.equals("vd_pv") || value.equals("vd-pv") || value.equals("gebeten heeft");
  }

  /**
   * Returns 1 for pv/finite auxiliary, 2 for VD/participle, 0 if unknown.
   * The detection first checks explicit category labels and then descends into
   * terminal labels so both V->pv/VD and V->heeft/gebeten drawings work.
   */
  private static int verbClusterKind(OpenGraphNodeEx node)
  {
    String label = cleanLabel(node == null || node.getNode() == null ? null : node.getNode().getLabel());
    if ( isFiniteVerbLabel(label) ) return 1;
    if ( isParticipleLabel(label) ) return 2;

    Vector children = node == null ? null : node.getChildren();
    if ( children == null )
    {
      return 0;
    }
    int result = 0;
    for ( int i=0; i<children.size(); i++ )
    {
      int childKind = verbClusterKind((OpenGraphNodeEx)children.elementAt(i));
      if ( childKind != 0 )
      {
        if ( result != 0 && result != childKind )
        {
          return 0;
        }
        result = childKind;
      }
    }
    return result;
  }

  private static boolean isFiniteVerbLabel(String label)
  {
    if ( label == null ) return false;
    String value = label.trim().toLowerCase();
    return value.equals("pv") || value.equals("fin") || value.equals("vfin") ||
           value.equals("v-aux") || value.equals("aux") || value.equals("heeft") ||
           value.equals("heb") || value.equals("hebt") || value.equals("hebben") ||
           value.equals("had") || value.equals("is") || value.equals("zijn") ||
           value.equals("was") || value.equals("wordt") || value.equals("werd") ||
           value.equals("zal") || value.equals("kan") || value.equals("moet") ||
           value.equals("mag") || value.equals("wil");
  }

  private static boolean isParticipleLabel(String label)
  {
    if ( label == null ) return false;
    String value = label.trim().toLowerCase();
    return value.equals("vd") || value.equals("vpart") || value.equals("v-part") ||
           value.equals("part") || value.equals("vpp") || value.equals("voltooid deelwoord") ||
           value.equals("gebeten") || value.equals("gebreid") || value.equals("gegeven") ||
           (value.startsWith("ge") && value.length() > 4 && !isFiniteVerbLabel(value));
  }

  private static String cleanLabel(String label)
  {
    if ( label == null )
    {
      return "";
    }
    return label.trim().toLowerCase();
  }

  private static void initializeLeaf(OpenGraphNodeEx root)
  {
    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(0);
    root.setBoundY(0);
    root.setBoundWidth(0);
    root.setBoundHeight(0);
  }


  /**
   * Language Tree V-cluster layout rule.
   *
   * Switching pv-VD <-> VD-pv must not change the surrounding tree anchor.
   * The ordinary binary domain rule lets the parent bounding box depend on
   * which child is on the left.  For V-clusters that made the fitted grid gain
   * one column on the left and shifted the whole tree horizontally.
   *
   * This rule keeps the same reserved box for both orders and only swaps the
   * visible child assignment.  The projection mechanism remains unchanged.
   */
  private static void verbClusterRule(OpenGraphNodeEx root,
                                      OpenGraphNodeEx visualFirst,
                                      OpenGraphNodeEx visualSecond,
                                      OpenGraphNodeEx childA,
                                      OpenGraphNodeEx childB,
                                      int firstSide)
  {
    LayoutBox boxA = LayoutBox.fromSubtree(childA);
    LayoutBox boxB = LayoutBox.fromSubtree(childB);
    int maxWidth = Math.max(childA.getBoundWidth(), childB.getBoundWidth());
    int sideCapacity = maxWidth + ROOT_SIDE_GAP + 1;

    OpenGraphNodeEx visualLeft = firstSide == SIDE_RIGHT ? visualSecond : visualFirst;
    OpenGraphNodeEx visualRight = firstSide == SIDE_RIGHT ? visualFirst : visualSecond;

    LayoutBox leftBox = visualLeft == childA ? boxA : boxB;
    LayoutBox rightBox = visualRight == childA ? boxA : boxB;
    LayoutBox topBox = firstSide == SIDE_RIGHT ? rightBox : leftBox;
    LayoutBox lowerBox = firstSide == SIDE_RIGHT ? leftBox : rightBox;

    int leftShiftX = -(sideCapacity - leftExtent(visualLeft));
    int rightShiftX = sideCapacity - rightExtent(visualRight);
    int topShiftY = 1;
    int lowerShiftY = stackedBelowShiftY(topBox, topShiftY, lowerBox, 0);
    int leftShiftY = firstSide == SIDE_RIGHT ? lowerShiftY : topShiftY;
    int rightShiftY = firstSide == SIDE_RIGHT ? topShiftY : lowerShiftY;

    visualLeft.shiftX(leftShiftX);
    visualLeft.shiftY(leftShiftY);

    visualRight.shiftX(rightShiftX);
    visualRight.shiftY(rightShiftY);

    /*
     * Keep lexical preterminals free/open as well.  In side-aware mode the
     * terminal fans out to the same outer side as its preterminal: left-side
     * preterminals to the left, right-side preterminals to the right.  This is
     * the important correction for right-growing VP/V clusters: pv -> heeft no
     * longer folds back to the left of the higher VP axis.
     */
    fanOutUnaryPreterminal(visualLeft, SIDE_LEFT);
    fanOutUnaryPreterminal(visualRight, SIDE_RIGHT);

    int minX = Math.min(0, Math.min(boxMinX(visualLeft), boxMinX(visualRight)));
    int maxX = Math.max(0, Math.max(boxMaxX(visualLeft), boxMaxX(visualRight)));
    int maxY = Math.max(0, Math.max(boxMaxY(visualLeft), boxMaxY(visualRight)));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(-minX);
    root.setBoundY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
  }

  private static void fanOutUnaryPreterminal(OpenGraphNodeEx node, int direction)
  {
    if ( node == null )
    {
      return;
    }
    Vector children = node.getChildren();
    if ( children == null || children.size() != 1 )
    {
      return;
    }

    OpenGraphNodeEx child = (OpenGraphNodeEx)children.elementAt(0);
    if ( child == null || child.getChildren().size() != 0 )
    {
      return;
    }

    forceUnaryFanOut(node, child, direction);
  }

  /**
   * D-lite Language Tree rule: unary edges are still built recursively, but the
   * returned box is now a real occupied-cell box.  A single child is not left
   * directly below its parent in free Language Tree layout.
   */
  private static void freeUnaryRule(OpenGraphNodeEx root, OpenGraphNodeEx child, int direction)
  {
    child.shiftY(1);
    forceUnaryFanOut(root, child, direction);
  }

  private static int preferredUnaryDirection(OpenGraphNodeEx root, OpenGraphNodeEx child,
                                             int sidePreference)
  {
    if ( sidePreference == SIDE_LEFT || sidePreference == SIDE_RIGHT )
    {
      return sidePreference;
    }
    return SIDE_RIGHT;
  }

  private static void forceUnaryFanOut(OpenGraphNodeEx root, OpenGraphNodeEx child, int direction)
  {
    if ( root == null || child == null )
    {
      return;
    }

    /*
     * Grid coordinates are local until correctGridCoordinates() accumulates
     * them at the end of the operation.  A unary child therefore needs a
     * local offset from its parent, not an absolute x based on the already
     * shifted parent.  The previous version used root.getGridX()+/-1, which
     * let terminals such as "heeft" escape the box seen by the parent VP.
     */
    int targetLocalX = direction < 0 ? -1 : 1;
    child.shiftX(targetLocalX - child.getGridX());
    recomputeOccupiedBox(root);
  }

  /**
   * D-lite binary combiner.  It keeps the recursive box approach, but candidate
   * offsets are now checked against occupied node cells instead of only the
   * coarse bounding box.  The current compact/stacked OpenGraph shape remains
   * the first candidate; if it is invalid, the right subtree is moved down until
   * the occupied cells and parent-child constraints are valid.
   */
  private static void freeBinaryRule(OpenGraphNodeEx root,
                                     OpenGraphNodeEx first,
                                     OpenGraphNodeEx second,
                                     int firstSide)
  {
    int normalizedFirstSide = firstSide == SIDE_RIGHT ? SIDE_RIGHT : SIDE_LEFT;
    int secondSide = -normalizedFirstSide;

    int firstShiftX = normalizedFirstSide == SIDE_LEFT
                    ? -(rightExtent(first) + ROOT_SIDE_GAP)
                    :  (leftExtent(first) + ROOT_SIDE_GAP);
    int firstShiftY = 1;

    int secondShiftX = secondSide == SIDE_LEFT
                     ? -(rightExtent(second) + ROOT_SIDE_GAP)
                     :  (leftExtent(second) + ROOT_SIDE_GAP);
    OpenGraphNodeEx visualLeft = normalizedFirstSide == SIDE_LEFT ? first : second;
    OpenGraphNodeEx visualRight = normalizedFirstSide == SIDE_LEFT ? second : first;
    int extraGap = needsExtraRootSentenceGap(root, visualLeft, visualRight) ? 1 : 0;

    LayoutBox firstBox = LayoutBox.fromSubtree(first);
    LayoutBox secondBox = LayoutBox.fromSubtree(second);
    int secondShiftY = stackedBelowShiftY(firstBox, firstShiftY, secondBox, extraGap);

    /*
     * v4.24.3 structural LR + inherited avoid-bound:
     * binary child order is not flipped by a right-side context.  The complete
     * right/second subtree box may not intrude into the zone reserved by the
     * left/first subtree box.  If needed, the already-recursed child box is
     * shifted farther outward and then downward until the position is free.
     */
    secondShiftX = enforceSiblingBoxAvoid(firstBox, secondBox,
                                          firstShiftX, secondShiftX, secondSide);

    int guard = Math.max(8, first.getSubTreeSize() + second.getSubTreeSize() + 8);
    int attempt = 0;
    while ( attempt < guard &&
            !candidateBinaryPlacementIsValid(firstBox, secondBox,
                                             firstShiftX, firstShiftY,
                                             secondShiftX, secondShiftY) )
    {
      secondShiftY++;
      attempt++;
    }

    first.shiftX(firstShiftX);
    first.shiftY(firstShiftY);

    second.shiftX(secondShiftX);
    second.shiftY(secondShiftY);

    recomputeOccupiedBox(root);
  }

  /**
   * Legacy v4.24.0 combiner.  Deliberately not used for Language Tree now:
   * it produced RR/LL cascades.  The active v4.24.2 rule keeps the requested
   * LR/RL binary combiner and only enlarges child-box shifts to obey inherited
   * exclusion boundaries.
   */
  private static void freeBinarySameSideBoxAvoidRule(OpenGraphNodeEx root,
                                                    OpenGraphNodeEx first,
                                                    OpenGraphNodeEx second,
                                                    int side)
  {
    int direction = side == SIDE_RIGHT ? SIDE_RIGHT : SIDE_LEFT;

    LayoutBox firstBox = LayoutBox.fromSubtree(first);
    LayoutBox secondBox = LayoutBox.fromSubtree(second);

    int firstShiftX = direction == SIDE_LEFT
                    ? -(rightExtent(first) + ROOT_SIDE_GAP)
                    :  (leftExtent(first) + ROOT_SIDE_GAP);
    int firstShiftY = 1;

    int secondShiftX;
    if ( direction == SIDE_RIGHT )
    {
      int requiredMinX = firstBox.maxX + firstShiftX + ROOT_SIDE_GAP + 1;
      secondShiftX = requiredMinX - secondBox.minX;
    }
    else
    {
      int requiredMaxX = firstBox.minX + firstShiftX - ROOT_SIDE_GAP - 1;
      secondShiftX = requiredMaxX - secondBox.maxX;
    }

    int extraGap = needsExtraRootSentenceGap(root, first, second) ? 1 : 0;
    int secondShiftY = stackedBelowShiftY(firstBox, firstShiftY, secondBox, extraGap);

    int guard = Math.max(16, first.getSubTreeSize() + second.getSubTreeSize() + 16);
    int attempt = 0;
    while ( attempt < guard &&
            !candidateBinaryPlacementIsValid(firstBox, secondBox,
                                             firstShiftX, firstShiftY,
                                             secondShiftX, secondShiftY) )
    {
      secondShiftY++;
      attempt++;
    }

    first.shiftX(firstShiftX);
    first.shiftY(firstShiftY);

    second.shiftX(secondShiftX);
    second.shiftY(secondShiftY);

    recomputeOccupiedBox(root);
  }

  /**
   * Returns the local Y shift for a later subtree whose full box must start
   * below the real bottom of an earlier subtree box.  This uses LayoutBox
   * geometry instead of boundHeight, because boundHeight can be stale or too
   * small after unary fan-out.
   *
   * v4.24.6: if the previous sibling box ends in a lexical/end terminal,
   * reserve one extra row.  Terminal rows are lexical positions; a following
   * category root such as V or VD must not be drawn on the same row as man or
   * heeft even when the occupied-node boxes do not technically collide.
   */
  private static int stackedBelowShiftY(LayoutBox upperBox, int upperShiftY,
                                        LayoutBox lowerBox, int extraGap)
  {
    int terminalGap = upperBox.endsInTerminal() ? 1 : 0;
    int gap = 1 + Math.max(0, extraGap) + terminalGap;
    return upperShiftY + upperBox.maxY + gap - lowerBox.minY;
  }

  private static int enforceSiblingBoxAvoid(LayoutBox firstBox, LayoutBox secondBox,
                                            int firstShiftX, int secondShiftX,
                                            int secondSide)
  {
    int minGap = ROOT_SIDE_GAP + 1;
    if ( secondSide == SIDE_RIGHT )
    {
      int requiredMinX = firstBox.maxX + firstShiftX + minGap;
      int currentMinX = secondBox.minX + secondShiftX;
      if ( currentMinX < requiredMinX )
      {
        return secondShiftX + (requiredMinX - currentMinX);
      }
      return secondShiftX;
    }

    int requiredMaxX = firstBox.minX + firstShiftX - minGap;
    int currentMaxX = secondBox.maxX + secondShiftX;
    if ( currentMaxX > requiredMaxX )
    {
      return secondShiftX - (currentMaxX - requiredMaxX);
    }
    return secondShiftX;
  }

  private static boolean candidateBinaryPlacementIsValid(LayoutBox leftBox,
                                                         LayoutBox rightBox,
                                                         int leftShiftX,
                                                         int leftShiftY,
                                                         int rightShiftX,
                                                         int rightShiftY)
  {
    if ( leftShiftX == 0 || rightShiftX == 0 )
    {
      return false;
    }
    if ( leftBox.boundsIntersectShifted(rightBox, leftShiftX, leftShiftY, rightShiftX, rightShiftY) )
    {
      return false;
    }
    if ( leftBox.intersectsShifted(rightBox, leftShiftX, leftShiftY, rightShiftX, rightShiftY) )
    {
      return false;
    }
    if ( leftBox.containsShifted(0, 0, leftShiftX, leftShiftY) ||
         rightBox.containsShifted(0, 0, rightShiftX, rightShiftY) )
    {
      return false;
    }
    return true;
  }

  private static void recomputeOccupiedBox(OpenGraphNodeEx root)
  {
    LayoutBox box = LayoutBox.fromSubtree(root);
    box.applyTo(root);
  }

  private static class LayoutBox
  {
    int minX;
    int maxX;
    int minY;
    int maxY;
    Hashtable leftContour;
    Hashtable rightContour;
    HashSet occupied;
    boolean hasTerminal;
    int terminalMaxY;

    private LayoutBox()
    {
      minX = 0;
      maxX = 0;
      minY = 0;
      maxY = 0;
      leftContour = new Hashtable();
      rightContour = new Hashtable();
      occupied = new HashSet();
      hasTerminal = false;
      terminalMaxY = 0;
    }

    static LayoutBox fromSubtree(OpenGraphNodeEx root)
    {
      LayoutBox box = new LayoutBox();
      box.collect(root, 0, 0);
      return box;
    }

    private void collect(OpenGraphNodeEx node, int parentX, int parentY)
    {
      if ( node == null )
      {
        return;
      }

      int x = parentX + node.getGridX();
      int y = parentY + node.getGridY();
      Vector children = node.getChildren();
      add(x, y, children.size() == 0);

      for ( int i=0; i<children.size(); i++ )
      {
        collect((OpenGraphNodeEx)children.elementAt(i), x, y);
      }
    }

    private void add(int x, int y, boolean terminal)
    {
      if ( occupied.size() == 0 )
      {
        minX = maxX = x;
        minY = maxY = y;
      }
      else
      {
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
      }
      occupied.add(cellKey(x, y));
      if ( terminal )
      {
        if ( !hasTerminal || y > terminalMaxY )
        {
          terminalMaxY = y;
        }
        hasTerminal = true;
      }

      Integer row = Integer.valueOf(y);
      Integer left = (Integer)leftContour.get(row);
      Integer right = (Integer)rightContour.get(row);
      if ( left == null || x < left.intValue() )
      {
        leftContour.put(row, Integer.valueOf(x));
      }
      if ( right == null || x > right.intValue() )
      {
        rightContour.put(row, Integer.valueOf(x));
      }
    }

    boolean endsInTerminal()
    {
      return hasTerminal && terminalMaxY >= maxY;
    }

    boolean containsShifted(int x, int y, int dx, int dy)
    {
      return occupied.contains(cellKey(x - dx, y - dy));
    }

    boolean intersectsShifted(LayoutBox other, int thisDx, int thisDy, int otherDx, int otherDy)
    {
      Iterator it = occupied.iterator();
      while ( it.hasNext() )
      {
        String key = (String)it.next();
        int comma = key.indexOf(',');
        int x = Integer.parseInt(key.substring(0, comma)) + thisDx;
        int y = Integer.parseInt(key.substring(comma + 1)) + thisDy;
        if ( other.containsShifted(x, y, otherDx, otherDy) )
        {
          return true;
        }
      }
      return false;
    }

    boolean boundsIntersectShifted(LayoutBox other, int thisDx, int thisDy, int otherDx, int otherDy)
    {
      int thisMinX = minX + thisDx;
      int thisMaxX = maxX + thisDx;
      int thisMinY = minY + thisDy;
      int thisMaxY = maxY + thisDy;
      int otherMinX = other.minX + otherDx;
      int otherMaxX = other.maxX + otherDx;
      int otherMinY = other.minY + otherDy;
      int otherMaxY = other.maxY + otherDy;

      boolean xOverlap = thisMinX <= otherMaxX && otherMinX <= thisMaxX;
      boolean yOverlap = thisMinY <= otherMaxY && otherMinY <= thisMaxY;
      return xOverlap && yOverlap;
    }

    void applyTo(OpenGraphNodeEx root)
    {
      root.setBoundX(root.getGridX() - minX);
      root.setBoundY(0);
      root.setBoundWidth(maxX - minX);
      root.setBoundHeight(maxY - root.getGridY());
    }

    private static String cellKey(int x, int y)
    {
      return x + "," + y;
    }
  }

  /**
   * Compact bottom-up box integration for the open tree.
   *
   * Each child first owns its smallest reserved bounding box.
   * The left subtree is placed completely left of the root axis;
   * the right subtree is placed completely right of the root axis and below
   * the reserved left box, so sibling leaves do not collapse onto one line.
   */
  static void domainRule(OpenGraphNodeEx root, OpenGraphNodeEx left, OpenGraphNodeEx right)
  {
    LayoutBox leftBox = LayoutBox.fromSubtree(left);
    LayoutBox rightBox = LayoutBox.fromSubtree(right);

    int leftShiftX = -(rightExtent(left) + ROOT_SIDE_GAP);
    int leftShiftY = 1;

    int rightShiftX = leftExtent(right) + ROOT_SIDE_GAP;
    int rightExtraGap = needsExtraRootSentenceGap(root, left, right) ? 1 : 0;
    int rightShiftY = stackedBelowShiftY(leftBox, leftShiftY, rightBox, rightExtraGap);

    left.shiftX(leftShiftX);
    left.shiftY(leftShiftY);

    right.shiftX(rightShiftX);
    right.shiftY(rightShiftY);

    int minX = Math.min(0, Math.min(boxMinX(left), boxMinX(right)));
    int maxX = Math.max(0, Math.max(boxMaxX(left), boxMaxX(right)));
    int maxY = Math.max(0, Math.max(boxMaxY(left), boxMaxY(right)));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(-minX);
    root.setBoundY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
  }

  /**
   * General open-tree rule for nodes with three or more children.
   *
   * Children are processed in deterministic structural order and stacked on
   * successive grid rows below the parent.  A small horizontal spread keeps
   * the outgoing edges visually distinguishable, while the vertical stacking
   * preserves the left lexical-axis reading order used by language trees.
   */

  /**
   * Dutch Language Tree readability tweak.
   *
   * For the classic S -> NP VP split, the VP category should not land on the
   * same visual row as the deepest terminal inside the subject NP box.
   * A one-row extra gap below the left NP box keeps the VP category visually
   * separate and more intuitive without affecting other binary trees.
   */
  private static boolean needsExtraRootSentenceGap(OpenGraphNodeEx root,
                                                   OpenGraphNodeEx left,
                                                   OpenGraphNodeEx right)
  {
    if ( root == null || left == null || right == null )
    {
      return false;
    }
    return isLabel(root, "s") &&
           ((isLabel(left, "np") && isLabel(right, "vp")) ||
            (isLabel(left, "dp") && isLabel(right, "vp")));
  }

  private static boolean isLabel(OpenGraphNodeEx node, String expected)
  {
    if ( expected == null )
    {
      return false;
    }
    return cleanLabel(node == null || node.getNode() == null ? null : node.getNode().getLabel()).equals(expected);
  }

  /**
   * n-binair compact-LR Language Tree combiner.
   *
   * This rule handles true n-ary nodes: 3, 4, 5, ... children are not first
   * converted to an artificial binary chain.  Each already-computed child box
   * is placed directly around the parent in source order, with inherited
   * LR/RL side-awareness.  Candidate placement is checked against the full
   * accumulated subtree boxes, so unary descendants inside n-ary children are
   * also part of the collision/avoid model.
   */
  private static void nAryCompactLRRule(OpenGraphNodeEx root, Vector children, int firstSide)
  {
    if ( children == null || children.size() == 0 )
    {
      initializeLeaf(root);
      return;
    }

    Vector placed = new Vector();
    ShiftedLayoutBox previous = null;
    int count = children.size();
    int guard = Math.max(16, root.getSubTreeSize() + 16);
    int leftSideOrdinal = 0;
    int rightSideOrdinal = 0;

    for ( int i=0; i<count; i++ )
    {
      OpenGraphNodeEx child = (OpenGraphNodeEx)children.elementAt(i);
      LayoutBox childBox = LayoutBox.fromSubtree(child);
      int childSide = (i % 2) == 0 ? firstSide : -firstSide;
      boolean placeLeft = childSide == SIDE_LEFT;

      /*
       * v4.24.8: terminals in n-ary fan-out have a lexical-position status.
       * Alternating LR alone put child 0 and child 2 on the same outer column
       * (for example de/hond or kleine/man).  That makes the lower lexical
       * child share the previous terminal corridor.  Keep the vertical source
       * order, but widen each repeated side by one column, so same-side
       * terminal/frontier boxes are distinct: L1, R1, L2, R2, ... .
       */
      int sameSideOrdinal;
      if ( placeLeft )
      {
        sameSideOrdinal = leftSideOrdinal++;
      }
      else
      {
        sameSideOrdinal = rightSideOrdinal++;
      }
      /*
       * v4.24.9: the first terminal corridors must also be diagonally free
       * from the n-ary parent.  With only one grid column between NP and a
       * lexical child, edges such as NP-de and NP-grote are visually/vertically
       * unfree.  Terminals therefore start one column farther out, while
       * repeated same-side children still get their own L2/R2/... corridors.
       */
      int terminalDiagonalGap = isTerminalNode(child) ? 1 : 0;
      int sameSideExtraGap = sameSideOrdinal + terminalDiagonalGap;

      int childShiftX = placeLeft ? (-ROOT_SIDE_GAP - sameSideExtraGap - childBox.maxX)
                                  : ( ROOT_SIDE_GAP + sameSideExtraGap - childBox.minX);

      /*
       * v4.24.7: n-ary children are stacked in source order with one
       * accumulated vertical frontier.  The previous implementation kept
       * separate left/right frontiers; with terminal children this allowed
       * child 0 and child 1, for example test and de, to share the same row.
       * Lexical terminals are real occupied rows in Language Tree layout,
       * so each later n-ary child must be placed below the full previous
       * subtree box, including terminal-aware bottom spacing.
       */
      int childShiftY = previous == null
                      ? 1 - childBox.minY
                      : stackedBelowShiftY(previous.box, previous.shiftY, childBox, 0);

      int attempt = 0;
      while ( attempt < guard &&
              !candidateNAryPlacementIsValid(childBox, childShiftX, childShiftY, placed) )
      {
        childShiftY++;
        attempt++;
      }

      child.shiftX(childShiftX);
      child.shiftY(childShiftY);

      previous = new ShiftedLayoutBox(childBox, childShiftX, childShiftY);
      placed.addElement(previous);
    }

    recomputeOccupiedBox(root);
  }

  private static boolean isTerminalNode(OpenGraphNodeEx node)
  {
    Vector children = node == null ? null : node.getChildren();
    return children == null || children.size() == 0;
  }

  private static boolean candidateNAryPlacementIsValid(LayoutBox childBox,
                                                       int childShiftX,
                                                       int childShiftY,
                                                       Vector placed)
  {
    if ( childShiftX == 0 )
    {
      return false;
    }
    if ( childBox.containsShifted(0, 0, childShiftX, childShiftY) )
    {
      return false;
    }

    for ( int i=0; i<placed.size(); i++ )
    {
      ShiftedLayoutBox other = (ShiftedLayoutBox)placed.elementAt(i);
      if ( other.box.boundsIntersectShifted(childBox, other.shiftX, other.shiftY,
                                            childShiftX, childShiftY) )
      {
        return false;
      }
      if ( other.box.intersectsShifted(childBox, other.shiftX, other.shiftY,
                                       childShiftX, childShiftY) )
      {
        return false;
      }
    }

    return true;
  }

  private static class ShiftedLayoutBox
  {
    LayoutBox box;
    int shiftX;
    int shiftY;

    ShiftedLayoutBox(LayoutBox box, int shiftX, int shiftY)
    {
      this.box = box;
      this.shiftX = shiftX;
      this.shiftY = shiftY;
    }
  }

  private static void nAryRule(OpenGraphNodeEx root, Vector children)
  {
    int currentY = 1;
    int minX = 0;
    int maxX = 0;
    int maxY = 0;
    int count = children == null ? 0 : children.size();
    int horizontalStep = ROOT_SIDE_GAP + 1;

    for ( int i=0; i<count; i++ )
    {
      OpenGraphNodeEx child = (OpenGraphNodeEx)children.elementAt(i);
      LayoutBox childBox = LayoutBox.fromSubtree(child);
      int childShiftX = ((2 * i) - (count - 1)) * horizontalStep;
      child.shiftX(childShiftX);
      child.shiftY(currentY);

      minX = Math.min(minX, boxMinX(child));
      maxX = Math.max(maxX, boxMaxX(child));
      maxY = Math.max(maxY, boxMaxY(child));

      currentY = currentY + childBox.maxY + 1;
    }

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
    root.setBoundX(-minX);
    root.setBoundY(0);
  }

  /**
   * Dutch Language Tree layout convention.
   *
   * The first branching under the DS root is drawn one grid row longer.  This
   * reserves a normal grid row on the lexical axis for FIN/V2 between slot1
   * and the first real DS child row.  It replaces the earlier half-row FIN
   * placement and keeps surface-order positions visually independent of DS
   * node levels.
   */
  private static void lengthenFirstRootBranch(OpenGraphNodeEx root)
  {
    if ( root == null )
    {
      return;
    }

    Vector children = root.getChildren();
    if ( children == null || children.size() == 0 )
    {
      return;
    }

    for ( int i=0; i<children.size(); i++ )
    {
      shiftSubtreeY((OpenGraphNodeEx)children.elementAt(i), 1);
    }
    root.setBoundHeight(root.getBoundHeight() + 1);
  }

  private static void shiftSubtreeX(OpenGraphNodeEx node, int shiftX)
  {
    if ( node == null )
    {
      return;
    }

    node.shiftX(shiftX);
    Vector children = node.getChildren();
    for ( int i=0; i<children.size(); i++ )
    {
      shiftSubtreeX((OpenGraphNodeEx)children.elementAt(i), shiftX);
    }
  }

  private static void shiftSubtreeY(OpenGraphNodeEx node, int shiftY)
  {
    if ( node == null )
    {
      return;
    }

    node.shiftY(shiftY);
    Vector children = node.getChildren();
    for ( int i=0; i<children.size(); i++ )
    {
      shiftSubtreeY((OpenGraphNodeEx)children.elementAt(i), shiftY);
    }
  }

  private static void otherRule(OpenGraphNodeEx root, OpenGraphNodeEx child)
  {
    child.shiftY(1);

    int minX = Math.min(0, boxMinX(child));
    int maxX = Math.max(0, boxMaxX(child));
    int maxY = Math.max(0, boxMaxY(child));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
    root.setBoundX(-minX);
    root.setBoundY(0);
  }

  private static int leftExtent(OpenGraphNodeEx node)
  {
    return node.getBoundX();
  }

  private static int rightExtent(OpenGraphNodeEx node)
  {
    return node.getBoundWidth() - node.getBoundX();
  }

  private static int boxMinX(OpenGraphNodeEx node)
  {
    return node.getGridX() - node.getBoundX();
  }

  private static int boxMaxX(OpenGraphNodeEx node)
  {
    return node.getGridX() + node.getBoundWidth() - node.getBoundX();
  }

  private static int boxMaxY(OpenGraphNodeEx node)
  {
    return node.getGridY() + node.getBoundHeight();
  }

  private static void correctGridCoordinates(OpenGraphNodeEx root, int shiftX, int shiftY)
  {
    root.shiftX(shiftX);
    root.shiftY(shiftY);

    Vector children = root.getChildren();
    for ( int i=0; i<children.size(); i++ )
    {
      correctGridCoordinates((OpenGraphNodeEx)children.elementAt(i),
                             root.getGridX(), root.getGridY());
    }
  }
}
