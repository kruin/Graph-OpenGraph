package graphStructure.mementos;

import graphStructure.Edge;
import graphStructure.Graph;
import graphStructure.Node;
import java.util.Vector;

/**
 * Undo/redo support for Greedy Grow visibility steps.
 *
 * <p>The static Greedy graph is already fully laid out.  Grow only changes
 * visibility.  This memento stores the node/edge visibility snapshot before a
 * grow step and swaps it with the current snapshot on apply, following the
 * standard JGraphEd reversible memento pattern.</p>
 */
public class GreedyGrowVisibilityMemento implements MementoInterface
{
  private final Graph target;
  private boolean[] nodeVisibility;
  private boolean[] edgeVisibility;

  private GreedyGrowVisibilityMemento(Graph target)
  {
    this.target = target;
    capture(target);
  }

  public static GreedyGrowVisibilityMemento createVisibilityMemento(Graph target)
  {
    return new GreedyGrowVisibilityMemento(target);
  }

  private void capture(Graph graph)
  {
    Vector nodes = graph.getNodes();
    Vector edges = graph.getEdges();

    nodeVisibility = new boolean[nodes.size()];
    for ( int i=0; i<nodes.size(); i++ )
    {
      nodeVisibility[i] = ((Node)nodes.elementAt(i)).getIsVisible();
    }

    edgeVisibility = new boolean[edges.size()];
    for ( int i=0; i<edges.size(); i++ )
    {
      edgeVisibility[i] = ((Edge)edges.elementAt(i)).getIsVisible();
    }
  }

  public void apply(Graph graph)
  {
    Vector nodes = target.getNodes();
    Vector edges = target.getEdges();

    boolean[] currentNodes = new boolean[nodes.size()];
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      currentNodes[i] = node.getIsVisible();
      if ( i < nodeVisibility.length )
      {
        node.setIsVisible(nodeVisibility[i]);
      }
    }

    boolean[] currentEdges = new boolean[edges.size()];
    for ( int i=0; i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      currentEdges[i] = edge.getIsVisible();
      if ( i < edgeVisibility.length )
      {
        edge.setIsVisible(edgeVisibility[i]);
      }
    }

    nodeVisibility = currentNodes;
    edgeVisibility = currentEdges;
    target.markForRepaint();
  }

  public String toString()
  {
    return "GreedyGrowVisibility: " + target;
  }

  public boolean isUseless()
  {
    return false;
  }
}
