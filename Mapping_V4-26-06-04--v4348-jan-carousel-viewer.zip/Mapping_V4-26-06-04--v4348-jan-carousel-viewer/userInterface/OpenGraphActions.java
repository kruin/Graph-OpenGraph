package userInterface;

import javax.swing.*;
import java.awt.Desktop;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.*;
import java.util.*;
import graphStructure.*;
import graphException.*;
import operation.*;
import userInterface.menuAndToolBar.*;
import userInterface.fileUtils.*;

public class OpenGraphActions
{
  public static final int GREEDY_IMPORT_ACTION_CANCEL = 0;
  public static final int GREEDY_IMPORT_ACTION_IMPORT = 1;
  public static final int GREEDY_IMPORT_ACTION_PREVIEW = 2;
  public static final int GREEDY_IMPORT_ACTION_REPORT = 3;
  public static final int GREEDY_IMPORT_ACTION_SPEC = 4;
  public static final int GREEDY_IMPORT_ACTION_FOLDER = 5;

  private static final int DEFAULT_VISIBLE_PADDING_CELLS = 2;
  private final GraphWindow graphWindow;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;
  private final OpenTreeStructureSupport opnSupport;
  private final MenuAndToolBar menuAndToolBar;

  public OpenGraphActions(GraphWindow graphWindow,
                           GraphWindowCoordinator graphWindowCoordinator,
                           GraphEditorActions graphEditorActions,
                           OpenTreeStructureSupport opnSupport,
                           MenuAndToolBar menuAndToolBar)
  {
    this.graphWindow = graphWindow;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphEditorActions = graphEditorActions;
    this.opnSupport = opnSupport;
    this.menuAndToolBar = menuAndToolBar;
  }

  public void refreshOPNMenuVisibility(GraphEditorWindow activeWindow)
  {
    if ( menuAndToolBar == null )
    {
      return;
    }

    menuAndToolBar.showSaveOPN();
    menuAndToolBar.setSaveOPNEnabled(activeWindow != null);
  }

  public void toggleLexicalProjection(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      return;
    }

    GraphEditor editor = activeWindow.getGraphEditor();
    OpenGraphProjectionSettings projectionSettings = editor.getOpenGraphProjectionSettings();
    boolean currentlyVisible = editor.isOpenGraphProjectionContextActive() &&
                               projectionSettings.isLexicalProjectionActive();
    boolean enable = !currentlyVisible;

    if ( enable )
    {
      if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) ||
           (!projectionSettings.getLeftProjectionEnabled() &&
            !projectionSettings.getRightProjectionEnabled() &&
            !projectionSettings.getTopProjectionEnabled() &&
            !projectionSettings.getBottomProjectionEnabled()) )
      {
        projectionSettings = editor.getRememberedLanguageProjectionSettings();
      }

      if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
      {
        projectionSettings.setStructureType(OpenGraphDialog.STRUCTURE_FRAME);
      }
      projectionSettings.setShowProjections(true);
      if ( !projectionSettings.getLeftProjectionEnabled() &&
           !projectionSettings.getRightProjectionEnabled() &&
           !projectionSettings.getTopProjectionEnabled() &&
           !projectionSettings.getBottomProjectionEnabled() )
      {
        projectionSettings.setLeftProjectionEnabled(true);
        projectionSettings.setRightProjectionEnabled(true);
        projectionSettings.setTopProjectionEnabled(true);
        projectionSettings.setBottomProjectionEnabled(true);
      }
    }
    else
    {
      projectionSettings.setShowProjections(false);
    }

    editor.setOpenGraphProjectionSettings(projectionSettings);
    if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
    {
      editor.rememberLanguageProjectionSettings(projectionSettings);
    }

    if ( !editor.isOpenGraphProjectionContextActive() )
    {
      editor.resetTransientEditorArtifacts();
      editor.update();
      return;
    }

    OpenGraphGridSettings gridSettings = editor.getOpenGraphGridSettings();
    if ( enable &&
         gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
    {
      gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
      editor.setOpenGraphGridSettings(gridSettings);
    }

    if ( editor.isInGridMode() )
    {
      // Do not refit or recalculate the OpenGraph grid window on a visibility
      // toggle. The project specification keeps the structure grid fixed while
      // projections are rendered in extra margin/render space. Reapplying the
      // fit-content grid here made Toggle ON appear to move the source graph
      // left by about two grid lines in FRAME examples.
    }
    editor.resetTransientEditorArtifacts();
    editor.update();
  }
  private void ensureProjectionContentVisible(GraphEditor graphEditor, OpenGraphGridSettings gridSettings)
  {
    centerVisibleContentInWindow(graphEditor);
  }

  private void centerVisibleContentInWindow(GraphEditor graphEditor)
  {
    if ( graphEditor == null )
    {
      return;
    }

    Graph graph = graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graphEditor.isInGridMode() )
    {
      return;
    }

    OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
    int cellWidth = Math.max(2, gridSettings.getCellWidth());
    int cellHeight = Math.max(2, gridSettings.getCellHeight());
    int drawWidth = Math.max(cellWidth * 2, graphEditor.getVisibleDrawWidth());
    int drawHeight = Math.max(cellHeight * 2, graphEditor.getVisibleDrawHeight());
    int paddingX = DEFAULT_VISIBLE_PADDING_CELLS * cellWidth;
    int paddingY = DEFAULT_VISIBLE_PADDING_CELLS * cellHeight;

    Rectangle2D.Double visibleBounds = graphEditor.getVisibleContentBounds();
    double visibleWidth = visibleBounds.getWidth();
    double visibleHeight = visibleBounds.getHeight();

    double desiredMinX;
    if ( visibleWidth + (2 * paddingX) <= drawWidth )
    {
      desiredMinX = (drawWidth - visibleWidth) / 2.0;
    }
    else
    {
      desiredMinX = paddingX;
    }

    double desiredMinY;
    if ( visibleHeight + (2 * paddingY) <= drawHeight )
    {
      desiredMinY = (drawHeight - visibleHeight) / 2.0;
    }
    else
    {
      desiredMinY = paddingY;
    }

    int dx = snapToGrid((int)Math.round(desiredMinX - visibleBounds.getMinX()), cellWidth);
    int dy = snapToGrid((int)Math.round(desiredMinY - visibleBounds.getMinY()), cellHeight);

    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    graphEditor.changeToOpenGraphGridMode(gridSettings);
  }

  private int snapToGrid(int value, int step)
  {
    if ( step <= 1 )
    {
      return value;
    }
    return (int)Math.round((double)value / (double)step) * step;
  }


  public void applyLanguageTreeZinstype(GraphEditorWindow editorWindow, String zinstype)
  {
    if ( editorWindow == null )
    {
      return;
    }

    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    settings.setShowProjections(true);
    settings.setLanguageTreeZinstype(zinstype);
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) )
    {
      settings.setLanguageTreeTopicPreview(buildLanguageTreeTopicPreview(graphEditor.getGraph()));
    }
    else
    {
      settings.setLanguageTreeTopicPreview("");
    }

    boolean preserveRootAnchor = isCurrentOpenGraphDraw(graphEditor);
    redrawOpenGraphFromSettings(editorWindow, settings, false, preserveRootAnchor);
  }

  public void applyLanguageTreeVerbClusterOrder(GraphEditorWindow editorWindow, String order)
  {
    if ( editorWindow == null )
    {
      return;
    }

    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    settings.setShowProjections(true);
    settings.setLanguageTreeVerbClusterOrder(order);
    boolean preserveRootAnchor = isCurrentOpenGraphDraw(graphEditor);
    redrawOpenGraphFromSettings(editorWindow, settings, false, preserveRootAnchor);
  }

  private boolean isCurrentOpenGraphDraw(GraphEditor graphEditor)
  {
    if ( graphEditor == null || graphEditor.getGraph() == null )
    {
      return false;
    }
    try
    {
      return graphEditor.getGraph().peekUndo() != null &&
             "Display OpenGraph Drawing".equals(graphEditor.getGraph().peekUndo().getTitle());
    }
    catch ( Exception ignored )
    {
      return false;
    }
  }

  public void restoreOriginalOpenGraphTree(GraphEditorWindow editorWindow)
  {
    try
    {
      if ( editorWindow == null || editorWindow.getGraphEditor() == null )
      {
        throw new GraphException("Origineel vereist een actief graph-venster.");
      }

      GraphEditor graphEditor = editorWindow.getGraphEditor();

      /*
       * v4.29.0: Tree = origineel is the current editor tree, not the
       * saved file on disk.  If the current view is an OpenGraph Draw result,
       * undo only that Draw memento.  Unsaved editor changes made before Draw
       * remain visible.  The normal Undo/Back command remains available for
       * deeper history navigation.
       */
      if ( isCurrentOpenGraphDraw(graphEditor) )
      {
        graphEditor.undo();
      }

      clearOPNState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }

      graphEditor.setOpenGraphProjectionContextActive(false);
      graphEditor.resetTransientEditorArtifacts();
      if ( graphEditor.isInGridMode() )
      {
        graphEditor.changeToEditMode();
      }
      graphEditor.update();
      editorWindow.updateOpenGraphHeaderControls();
      graphEditorActions.updateUndo(editorWindow);
    }
    catch ( Exception e )
    {
      reportOpenGraphDisplayError(e);
      JOptionPane.showMessageDialog(graphWindow, errorMessage(e),
                                    "Origineel", JOptionPane.ERROR_MESSAGE);
      if ( editorWindow != null )
      {
        editorWindow.updateOpenGraphHeaderControls();
      }
    }
  }

  public void applyOpenGraphStructureType(GraphEditorWindow editorWindow, int structureType)
  {
    if ( editorWindow == null )
    {
      return;
    }
    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }

    if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
         structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
         structureType != OpenGraphDialog.STRUCTURE_ANAPHOR_TREE &&
         structureType != OpenGraphDialog.STRUCTURE_FRAME &&
         structureType != OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      structureType = OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    settings.setStructureType(structureType);
    applyStructureTypeDefaults(settings, structureType);
    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(true);
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.resetTransientEditorArtifacts();
    graphEditor.update();
    editorWindow.updateOpenGraphHeaderControls();
  }

  public void drawSelectedOpenGraphStructure(GraphEditorWindow editorWindow)
  {
    if ( editorWindow == null )
    {
      return;
    }
    GraphEditor graphEditor = editorWindow.getGraphEditor();
    if ( graphEditor == null )
    {
      return;
    }
    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    applyStructureTypeDefaults(settings, settings.getStructureType());

    /*
     * v4.28.1: FRAME draw must not recenter after every Draw.
     * The frame profile uses left/right/top projection lanes; repeated Draw +
     * fit/center made the structure appear to jump.  Keep the root anchor fixed
     * for FRAME, also on the first draw from the source graph.
     */
    boolean preserveRootAnchor = settings.getStructureType() == OpenGraphDialog.STRUCTURE_FRAME ||
                                 isCurrentOpenGraphDraw(graphEditor);
    redrawOpenGraphFromSettings(editorWindow, settings, false, preserveRootAnchor);
  }

  private void applyStructureTypeDefaults(OpenGraphProjectionSettings settings, int structureType)
  {
    if ( settings == null )
    {
      return;
    }

    OpenGraphProjectionSupport.applyBestAvailableProfileForStructureType(settings, structureType);
    if ( structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      settings.setLanguageTreeTopicPreview("");
    }
  }

  private void redrawOpenGraphFromSettings(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings)
  {
    redrawOpenGraphFromSettings(editorWindow, projectionSettings, false);
  }

  private void redrawOpenGraphFromSettings(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings, boolean reloadOriginalGraph)
  {
    redrawOpenGraphFromSettings(editorWindow, projectionSettings, reloadOriginalGraph, false);
  }

  private void redrawOpenGraphFromSettings(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings, boolean reloadOriginalGraph, boolean preserveRootAnchor)
  {
    if ( editorWindow == null || projectionSettings == null )
    {
      return;
    }

    boolean mementoStarted = false;
    boolean anchorKnown = false;
    int anchorRootIndex = -1;
    int anchorX = 0;
    int anchorY = 0;
    if ( preserveRootAnchor )
    {
      try
      {
        GraphEditor anchorEditor = editorWindow.getGraphEditor();
        Graph anchorGraph = anchorEditor == null ? null : anchorEditor.getGraph();
        if ( anchorGraph != null && anchorGraph.getNumNodes() > 0 )
        {
          anchorRootIndex = OpenGraphRootSelector.getRootIndex(editorWindow);
          if ( anchorRootIndex >= 0 && anchorRootIndex < anchorGraph.getNumNodes() )
          {
            Node anchorRoot = anchorGraph.getNodeAt(anchorRootIndex);
            if ( anchorRoot != null && anchorRoot.getLocation() != null )
            {
              anchorX = anchorRoot.getLocation().intX();
              anchorY = anchorRoot.getLocation().intY();
              anchorKnown = true;
            }
          }
        }
      }
      catch ( Exception ignored )
      {
        anchorKnown = false;
      }
    }

    try
    {
      GraphEditor graphEditor = editorWindow.getGraphEditor();
      if ( reloadOriginalGraph )
      {
        reloadOriginalGraphForOpenGraphDraw(editorWindow, projectionSettings);
        graphEditor = editorWindow.getGraphEditor();
      }

      clearOPNState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }

      Graph graph = graphEditor.getGraph();
      if ( graph == null || graph.getNumNodes() == 0 )
      {
        throw new GraphException("OpenGraph Draw requires an open graph with at least one node.");
      }

      int structureType = projectionSettings.getStructureType();
      if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_ANAPHOR_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_FRAME &&
         structureType != OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
      {
        throw new GraphException("Only Simple, Language Tree / Phrase, Functional Tree, Anafoor, and Frame are implemented reliably at the moment.");
      }

      int rootIndex = OpenGraphRootSelector.getRootIndex(editorWindow);
      graph.newMemento("Display OpenGraph Drawing");
      mementoStarted = true;

      graphEditor.setOpenGraphProjectionSettings(projectionSettings);
      boolean projectionContext =
        OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType());
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);

      OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
      if ( projectionContext &&
           gridSettings.getGridMode() == OpenGraphGridSettings.MODE_FIT_CONTENT &&
           gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
      {
        gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
        graphEditor.setOpenGraphGridSettings(gridSettings);
      }

      OpenGraphTreeDrawOperation.displayOpenGraphTreeDrawing(
        graph,
        graph.getNodeAt(rootIndex),
        1,
        2,
        2,
        gridSettings.getCellWidth(),
        gridSettings.getCellHeight(),
        graphEditor.getDrawWidth(),
        graphEditor.getDrawHeight(),
        structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
        structureType == OpenGraphDialog.STRUCTURE_FRAME ||
        structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ||
        structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE,
        false,
        projectionSettings.getLanguageTreeVerbClusterOrder(),
        projectionSettings.getLanguageTreeLayoutStrategy() );

      graphEditor.changeToOpenGraphGridMode(gridSettings);
      if ( preserveRootAnchor && anchorKnown )
      {
        preserveOpenGraphRootAnchor(graphEditor, anchorRootIndex, anchorX, anchorY, gridSettings);
      }
      else
      {
        centerVisibleContentInWindow(graphEditor);
      }
      if ( projectionContext )
      {
        graphEditor.rememberLanguageProjectionSettings(projectionSettings);
      }
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);
      graphEditor.resetTransientEditorArtifacts();
      graphEditor.update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graph.doneMemento();
      graphEditorActions.updateUndo(editorWindow);
      opnSupport.rememberResult(editorWindow, graph);
      refreshOPNMenuVisibility(editorWindow);
      editorWindow.updateOpenGraphHeaderControls();
    }
    catch ( Exception e )
    {
      reportOpenGraphDisplayError(e);

      Graph graph = null;
      try
      {
        graph = editorWindow.getGraphEditor().getGraph();
        if ( graph != null && mementoStarted )
        {
          graph.undoMemento();
          graph.abortMemento();
        }
      }
      catch ( Exception ignored )
      {
      }

      JOptionPane.showMessageDialog(graphWindow, errorMessage(e),
                                    "Error During OpenGraph Drawing Display", JOptionPane.ERROR_MESSAGE);
      if ( editorWindow != null )
      {
        editorWindow.updateOpenGraphHeaderControls();
      }
    }
  }

  private void preserveOpenGraphRootAnchor(GraphEditor graphEditor, int rootIndex, int anchorX, int anchorY, OpenGraphGridSettings gridSettings)
  {
    if ( graphEditor == null )
    {
      return;
    }
    Graph graph = graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || rootIndex < 0 || rootIndex >= graph.getNumNodes() )
    {
      return;
    }
    Node root = graph.getNodeAt(rootIndex);
    if ( root == null || root.getLocation() == null )
    {
      return;
    }

    int dx = anchorX - root.getLocation().intX();
    int dy = anchorY - root.getLocation().intY();
    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    if ( gridSettings != null )
    {
      graphEditor.changeToOpenGraphGridMode(gridSettings);
    }
  }

  private void reloadOriginalGraphForOpenGraphDraw(GraphEditorWindow editorWindow, OpenGraphProjectionSettings projectionSettings) throws Exception
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null )
    {
      throw new GraphException("OpenGraph Draw requires an active graph editor window.");
    }

    Graph currentGraph = editorWindow.getGraphEditor().getGraph();
    String path = currentGraph == null ? "" : currentGraph.getFilePath();
    if ( path == null || path.trim().length() == 0 )
    {
      throw new GraphException("Deze zinstype-/OpenGraph-draw moet uitgaan van de oorspronkelijke .graph. Er is geen .graph-pad bekend. Open eerst een opgeslagen .graph-bestand.");
    }

    File sourceFile = new File(path);
    if ( !sourceFile.exists() || !sourceFile.isFile() )
    {
      throw new GraphException("De oorspronkelijke .graph ontbreekt. Verwacht bestand:\n" + sourceFile.getPath());
    }

    String extension = Utils.getExtension(sourceFile);
    if ( extension == null || !extension.equalsIgnoreCase(Utils.graph) )
    {
      throw new GraphException("Deze zinstype-/OpenGraph-draw gebruikt voorlopig alleen de oorspronkelijke .graph als bron. Huidig bronbestand is geen .graph:\n" + sourceFile.getPath());
    }

    BufferedReader reader = new BufferedReader(new FileReader(sourceFile));
    Graph originalGraph = null;
    try
    {
      originalGraph = Graph.loadFrom(reader);
    }
    finally
    {
      reader.close();
    }

    originalGraph.setFilePath(sourceFile.getCanonicalPath());
    applyGraphFileLanguageTreeHint(originalGraph, sourceFile);

    GraphEditor graphEditor = editorWindow.getGraphEditor();
    graphEditor.setGraph(originalGraph);
    graphEditor.setOpenGraphProjectionSettings(projectionSettings);
    graphEditor.setOpenGraphProjectionContextActive(OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()));
  }

  private void applyGraphFileLanguageTreeHint(Graph graph, File selectedFile)
  {
    if ( graph == null )
    {
      return;
    }

    String label = graph.getLabel();
    String fileName = selectedFile == null ? "" : selectedFile.getName();
    String combined = ((label == null ? "" : label) + " " + fileName).toUpperCase();

    if ( combined.indexOf("LANGUAGE_TREE") >= 0 ||
         combined.indexOf("LANGUAGE TREE") >= 0 ||
         combined.indexOf("LEXTEST") >= 0 )
    {
      graph.setOPNLanguageTreePreferred(true);
      graph.setOPNLanguageTreeTypeSummary("Language Tree graph");
    }
  }


  private String buildLanguageTreeTopicPreview(Graph graph)
  {
    if ( graph == null )
    {
      return "";
    }
    Vector selectedNodes = graph.selectedNodes();
    if ( selectedNodes == null || selectedNodes.size() == 0 )
    {
      return "";
    }
    if ( selectedNodes.size() > 1 )
    {
      return "meerdere selectie";
    }

    Node selected = (Node)selectedNodes.elementAt(0);
    String category = cleanLabel(selected == null ? "" : selected.getLabel());
    if ( selected == null || category.length() == 0 )
    {
      return "";
    }
    if ( !isLikelyCategoryLabel(category) )
    {
      return "selecteer categoriale knoop";
    }

    Vector terminals = collectLanguageTreeTerminalNodes(selected);
    Collections.sort(terminals, new Comparator()
    {
      public int compare(Object a, Object b)
      {
        Node n1 = (Node)a;
        Node n2 = (Node)b;
        int y1 = n1.getLocation().intY();
        int y2 = n2.getLocation().intY();
        if ( y1 != y2 ) return y1 - y2;
        return n1.getLocation().intX() - n2.getLocation().intX();
      }
    });

    StringBuffer lexical = new StringBuffer();
    for ( int i=0; i<terminals.size(); i++ )
    {
      Node terminal = (Node)terminals.elementAt(i);
      String label = cleanLabel(terminal.getLabel());
      if ( label.length() == 0 || isLikelyCategoryLabel(label) )
      {
        continue;
      }
      if ( lexical.length() > 0 ) lexical.append(' ');
      lexical.append(label);
    }

    if ( lexical.length() > 0 && isLikelyCategoryLabel(category) )
    {
      return category + "(" + lexical.toString() + ")";
    }
    if ( lexical.length() > 0 && !category.equals(lexical.toString()) )
    {
      return category + "(" + lexical.toString() + ")";
    }
    return category;
  }

  private Vector collectLanguageTreeTerminalNodes(Node start)
  {
    Vector result = new Vector();
    Vector visited = new Vector();
    collectLanguageTreeTerminalNodes(start, null, result, visited);
    return result;
  }

  private void collectLanguageTreeTerminalNodes(Node node, Node parent, Vector result, Vector visited)
  {
    if ( node == null || visited.contains(node) )
    {
      return;
    }
    visited.addElement(node);

    Vector children = childNodesBelow(node, parent);
    if ( children.size() == 0 )
    {
      result.addElement(node);
      return;
    }

    for ( int i=0; i<children.size(); i++ )
    {
      collectLanguageTreeTerminalNodes((Node)children.elementAt(i), node, result, visited);
    }
  }

  private Vector childNodesBelow(Node node, Node parent)
  {
    Vector children = new Vector();
    Vector edges = node.incidentEdges();
    for ( int i=0; i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      Node other = null;
      if ( edge.getStartNode() == node )
      {
        other = (Node)edge.getEndNode();
      }
      else if ( edge.getEndNode() == node )
      {
        other = (Node)edge.getStartNode();
      }
      if ( other == null || other == parent )
      {
        continue;
      }
      if ( other.getLocation().intY() > node.getLocation().intY() )
      {
        children.addElement(other);
      }
    }
    return children;
  }

  private String cleanLabel(String label)
  {
    return label == null ? "" : label.trim();
  }

  private boolean isLikelyCategoryLabel(String label)
  {
    if ( label == null ) return false;
    String v = label.trim();
    if ( v.length() == 0 ) return false;
    if ( v.equals("S") || v.equals("CP") || v.equals("VP") || v.equals("DP") ||
         v.equals("NP") || v.equals("PP") || v.equals("AP") || v.equals("V") ||
         v.equals("N") || v.equals("A") || v.equals("P") || v.equals("Det") ||
         v.equals("Comp") || v.equals("PV") || v.equals("VD") )
    {
      return true;
    }
    return v.toUpperCase().equals(v) && v.length() <= 6;
  }

  public void clearOPNState(GraphEditorWindow activeWindow)
  {
    opnSupport.clear();
    refreshOPNMenuVisibility(activeWindow);
  }

  public void saveOPN(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Save OPN requires an open graph or OPN window.",
                                    "Save OPN",
                                    JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    try
    {
      Graph currentGraph = activeWindow.getGraphEditor().getGraph();
      if ( opnSupport.isSaveAvailableFor(activeWindow) )
      {
        opnSupport.saveResult(graphWindow, currentGraph);
        clearOPNState(activeWindow);
      }
      else
      {
        opnSupport.saveCurrentGraph(graphWindow, currentGraph);
      }
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                    "Error During Save OPN", JOptionPane.ERROR_MESSAGE);
    }
  }

  public void displayOpenGraphTree(final GraphController controller,
                               final GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      clearOPNState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }
      OpenGraphDialog dialog = new OpenGraphDialog( controller,
        editorWindow,
        "OpenGraph Draw",
        "<html>Select structure type, then Draw.</html>" )
      {
        public void actionPerformed(ActionEvent e)
        {
          displayOpenGraphTreeHelper(getOwner(), this);
        }
      };
      dialog.preloadFromEditor(editorWindow.getGraphEditor());
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
    }
  }

  private void displayOpenGraphTreeHelper(GraphEditorWindow editorWindow, OpenGraphDialog dialog)
  {
    try
    {
      GraphEditor graphEditor = editorWindow.getGraphEditor();
      Graph graph = graphEditor.getGraph();
      int rootIndex = OpenGraphRootSelector.getRootIndex(editorWindow);
      int anchorX = 0;
      int anchorY = 0;
      boolean anchorKnown = false;
      try
      {
        Node anchorRoot = graph.getNodeAt(rootIndex);
        if ( anchorRoot != null && anchorRoot.getLocation() != null )
        {
          anchorX = anchorRoot.getLocation().intX();
          anchorY = anchorRoot.getLocation().intY();
          anchorKnown = true;
        }
      }
      catch ( Exception ignored )
      {
        anchorKnown = false;
      }
      graph.newMemento("Display OpenGraph Drawing");

      int structureType = dialog.getStructureType();
      if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_ANAPHOR_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_FRAME &&
         structureType != OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
      {
        throw new GraphException("Only Simple, Language Tree / Phrase, Functional Tree, Anafoor, and Frame are implemented reliably at the moment.");
      }

      OpenGraphProjectionSettings projectionSettings = OpenGraphProjectionSupport.fromDialog(dialog);
      graphEditor.setOpenGraphProjectionSettings(projectionSettings);
      boolean projectionContext =
        OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType());
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);

      OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
      if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) &&
           gridSettings.getGridMode() == OpenGraphGridSettings.MODE_FIT_CONTENT &&
           gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
      {
        gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
        graphEditor.setOpenGraphGridSettings(gridSettings);
      }
      OpenGraphTreeDrawOperation.displayOpenGraphTreeDrawing(
        graph,
        graph.getNodeAt(rootIndex),
        dialog.getSelectedMethodNumber(),
        dialog.getStructureOffsetFromLeft(),
        dialog.getStructureOffsetFromTop(),
        gridSettings.getCellWidth(),
        gridSettings.getCellHeight(),
        graphEditor.getDrawWidth(),
        graphEditor.getDrawHeight(),
        structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
        structureType == OpenGraphDialog.STRUCTURE_FRAME ||
        structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ||
        structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE,
        false,
        projectionSettings.getLanguageTreeVerbClusterOrder(),
        projectionSettings.getLanguageTreeLayoutStrategy() );
      graphEditor.changeToOpenGraphGridMode(gridSettings);
      if ( structureType == OpenGraphDialog.STRUCTURE_FRAME && anchorKnown )
      {
        preserveOpenGraphRootAnchor(graphEditor, rootIndex, anchorX, anchorY, gridSettings);
      }
      else
      {
        centerVisibleContentInWindow(graphEditor);
      }
      if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
      {
        graphEditor.rememberLanguageProjectionSettings(projectionSettings);
      }
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);
      graphEditor.resetTransientEditorArtifacts();
      graphEditor.update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.closeDialogAndClearOwner(editorWindow);
      graph.doneMemento();
      graphEditorActions.updateUndo(editorWindow);
      opnSupport.rememberResult(editorWindow, graph);
      refreshOPNMenuVisibility(editorWindow);
    }
    catch ( Exception e )
    {
      reportOpenGraphDisplayError(e);

      try
      {
        Graph graph = editorWindow.getGraphEditor().getGraph();
        if ( graph != null )
        {
          graph.undoMemento();
          graph.abortMemento();
        }
      }
      catch ( Exception ignored )
      {
      }

      JOptionPane.showMessageDialog(graphWindow, errorMessage(e),
                                    "Error During OpenGraph Drawing Display", JOptionPane.ERROR_MESSAGE);
    }
  }

  public boolean configureGreedyGenerator(boolean allowGenerate)
  {
    // Legacy compatibility for old menu methods. The normal v4322 route is
    // showGreedySettingsAndMaybeGenerateGraph(...), which does not write YAML.
    Graph graph = showGreedySettingsAndMaybeGenerateGraph(null);
    return graph != null && allowGenerate;
  }

  public Graph showGreedySettingsAndMaybeGenerateGraph(Graph contextGraph)
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    if ( dir == null || !dir.exists() || !dir.isDirectory() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Graph Generator directory could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath(),
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    File spec = new File(dir, "spec.yaml");
    String embeddedSpec = contextGraph != null ? contextGraph.getGreedySettingsSpecText() : "";
    GreedyGeneratorSettingsDialog dialog = new GreedyGeneratorSettingsDialog(graphWindow, spec, embeddedSpec);
    int result = dialog.showDialog();
    if ( result == GreedyGeneratorSettingsDialog.RESULT_CANCEL ) return null;

    if ( result == GreedyGeneratorSettingsDialog.RESULT_GENERATE )
    {
      return generateInternalGreedyPreviewGraphFromSpecText(dialog.getSpecText());
    }

    return null;
  }

  public void launchGreedyGenerator()
  {
    File script = getGreedyGeneratorStartScript();
    File dir = script == null ? null : script.getParentFile();

    if ( script == null || !script.exists() || dir == null || !dir.exists() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Graph Generator could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath() +
                                    File.separator + "start_gui.bat\n\n" +
                                    "Check whether the tools/greedy_generator_gui directory is present in this OpenGraphEd package.",
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return;
    }

    try
    {
      ProcessBuilder builder;
      if ( isWindows() )
      {
        builder = new ProcessBuilder("cmd.exe", "/c", "start", "Greedy Graph Generator", "start_gui.bat");
      }
      else
      {
        builder = new ProcessBuilder("python3", "greedy_generator_gui.py");
      }
      builder.directory(dir);
      builder.start();

      JOptionPane.showMessageDialog(graphWindow,
                                    "Greedy Graph Generator started.\n\n" +
                                    "After generation, use Greedy > Open Greedy OPN or File > Open OPN to load the generated .opn result.",
                                    "Greedy Generator",
                                    JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to start the Greedy Graph Generator.\n\n" +
                                    "Path: " + script.getPath() + "\n" +
                                    "Reason: " + errorMessage(e),
                                    "Unable to Start Greedy Generator",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  public File getGreedyGeneratorDefaultOutputDirectory()
  {
    return new File(getGreedyGeneratorDefaultDirectory(), "output");
  }

  public void openGreedyOutputFolder()
  {
    openGreedyFileOrDirectory(getGreedyGeneratorDefaultOutputDirectory(),
                              "Greedy Output Folder",
                              "The Greedy output folder does not exist yet. Generate output first.");
  }

  public void openGreedyPreviewPNG()
  {
    File file = findLatestFileWithExtension(getGreedyGeneratorDefaultOutputDirectory(), ".png");
    openGreedyFileOrDirectory(file,
                              "Greedy Preview PNG",
                              "No Greedy PNG preview was found. Generate output with PNG enabled first.");
  }

  public void openGreedyReport()
  {
    File file = findLatestFileWithExtension(getGreedyGeneratorDefaultOutputDirectory(), "_report.txt");
    openGreedyFileOrDirectory(file,
                              "Greedy Report",
                              "No Greedy report was found. Generate output with report enabled first.");
  }

  public void openGreedyEffectiveSpec()
  {
    File file = findLatestFileWithExtension(getGreedyGeneratorDefaultOutputDirectory(), "_effective_spec.yaml");
    openGreedyFileOrDirectory(file,
                              "Greedy Effective Spec",
                              "No Greedy effective spec was found. Generate output with effective spec enabled first.");
  }

  public void openGreedyManualPDF()
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    File nl = new File(dir, "GREEDY_GENERATOR_UITLEG_NL.pdf");
    File en = new File(dir, "GREEDY_GENERATOR_EXPLANATION_EN.pdf");

    File chosen = nl.exists() ? nl : en;
    if ( en.exists() )
    {
      int choice = JOptionPane.showOptionDialog(graphWindow,
        "Open which Greedy Generator manual?",
        "Greedy Manual",
        JOptionPane.DEFAULT_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        new Object[] { "Nederlands", "English", "Cancel" },
        "Nederlands");
      if ( choice == 1 ) chosen = en;
      else if ( choice == 2 || choice == JOptionPane.CLOSED_OPTION ) return;
      else chosen = nl;
    }

    openGreedyFileOrDirectory(chosen,
                              "Greedy Manual",
                              "The Greedy Generator PDF manual was not found in tools/greedy_generator_gui.");
  }


  public int showGreedyImportWorkflow(File opnFile)
  {
    if ( opnFile == null || !opnFile.exists() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "No Greedy OPN file is available for import.",
                                    "Greedy Import Workflow",
                                    JOptionPane.WARNING_MESSAGE);
      return GREEDY_IMPORT_ACTION_CANCEL;
    }

    File outputDir = getGreedyGeneratorDefaultOutputDirectory();
    File png = findLatestFileWithExtension(outputDir, ".png");
    File report = findLatestFileWithExtension(outputDir, "_report.txt");
    File spec = findLatestFileWithExtension(outputDir, "_effective_spec.yaml");

    StringBuffer message = new StringBuffer();
    message.append("Greedy generation finished.\n\n");
    message.append("Generated OPN:\n").append(opnFile.getPath()).append("\n\n");
    message.append("This workflow keeps the generated result visible before importing it into OpenGraphEd.\n");
    message.append("You can inspect the preview or report first, or import the OPN now.\n\n");
    message.append("Preview PNG: ").append(png != null && png.exists() ? png.getName() : "not found").append("\n");
    message.append("Report: ").append(report != null && report.exists() ? report.getName() : "not found").append("\n");
    message.append("Effective spec: ").append(spec != null && spec.exists() ? spec.getName() : "not found");

    Object[] options = new Object[] {
      "Import OPN",
      "Preview PNG",
      "Report",
      "Effective Spec",
      "Output Folder",
      "Cancel"
    };

    int choice = JOptionPane.showOptionDialog(graphWindow,
      message.toString(),
      "Greedy Result Import Workflow",
      JOptionPane.DEFAULT_OPTION,
      JOptionPane.QUESTION_MESSAGE,
      null,
      options,
      options[0]);

    if ( choice == 0 ) return GREEDY_IMPORT_ACTION_IMPORT;
    if ( choice == 1 ) return GREEDY_IMPORT_ACTION_PREVIEW;
    if ( choice == 2 ) return GREEDY_IMPORT_ACTION_REPORT;
    if ( choice == 3 ) return GREEDY_IMPORT_ACTION_SPEC;
    if ( choice == 4 ) return GREEDY_IMPORT_ACTION_FOLDER;
    return GREEDY_IMPORT_ACTION_CANCEL;
  }


  public File generateInternalGreedyGeneratorDefaultOPN()
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    if ( dir == null || !dir.exists() || !dir.isDirectory() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Generator directory could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath(),
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    try
    {
      File opnFile = GreedyInternalGenerator.generateFromDefaultSpec(dir);
      if ( opnFile == null || !opnFile.exists() )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "The internal Java Greedy engine finished but no .opn file was found.\n\n" +
                                      "Output directory:\n" + getGreedyGeneratorDefaultOutputDirectory().getPath(),
                                      "No Internal Greedy OPN Found",
                                      JOptionPane.ERROR_MESSAGE);
        return null;
      }
      return opnFile;
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to generate an internal Greedy OPN.\n\n" +
                                    "Reason: " + errorMessage(e),
                                    "Unable to Generate Internal Greedy OPN",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
  }


  public Graph generateInternalGreedyPreviewGraph()
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    if ( dir == null || !dir.exists() || !dir.isDirectory() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Generator directory could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath(),
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    try
    {
      return GreedyInternalGenerator.generatePreviewGraphFromDefaultSpec(dir);
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to generate a Greedy graph preview.\n\n" +
                                    "Reason: " + errorMessage(e),
                                    "Unable to Generate Greedy Graph",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
  }

  public Graph generateInternalGreedyPreviewGraphFromSpecText(String specText)
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    if ( dir == null || !dir.exists() || !dir.isDirectory() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Generator directory could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath(),
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    try
    {
      return GreedyInternalGenerator.generatePreviewGraphFromSpecText(specText, dir);
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to generate a Greedy graph preview from the current settings.\n\n" +
                                    "Reason: " + errorMessage(e),
                                    "Unable to Generate Greedy Graph",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
  }


  public File exportGreedyGrowJSON(String specText)
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    if ( dir == null || !dir.exists() || !dir.isDirectory() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Generator directory could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath(),
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    try
    {
      File jsonFile;
      if ( specText != null && specText.trim().length() > 0 )
      {
        jsonFile = GreedyInternalGenerator.exportGrowDemoJsonFromSpecText(specText, dir);
      }
      else
      {
        jsonFile = GreedyInternalGenerator.exportGrowDemoJsonFromDefaultSpec(dir);
      }

      JOptionPane.showMessageDialog(graphWindow,
                                    "Greedy Grow JSON export created.\n\n" +
                                    "File:\n" + jsonFile.getPath() + "\n\n" +
                                    "Use this file as input for the mobile/PWA demo viewer.",
                                    "Greedy Grow JSON Export",
                                    JOptionPane.INFORMATION_MESSAGE);
      return jsonFile;
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to export a Greedy Grow JSON demo.\n\n" +
                                    "Reason: " + errorMessage(e),
                                    "Unable to Export Greedy Grow JSON",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
  }


  public File generateGreedyGeneratorDefaultOPN()
  {
    File dir = getGreedyGeneratorDefaultDirectory();
    File script = getGreedyGeneratorHeadlessScript();

    if ( dir == null || !dir.exists() || !dir.isDirectory() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled Greedy Graph Generator directory could not be found.\n\n" +
                                    "Expected location:\n" + getGreedyGeneratorDefaultDirectory().getPath(),
                                    "Greedy Generator Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    if ( isWindows() && (script == null || !script.exists()) )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The bundled headless Greedy Generator script could not be found.\n\n" +
                                    "Expected location:\n" + script.getPath(),
                                    "Greedy Generator Script Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }

    try
    {
      ProcessBuilder builder;
      if ( isWindows() )
      {
        builder = new ProcessBuilder("cmd.exe", "/c", "generate_default_opn.bat");
      }
      else
      {
        builder = new ProcessBuilder("python3", "greedy_generator_gui.py", "--generate", "--force-opn", "spec.yaml");
      }
      builder.directory(dir);
      builder.redirectErrorStream(true);

      Process process = builder.start();
      String output = readProcessOutput(process.getInputStream());
      int exitCode = process.waitFor();

      if ( exitCode != 0 )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "The Greedy Generator did not finish successfully.\n\n" +
                                      "Exit code: " + exitCode + "\n\n" +
                                      trimForDialog(output),
                                      "Greedy Generation Failed",
                                      JOptionPane.ERROR_MESSAGE);
        return null;
      }

      File opnFile = readLastGeneratedOPNFile();
      if ( opnFile == null || !opnFile.exists() )
      {
        opnFile = findLatestOPNFile(getGreedyGeneratorDefaultOutputDirectory());
      }

      if ( opnFile == null || !opnFile.exists() )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Greedy generation finished, but no .opn file was found.\n\n" +
                                      "Output directory:\n" + getGreedyGeneratorDefaultOutputDirectory().getPath() + "\n\n" +
                                      trimForDialog(output),
                                      "No Greedy OPN Found",
                                      JOptionPane.ERROR_MESSAGE);
        return null;
      }

      return opnFile;
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to generate and load a Greedy OPN.\n\n" +
                                    "Reason: " + errorMessage(e),
                                    "Unable to Generate Greedy OPN",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
  }


  private File getGreedyGeneratorHeadlessScript()
  {
    return new File(getGreedyGeneratorDefaultDirectory(), "generate_default_opn.bat");
  }

  private void openGreedyFileOrDirectory(File file, String title, String missingMessage)
  {
    if ( file == null || !file.exists() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    missingMessage,
                                    title,
                                    JOptionPane.WARNING_MESSAGE);
      return;
    }

    if ( !Desktop.isDesktopSupported() )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Desktop open is not supported on this system.\n\nPath:\n" + file.getPath(),
                                    title,
                                    JOptionPane.INFORMATION_MESSAGE);
      return;
    }

    try
    {
      Desktop.getDesktop().open(file);
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Unable to open:\n" + file.getPath() + "\n\nReason: " + errorMessage(e),
                                    title,
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private File findLatestFileWithExtension(File dir, String suffix)
  {
    if ( dir == null || !dir.exists() || !dir.isDirectory() ) return null;
    File[] files = dir.listFiles();
    if ( files == null ) return null;

    String wanted = suffix == null ? "" : suffix.toLowerCase();
    File latest = null;
    long latestTime = Long.MIN_VALUE;
    for ( int i=0; i<files.length; i++ )
    {
      File file = files[i];
      if ( file == null || !file.isFile() ) continue;
      String name = file.getName();
      if ( name == null || !name.toLowerCase().endsWith(wanted) ) continue;
      long modified = file.lastModified();
      if ( latest == null || modified > latestTime )
      {
        latest = file;
        latestTime = modified;
      }
    }
    return latest;
  }

  private File readLastGeneratedOPNFile()
  {
    File info = new File(getGreedyGeneratorDefaultOutputDirectory(), "last_generated.txt");
    if ( !info.exists() || !info.isFile() ) return null;

    BufferedReader reader = null;
    try
    {
      reader = new BufferedReader(new FileReader(info));
      String line;
      while ( (line = reader.readLine()) != null )
      {
        if ( line.startsWith("opn=") )
        {
          String path = line.substring(4).trim();
          if ( path.length() > 0 ) return new File(path);
        }
      }
    }
    catch ( IOException ignored )
    {
    }
    finally
    {
      try { if ( reader != null ) reader.close(); } catch ( IOException ignored ) {}
    }
    return null;
  }

  private File findLatestOPNFile(File dir)
  {
    if ( dir == null || !dir.exists() || !dir.isDirectory() ) return null;
    File[] files = dir.listFiles();
    if ( files == null ) return null;

    File latest = null;
    long latestTime = Long.MIN_VALUE;
    for ( int i=0; i<files.length; i++ )
    {
      File file = files[i];
      if ( file == null || !file.isFile() ) continue;
      String name = file.getName();
      if ( name == null || !name.toLowerCase().endsWith(".opn") ) continue;
      long modified = file.lastModified();
      if ( latest == null || modified > latestTime )
      {
        latest = file;
        latestTime = modified;
      }
    }
    return latest;
  }

  private String readProcessOutput(InputStream input) throws IOException
  {
    StringBuffer buffer = new StringBuffer();
    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
    String line;
    while ( (line = reader.readLine()) != null )
    {
      buffer.append(line).append('\n');
    }
    return buffer.toString();
  }

  private String trimForDialog(String text)
  {
    if ( text == null ) return "";
    String value = text.trim();
    if ( value.length() <= 1200 ) return value;
    return value.substring(0, 1200) + "\n...";
  }

  private File getGreedyGeneratorStartScript()
  {
    return new File(getGreedyGeneratorDefaultDirectory(), "start_gui.bat");
  }

  private File getGreedyGeneratorDefaultDirectory()
  {
    return new File(System.getProperty("user.dir"),
                    "tools" + File.separator + "greedy_generator_gui");
  }

  private boolean isWindows()
  {
    String os = System.getProperty("os.name");
    return os != null && os.toLowerCase().indexOf("win") >= 0;
  }

  private void reportOpenGraphDisplayError(Exception e)
  {
    System.err.println("[OpenGraph] Error During OpenGraph Drawing Display: " + errorMessage(e));
    if ( e != null )
    {
      e.printStackTrace(System.err);
    }
  }

  private String errorMessage(Exception e)
  {
    if ( e == null )
    {
      return "Unknown OpenGraph error";
    }
    if ( e.getMessage() != null && e.getMessage().length() > 0 )
    {
      return e.getMessage();
    }
    return e.getClass().getName();
  }
}
