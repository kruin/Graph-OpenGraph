package userInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class GreedyGeneratorSettingsDialog extends JDialog
{
  public static final int RESULT_CANCEL = 0;
  public static final int RESULT_SAVE = 1;
  public static final int RESULT_GENERATE = 2;

  private final File specFile;
  private int result = RESULT_CANCEL;
  private String uiLang = "nl";

  private JTabbedPane tabs;
  // v4322: Generate is display-only; YAML is no longer written before generation.
  private JButton generateButton;
  private JButton cancelButton;

  private Hashtable labels = new Hashtable();
  private Hashtable notes = new Hashtable();
  private Hashtable buttons = new Hashtable();
  private Vector rows = new Vector();

  private JTextField projectNameField;
  private JTextField projectTitleField;
  private JTextField baseNameField;
  private JTextField outputDirField;
  private JSpinner countSpinner;
  private JSpinner maxSpinner;
  private JCheckBox noLimitBox;
  private JSpinner stepXSpinner;
  private JSpinner stepYSpinner;
  private JSpinner gridHeightSpinner;
  private JSpinner gridWidthSpinner;
  private JSpinner marginSpinner;
  private JSpinner majorSpinner;
  private JCheckBox fitContentBox;
  private JCheckBox showGridBox;
  private JCheckBox showEditorGridBox;
  private JCheckBox showAxesBox;
  private JComboBox styleCombo;
  private JComboBox ruleCombo;
  private JComboBox diagonalCombo;
  private JSpinner angleSpinner;
  private JComboBox languageCombo;
  private JComboBox namingCombo;
  private JCheckBox graphBox;
  private JCheckBox opnBox;
  private JCheckBox svgBox;
  private JCheckBox pngBox;
  private JCheckBox reportBox;
  private JCheckBox effectiveSpecBox;
  private JSpinner growIntervalSpinner;
  private JSpinner growStartStepSpinner;
  private JCheckBox growAutoStartBox;
  private JComboBox growRevealEdgesCombo;
  private JCheckBox growStopAtEndBox;
  private JCheckBox growLoopBox;
  private JTextArea helpArea;

  public GreedyGeneratorSettingsDialog(Component owner, File specFile)
  {
    this(owner, specFile, null);
  }

  public GreedyGeneratorSettingsDialog(Component owner, File specFile, String initialSpecText)
  {
    super(JOptionPane.getFrameForComponent(owner), "Greedy Generator", true);
    this.specFile = specFile;
    GreedySpecValues values = readValues(initialSpecText);
    uiLang = cleanLanguage(values.language);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    buildUI();
    applyValues(values);
    updateLanguageTexts();
    pack();
    setMinimumSize(new Dimension(660, 590));
    setLocationRelativeTo(owner);
  }

  public int showDialog()
  {
    setVisible(true);
    return result;
  }

  private void buildUI()
  {
    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    setContentPane(root);

    tabs = new JTabbedPane();
    tabs.addTab("", createBasisPanel());
    tabs.addTab("", createGridPanel());
    tabs.addTab("", createGreedyPanel());
    tabs.addTab("", createGrowPanel());
    tabs.addTab("", createOutputPanel());
    tabs.addTab("", createHelpPanel());
    root.add(tabs, BorderLayout.CENTER);

    JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    generateButton = new JButton();
    cancelButton = new JButton();

    generateButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { generateAndClose(); }
    });
    cancelButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { result = RESULT_CANCEL; dispose(); }
    });

    footer.add(generateButton);
    footer.add(cancelButton);
    root.add(footer, BorderLayout.SOUTH);
  }

  private JPanel createBasisPanel()
  {
    JPanel p = formPanel();
    projectNameField = new JTextField(24);
    projectTitleField = new JTextField(24);
    baseNameField = new JTextField(24);
    countSpinner = spinner(31, 1, 10000, 1);
    maxSpinner = spinner(20, 0, 10000, 1);
    noLimitBox = new JCheckBox();
    languageCombo = new JComboBox(new String[] { "nl", "en" });
    languageCombo.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        uiLang = cleanLanguage(String.valueOf(languageCombo.getSelectedItem()));
        updateLanguageTexts();
      }
    });

    addRow(p, 0, "projectName", projectNameField);
    addRow(p, 1, "projectTitle", projectTitleField);
    addRow(p, 2, "baseName", baseNameField);
    addRow(p, 3, "count", countSpinner);
    addRow(p, 4, "max", maxSpinner);
    addRow(p, 5, "noLimit", noLimitBox);
    addRow(p, 6, "language", languageCombo);
    addNote(p, 7, "basisNote");
    return p;
  }

  private JPanel createGridPanel()
  {
    JPanel p = formPanel();
    stepXSpinner = spinner(20, 1, 500, 1);
    stepYSpinner = spinner(20, 1, 500, 1);
    gridHeightSpinner = spinner(0, 0, 2000, 1);
    gridWidthSpinner = spinner(0, 0, 2000, 1);
    marginSpinner = spinner(2, 0, 100, 1);
    majorSpinner = spinner(5, 1, 50, 1);
    fitContentBox = new JCheckBox();
    showGridBox = new JCheckBox();
    showEditorGridBox = new JCheckBox();
    showAxesBox = new JCheckBox();

    addRow(p, 0, "stepX", stepXSpinner);
    addRow(p, 1, "stepY", stepYSpinner);
    addRow(p, 2, "gridHeight", gridHeightSpinner);
    addRow(p, 3, "gridWidth", gridWidthSpinner);
    addRow(p, 4, "fitContent", fitContentBox);
    addRow(p, 5, "margin", marginSpinner);
    addRow(p, 6, "majorEvery", majorSpinner);
    addRow(p, 7, "showEditorGrid", showEditorGridBox);
    addRow(p, 8, "showGrid", showGridBox);
    addRow(p, 9, "showAxes", showAxesBox);
    addNote(p, 10, "gridNote");
    return p;
  }

  private JPanel createGreedyPanel()
  {
    JPanel p = formPanel();
    styleCombo = new JComboBox(new String[] { "near0", "maxturn", "quadrant", "ring" });
    ruleCombo = new JComboBox(new String[] { "none", "extension", "collinear", "angle" });
    diagonalCombo = new JComboBox(new String[] { "none", "slash", "backslash", "both" });
    angleSpinner = spinner(30, 0, 89, 1);

    addRow(p, 0, "style", styleCombo);
    addRow(p, 1, "rule", ruleCombo);
    addRow(p, 2, "diagonalFree", diagonalCombo);
    addRow(p, 3, "angleMin", angleSpinner);
    addNote(p, 4, "greedyNote");
    return p;
  }

  private JPanel createGrowPanel()
  {
    JPanel p = formPanel();
    growIntervalSpinner = spinner(700, 100, 10000, 100);
    growStartStepSpinner = spinner(0, 0, 10000, 1);
    growAutoStartBox = new JCheckBox();
    growRevealEdgesCombo = new JComboBox(new String[] { "when_both_nodes_visible" });
    growStopAtEndBox = new JCheckBox();
    growLoopBox = new JCheckBox();

    addRow(p, 0, "growInterval", growIntervalSpinner);
    addRow(p, 1, "growStartStep", growStartStepSpinner);
    addRow(p, 2, "growAutoStart", growAutoStartBox);
    addRow(p, 3, "growRevealEdges", growRevealEdgesCombo);
    addRow(p, 4, "growStopAtEnd", growStopAtEndBox);
    addRow(p, 5, "growLoop", growLoopBox);
    addNote(p, 6, "growNote");
    return p;
  }

  private JPanel createOutputPanel()
  {
    JPanel p = formPanel();
    outputDirField = new JTextField(24);
    JButton browse = new JButton("...");
    browse.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { chooseOutputDirectory(); }
    });
    JPanel outDirPanel = new JPanel(new BorderLayout(4, 0));
    outDirPanel.add(outputDirField, BorderLayout.CENTER);
    outDirPanel.add(browse, BorderLayout.EAST);

    namingCombo = new JComboBox(new String[] { "short", "full" });
    graphBox = new JCheckBox(".graph", true);
    opnBox = new JCheckBox(".opn", true);
    svgBox = new JCheckBox(".svg", true);
    pngBox = new JCheckBox(".png", true);
    reportBox = new JCheckBox();
    effectiveSpecBox = new JCheckBox();

    JPanel formats = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    formats.add(graphBox);
    formats.add(opnBox);
    formats.add(svgBox);
    formats.add(pngBox);

    addRow(p, 0, "outputDir", outDirPanel);
    addRow(p, 1, "naming", namingCombo);
    addRow(p, 2, "formats", formats);
    addRow(p, 3, "report", reportBox);
    addRow(p, 4, "effectiveSpec", effectiveSpecBox);
    addNote(p, 5, "outputNote");
    return p;
  }

  private JPanel createHelpPanel()
  {
    JPanel p = new JPanel(new BorderLayout());
    helpArea = new JTextArea();
    helpArea.setEditable(false);
    helpArea.setLineWrap(true);
    helpArea.setWrapStyleWord(true);
    helpArea.setFont(UIManager.getFont("Label.font"));
    p.add(new JScrollPane(helpArea), BorderLayout.CENTER);
    return p;
  }

  private JPanel formPanel()
  {
    JPanel p = new JPanel(new GridBagLayout());
    p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    return p;
  }

  private JSpinner spinner(int value, int min, int max, int step)
  {
    return new JSpinner(new SpinnerNumberModel(value, min, max, step));
  }

  private void addRow(JPanel p, int row, String key, JComponent comp)
  {
    JLabel label = new JLabel();
    labels.put(key, label);

    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = row;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(4, 4, 4, 8);
    p.add(label, c);

    c = new GridBagConstraints();
    c.gridx = 1;
    c.gridy = row;
    c.weightx = 1.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(4, 4, 4, 4);
    p.add(comp, c);
  }

  private void addNote(JPanel p, int row, String key)
  {
    JTextArea area = new JTextArea();
    area.setEditable(false);
    area.setOpaque(false);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setFont(UIManager.getFont("Label.font"));
    notes.put(key, area);

    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 2;
    c.weightx = 1.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(12, 4, 4, 4);
    p.add(area, c);
  }

  private void updateLanguageTexts()
  {
    setTitle(t("dialogTitle"));
    tabs.setTitleAt(0, t("tabBasis"));
    tabs.setTitleAt(1, t("tabGrid"));
    tabs.setTitleAt(2, t("tabGreedy"));
    tabs.setTitleAt(3, t("tabGrow"));
    tabs.setTitleAt(4, t("tabOutput"));
    tabs.setTitleAt(5, t("tabHelp"));

    generateButton.setText(t("generate"));
    cancelButton.setText(t("cancel"));

    String[] labelKeys = {
      "projectName", "projectTitle", "baseName", "count", "max", "noLimit", "language",
      "stepX", "stepY", "gridHeight", "gridWidth", "fitContent", "margin", "majorEvery", "showEditorGrid", "showGrid", "showAxes",
      "style", "rule", "diagonalFree", "angleMin", "growInterval", "growStartStep", "growAutoStart", "growRevealEdges", "growStopAtEnd", "growLoop", "outputDir", "naming",
      "formats", "report", "effectiveSpec"
    };
    for ( int i=0; i<labelKeys.length; i++ )
    {
      JLabel label = (JLabel)labels.get(labelKeys[i]);
      if ( label != null ) label.setText(t(labelKeys[i]));
    }

    noLimitBox.setText(t("noLimitBox"));
    fitContentBox.setText(t("fitContentBox"));
    showEditorGridBox.setText(t("showEditorGridBox"));
    showGridBox.setText(t("showGridBox"));
    showAxesBox.setText(t("showAxesBox"));
    growAutoStartBox.setText(t("growAutoStartBox"));
    growStopAtEndBox.setText(t("growStopAtEndBox"));
    growLoopBox.setText(t("growLoopBox"));
    reportBox.setText(t("reportBox"));
    effectiveSpecBox.setText(t("effectiveSpecBox"));

    String[] noteKeys = { "basisNote", "gridNote", "greedyNote", "growNote", "outputNote" };
    for ( int i=0; i<noteKeys.length; i++ )
    {
      JTextArea area = (JTextArea)notes.get(noteKeys[i]);
      if ( area != null ) area.setText(t(noteKeys[i]));
    }
    helpArea.setText(t("helpText"));
    helpArea.setCaretPosition(0);
  }

  private String t(String key)
  {
    boolean en = "en".equals(uiLang);

    if ( "dialogTitle".equals(key) ) return "Greedy Generator";
    if ( "tabBasis".equals(key) ) return en ? "Basic" : "Basis";
    if ( "tabGrid".equals(key) ) return "Grid";
    if ( "tabGreedy".equals(key) ) return "Greedy";
    if ( "tabGrow".equals(key) ) return "Grow";
    if ( "tabOutput".equals(key) ) return en ? "Save/Export" : "Opslaan/Export";
    if ( "tabHelp".equals(key) ) return en ? "Explanation" : "Uitleg";
    if ( "generate".equals(key) ) return en ? "Generate" : "Genereren";
    if ( "cancel".equals(key) ) return en ? "Cancel" : "Annuleren";

    if ( "projectName".equals(key) ) return en ? "Project name" : "Projectnaam";
    if ( "projectTitle".equals(key) ) return en ? "Title" : "Titel";
    if ( "baseName".equals(key) ) return en ? "Document base name" : "Documentbasisnaam";
    if ( "count".equals(key) ) return "COUNT";
    if ( "max".equals(key) ) return "MAX";
    if ( "noLimit".equals(key) ) return "NO_LIMIT";
    if ( "language".equals(key) ) return en ? "Language" : "Taal";
    if ( "stepX".equals(key) ) return en ? "Grid step X" : "Gridstap X";
    if ( "stepY".equals(key) ) return en ? "Grid step Y" : "Gridstap Y";
    if ( "gridHeight".equals(key) ) return en ? "Grid height rows" : "Gridhoogte rijen";
    if ( "gridWidth".equals(key) ) return en ? "Grid width columns" : "Gridbreedte kolommen";
    if ( "fitContent".equals(key) ) return en ? "Fit content" : "Fit content";
    if ( "margin".equals(key) ) return en ? "Margin" : "Marge";
    if ( "majorEvery".equals(key) ) return en ? "Major grid every" : "Hoofdlijn elke";
    if ( "showEditorGrid".equals(key) ) return en ? "Editor grid" : "Editorgrid";
    if ( "showGrid".equals(key) ) return en ? "Export grid" : "Exportgrid";
    if ( "showAxes".equals(key) ) return en ? "Axes" : "Assen";
    if ( "style".equals(key) ) return "STYLE";
    if ( "rule".equals(key) ) return "RULE";
    if ( "diagonalFree".equals(key) ) return "DIAGONAL_FREE";
    if ( "angleMin".equals(key) ) return "ANGLE_MIN";
    if ( "growInterval".equals(key) ) return en ? "Interval ms" : "Interval ms";
    if ( "growStartStep".equals(key) ) return en ? "Start step" : "Startstap";
    if ( "growAutoStart".equals(key) ) return en ? "Auto start" : "Auto-start";
    if ( "growRevealEdges".equals(key) ) return en ? "Reveal edges" : "Edges tonen";
    if ( "growStopAtEnd".equals(key) ) return en ? "Stop at end" : "Stop aan einde";
    if ( "growLoop".equals(key) ) return "Loop";
    if ( "outputDir".equals(key) ) return en ? "Package/export folder" : "Pakket-/exportmap";
    if ( "naming".equals(key) ) return en ? "Naming" : "Naamgeving";
    if ( "formats".equals(key) ) return en ? "Package formats" : "Pakketformaten";
    if ( "report".equals(key) ) return en ? "Report" : "Rapport";
    if ( "effectiveSpec".equals(key) ) return en ? "Effective spec" : "Effective spec";

    if ( "noLimitBox".equals(key) ) return en ? "No artificial 30-node cap; use config COUNT/MAX" : "Geen kunstmatige 30-grens; gebruik config COUNT/MAX";
    if ( "fitContentBox".equals(key) ) return en ? "Fit grid to generated content" : "Grid passend rond inhoud";
    if ( "showEditorGridBox".equals(key) ) return en ? "Show grid in editor" : "Toon grid in editor";
    if ( "showGridBox".equals(key) ) return en ? "Show grid in SVG/PNG" : "Toon grid in SVG/PNG";
    if ( "showAxesBox".equals(key) ) return en ? "Show axes through node 0" : "Toon assen door knoop 0";
    if ( "reportBox".equals(key) ) return en ? "write report" : "schrijf rapport";
    if ( "effectiveSpecBox".equals(key) ) return en ? "write effective spec" : "schrijf effective spec";
    if ( "growAutoStartBox".equals(key) ) return en ? "start grow immediately" : "start grow direct";
    if ( "growStopAtEndBox".equals(key) ) return en ? "stop when final node is visible" : "stop als laatste knoop zichtbaar is";
    if ( "growLoopBox".equals(key) ) return en ? "restart after final node" : "herstart na laatste knoop";

    if ( "basisNote".equals(key) ) return en ?
      "Generate displays a new Greedy graph in OpenGraphEd. It does not write YAML, OPN, GRAPH, SVG or PNG. COUNT controls the number of labels; NO_LIMIT removes the old 0..30 teaching cap and uses the config values." :
      "Genereren toont een nieuwe Greedy-graph in OpenGraphEd. Er wordt geen YAML, OPN, GRAPH, SVG of PNG geschreven. COUNT bepaalt het aantal labels; NO_LIMIT verwijdert de oude 0..30-lesgrens en gebruikt de configwaarden.";
    if ( "gridNote".equals(key) ) return en ?
      "Default: editor grid on, fit-content. Grid step X/Y is the cell width/height used for display and later export names. Use explicit rows/columns only if you do not want automatic fit-content sizing." :
      "Standaard: editorgrid aan, fit-content. Gridstap X/Y is de celbreedte/celhoogte voor weergave en latere exportnamen. Gebruik expliciete rijen/kolommen alleen als je geen automatische fit-content-maat wilt.";
    if ( "greedyNote".equals(key) ) return en ?
      "STYLE only orders candidate points. RULE and DIAGONAL_FREE are the hard filters. Current styles: near0=compact near zero, maxturn=largest turn, quadrant=balanced spread, ring=inside-out ring growth. No more styles are offered for now: these four are transparent, deterministic and easier to compare." :
      "STYLE bepaalt alleen de volgorde van kandidaatpunten. RULE en DIAGONAL_FREE zijn de harde filters. Huidige styles: near0=compact rond nul, maxturn=grootste draai, quadrant=evenwichtige spreiding, ring=van binnen naar buiten. Meer styles zijn er nu bewust niet: deze vier zijn transparant, deterministisch en goed vergelijkbaar.";
    if ( "growNote".equals(key) ) return en ?
      "Grow uses the same static graph and settings. These fields only control time and visibility; the last grow step must equal the static graph." :
      "Grow gebruikt dezelfde statische graph en instellingen. Deze velden sturen alleen tijd en zichtbaarheid; de laatste grow-stap moet gelijk zijn aan static.";
    if ( "outputNote".equals(key) ) return en ?
      "These values are used when you later choose Greedy > Save As. A Greedy package and an OPN document preserve generator restore. Graph only and Image only do not." :
      "Deze waarden worden gebruikt wanneer je later Greedy > Save As kiest. Een Greedy package en een OPN-document bewaren generator-restore. Graph only en Image only doen dat niet.";
    if ( "helpText".equals(key) ) return en ? helpTextEN() : helpTextNL();

    return key;
  }

  private String helpTextNL()
  {
    return "Greedy Generator in OpenGraphEd\n\n" +
      "Hoofdroute\n" +
      "1. Kies instellingen.\n" +
      "2. Klik Genereren. De graph wordt direct in OpenGraphEd getoond. Er wordt niets naar schijf geschreven.\n" +
      "3. Fine-tune daarna in het document: grid, labels, knopen, projecties of layout.\n" +
      "4. Kies pas daarna Greedy > Save As om te bewaren of te exporteren.\n\n" +
      "Wat Genereren niet doet\n" +
      "Genereren schrijft geen spec.yaml, geen .opn, geen .graph, geen .svg en geen .png. De actuele instellingen blijven aan het geopende document gekoppeld.\n\n" +
      "Save As\n" +
      "Greedy package (.zip) is de volledige archiefvorm: OPN, GRAPH, YAML/spec, SVG, PNG, rapport en README waar beschikbaar.\n" +
      "OPN document (.opn) bewaart de graph plus embedded GREEDY_SETTINGS_YAML en is herstelbaar via Open Greedy OPN.\n" +
      "Graph only (.graph) en Image only zijn exportvormen. Die bewaren geen Greedy-restore.\n\n" +
      "Grid en naamgeving\n" +
      "De actieve gridcel bepaalt de tag in uitvoernamen: gridH<rijhoogte>W<kolombreedte>. Gridstap Y wordt dus H; Gridstap X wordt W.\n\n" +
      "Greedy-regel\n" +
      "Greedy betekent: sorteer kandidaten, test ze, neem de eerste kandidaat die aan de harde regels voldoet. Er is geen backtracking en geen globale optimalisatie achteraf.\n\n" +
      "Vrije knoop\n" +
      "Een vrije knoop is een bronknoop in OPN: label + gridpositie + verbindingen. De knoop is nog niet verplicht tot een klassieke boompositie zoals links, rechts of onder.\n\n" +
      "Styles / plaatsingsstijlen\n" +
      "STYLE bepaalt alleen de volgorde waarin kandidaatpunten worden geprobeerd. Daarna beslissen RULE, DIAGONAL_FREE en de bezette gridlijnen of de kandidaat geldig is.\n" +
      "near0 = near-null / dicht bij nul: compact rond knoop 0.\n" +
      "maxturn = grootste draai ten opzichte van de vorige stap.\n" +
      "quadrant = spreiding over de vier kwadranten rond 0.\n" +
      "ring = van binnen naar buiten, ring gebaseerd op max(abs(x), abs(y)).\n" +
      "Er zijn nu bewust geen extra styles: deze vier zijn deterministisch, transparant en vertegenwoordigen vier duidelijk verschillende tekenprincipes. Meer styles worden pas toegevoegd als ze een echt nieuw principe geven.\n\n" +
      "Rules\n" +
      "extension verbiedt doortrekken; collinear verbiedt dezelfde rechte drager; angle verbiedt hoeken kleiner dan ANGLE_MIN en groter dan 180-ANGLE_MIN.\n\n" +
      "Diagonale vrijheid\n" +
      "slash houdt /-diagonalen vrij (x+y uniek); backslash houdt \\-diagonalen vrij (x-y uniek); both eist beide.";
  }

  private String helpTextEN()
  {
    return "Greedy Generator in OpenGraphEd\n\n" +
      "Main route\n" +
      "1. Choose settings.\n" +
      "2. Click Generate. The graph is displayed directly in OpenGraphEd. Nothing is written to disk.\n" +
      "3. Fine-tune the document afterwards: grid, labels, nodes, projections or layout.\n" +
      "4. Only then choose Greedy > Save As to save or export.\n\n" +
      "What Generate does not do\n" +
      "Generate writes no spec.yaml, no .opn, no .graph, no .svg and no .png. The current settings remain attached to the open document.\n\n" +
      "Save As\n" +
      "Greedy package (.zip) is the complete archive form: OPN, GRAPH, YAML/spec, SVG, PNG, report and README when available.\n" +
      "OPN document (.opn) stores the graph plus embedded GREEDY_SETTINGS_YAML and can be restored through Open Greedy OPN.\n" +
      "Graph only (.graph) and Image only are export forms. They do not preserve Greedy restore.\n\n" +
      "Grid and naming\n" +
      "The active grid cell determines the filename tag: gridH<row height>W<column width>. Grid step Y is H; Grid step X is W.\n\n" +
      "Greedy rule\n" +
      "Greedy means: sort candidates, test them, take the first candidate that satisfies the hard rules. There is no backtracking and no global optimization afterwards.\n\n" +
      "Free node\n" +
      "A free node is an OPN source node: label + grid position + connections. It is not yet forced into a traditional tree position such as left, right or below.\n\n" +
      "Styles / placement strategies\n" +
      "STYLE only orders candidate points. RULE, DIAGONAL_FREE and the occupied grid lines still decide whether the candidate is valid.\n" +
      "near0 = near-zero: compact around node 0.\n" +
      "maxturn = largest turn against the previous step.\n" +
      "quadrant = spread over the four quadrants around 0.\n" +
      "ring = inside-out growth, ring based on max(abs(x), abs(y)).\n" +
      "There are no additional styles for now: these four are deterministic, transparent and represent four clearly different drawing principles. More styles should only be added when they introduce a genuinely new principle.\n\n" +
      "Rules\n" +
      "extension forbids continuing; collinear forbids the same straight carrier line; angle forbids angles smaller than ANGLE_MIN and larger than 180-ANGLE_MIN.\n\n" +
      "Diagonal freedom\n" +
      "slash keeps / diagonals free (unique x+y); backslash keeps \\ diagonals free (unique x-y); both requires both.";
  }

  private void chooseOutputDirectory()
  {
    JFileChooser chooser = new JFileChooser();
    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    File current = new File(outputDirField.getText());
    if ( current.exists() ) chooser.setCurrentDirectory(current);
    int choice = chooser.showOpenDialog(this);
    if ( choice == JFileChooser.APPROVE_OPTION ) outputDirField.setText(chooser.getSelectedFile().getPath());
  }

  private GreedySpecValues readValues(String initialSpecText)
  {
    GreedySpecValues values = new GreedySpecValues();
    if ( initialSpecText != null && initialSpecText.trim().length() > 0 )
    {
      readValuesFromReader(values, new BufferedReader(new StringReader(initialSpecText)));
      return values;
    }
    if ( specFile != null && specFile.exists() )
    {
      try
      {
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(specFile), "UTF-8"));
        try
        {
          readValuesFromReader(values, reader);
        }
        finally { reader.close(); }
      }
      catch ( Exception ignored ) {}
    }
    return values;
  }


  private void readValuesFromReader(GreedySpecValues values, BufferedReader reader)
  {
    try
    {
      String section = "";
      String line;
      while ( (line = reader.readLine()) != null )
      {
        String trimmed = line.trim();
        if ( trimmed.length() == 0 || trimmed.startsWith("#") ) continue;
        if ( !line.startsWith(" ") && trimmed.endsWith(":"))
        {
          section = trimmed.substring(0, trimmed.length()-1);
          continue;
        }
        if ( trimmed.indexOf(":") < 0 ) continue;
        String key = trimmed.substring(0, trimmed.indexOf(":"));
        String value = trimmed.substring(trimmed.indexOf(":") + 1).trim();
        values.set(section, key, value);
      }
    }
    catch ( Exception ignored ) {}
  }

  private void applyValues(GreedySpecValues values)
  {
    projectNameField.setText(values.projectName);
    projectTitleField.setText(values.projectTitle);
    baseNameField.setText(values.baseName);
    outputDirField.setText(values.outputDir);
    countSpinner.setValue(Integer.valueOf(values.count));
    maxSpinner.setValue(Integer.valueOf(values.max));
    noLimitBox.setSelected(values.noLimit);
    stepXSpinner.setValue(Integer.valueOf(values.stepX));
    stepYSpinner.setValue(Integer.valueOf(values.stepY));
    gridHeightSpinner.setValue(Integer.valueOf(values.gridHeight));
    gridWidthSpinner.setValue(Integer.valueOf(values.gridWidth));
    fitContentBox.setSelected(values.fitContentGrid);
    marginSpinner.setValue(Integer.valueOf(values.margin));
    majorSpinner.setValue(Integer.valueOf(values.majorEvery));
    showEditorGridBox.setSelected(values.showEditorGrid);
    showGridBox.setSelected(values.showGrid);
    showAxesBox.setSelected(values.showAxes);
    styleCombo.setSelectedItem(values.style);
    ruleCombo.setSelectedItem(values.rule);
    diagonalCombo.setSelectedItem(values.diagonalFree);
    angleSpinner.setValue(Integer.valueOf(values.angleMin));
    growIntervalSpinner.setValue(Integer.valueOf(values.growIntervalMs));
    growStartStepSpinner.setValue(Integer.valueOf(values.growStartStep));
    growAutoStartBox.setSelected(values.growAutoStart);
    growRevealEdgesCombo.setSelectedItem(values.growRevealEdges);
    growStopAtEndBox.setSelected(values.growStopAtEnd);
    growLoopBox.setSelected(values.growLoop);
    languageCombo.setSelectedItem(cleanLanguage(values.language));
    namingCombo.setSelectedItem(values.naming);
    graphBox.setSelected(values.formatGraph);
    opnBox.setSelected(values.formatOPN);
    svgBox.setSelected(values.formatSVG);
    pngBox.setSelected(values.formatPNG);
    reportBox.setSelected(values.writeReport);
    effectiveSpecBox.setSelected(values.writeEffectiveSpec);
  }

  private String cleanLanguage(String lang)
  {
    if ( "en".equalsIgnoreCase(lang) ) return "en";
    return "nl";
  }

  private void generateAndClose()
  {
    try
    {
      validateValues();
      result = RESULT_GENERATE;
      dispose();
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(this, e.getMessage(), en() ? "Invalid Greedy Settings" : "Ongeldige Greedy-instellingen", JOptionPane.ERROR_MESSAGE);
    }
  }

  public String getSpecText()
  {
    return buildSpecText();
  }

  public void exportSpecFile() throws IOException
  {
    validateValues();
    writeSpecFile();
  }

  private boolean en() { return "en".equals(uiLang); }

  private void validateValues()
  {
    int count = intValue(countSpinner);
    int max = intValue(maxSpinner);
    if ( count < 1 ) throw new IllegalArgumentException(en() ? "COUNT must be at least 1." : "COUNT moet minstens 1 zijn.");
    if ( max < 0 ) throw new IllegalArgumentException(en() ? "MAX must be at least 0." : "MAX moet minstens 0 zijn.");
    int gridHeight = intValue(gridHeightSpinner);
    int gridWidth = intValue(gridWidthSpinner);
    boolean fitContent = fitContentBox.isSelected();
    boolean noLimit = noLimitBox.isSelected();
    if ( !fitContent && gridHeight > 0 && gridHeight < 2 * max + 1 )
      throw new IllegalArgumentException(en() ? ("Grid height is too small for MAX. Minimum: " + (2 * max + 1)) : ("Gridhoogte is te klein voor MAX. Minimum: " + (2 * max + 1)));
    if ( !fitContent && gridWidth > 0 && gridWidth < 2 * max + 1 )
      throw new IllegalArgumentException(en() ? ("Grid width is too small for MAX. Minimum: " + (2 * max + 1)) : ("Gridbreedte is te klein voor MAX. Minimum: " + (2 * max + 1)));
    if ( !noLimit && count > 2 * max + 1 )
    {
      int needed = (count - 1) / 2;
      throw new IllegalArgumentException(en() ?
        ("COUNT=" + count + " does not fit MAX=" + max + ". Minimum MAX for unique x/y lines: " + needed + ". Or enable NO_LIMIT.") :
        ("COUNT=" + count + " past niet bij MAX=" + max + ". Minimale MAX voor unieke x/y-lijnen: " + needed + ". Of zet NO_LIMIT aan."));
    }
  }

  private int intValue(JSpinner spinner)
  {
    Object v = spinner.getValue();
    if ( v instanceof Number ) return ((Number)v).intValue();
    return Integer.parseInt(String.valueOf(v));
  }

  private void writeSpecFile() throws IOException
  {
    if ( specFile == null ) throw new IOException("No spec file configured.");
    File dir = specFile.getParentFile();
    if ( dir != null && !dir.exists() ) dir.mkdirs();

    if ( specFile.exists() )
    {
      File backup = new File(specFile.getParentFile(), specFile.getName() + ".bak");
      copyFile(specFile, backup);
    }

    OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(specFile), "UTF-8");
    try { writer.write(buildSpecText()); }
    finally { writer.close(); }
  }

  private void copyFile(File source, File target) throws IOException
  {
    FileInputStream in = new FileInputStream(source);
    FileOutputStream out = new FileOutputStream(target);
    try
    {
      byte[] buffer = new byte[8192];
      int read;
      while ( (read = in.read(buffer)) != -1 ) out.write(buffer, 0, read);
    }
    finally
    {
      try { in.close(); } catch ( IOException ignored ) {}
      try { out.close(); } catch ( IOException ignored ) {}
    }
  }

  private String buildSpecText()
  {
    StringBuffer b = new StringBuffer();
    b.append("project:\n");
    b.append("  name: ").append(safeYaml(projectNameField.getText())).append("\n");
    b.append("  title: ").append(safeYaml(projectTitleField.getText())).append("\n");
    b.append("  description: Greedy spec edited from OpenGraphEd\n\n");

    b.append("grid:\n");
    b.append("  step_x: ").append(intValue(stepXSpinner)).append("\n");
    b.append("  step_y: ").append(intValue(stepYSpinner)).append("\n");
    b.append("  height: ").append(intValue(gridHeightSpinner)).append("  # 0 = derive from max and margin\n");
    b.append("  width: ").append(intValue(gridWidthSpinner)).append("   # 0 = derive from max and margin\n");
    b.append("  show_grid_in_svg_png: ").append(showGridBox.isSelected()).append("\n");
    b.append("  show_axes_through_origin: ").append(showAxesBox.isSelected()).append("\n");
    b.append("  show_major_grid_every: ").append(intValue(majorSpinner)).append("\n");
    b.append("  margin: ").append(intValue(marginSpinner)).append("\n\n");

    b.append("graph:\n");
    b.append("  count: ").append(intValue(countSpinner)).append("\n");
    b.append("  max: ").append(intValue(maxSpinner)).append("\n");
    b.append("  start: [0, 0]\n\n");

    b.append("constraints:\n");
    b.append("  diagonal_free: ").append(String.valueOf(diagonalCombo.getSelectedItem())).append("\n\n");

    b.append("greedy:\n");
    b.append("  style: ").append(String.valueOf(styleCombo.getSelectedItem())).append("\n");
    b.append("  rule: ").append(String.valueOf(ruleCombo.getSelectedItem())).append("\n");
    b.append("  angle_min: ").append(intValue(angleSpinner)).append("\n\n");

    b.append("output:\n");
    b.append("  dir: ").append(safeYaml(outputDirField.getText())).append("\n");
    b.append("  base_name: ").append(safeYaml(baseNameField.getText())).append("\n");
    b.append("  formats: [").append(formatsText()).append("]\n");
    b.append("  naming: ").append(String.valueOf(namingCombo.getSelectedItem())).append("\n");
    b.append("  language: ").append(cleanLanguage(String.valueOf(languageCombo.getSelectedItem()))).append("\n");
    b.append("  write_report: ").append(reportBox.isSelected()).append("\n");
    b.append("  write_effective_spec: ").append(effectiveSpecBox.isSelected()).append("\n");
    return b.toString();
  }

  private String formatsText()
  {
    Vector parts = new Vector();
    if ( graphBox.isSelected() ) parts.add("graph");
    if ( opnBox.isSelected() ) parts.add("opn");
    if ( svgBox.isSelected() ) parts.add("svg");
    if ( pngBox.isSelected() ) parts.add("png");

    StringBuffer b = new StringBuffer();
    for ( int i=0; i<parts.size(); i++ )
    {
      if ( i > 0 ) b.append(", ");
      b.append(parts.get(i));
    }
    return b.toString();
  }

  private String safeYaml(String value)
  {
    if ( value == null ) return "";
    value = value.trim();
    if ( value.length() == 0 ) return "";
    if ( value.indexOf(':') >= 0 || value.indexOf('#') >= 0 || value.indexOf('[') >= 0 || value.indexOf(']') >= 0 )
    {
      return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
    return value;
  }

  private static class GreedySpecValues
  {
    String projectName = "space3";
    String projectTitle = "Space3 Greedy Graph";
    String baseName = "space3";
    String outputDir = "output";
    int count = 31;
    int max = 20;
    boolean noLimit = false;
    int stepX = 20;
    int stepY = 20;
    int gridHeight = 0;
    int gridWidth = 0;
    boolean fitContentGrid = true;
    int margin = 2;
    int majorEvery = 5;
    boolean showGrid = true;
    boolean showEditorGrid = true;
    boolean showAxes = true;
    String style = "near0";
    String rule = "collinear";
    String diagonalFree = "none";
    int angleMin = 30;
    String language = "nl";
    String naming = "short";
    boolean formatGraph = true;
    boolean formatOPN = true;
    boolean formatSVG = true;
    boolean formatPNG = true;
    boolean writeReport = true;
    boolean writeEffectiveSpec = true;
    int growIntervalMs = 700;
    int growStartStep = 0;
    boolean growAutoStart = false;
    String growRevealEdges = "when_both_nodes_visible";
    boolean growStopAtEnd = true;
    boolean growLoop = false;

    void set(String section, String key, String value)
    {
      value = stripQuotes(value);
      if ( "project".equals(section) )
      {
        if ( "name".equals(key) ) projectName = value;
        if ( "title".equals(key) ) projectTitle = value;
      }
      else if ( "grid".equals(section) )
      {
        if ( "step_x".equals(key) ) stepX = parseInt(value, stepX);
        if ( "step_y".equals(key) ) stepY = parseInt(value, stepY);
        if ( "height".equals(key) || "rows".equals(key) || "grid_height".equals(key) ) gridHeight = parseInt(value, gridHeight);
        if ( "width".equals(key) || "cols".equals(key) || "columns".equals(key) || "grid_width".equals(key) ) gridWidth = parseInt(value, gridWidth);
        if ( "fit_content".equals(key) || "fit_content_grid".equals(key) ) fitContentGrid = parseBool(value, fitContentGrid);
        if ( "show_grid_in_editor".equals(key) || "show_grid".equals(key) ) showEditorGrid = parseBool(value, showEditorGrid);
        if ( "show_grid_in_svg_png".equals(key) ) showGrid = parseBool(value, showGrid);
        if ( "show_axes_through_origin".equals(key) ) showAxes = parseBool(value, showAxes);
        if ( "show_major_grid_every".equals(key) ) majorEvery = parseInt(value, majorEvery);
        if ( "margin".equals(key) ) margin = parseInt(value, margin);
      }
      else if ( "graph".equals(section) )
      {
        if ( "count".equals(key) ) count = parseInt(value, count);
        if ( "max".equals(key) ) max = parseInt(value, max);
        if ( "no_limit".equals(key) || "nolimit".equals(key) ) noLimit = parseBool(value, noLimit);
      }
      else if ( "constraints".equals(section) )
      {
        if ( "diagonal_free".equals(key) ) diagonalFree = value;
      }
      else if ( "greedy".equals(section) )
      {
        if ( "style".equals(key) ) style = value;
        if ( "rule".equals(key) ) rule = value;
        if ( "angle_min".equals(key) ) angleMin = parseInt(value, angleMin);
      }
      else if ( "grow".equals(section) )
      {
        if ( "interval_ms".equals(key) || "interval".equals(key) || "delay_ms".equals(key) ) growIntervalMs = parseInt(value, growIntervalMs);
        if ( "start_step".equals(key) ) growStartStep = parseInt(value, growStartStep);
        if ( "auto_start".equals(key) ) growAutoStart = parseBool(value, growAutoStart);
        if ( "reveal_edges".equals(key) ) growRevealEdges = value;
        if ( "stop_at_end".equals(key) ) growStopAtEnd = parseBool(value, growStopAtEnd);
        if ( "loop".equals(key) ) growLoop = parseBool(value, growLoop);
      }
      else if ( "output".equals(section) )
      {
        if ( "dir".equals(key) ) outputDir = value;
        if ( "base_name".equals(key) ) baseName = value;
        if ( "naming".equals(key) ) naming = value;
        if ( "language".equals(key) ) language = value;
        if ( "write_report".equals(key) ) writeReport = parseBool(value, writeReport);
        if ( "write_effective_spec".equals(key) ) writeEffectiveSpec = parseBool(value, writeEffectiveSpec);
        if ( "formats".equals(key) ) parseFormats(value);
      }
    }

    private void parseFormats(String value)
    {
      formatGraph = false;
      formatOPN = false;
      formatSVG = false;
      formatPNG = false;
      value = value.replace("[", "").replace("]", "");
      String[] parts = value.split(",");
      for ( int i=0; i<parts.length; i++ )
      {
        String part = stripQuotes(parts[i].trim());
        if ( "graph".equals(part) ) formatGraph = true;
        if ( "opn".equals(part) ) formatOPN = true;
        if ( "svg".equals(part) ) formatSVG = true;
        if ( "png".equals(part) ) formatPNG = true;
      }
    }

    private static int parseInt(String value, int fallback)
    {
      try { return Integer.parseInt(value.trim()); } catch ( Exception e ) { return fallback; }
    }

    private static boolean parseBool(String value, boolean fallback)
    {
      if ( "true".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value) || "ja".equalsIgnoreCase(value) || "1".equals(value) ) return true;
      if ( "false".equalsIgnoreCase(value) || "no".equalsIgnoreCase(value) || "nee".equalsIgnoreCase(value) || "0".equals(value) ) return false;
      return fallback;
    }

    private static String stripQuotes(String value)
    {
      if ( value == null ) return "";
      value = value.trim();
      if ( value.length() >= 2 && ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) )
      {
        value = value.substring(1, value.length()-1);
      }
      return value;
    }
  }
}
