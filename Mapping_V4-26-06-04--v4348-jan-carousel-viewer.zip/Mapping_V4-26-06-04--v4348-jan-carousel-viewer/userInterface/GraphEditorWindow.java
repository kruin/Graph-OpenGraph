package userInterface;


import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Properties;
import java.util.Vector;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import graphStructure.*;
import graphStructure.mementos.GreedyGrowVisibilityMemento;
import operation.OpenGraphTreeDrawOperation;

public class GraphEditorWindow extends OpenGraphEdInternalFrame
{
  private static final int STRUCTURE_ORIGINAL_GRAPH = 0;
  private static final int STRUCTURE_OPENGRAPH_CAROUSEL = -1;

  public static int WIDTH = 1150;//400;//SET MAX, see below:setSize
  public static int HEIGHT = 750;//400;

  private GraphController graphController;
  private GraphEditor graphEditor;
  private static int newCount = 0;
  private GraphEditorDialog ged;
  private GraphEditorInfoWindow infoWindow;
  private GraphEditorLogWindow logWindow;
  private ButtonGroup zinstypeButtonGroup;
  private JToggleButton basisZinstypeButton;
  private JToggleButton bijzinZinstypeButton;
  private JToggleButton stellendZinstypeButton;
  private JToggleButton jaNeeZinstypeButton;
  private JToggleButton whZinstypeButton;
  private JToggleButton topicalisatieZinstypeButton;
  private JComboBox structureTypeCombo;
  private JButton openGraphDrawButton;
  private JButton openGraphExplainButton;
  private JLabel zinstypeLabel;
  private JPanel zinstypePanel;
  private JPanel verbClusterPanel;
  private JButton languageTreeSettingsButton;
  private JButton functionalTreeSettingsButton;
  private JPanel editorDeckPanel;
  private CardLayout editorDeckLayout;
  private JScrollPane graphEditorScrollPane;
  private JPanel openGraphCarouselPanel;
  private JLabel openGraphCarouselImageLabel;
  private JTextArea openGraphCarouselTextArea;
  private JLabel openGraphCarouselStatusLabel;
  private JButton openGraphCarouselFirstButton;
  private JButton openGraphCarouselPrevButton;
  private JButton openGraphCarouselNextButton;
  private JButton openGraphCarouselLastButton;
  private JButton openGraphCarouselGoToButton;
  private JButton openGraphCarouselAddButton;
  private JButton openGraphCarouselDeleteButton;
  private JButton openGraphCarouselSaveTextButton;
  private JButton openGraphCarouselRefreshButton;
  private JButton openGraphCarouselMoveLeftButton;
  private JButton openGraphCarouselMoveRightButton;
  private JButton openGraphCarouselMoveToButton;
  private JButton openGraphCarouselSwapButton;
  private JButton openGraphCarouselExportButton;
  private JButton openGraphCarouselImportButton;
  private JButton openGraphCarouselReminderButton;
  private JLabel openGraphCarouselReminderLabel;
  private Vector openGraphCarouselSlides = new Vector();
  private int openGraphCarouselIndex = 0;
  private ButtonGroup verbClusterButtonGroup;
  private JToggleButton pvVdVerbClusterButton;
  private JToggleButton vdPvVerbClusterButton;
  private JPanel projectionProfilePanel;
  private JCheckBox projectionShowCheckBox;
  private JCheckBox projectionLeftCheckBox;
  private JCheckBox projectionRightCheckBox;
  private JCheckBox projectionTopCheckBox;
  private JCheckBox projectionBottomCheckBox;
  private JTextField projectionLeftCaptionField;
  private JTextField projectionRightCaptionField;
  private JTextField projectionTopCaptionField;
  private JTextField projectionBottomCaptionField;
  private JButton projectionSaveProfileButton;
  private boolean updatingStructureTypeCombo = false;
  private boolean updatingProjectionProfileControls = false;
  private int lastExplicitTreeTypeSelection = STRUCTURE_ORIGINAL_GRAPH;
  private JPanel greedyGrowPanel;
  private JButton greedyGrowPreviousButton;
  private JButton greedyGrowResetButton;
  private JButton greedyGrowNextButton;
  private JButton greedyGrowAllButton;
  private JButton greedyGrowAutoButton;
  private JSpinner greedyGrowIntervalSpinner;
  private JLabel greedyGrowStatusLabel;
  private javax.swing.Timer greedyGrowTimer;
  private int greedyGrowVisibleCount = 0;
  private boolean greedyGrowRunning = false;
  private boolean greedyGrowStopAtEnd = true;
  private boolean greedyGrowLoop = false;
  private boolean greedyGrowKeysInstalled = false;
  private MouseAdapter greedyGrowClickListener;

  public GraphEditorWindow(GraphController graphController, Graph graph)
  {
    super(graphController, graph.getFileName(),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    if ( graph.getLabel().length() == 0 )
    {
      setTitle(graph.getFileName());
    }
    init(graphController);
    graphEditor.setGraph(graph);
    OpenGraphProjectionSettings initialSettings = initialProjectionSettingsForGraph(graph);
    if ( initialSettings != null )
    {
      graphEditor.setOpenGraphProjectionSettings(initialSettings);
      graphEditor.rememberLanguageProjectionSettings(initialSettings);
      graphEditor.setOpenGraphProjectionContextActive(true);
      lastExplicitTreeTypeSelection = initialSettings.getStructureType();
    }
    updateOpenGraphHeaderControls();
  }


  private OpenGraphProjectionSettings initialProjectionSettingsForGraph(Graph graph)
  {
    int structureType = preferredStructureTypeForGraph(graph);
    if ( structureType == 0 )
    {
      return null;
    }

    OpenGraphProjectionSettings settings = OpenGraphProjectionSupport.loadBestAvailableForStructureType(structureType);
    settings.setStructureType(structureType);
    settings.setShowProjections(true);
    return settings;
  }

  private int preferredStructureTypeForGraph(Graph graph)
  {
    String topLabel = detectTopNodeLabel(graph);
    if ( topLabel.equals("CLAUSE") || topLabel.equals("V") || topLabel.equals("S") || topLabel.equals("S") )
    {
      return OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE;
    }
    if ( graph != null && graph.isOPNLanguageTreePreferred() )
    {
      return OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    }
    return 0;
  }

  private String detectTopNodeLabel(Graph graph)
  {
    if ( graph == null ) return "";

    java.util.Vector nodes = graph.getNodes();
    if ( nodes == null || nodes.size() == 0 ) return "";

    java.util.HashSet targets = new java.util.HashSet();
    java.util.Vector edges = graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge == null ) continue;
      NodeInterface end = edge.getEndNode();
      if ( end != null ) targets.add(end);
    }

    Node best = null;
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node == null ) continue;
      if ( !targets.contains(node) )
      {
        best = node;
        break;
      }
      if ( best == null || node.getLocation().intY() < best.getLocation().intY() ||
           (node.getLocation().intY() == best.getLocation().intY() &&
            node.getLocation().intX() < best.getLocation().intX()) )
      {
        best = node;
      }
    }

    if ( best == null ) return "";
    String label = best.getLabel();
    return label == null ? "" : label.trim().toUpperCase();
  }

  public GraphEditorWindow(GraphController graphController)
  {
    super(graphController, "Untitled " + ++newCount,
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    init(graphController);
  }

  private void init(GraphController graphController)
  {
    this.graphController = graphController;
    infoWindow = new GraphEditorInfoWindow(graphController, this);
    logWindow = new GraphEditorLogWindow(graphController, this);
    graphEditor = new GraphEditor(graphController, infoWindow, logWindow);
    ged = null;
    installImmediateZinstypeToolTips();

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    getContentPane().setLayout(layout);

    JPanel openGraphActionBar = createOpenGraphActionBar();
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.HORIZONTAL;
    layoutCons.insets = new Insets(3,3,0,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 0.0;
    layout.setConstraints(openGraphActionBar, layoutCons);
    getContentPane().add(openGraphActionBar);

    greedyGrowPanel = createGreedyGrowPanel();
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.HORIZONTAL;
    layoutCons.insets = new Insets(0,3,0,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 0.0;
    layout.setConstraints(greedyGrowPanel, layoutCons);
    getContentPane().add(greedyGrowPanel);

    graphEditorScrollPane = new JScrollPane(graphEditor,
                                             JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    openGraphCarouselPanel = createOpenGraphCarouselPanel();
    editorDeckLayout = new CardLayout();
    editorDeckPanel = new JPanel(editorDeckLayout);
    editorDeckPanel.add(graphEditorScrollPane, "graph");
    editorDeckPanel.add(openGraphCarouselPanel, "carousel");

    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = GridBagConstraints.REMAINDER;
    layoutCons.fill = GridBagConstraints.BOTH;
    layoutCons.insets = new Insets(3,3,3,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 1.0;
    layout.setConstraints(editorDeckPanel, layoutCons);
    getContentPane().add(editorDeckPanel);

    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    addInternalFrameListener(graphController);

  //  setSize(WIDTH, HEIGHT);
    
    setSize(graphController.getGraphWindow().getWidth(), graphController.getGraphWindow().getHeight());
    setVisible(true);
  }

  private void installImmediateZinstypeToolTips()
  {
    ToolTipManager manager = ToolTipManager.sharedInstance();
    manager.setInitialDelay(0);
    manager.setReshowDelay(0);
    manager.setDismissDelay(15000);
  }

  private JPanel createOpenGraphActionBar()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 2));
    panel.setBorder(BorderFactory.createEtchedBorder());

    JLabel structureTypeLabel = new JLabel("Tree:");
    structureTypeLabel.setToolTipText("OpenGraph tree. Language = DS-boom, LEX-as, zinstypeprofielen en V-cluster.");
    panel.add(structureTypeLabel);
    structureTypeCombo = createStructureTypeCombo();
    panel.add(structureTypeCombo);

    openGraphExplainButton = createOpenGraphButton("Uitleg", "Leg het huidige Tree-type uit: origineel, OpenGraph, Simple, Language, Functional, Frame of Anaphor.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        showCurrentTreeTypeExplanation();
      }
    });
    panel.add(openGraphExplainButton);

    languageTreeSettingsButton = createOpenGraphButton("Settings...", "Language Tree settings: V-cluster en projectieprofiel voor de gebruiker. Alleen zichtbaar bij Tree = Language.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        openLanguageTreeSettingsDialog();
      }
    });
    /* Keep the settings button directly next to Tree. It must be
     * findable before the wide Zinstype/V-cluster/projection groups on
     * narrow screens. */
    panel.add(languageTreeSettingsButton);

    functionalTreeSettingsButton = createOpenGraphButton("FT Settings...", "Functional Tree settings: core/frame roles, vertical spacing and role table. Alleen zichtbaar bij Tree = Functional.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        openFunctionalTreeSettingsDialog();
      }
    });
    panel.add(functionalTreeSettingsButton);

    /* Keep Zinstype close to Tree, but after LT Settings. */
    zinstypePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    zinstypePanel.setOpaque(false);
    zinstypeLabel = new JLabel("Zin:");
    zinstypeLabel.setToolTipText("Zinstype voor Language Tree / Phrase. De knoppen voeren direct Draw/Redraw uit; de DS-boom blijft ongewijzigd.");
    zinstypePanel.add(zinstypeLabel);
    zinstypeButtonGroup = new ButtonGroup();
    basisZinstypeButton = createZinstypeButton("Basis", OpenGraphProjectionSettings.ZINSTYPE_BASIS);
    bijzinZinstypeButton = createZinstypeButton("Bijzin", OpenGraphProjectionSettings.ZINSTYPE_BIJZIN);
    stellendZinstypeButton = createZinstypeButton("Stell.", OpenGraphProjectionSettings.ZINSTYPE_STELLEND);
    jaNeeZinstypeButton = createZinstypeButton("Ja/nee", OpenGraphProjectionSettings.ZINSTYPE_JA_NEE);
    whZinstypeButton = createZinstypeButton("WH", OpenGraphProjectionSettings.ZINSTYPE_WH);
    topicalisatieZinstypeButton = createZinstypeButton("Topic", OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE);
    zinstypePanel.add(basisZinstypeButton);
    zinstypePanel.add(bijzinZinstypeButton);
    zinstypePanel.add(stellendZinstypeButton);
    zinstypePanel.add(jaNeeZinstypeButton);
    zinstypePanel.add(whZinstypeButton);
    zinstypePanel.add(topicalisatieZinstypeButton);
    panel.add(zinstypePanel);

    verbClusterPanel = createVerbClusterPanel();
    panel.add(verbClusterPanel);

    projectionProfilePanel = createProjectionProfilePanel();
    panel.add(projectionProfilePanel);

    openGraphDrawButton = createOpenGraphButton("Draw", "Draw/Redraw using the selected Tree. Tree selection alone does not draw.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.drawSelectedOpenGraphStructure(GraphEditorWindow.this);
      }
    });
    panel.add(openGraphDrawButton);

    panel.add(createOpenGraphButton("Grid", "Set or reapply the OpenGraph grid without clearing the current OPN result", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.openGraphGridMode(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Toggle Proj.", "Show or hide OpenGraph projections without moving the structure grid", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.toggleLexicalProjection(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Save OPN", "Save the current OpenGraph result as .opn", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.saveOPN(GraphEditorWindow.this);
      }
    }));

    updateZinstypeButtonSelection();
    updateVerbClusterButtonSelection();
    updateStructureTypeComboSelection();
    updateOpenGraphHeaderControlsVisibility();
    return panel;
  }



  private JPanel createGreedyGrowPanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
    panel.setBorder(BorderFactory.createEtchedBorder());
    panel.setVisible(false);

    JLabel title = new JLabel("Greedy grow:");
    title.setFont(title.getFont().deriveFont(Font.BOLD));
    title.setToolTipText("Grow werkt in hetzelfde statische Greedy-graphvenster. Geen apart tekenscherm.");
    panel.add(title);

    greedyGrowPreviousButton = createOpenGraphButton("Vorige", "Verberg de laatst getoonde Greedy-knoop.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        greedyGrowPrevious();
      }
    });
    panel.add(greedyGrowPreviousButton);

    greedyGrowResetButton = createOpenGraphButton("Reset", "Terug naar alleen de eerste Greedy-knoop.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        greedyGrowReset();
      }
    });
    panel.add(greedyGrowResetButton);

    greedyGrowNextButton = createOpenGraphButton("Next", "Toon de volgende Greedy-knoop. ENTER, SPACE, rechterpijl of klik doen hetzelfde.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        greedyGrowNext();
      }
    });
    panel.add(greedyGrowNextButton);

    greedyGrowAllButton = createOpenGraphButton("Static/all", "Toon de volledige statische Greedy-eindweergave.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        greedyGrowShowAll();
      }
    });
    panel.add(greedyGrowAllButton);

    greedyGrowAutoButton = createOpenGraphButton("Start grow", "Automatisch één knoop per interval tonen. G start/stopt.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        greedyGrowToggleAuto();
      }
    });
    panel.add(greedyGrowAutoButton);

    panel.add(new JLabel("interval ms:"));
    greedyGrowIntervalSpinner = new JSpinner(new SpinnerNumberModel(700, 100, 10000, 100));
    panel.add(greedyGrowIntervalSpinner);

    greedyGrowStatusLabel = new JLabel(" ");
    greedyGrowStatusLabel.setToolTipText("ENTER/SPACE/klik = volgende knoop; G = grow-mode; Static/all = volledige eindweergave.");
    panel.add(greedyGrowStatusLabel);

    greedyGrowTimer = new javax.swing.Timer(700, new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        greedyGrowOneTimerStep();
      }
    });

    return panel;
  }

  public void startGreedyStaticGrow(String specText)
  {
    if ( graphEditor == null || graphEditor.getGraph() == null )
    {
      return;
    }

    int total = graphEditor.getGraph().getNumNodes();
    if ( total <= 0 )
    {
      return;
    }

    stopGreedyGrowTimer();
    int startStep = parseGreedyGrowInt(specText, "start_step", 0, 0, Math.max(0, total - 1));
    greedyGrowVisibleCount = Math.max(1, Math.min(total, startStep + 1));
    greedyGrowStopAtEnd = parseGreedyGrowBool(specText, "stop_at_end", true);
    greedyGrowLoop = parseGreedyGrowBool(specText, "loop", false);
    boolean autoStart = parseGreedyGrowBool(specText, "auto_start", false);
    int interval = parseGreedyGrowIntervalMillis(specText, 700);
    greedyGrowIntervalSpinner.setValue(new Integer(interval));
    greedyGrowTimer.setDelay(interval);
    greedyGrowTimer.setInitialDelay(interval);
    greedyGrowPanel.setVisible(true);
    installGreedyGrowInputHandlers();
    graphEditor.changeToMoveMode();
    applyGreedyGrowVisibility();
    updateGreedyGrowStatus();
    validate();
    repaint();
    graphEditor.requestFocusInWindow();
    if ( autoStart && greedyGrowVisibleCount < total )
    {
      greedyGrowToggleAuto();
    }
  }

  private void installGreedyGrowInputHandlers()
  {
    if ( !greedyGrowKeysInstalled )
    {
      InputMap input = graphEditor.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
      ActionMap actions = graphEditor.getActionMap();
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "greedyGrowNext");
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "greedyGrowNext");
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "greedyGrowNext");
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "greedyGrowPrevious");
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0), "greedyGrowPrevious");
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_G, 0), "greedyGrowToggleAuto");
      input.put(KeyStroke.getKeyStroke(KeyEvent.VK_R, 0), "greedyGrowReset");
      actions.put("greedyGrowNext", new AbstractAction()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( greedyGrowPanel != null && greedyGrowPanel.isVisible() ) greedyGrowNext();
        }
      });
      actions.put("greedyGrowPrevious", new AbstractAction()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( greedyGrowPanel != null && greedyGrowPanel.isVisible() ) greedyGrowPrevious();
        }
      });
      actions.put("greedyGrowToggleAuto", new AbstractAction()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( greedyGrowPanel != null && greedyGrowPanel.isVisible() ) greedyGrowToggleAuto();
        }
      });
      actions.put("greedyGrowReset", new AbstractAction()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( greedyGrowPanel != null && greedyGrowPanel.isVisible() ) greedyGrowReset();
        }
      });
      greedyGrowKeysInstalled = true;
    }

    if ( greedyGrowClickListener == null )
    {
      greedyGrowClickListener = new MouseAdapter()
      {
        public void mouseClicked(MouseEvent e)
        {
          if ( greedyGrowPanel != null && greedyGrowPanel.isVisible() && e.getButton() == MouseEvent.BUTTON1 )
          {
            greedyGrowNext();
          }
        }
      };
      graphEditor.addMouseListener(greedyGrowClickListener);
    }
  }

  private void greedyGrowNext()
  {
    stopGreedyGrowTimer();
    greedyGrowStepForward();
  }

  private void greedyGrowStepForward()
  {
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;
    if ( greedyGrowVisibleCount >= graph.getNumNodes() ) return;

    if ( isGreedyGrowRedoAvailable(graph) )
    {
      graphEditor.redo();
      syncGreedyGrowAfterHistoryNavigation();
      updateGreedyGrowUndoControls(graph);
      return;
    }

    setGreedyGrowVisibleCountWithHistory(greedyGrowVisibleCount + 1, "Greedy Grow Step");
  }

  private void greedyGrowPrevious()
  {
    stopGreedyGrowTimer();
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;

    if ( isGreedyGrowUndoAvailable(graph) )
    {
      graphEditor.undo();
      syncGreedyGrowAfterHistoryNavigation();
      updateGreedyGrowUndoControls(graph);
      return;
    }

    if ( greedyGrowVisibleCount > 1 )
    {
      setGreedyGrowVisibleCountNoHistory(greedyGrowVisibleCount - 1);
    }
  }

  private void greedyGrowReset()
  {
    stopGreedyGrowTimer();
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;
    int targetCount = graph.getNumNodes() == 0 ? 0 : 1;
    setGreedyGrowVisibleCountWithHistory(targetCount, "Greedy Grow Reset");
  }

  private void greedyGrowShowAll()
  {
    stopGreedyGrowTimer();
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;
    setGreedyGrowVisibleCountWithHistory(graph.getNumNodes(), "Greedy Grow Static All");
  }

  private void greedyGrowToggleAuto()
  {
    if ( greedyGrowRunning )
    {
      stopGreedyGrowTimer();
      updateGreedyGrowStatus();
      return;
    }
    int delay = ((Integer)greedyGrowIntervalSpinner.getValue()).intValue();
    greedyGrowTimer.setDelay(delay);
    greedyGrowTimer.setInitialDelay(delay);
    greedyGrowRunning = true;
    greedyGrowAutoButton.setText("Pauze");
    greedyGrowTimer.start();
    updateGreedyGrowStatus();
  }

  private void greedyGrowOneTimerStep()
  {
    Graph graph = graphEditor.getGraph();
    if ( graph == null )
    {
      stopGreedyGrowTimer();
      updateGreedyGrowStatus();
      return;
    }
    if ( greedyGrowVisibleCount >= graph.getNumNodes() )
    {
      if ( greedyGrowLoop )
      {
        setGreedyGrowVisibleCountWithHistory(graph.getNumNodes() == 0 ? 0 : 1, "Greedy Grow Loop Reset");
        return;
      }
      if ( greedyGrowStopAtEnd ) stopGreedyGrowTimer();
      updateGreedyGrowStatus();
      return;
    }
    setGreedyGrowVisibleCountWithHistory(greedyGrowVisibleCount + 1, "Greedy Grow Auto Step");
  }

  private void stopGreedyGrowTimer()
  {
    if ( greedyGrowTimer != null ) greedyGrowTimer.stop();
    greedyGrowRunning = false;
    if ( greedyGrowAutoButton != null ) greedyGrowAutoButton.setText("Start grow");
  }

  private void setGreedyGrowVisibleCountWithHistory(int newVisibleCount, String title)
  {
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;
    int total = graph.getNumNodes();
    int normalized = Math.max(total == 0 ? 0 : 1, Math.min(total, newVisibleCount));
    if ( normalized == greedyGrowVisibleCount )
    {
      updateGreedyGrowStatus();
      return;
    }

    graph.newMemento(title);
    graph.addCustomMemento(GreedyGrowVisibilityMemento.createVisibilityMemento(graph));
    greedyGrowVisibleCount = normalized;
    applyGreedyGrowVisibility();
    graph.doneMemento();
    updateGreedyGrowStatus();
    updateGreedyGrowUndoControls(graph);
  }

  private void setGreedyGrowVisibleCountNoHistory(int newVisibleCount)
  {
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;
    int total = graph.getNumNodes();
    greedyGrowVisibleCount = Math.max(total == 0 ? 0 : 1, Math.min(total, newVisibleCount));
    applyGreedyGrowVisibility();
    updateGreedyGrowStatus();
    updateGreedyGrowUndoControls(graph);
  }

  private void applyGreedyGrowVisibility()
  {
    Graph graph = graphEditor.getGraph();
    if ( graph == null ) return;
    Vector nodes = graph.getNodes();
    Vector edges = graph.getEdges();
    for ( int i=0; i<nodes.size(); i++ )
    {
      ((Node)nodes.elementAt(i)).setIsVisible(i < greedyGrowVisibleCount);
    }
    for ( int i=0; i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      int a = nodes.indexOf(edge.getStartNode());
      int b = nodes.indexOf(edge.getEndNode());
      boolean visible = a >= 0 && b >= 0 && a < greedyGrowVisibleCount && b < greedyGrowVisibleCount;
      edge.setIsVisible(visible);
    }
    applyGreedyGrowGridWindow();
    graph.markForRepaint();
    graphEditor.update();
  }

  private void applyGreedyGrowGridWindow()
  {
    Graph graph = graphEditor.getGraph();
    if ( graph == null || !graph.getDrawGrid() || greedyGrowVisibleCount <= 0 ) return;

    Vector nodes = graph.getNodes();
    if ( nodes == null || nodes.size() == 0 ) return;

    int cellWidth = Math.max(2, graph.getGridColWidth());
    int cellHeight = Math.max(2, graph.getGridRowHeight());
    OpenGraphGridSettings settings = graphEditor.getOpenGraphGridSettings();

    int marginLeft = settings == null ? 2 : Math.max(0, settings.getMarginLeftLines());
    int marginRight = settings == null ? 2 : Math.max(0, settings.getMarginRightLines());
    int marginTop = settings == null ? 2 : Math.max(0, settings.getMarginTopLines());
    int marginBottom = settings == null ? 2 : Math.max(0, settings.getMarginBottomLines());

    int minX = Integer.MAX_VALUE;
    int minY = Integer.MAX_VALUE;
    int maxX = Integer.MIN_VALUE;
    int maxY = Integer.MIN_VALUE;

    FontMetrics fm = graphEditor.getFontMetrics(graphEditor.getFont());
    int max = Math.min(greedyGrowVisibleCount, nodes.size());
    for ( int i=0; i<max; i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      int x = node.getLocation().intX();
      int y = node.getLocation().intY();
      minX = Math.min(minX, x - Node.RADIUS - 2);
      minY = Math.min(minY, y - Node.RADIUS - 2);
      maxX = Math.max(maxX, x + Node.RADIUS + 2);
      maxY = Math.max(maxY, y + Node.RADIUS + 2);

      String text = null;
      if ( graph.getShowLabels() ) text = node.getLabel();
      else if ( graph.getShowCoords() ) text = String.valueOf(x) + ", " + String.valueOf(y);
      if ( text != null && text.length() > 0 )
      {
        int textX = x + Node.RADIUS + 3;
        int textY = y + Node.RADIUS + 2 - fm.getAscent();
        minX = Math.min(minX, textX);
        minY = Math.min(minY, textY);
        maxX = Math.max(maxX, textX + fm.stringWidth(text) + 2);
        maxY = Math.max(maxY, textY + fm.getHeight());
      }
    }

    if ( minX == Integer.MAX_VALUE ) return;

    minX = floorGreedyGrowGrid(minX, cellWidth) - marginLeft * cellWidth;
    minY = floorGreedyGrowGrid(minY, cellHeight) - marginTop * cellHeight;
    maxX = ceilGreedyGrowGrid(maxX, cellWidth) + marginRight * cellWidth;
    maxY = ceilGreedyGrowGrid(maxY, cellHeight) + marginBottom * cellHeight;

    if ( maxX <= minX ) maxX = minX + cellWidth;
    if ( maxY <= minY ) maxY = minY + cellHeight;

    int cols = Math.max(2, ((maxX - minX) / cellWidth) + 1);
    int rows = Math.max(2, ((maxY - minY) / cellHeight) + 1);
    graph.setGridDisplayWindow(minX, minY, rows, cols);
  }

  private int floorGreedyGrowGrid(int value, int step)
  {
    return (int)Math.floor((double)value / (double)step) * step;
  }

  private int ceilGreedyGrowGrid(int value, int step)
  {
    return (int)Math.ceil((double)value / (double)step) * step;
  }

  private boolean isGreedyGrowUndoAvailable(Graph graph)
  {
    return graph != null && graph.peekUndo() != null && isGreedyGrowHistoryTitle(graph.peekUndo().getTitle());
  }

  private boolean isGreedyGrowRedoAvailable(Graph graph)
  {
    return graph != null && graph.peekRedo() != null && isGreedyGrowHistoryTitle(graph.peekRedo().getTitle());
  }

  private boolean isGreedyGrowHistoryTitle(String title)
  {
    return title != null && title.startsWith("Greedy Grow");
  }

  public void syncGreedyGrowAfterHistoryNavigation()
  {
    if ( greedyGrowPanel == null || !greedyGrowPanel.isVisible() || graphEditor == null || graphEditor.getGraph() == null )
    {
      return;
    }
    stopGreedyGrowTimer();
    greedyGrowVisibleCount = countVisibleGreedyGrowNodes(graphEditor.getGraph());
    updateGreedyGrowStatus();
    graphEditor.updateShapes();
    graphEditor.repaint();
  }

  private int countVisibleGreedyGrowNodes(Graph graph)
  {
    Vector nodes = graph.getNodes();
    int count = 0;
    for ( int i=0; i<nodes.size(); i++ )
    {
      if ( ((Node)nodes.elementAt(i)).getIsVisible() ) count++;
    }
    return count;
  }

  private void updateGreedyGrowUndoControls(Graph graph)
  {
    if ( graphController != null && graph != null )
    {
      graphController.getMenuAndToolBar().updateUndo(graph);
    }
  }

  private void updateGreedyGrowStatus()
  {
    if ( graphEditor == null || graphEditor.getGraph() == null || greedyGrowPanel == null ) return;
    int total = graphEditor.getGraph().getNumNodes();
    int current = greedyGrowVisibleCount <= 0 ? -1 : greedyGrowVisibleCount - 1;
    greedyGrowStatusLabel.setText("knoop " + current + " / " + Math.max(0, total - 1) + " — ENTER/SPACE/klik=next; G=grow");
    greedyGrowPreviousButton.setEnabled(greedyGrowVisibleCount > 1);
    greedyGrowNextButton.setEnabled(greedyGrowVisibleCount < total);
    greedyGrowResetButton.setEnabled(total > 0);
    greedyGrowAllButton.setEnabled(total > 0 && greedyGrowVisibleCount < total);
    greedyGrowAutoButton.setEnabled((total > 1 && greedyGrowVisibleCount < total) || greedyGrowRunning);
  }

  private int parseGreedyGrowInt(String specText, String wantedKey, int defaultValue, int min, int max)
  {
    String value = findGreedyGrowValue(specText, wantedKey);
    if ( value == null ) return defaultValue;
    try
    {
      int parsed = Integer.parseInt(value);
      if ( parsed < min ) return min;
      if ( parsed > max ) return max;
      return parsed;
    }
    catch ( Exception ignored )
    {
      return defaultValue;
    }
  }

  private boolean parseGreedyGrowBool(String specText, String wantedKey, boolean defaultValue)
  {
    String value = findGreedyGrowValue(specText, wantedKey);
    if ( value == null ) return defaultValue;
    if ( "true".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value) || "ja".equalsIgnoreCase(value) || "1".equals(value) ) return true;
    if ( "false".equalsIgnoreCase(value) || "no".equalsIgnoreCase(value) || "nee".equalsIgnoreCase(value) || "0".equals(value) ) return false;
    return defaultValue;
  }

  private String findGreedyGrowValue(String specText, String wantedKey)
  {
    if ( specText == null ) return null;
    String[] lines = specText.split("\r?\n");
    String section = "";
    for ( int i=0; i<lines.length; i++ )
    {
      String line = stripGreedyGrowComment(lines[i]).trim();
      if ( line.length() == 0 ) continue;
      if ( line.endsWith(":") && line.indexOf(':') == line.length() - 1 )
      {
        section = line.substring(0, line.length() - 1).trim().toLowerCase();
        continue;
      }
      int idx = line.indexOf(':');
      if ( idx < 0 ) continue;
      String key = line.substring(0, idx).trim().toLowerCase();
      String value = unquoteGreedyGrowValue(line.substring(idx + 1).trim());
      if ( "grow".equals(section) && wantedKey.equals(key) ) return value;
      if ( ("grow_" + wantedKey).equals(key) ) return value;
    }
    return null;
  }

  private int parseGreedyGrowIntervalMillis(String specText, int defaultValue)
  {
    if ( specText == null ) return defaultValue;
    String[] lines = specText.split("\\r?\\n");
    String section = "";
    for ( int i=0; i<lines.length; i++ )
    {
      String line = stripGreedyGrowComment(lines[i]).trim();
      if ( line.length() == 0 ) continue;
      if ( line.endsWith(":") && line.indexOf(':') == line.length() - 1 )
      {
        section = line.substring(0, line.length() - 1).trim().toLowerCase();
        continue;
      }
      int idx = line.indexOf(':');
      if ( idx < 0 ) continue;
      String key = line.substring(0, idx).trim().toLowerCase();
      String value = unquoteGreedyGrowValue(line.substring(idx + 1).trim());
      if ( ("grow".equals(section) && ("interval_ms".equals(key) || "interval".equals(key) || "delay_ms".equals(key))) ||
           "grow_interval_ms".equals(key) )
      {
        try
        {
          int parsed = Integer.parseInt(value);
          if ( parsed >= 100 && parsed <= 10000 ) return parsed;
        }
        catch ( Exception ignored )
        {
        }
      }
    }
    return defaultValue;
  }

  private String stripGreedyGrowComment(String line)
  {
    if ( line == null ) return "";
    int idx = line.indexOf('#');
    return idx >= 0 ? line.substring(0, idx) : line;
  }

  private String unquoteGreedyGrowValue(String value)
  {
    if ( value == null ) return "";
    String v = value.trim();
    if ( v.length() >= 2 && ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) )
    {
      return v.substring(1, v.length() - 1);
    }
    return v;
  }

  private JPanel createOpenGraphCarouselPanel()
  {
    JPanel root = new JPanel(new BorderLayout(6, 6));
    root.setBackground(Color.white);
    root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

    JPanel north = new JPanel(new BorderLayout(4, 4));
    north.setOpaque(false);

    JPanel titleRow = new JPanel(new BorderLayout(6, 0));
    titleRow.setOpaque(false);
    JLabel title = new JLabel("OpenGraph - uitlegcarrousel");
    title.setFont(title.getFont().deriveFont(Font.BOLD));
    title.setToolTipText("Screenshots in de map opengraph_carousel, met optionele tekstbestanden naast de afbeeldingen.");
    titleRow.add(title, BorderLayout.WEST);

    JPanel navButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
    navButtons.setOpaque(false);
    openGraphCarouselFirstButton = createOpenGraphButton("Eerste", "Ga naar de eerste screenshot", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        goToOpenGraphCarouselSlide(0);
      }
    });
    openGraphCarouselPrevButton = createOpenGraphButton("<", "Vorige screenshot", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        moveOpenGraphCarousel(-1);
      }
    });
    openGraphCarouselNextButton = createOpenGraphButton(">", "Volgende screenshot", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        moveOpenGraphCarousel(1);
      }
    });
    openGraphCarouselLastButton = createOpenGraphButton("Laatste", "Ga naar de laatste screenshot", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        goToOpenGraphCarouselSlide(openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size() - 1);
      }
    });
    openGraphCarouselGoToButton = createOpenGraphButton("Naar...", "Ga naar screenshotnummer", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        goToOpenGraphCarouselSlidePrompt();
      }
    });
    navButtons.add(openGraphCarouselFirstButton);
    navButtons.add(openGraphCarouselPrevButton);
    navButtons.add(openGraphCarouselNextButton);
    navButtons.add(openGraphCarouselLastButton);
    navButtons.add(openGraphCarouselGoToButton);
    titleRow.add(navButtons, BorderLayout.EAST);
    north.add(titleRow, BorderLayout.NORTH);

    JPanel actionButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    actionButtons.setOpaque(false);
    openGraphCarouselAddButton = createOpenGraphButton("Screenshot toevoegen", "Voeg een PNG/JPG/GIF toe aan de OpenGraph-carrousel en geef eigen toelichting.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        addOpenGraphCarouselScreenshot();
      }
    });
    openGraphCarouselDeleteButton = createOpenGraphButton("Verwijder", "Verwijder de huidige screenshot en de bijbehorende tekst uit de carrousel.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        deleteCurrentOpenGraphCarouselSlide();
      }
    });
    openGraphCarouselSaveTextButton = createOpenGraphButton("Tekst opslaan", "Sla de toelichtende tekst van deze screenshot op.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveCurrentOpenGraphCarouselText();
      }
    });
    openGraphCarouselRefreshButton = createOpenGraphButton("Ververs", "Lees de map opengraph_carousel opnieuw in.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        reloadOpenGraphCarouselSlides();
      }
    });
    openGraphCarouselMoveLeftButton = createOpenGraphButton("Plaats <", "Schuif de huidige screenshot één plaats naar voren.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        moveCurrentOpenGraphCarouselSlideBy(-1);
      }
    });
    openGraphCarouselMoveRightButton = createOpenGraphButton("Plaats >", "Schuif de huidige screenshot één plaats naar achteren.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        moveCurrentOpenGraphCarouselSlideBy(1);
      }
    });
    openGraphCarouselMoveToButton = createOpenGraphButton("Verplaats...", "Verplaats de huidige screenshot naar een opgegeven positie.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        moveCurrentOpenGraphCarouselSlideToPrompt();
      }
    });
    openGraphCarouselSwapButton = createOpenGraphButton("Wissel...", "Wissel de huidige screenshot met een opgegeven positie.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        swapCurrentOpenGraphCarouselSlidePrompt();
      }
    });
    openGraphCarouselExportButton = createOpenGraphButton("Export carousel", "Sla de actuele carrouselmap op als zip voor de volgende versie.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        exportOpenGraphCarousel();
      }
    });
    openGraphCarouselImportButton = createOpenGraphButton("Import carousel", "Laad een eerder geëxporteerde carrouselzip in.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        importOpenGraphCarousel();
      }
    });
    openGraphCarouselReminderButton = createOpenGraphButton("Reminder", "Toon de workflow: exporteer carrousel en update git handmatig.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        showOpenGraphCarouselWorkflowReminder();
      }
    });
    actionButtons.add(openGraphCarouselAddButton);
    actionButtons.add(openGraphCarouselDeleteButton);
    actionButtons.add(openGraphCarouselSaveTextButton);
    actionButtons.add(openGraphCarouselRefreshButton);
    actionButtons.add(new JLabel("  Volgorde:"));
    actionButtons.add(openGraphCarouselMoveLeftButton);
    actionButtons.add(openGraphCarouselMoveRightButton);
    actionButtons.add(openGraphCarouselMoveToButton);
    actionButtons.add(openGraphCarouselSwapButton);
    actionButtons.add(new JLabel("  Bestand:"));
    actionButtons.add(openGraphCarouselExportButton);
    actionButtons.add(openGraphCarouselImportButton);
    actionButtons.add(openGraphCarouselReminderButton);
    north.add(actionButtons, BorderLayout.SOUTH);
    root.add(north, BorderLayout.NORTH);

    openGraphCarouselImageLabel = new JLabel("Geen screenshots gevonden.", SwingConstants.CENTER);
    openGraphCarouselImageLabel.setVerticalAlignment(SwingConstants.CENTER);
    openGraphCarouselImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    openGraphCarouselImageLabel.setOpaque(true);
    openGraphCarouselImageLabel.setBackground(Color.white);
    JScrollPane imagePane = new JScrollPane(openGraphCarouselImageLabel,
      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
      JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    imagePane.setBorder(BorderFactory.createLineBorder(Color.lightGray));
    root.add(imagePane, BorderLayout.CENTER);

    JPanel bottom = new JPanel(new BorderLayout(4, 4));
    bottom.setOpaque(false);
    openGraphCarouselStatusLabel = new JLabel(" ");
    bottom.add(openGraphCarouselStatusLabel, BorderLayout.NORTH);
    openGraphCarouselTextArea = new JTextArea(7, 80);
    openGraphCarouselTextArea.setLineWrap(true);
    openGraphCarouselTextArea.setWrapStyleWord(true);
    openGraphCarouselTextArea.setText(defaultOpenGraphCarouselIntroText());
    bottom.add(new JScrollPane(openGraphCarouselTextArea,
      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
      JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
    openGraphCarouselReminderLabel = new JLabel(openGraphCarouselWorkflowReminderShort());
    openGraphCarouselReminderLabel.setForeground(Color.darkGray);
    openGraphCarouselReminderLabel.setToolTipText("Carrouselwijzigingen blijven lokaal. Export carousel en git-update blijven aparte handmatige stappen.");
    bottom.add(openGraphCarouselReminderLabel, BorderLayout.SOUTH);
    root.add(bottom, BorderLayout.SOUTH);

    return root;
  }

  private void showOpenGraphCarousel()
  {
    lastExplicitTreeTypeSelection = STRUCTURE_OPENGRAPH_CAROUSEL;
    if ( graphEditor != null )
    {
      graphEditor.setOpenGraphProjectionContextActive(false);
    }
    if ( editorDeckLayout != null && editorDeckPanel != null )
    {
      reloadOpenGraphCarouselSlidesIfNeeded();
      editorDeckLayout.show(editorDeckPanel, "carousel");
    }
    updateOpenGraphHeaderControlsVisibility();
  }

  private void showGraphEditorCard()
  {
    if ( editorDeckLayout != null && editorDeckPanel != null )
    {
      editorDeckLayout.show(editorDeckPanel, "graph");
    }
  }

  private boolean isOpenGraphCarouselSelected()
  {
    return lastExplicitTreeTypeSelection == STRUCTURE_OPENGRAPH_CAROUSEL;
  }

  private void reloadOpenGraphCarouselSlidesIfNeeded()
  {
    if ( openGraphCarouselSlides == null || openGraphCarouselSlides.size() == 0 )
    {
      reloadOpenGraphCarouselSlides();
    }
    else
    {
      updateOpenGraphCarouselSlide();
    }
  }

  private void reloadOpenGraphCarouselSlides()
  {
    openGraphCarouselSlides = new Vector();
    File dir = openGraphCarouselDirectory(false);
    File[] files = dir != null && dir.exists() ? dir.listFiles() : null;
    if ( files != null )
    {
      Arrays.sort(files, new Comparator()
      {
        public int compare(Object a, Object b)
        {
          return ((File)a).getName().compareToIgnoreCase(((File)b).getName());
        }
      });
      for ( int i=0; i<files.length; i++ )
      {
        File f = files[i];
        if ( f != null && f.isFile() && isOpenGraphCarouselImageFile(f) )
        {
          openGraphCarouselSlides.addElement(new OpenGraphCarouselSlide(f, captionFileForImage(f)));
        }
      }
    }
    if ( openGraphCarouselIndex >= openGraphCarouselSlides.size() )
    {
      openGraphCarouselIndex = Math.max(0, openGraphCarouselSlides.size() - 1);
    }
    updateOpenGraphCarouselSlide();
  }

  private File openGraphCarouselDirectory(boolean create)
  {
    File dir = new File("opengraph_carousel");
    if ( dir.exists() )
    {
      return dir;
    }
    if ( create )
    {
      dir.mkdirs();
      return dir;
    }
    File fallback = new File("examples" + File.separator + "opengraph-carousel");
    if ( fallback.exists() )
    {
      return fallback;
    }
    return dir;
  }

  private boolean isOpenGraphCarouselImageFile(File file)
  {
    String name = file.getName().toLowerCase();
    return name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".gif");
  }

  private File captionFileForImage(File image)
  {
    String name = image.getName();
    int dot = name.lastIndexOf('.');
    String base = dot >= 0 ? name.substring(0, dot) : name;
    return new File(image.getParentFile(), base + ".txt");
  }

  private void moveOpenGraphCarousel(int delta)
  {
    if ( openGraphCarouselSlides == null || openGraphCarouselSlides.size() == 0 )
    {
      return;
    }
    openGraphCarouselIndex += delta;
    if ( openGraphCarouselIndex < 0 ) openGraphCarouselIndex = openGraphCarouselSlides.size() - 1;
    if ( openGraphCarouselIndex >= openGraphCarouselSlides.size() ) openGraphCarouselIndex = 0;
    updateOpenGraphCarouselSlide();
  }

  private void goToOpenGraphCarouselSlide(int index)
  {
    if ( openGraphCarouselSlides == null || openGraphCarouselSlides.size() == 0 )
    {
      return;
    }
    if ( index < 0 ) index = 0;
    if ( index >= openGraphCarouselSlides.size() ) index = openGraphCarouselSlides.size() - 1;
    openGraphCarouselIndex = index;
    updateOpenGraphCarouselSlide();
  }

  private void goToOpenGraphCarouselSlidePrompt()
  {
    int count = openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size();
    if ( count <= 0 ) return;
    Integer number = askOpenGraphCarouselPosition("Ga naar screenshot", openGraphCarouselIndex + 1, count);
    if ( number == null ) return;
    goToOpenGraphCarouselSlide(number.intValue() - 1);
  }

  private Integer askOpenGraphCarouselPosition(String title, int currentValue, int count)
  {
    String answer = JOptionPane.showInputDialog(this,
      "Positie 1 t/m " + count + ":",
      title,
      JOptionPane.QUESTION_MESSAGE);
    if ( answer == null ) return null;
    answer = answer.trim();
    if ( answer.length() == 0 ) return null;
    try
    {
      int pos = Integer.parseInt(answer);
      if ( pos < 1 || pos > count )
      {
        JOptionPane.showMessageDialog(this,
          "Gebruik een getal van 1 t/m " + count + ".",
          "OpenGraph-carrousel", JOptionPane.WARNING_MESSAGE);
        return null;
      }
      return new Integer(pos);
    }
    catch ( NumberFormatException ex )
    {
      JOptionPane.showMessageDialog(this,
        "Geen geldig getal: " + answer,
        "OpenGraph-carrousel", JOptionPane.WARNING_MESSAGE);
      return null;
    }
  }

  private void updateOpenGraphCarouselSlide()
  {
    if ( openGraphCarouselImageLabel == null || openGraphCarouselTextArea == null || openGraphCarouselStatusLabel == null )
    {
      return;
    }
    int count = openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size();
    boolean hasSlide = count > 0;
    boolean hasMultipleSlides = count > 1;
    if ( openGraphCarouselFirstButton != null ) openGraphCarouselFirstButton.setEnabled(hasSlide);
    if ( openGraphCarouselPrevButton != null ) openGraphCarouselPrevButton.setEnabled(hasSlide);
    if ( openGraphCarouselNextButton != null ) openGraphCarouselNextButton.setEnabled(hasSlide);
    if ( openGraphCarouselLastButton != null ) openGraphCarouselLastButton.setEnabled(hasSlide);
    if ( openGraphCarouselGoToButton != null ) openGraphCarouselGoToButton.setEnabled(hasSlide);
    if ( openGraphCarouselDeleteButton != null ) openGraphCarouselDeleteButton.setEnabled(hasSlide);
    if ( openGraphCarouselSaveTextButton != null ) openGraphCarouselSaveTextButton.setEnabled(hasSlide);
    if ( openGraphCarouselMoveLeftButton != null ) openGraphCarouselMoveLeftButton.setEnabled(hasMultipleSlides && openGraphCarouselIndex > 0);
    if ( openGraphCarouselMoveRightButton != null ) openGraphCarouselMoveRightButton.setEnabled(hasMultipleSlides && openGraphCarouselIndex < count - 1);
    if ( openGraphCarouselMoveToButton != null ) openGraphCarouselMoveToButton.setEnabled(hasMultipleSlides);
    if ( openGraphCarouselSwapButton != null ) openGraphCarouselSwapButton.setEnabled(hasMultipleSlides);
    if ( openGraphCarouselExportButton != null ) openGraphCarouselExportButton.setEnabled(true);
    if ( openGraphCarouselImportButton != null ) openGraphCarouselImportButton.setEnabled(true);
    if ( openGraphCarouselReminderButton != null ) openGraphCarouselReminderButton.setEnabled(true);

    if ( !hasSlide )
    {
      clearOpenGraphCarouselImageIcon();
      openGraphCarouselImageLabel.setText("Geen screenshots gevonden in opengraph_carousel.");
      openGraphCarouselTextArea.setText(defaultOpenGraphCarouselIntroText());
      openGraphCarouselStatusLabel.setText("Plaats PNG/JPG/GIF-bestanden in opengraph_carousel, of gebruik Screenshot toevoegen.");
      return;
    }

    if ( openGraphCarouselIndex < 0 ) openGraphCarouselIndex = 0;
    if ( openGraphCarouselIndex >= count ) openGraphCarouselIndex = count - 1;

    OpenGraphCarouselSlide slide = (OpenGraphCarouselSlide)openGraphCarouselSlides.elementAt(openGraphCarouselIndex);
    ImageIcon icon = loadOpenGraphCarouselIcon(slide.imageFile);
    ImageIcon scaled = scaleOpenGraphCarouselIcon(icon);
    openGraphCarouselImageLabel.setText("");
    openGraphCarouselImageLabel.setIcon(scaled);
    openGraphCarouselTextArea.setText(readTextFile(slide.captionFile, defaultCaptionForImage(slide.imageFile)));
    openGraphCarouselTextArea.setCaretPosition(0);
    openGraphCarouselStatusLabel.setText("Screenshot " + (openGraphCarouselIndex + 1) + " / " + count + " - " + slide.imageFile.getName());
  }

  private void clearOpenGraphCarouselImageIcon()
  {
    if ( openGraphCarouselImageLabel == null ) return;
    Icon icon = openGraphCarouselImageLabel.getIcon();
    if ( icon instanceof ImageIcon )
    {
      Image image = ((ImageIcon)icon).getImage();
      if ( image != null ) image.flush();
    }
    openGraphCarouselImageLabel.setIcon(null);
  }

  private ImageIcon loadOpenGraphCarouselIcon(File imageFile)
  {
    if ( imageFile == null )
    {
      return null;
    }
    try
    {
      BufferedImage image = ImageIO.read(imageFile);
      if ( image != null )
      {
        return new ImageIcon(image);
      }
    }
    catch ( IOException ex )
    {
      // Fallback below. The status line already shows the filename; keep the UI usable.
    }
    return new ImageIcon(imageFile.getAbsolutePath());
  }

  private ImageIcon scaleOpenGraphCarouselIcon(ImageIcon icon)
  {
    if ( icon == null || icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0 )
    {
      return icon;
    }
    int maxW = Math.max(420, getWidth() - 70);
    int maxH = Math.max(260, getHeight() - 260);
    int w = icon.getIconWidth();
    int h = icon.getIconHeight();
    double scale = Math.min((double)maxW / (double)w, (double)maxH / (double)h);
    if ( scale >= 1.0 ) return icon;
    int sw = Math.max(1, (int)Math.round(w * scale));
    int sh = Math.max(1, (int)Math.round(h * scale));
    return new ImageIcon(icon.getImage().getScaledInstance(sw, sh, Image.SCALE_SMOOTH));
  }

  private String readTextFile(File file, String fallback)
  {
    if ( file == null || !file.exists() )
    {
      return fallback;
    }
    try
    {
      StringBuffer text = new StringBuffer();
      InputStreamReader reader = new InputStreamReader(new FileInputStream(file), "UTF-8");
      try
      {
        char[] buf = new char[2048];
        int n;
        while ( (n = reader.read(buf)) >= 0 )
        {
          text.append(buf, 0, n);
        }
      }
      finally
      {
        reader.close();
      }
      return text.toString();
    }
    catch ( IOException ex )
    {
      return fallback + "\n\n[Kon toelichting niet lezen: " + ex.getMessage() + "]";
    }
  }

  private void writeTextFile(File file, String text) throws IOException
  {
    OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
    try
    {
      writer.write(text == null ? "" : text);
    }
    finally
    {
      writer.close();
    }
  }

  private String openGraphCarouselWorkflowReminderShort()
  {
    return "Reminder: na carrouselwijzigingen: Export carousel. Upload die zip hier mee bij je volgende verzoek. Git-update blijft handwerk: git add / commit / push.";
  }

  private String openGraphCarouselWorkflowReminderText()
  {
    return "Workflow voor de volgende versie:\n\n" +
           "1. Werk de carrousel bij: toevoegen, verwijderen, verplaatsen, wisselen, tekst opslaan.\n" +
           "2. Klik Export carousel en bewaar de zip. Upload die zip hier mee bij je volgende verzoek, zodat de actuele carrouselstand in de volgende zipversie meegenomen kan worden.\n" +
           "3. Update git handmatig. De app doet geen git add/commit/push.\n\n" +
           "Handmatig voorbeeld:\n" +
           "git add opengraph_carousel\n" +
           "git commit -m \"update opengraph carousel\"\n" +
           "git push";
  }

  private void showOpenGraphCarouselWorkflowReminder()
  {
    JOptionPane.showMessageDialog(this,
      openGraphCarouselWorkflowReminderText(),
      "OpenGraph-carrousel reminder",
      JOptionPane.INFORMATION_MESSAGE);
  }

  private void markOpenGraphCarouselChanged(String action)
  {
    if ( openGraphCarouselReminderLabel != null )
    {
      openGraphCarouselReminderLabel.setText(openGraphCarouselWorkflowReminderShort());
    }
    if ( openGraphCarouselStatusLabel != null )
    {
      String prefix = action == null || action.length() == 0 ? "Carrousel gewijzigd" : action;
      openGraphCarouselStatusLabel.setText(prefix + ". Reminder: Export carousel; upload die zip hier mee bij je volgende verzoek; daarna git handmatig updaten.");
    }
  }

  private String carouselTimestamp()
  {
    return new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
  }

  private boolean isOpenGraphCarouselTextFile(File file)
  {
    return file != null && file.isFile() && file.getName().toLowerCase().endsWith(".txt");
  }

  private boolean isOpenGraphCarouselReadmeFile(File file)
  {
    return file != null && file.isFile() && file.getName().equalsIgnoreCase("README.txt");
  }

  private boolean isAllowedOpenGraphCarouselExportFile(File file)
  {
    return file != null && file.isFile() &&
      (isOpenGraphCarouselImageFile(file) || isOpenGraphCarouselTextFile(file) || isOpenGraphCarouselReadmeFile(file));
  }

  private void exportOpenGraphCarousel()
  {
    saveCurrentOpenGraphCarouselTextSilently();
    File dir = openGraphCarouselDirectory(false);
    if ( dir == null || !dir.exists() )
    {
      JOptionPane.showMessageDialog(this,
        "Geen carrouselmap gevonden om te exporteren.",
        "Export carousel", JOptionPane.WARNING_MESSAGE);
      return;
    }

    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Export carousel");
    chooser.setSelectedFile(new File("opengraph_carousel_export_" + carouselTimestamp() + ".zip"));
    int result = chooser.showSaveDialog(this);
    if ( result != JFileChooser.APPROVE_OPTION ) return;
    File target = chooser.getSelectedFile();
    if ( target == null ) return;
    if ( !target.getName().toLowerCase().endsWith(".zip") )
    {
      target = new File(target.getParentFile(), target.getName() + ".zip");
    }
    if ( target.exists() )
    {
      int answer = JOptionPane.showConfirmDialog(this,
        "Bestand bestaat al. Overschrijven?\n\n" + target.getAbsolutePath(),
        "Export carousel", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
      if ( answer != JOptionPane.YES_OPTION ) return;
    }

    try
    {
      exportOpenGraphCarouselToZip(dir, target);
      openGraphCarouselStatusLabel.setText("Carousel geëxporteerd: " + target.getName() + ". Upload die zip hier mee bij je volgende verzoek. Vergeet git-update niet.");
      JOptionPane.showMessageDialog(this,
        "Carousel geëxporteerd:\n" + target.getAbsolutePath() + "\n\n" +
        "Reminder: upload die zip hier mee bij je volgende verzoek, zodat de carrouselstand in de volgende zipversie meegaat. Git-update blijft handwerk.",
        "Export carousel", JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( IOException ex )
    {
      JOptionPane.showMessageDialog(this,
        "Export mislukt:\n" + ex.getMessage(),
        "Export carousel", JOptionPane.ERROR_MESSAGE);
    }
  }

  private void exportOpenGraphCarouselToZip(File dir, File target) throws IOException
  {
    ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(target));
    try
    {
      File[] files = dir.listFiles();
      if ( files == null ) return;
      Arrays.sort(files, new Comparator()
      {
        public int compare(Object a, Object b)
        {
          return ((File)a).getName().compareToIgnoreCase(((File)b).getName());
        }
      });
      byte[] buffer = new byte[8192];
      for ( int i=0; i<files.length; i++ )
      {
        File file = files[i];
        if ( !isAllowedOpenGraphCarouselExportFile(file) ) continue;
        ZipEntry entry = new ZipEntry("opengraph_carousel/" + file.getName());
        zip.putNextEntry(entry);
        FileInputStream in = new FileInputStream(file);
        try
        {
          int n;
          while ( (n = in.read(buffer)) >= 0 )
          {
            zip.write(buffer, 0, n);
          }
        }
        finally
        {
          in.close();
        }
        zip.closeEntry();
      }
    }
    finally
    {
      zip.close();
    }
  }

  private void importOpenGraphCarousel()
  {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Import carousel");
    int result = chooser.showOpenDialog(this);
    if ( result != JFileChooser.APPROVE_OPTION ) return;
    File source = chooser.getSelectedFile();
    if ( source == null || !source.exists() ) return;
    if ( !source.getName().toLowerCase().endsWith(".zip") )
    {
      JOptionPane.showMessageDialog(this,
        "Kies een .zip-bestand dat met Export carousel is gemaakt.",
        "Import carousel", JOptionPane.WARNING_MESSAGE);
      return;
    }

    int answer = JOptionPane.showConfirmDialog(this,
      "Import vervangt de huidige carrouselbestanden.\n\nMaak eerst Export carousel als je de huidige stand wilt bewaren.\n\nImporteren?",
      "Import carousel", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    if ( answer != JOptionPane.YES_OPTION ) return;

    File dir = openGraphCarouselDirectory(true);
    try
    {
      clearOpenGraphCarouselImageIcon();
      deleteAllOpenGraphCarouselFiles(dir);
      importOpenGraphCarouselFromZip(source, dir);
      openGraphCarouselIndex = 0;
      reloadOpenGraphCarouselSlides();
      markOpenGraphCarouselChanged("Carousel geïmporteerd");
    }
    catch ( IOException ex )
    {
      JOptionPane.showMessageDialog(this,
        "Import mislukt:\n" + ex.getMessage(),
        "Import carousel", JOptionPane.ERROR_MESSAGE);
      reloadOpenGraphCarouselSlides();
    }
  }

  private void importOpenGraphCarouselFromZip(File source, File dir) throws IOException
  {
    if ( dir == null ) throw new IOException("Carrouselmap ontbreekt.");
    if ( !dir.exists() && !dir.mkdirs() ) throw new IOException("Kon carrouselmap niet maken.");
    ZipInputStream zip = new ZipInputStream(new FileInputStream(source));
    try
    {
      ZipEntry entry;
      while ( (entry = zip.getNextEntry()) != null )
      {
        if ( entry.isDirectory() )
        {
          zip.closeEntry();
          continue;
        }
        String entryName = entry.getName();
        entryName = entryName.replace('\\', '/');
        int slash = entryName.lastIndexOf('/');
        String fileName = slash >= 0 ? entryName.substring(slash + 1) : entryName;
        fileName = sanitizeImportedCarouselFileName(fileName);
        if ( fileName.length() == 0 )
        {
          zip.closeEntry();
          continue;
        }
        File target = new File(dir, fileName);
        if ( !(isOpenGraphCarouselImageFile(target) || isOpenGraphCarouselTextFile(target) || isOpenGraphCarouselReadmeFile(target)) )
        {
          zip.closeEntry();
          continue;
        }
        FileOutputStream out = new FileOutputStream(target);
        try
        {
          byte[] buffer = new byte[8192];
          int n;
          while ( (n = zip.read(buffer)) >= 0 )
          {
            out.write(buffer, 0, n);
          }
        }
        finally
        {
          out.close();
        }
        zip.closeEntry();
      }
    }
    finally
    {
      zip.close();
    }
  }

  private String sanitizeImportedCarouselFileName(String name)
  {
    if ( name == null ) return "";
    StringBuffer clean = new StringBuffer();
    for ( int i=0; i<name.length(); i++ )
    {
      char ch = name.charAt(i);
      if ( Character.isLetterOrDigit(ch) || ch == '-' || ch == '_' || ch == '.' || ch == ' ' )
      {
        clean.append(ch);
      }
      else
      {
        clean.append('_');
      }
    }
    return clean.toString().trim();
  }

  private void deleteAllOpenGraphCarouselFiles(File dir) throws IOException
  {
    File[] files = dir == null ? null : dir.listFiles();
    if ( files == null ) return;
    for ( int i=0; i<files.length; i++ )
    {
      File file = files[i];
      if ( file != null && file.isFile() && isAllowedOpenGraphCarouselExportFile(file) )
      {
        if ( !file.delete() )
        {
          throw new IOException("Kon oud carrouselbestand niet verwijderen: " + file.getName());
        }
      }
    }
  }

  private String defaultOpenGraphCarouselIntroText()
  {
    return "OpenGraph-carrousel\n\n" +
           "Deze carrousel is bedoeld als uitlegscherm in de editor. Voeg screenshots toe van de OpenGraph-notatie en schrijf per screenshot een toelichting.\n\n" +
           "Standaardfuncties:\n" +
           "- navigeren: eerste, vorige, volgende, laatste, ga naar nummer;\n" +
           "- beheren: screenshot toevoegen, verwijderen, tekst opslaan, verversen;\n" +
           "- ordenen: één plaats naar voren/achteren, verplaatsen naar positie, wisselen met positie;\n" +
           "- bestand: Export carousel en Import carousel voor overdracht naar een volgende zipversie.\n\n" +
           "Reminder:\n" +
           "Na carrouselwijzigingen: klik Export carousel. Upload die zip hier mee bij je volgende verzoek. De git-update blijft handwerk: git add, git commit, git push.\n\n" +
           "Plan:\n" +
           "1. Simpele vertakking: één level, met varianten.\n" +
           "2. Projectie naar links: eerst zonder naam, als kale lijn met kopieën van knopen.\n" +
           "3. Daarna projectienamen, meerdere projectierichtingen en taalboomvoorbeelden.";
  }

  private String defaultCaptionForImage(File imageFile)
  {
    return "Toelichting bij " + imageFile.getName() + "\n\n" +
           "Beschrijf hier wat de student in deze screenshot moet zien: de vrije knopen, de vertakking, de projectielijn of de relatie met de klassieke boomnotatie.";
  }

  private void saveCurrentOpenGraphCarouselText()
  {
    if ( saveCurrentOpenGraphCarouselTextSilently() )
    {
      OpenGraphCarouselSlide slide = (OpenGraphCarouselSlide)openGraphCarouselSlides.elementAt(openGraphCarouselIndex);
      markOpenGraphCarouselChanged("Tekst opgeslagen: " + slide.captionFile.getName());
    }
  }

  private boolean saveCurrentOpenGraphCarouselTextSilently()
  {
    if ( openGraphCarouselSlides == null || openGraphCarouselSlides.size() == 0 )
    {
      return false;
    }
    OpenGraphCarouselSlide slide = (OpenGraphCarouselSlide)openGraphCarouselSlides.elementAt(openGraphCarouselIndex);
    try
    {
      writeTextFile(slide.captionFile, openGraphCarouselTextArea == null ? "" : openGraphCarouselTextArea.getText());
      return true;
    }
    catch ( IOException ex )
    {
      JOptionPane.showMessageDialog(this,
        "Toelichting kon niet worden opgeslagen:\n" + ex.getMessage(),
        "OpenGraph-carrousel", JOptionPane.ERROR_MESSAGE);
      return false;
    }
  }

  private void addOpenGraphCarouselScreenshot()
  {
    saveCurrentOpenGraphCarouselTextSilently();
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Screenshot toevoegen aan OpenGraph-carrousel");
    int result = chooser.showOpenDialog(this);
    if ( result != JFileChooser.APPROVE_OPTION )
    {
      return;
    }
    File selected = chooser.getSelectedFile();
    if ( selected == null || !selected.exists() || !isOpenGraphCarouselImageFile(selected) )
    {
      JOptionPane.showMessageDialog(this,
        "Kies een PNG/JPG/GIF-bestand.",
        "OpenGraph-carrousel", JOptionPane.WARNING_MESSAGE);
      return;
    }

    File dir = openGraphCarouselDirectory(true);
    File target = uniqueCarouselTargetFile(dir, selected.getName());
    try
    {
      reloadOpenGraphCarouselSlides();
      copyFile(selected, target);
      JTextArea text = new JTextArea(defaultCaptionForImage(target), 9, 60);
      text.setLineWrap(true);
      text.setWrapStyleWord(true);
      int answer = JOptionPane.showConfirmDialog(this,
        new JScrollPane(text),
        "Toelichting bij screenshot",
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.PLAIN_MESSAGE);
      if ( answer == JOptionPane.OK_OPTION )
      {
        writeTextFile(captionFileForImage(target), text.getText());
      }
      Vector ordered = cloneOpenGraphCarouselSlides();
      ordered.addElement(new OpenGraphCarouselSlide(target, captionFileForImage(target)));
      persistOpenGraphCarouselOrder(ordered, ordered.size() - 1);
    }
    catch ( IOException ex )
    {
      JOptionPane.showMessageDialog(this,
        "Screenshot kon niet worden toegevoegd:\n" + ex.getMessage(),
        "OpenGraph-carrousel", JOptionPane.ERROR_MESSAGE);
    }
  }

  private void deleteCurrentOpenGraphCarouselSlide()
  {
    int count = openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size();
    if ( count <= 0 ) return;
    OpenGraphCarouselSlide slide = (OpenGraphCarouselSlide)openGraphCarouselSlides.elementAt(openGraphCarouselIndex);
    int answer = JOptionPane.showConfirmDialog(this,
      "Verwijder deze screenshot uit de carrousel?\n\n" + slide.imageFile.getName(),
      "OpenGraph-carrousel",
      JOptionPane.YES_NO_OPTION,
      JOptionPane.WARNING_MESSAGE);
    if ( answer != JOptionPane.YES_OPTION ) return;

    clearOpenGraphCarouselImageIcon();
    Vector ordered = cloneOpenGraphCarouselSlides();
    ordered.removeElementAt(openGraphCarouselIndex);
    boolean imageDeleted = deleteFileIfExists(slide.imageFile);
    boolean captionDeleted = deleteFileIfExists(slide.captionFile);
    if ( !imageDeleted || !captionDeleted )
    {
      JOptionPane.showMessageDialog(this,
        "Niet alle bestanden konden worden verwijderd. Controleer de map opengraph_carousel.",
        "OpenGraph-carrousel", JOptionPane.WARNING_MESSAGE);
    }
    if ( ordered.size() == 0 )
    {
      openGraphCarouselIndex = 0;
      reloadOpenGraphCarouselSlides();
      markOpenGraphCarouselChanged("Screenshot verwijderd");
      return;
    }
    int newIndex = openGraphCarouselIndex;
    if ( newIndex >= ordered.size() ) newIndex = ordered.size() - 1;
    persistOpenGraphCarouselOrder(ordered, newIndex);
  }

  private boolean deleteFileIfExists(File file)
  {
    if ( file == null || !file.exists() ) return true;
    return file.delete();
  }

  private void moveCurrentOpenGraphCarouselSlideBy(int delta)
  {
    saveCurrentOpenGraphCarouselTextSilently();
    int count = openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size();
    if ( count <= 1 ) return;
    int target = openGraphCarouselIndex + delta;
    if ( target < 0 || target >= count ) return;
    Vector ordered = cloneOpenGraphCarouselSlides();
    Object item = ordered.elementAt(openGraphCarouselIndex);
    ordered.removeElementAt(openGraphCarouselIndex);
    ordered.insertElementAt(item, target);
    persistOpenGraphCarouselOrder(ordered, target);
  }

  private void moveCurrentOpenGraphCarouselSlideToPrompt()
  {
    saveCurrentOpenGraphCarouselTextSilently();
    int count = openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size();
    if ( count <= 1 ) return;
    Integer number = askOpenGraphCarouselPosition("Verplaats screenshot", openGraphCarouselIndex + 1, count);
    if ( number == null ) return;
    int target = number.intValue() - 1;
    if ( target == openGraphCarouselIndex ) return;
    Vector ordered = cloneOpenGraphCarouselSlides();
    Object item = ordered.elementAt(openGraphCarouselIndex);
    ordered.removeElementAt(openGraphCarouselIndex);
    ordered.insertElementAt(item, target);
    persistOpenGraphCarouselOrder(ordered, target);
  }

  private void swapCurrentOpenGraphCarouselSlidePrompt()
  {
    saveCurrentOpenGraphCarouselTextSilently();
    int count = openGraphCarouselSlides == null ? 0 : openGraphCarouselSlides.size();
    if ( count <= 1 ) return;
    Integer number = askOpenGraphCarouselPosition("Wissel met screenshot", openGraphCarouselIndex + 1, count);
    if ( number == null ) return;
    int target = number.intValue() - 1;
    if ( target == openGraphCarouselIndex ) return;
    Vector ordered = cloneOpenGraphCarouselSlides();
    Object current = ordered.elementAt(openGraphCarouselIndex);
    Object other = ordered.elementAt(target);
    ordered.setElementAt(other, openGraphCarouselIndex);
    ordered.setElementAt(current, target);
    persistOpenGraphCarouselOrder(ordered, target);
  }

  private Vector cloneOpenGraphCarouselSlides()
  {
    Vector ordered = new Vector();
    if ( openGraphCarouselSlides != null )
    {
      for ( int i=0; i<openGraphCarouselSlides.size(); i++ )
      {
        ordered.addElement(openGraphCarouselSlides.elementAt(i));
      }
    }
    return ordered;
  }

  private void persistOpenGraphCarouselOrder(Vector orderedSlides, int selectedIndex)
  {
    if ( orderedSlides == null ) return;
    clearOpenGraphCarouselImageIcon();
    System.gc();

    File dir = openGraphCarouselDirectory(true);
    if ( dir == null ) return;
    if ( !dir.exists() && !dir.mkdirs() )
    {
      JOptionPane.showMessageDialog(this,
        "Carrouselmap kon niet worden gemaakt:\n" + dir.getAbsolutePath(),
        "OpenGraph-carrousel", JOptionPane.ERROR_MESSAGE);
      return;
    }

    File tempDir = new File(dir, "__opengraph_carousel_reorder_" + System.currentTimeMillis());
    try
    {
      if ( !tempDir.mkdirs() )
      {
        throw new IOException("Kon tijdelijke map niet maken: " + tempDir.getName());
      }

      Vector usedBases = new Vector();
      for ( int i=0; i<orderedSlides.size(); i++ )
      {
        OpenGraphCarouselSlide oldSlide = (OpenGraphCarouselSlide)orderedSlides.elementAt(i);
        String ext = extensionOf(oldSlide.imageFile.getName());
        String base = baseNameWithoutExtension(oldSlide.imageFile.getName());
        base = stripCarouselOrderPrefix(base);
        base = sanitizeCarouselBase(base);
        if ( base.length() == 0 ) base = "screenshot";
        String numberedBase = uniqueCarouselOrderedBase(formatCarouselOrderNumber(i + 1) + "-" + base, usedBases);

        File tempImage = new File(tempDir, numberedBase + ext);
        File tempCaption = new File(tempDir, numberedBase + ".txt");
        copyFile(oldSlide.imageFile, tempImage);
        if ( oldSlide.captionFile != null && oldSlide.captionFile.exists() )
        {
          copyFile(oldSlide.captionFile, tempCaption);
        }
      }

      deleteAllOpenGraphCarouselImageAndCaptionFiles(dir);

      File[] tempFiles = tempDir.listFiles();
      if ( tempFiles != null )
      {
        for ( int i=0; i<tempFiles.length; i++ )
        {
          File source = tempFiles[i];
          if ( source != null && source.isFile() )
          {
            File target = new File(dir, source.getName());
            moveFile(source, target);
          }
        }
      }

      deleteDirectoryIfEmpty(tempDir);
      openGraphCarouselIndex = selectedIndex;
      reloadOpenGraphCarouselSlides();
      markOpenGraphCarouselChanged("Carrouselvolgorde opgeslagen");
    }
    catch ( IOException ex )
    {
      JOptionPane.showMessageDialog(this,
        "Volgorde kon niet worden opgeslagen. De carrouselmap is niet gedeeltelijk hernummerd.\n" + ex.getMessage(),
        "OpenGraph-carrousel", JOptionPane.ERROR_MESSAGE);
      deleteDirectoryRecursive(tempDir);
      reloadOpenGraphCarouselSlides();
    }
  }

  private void deleteAllOpenGraphCarouselImageAndCaptionFiles(File dir) throws IOException
  {
    File[] files = dir == null ? null : dir.listFiles();
    if ( files == null ) return;
    for ( int i=0; i<files.length; i++ )
    {
      File file = files[i];
      if ( file != null && file.isFile() && isOpenGraphCarouselImageFile(file) )
      {
        File caption = captionFileForImage(file);
        if ( caption.exists() && !caption.delete() )
        {
          throw new IOException("Kon oud tekstbestand niet verwijderen: " + caption.getName());
        }
        if ( !file.delete() )
        {
          throw new IOException("Kon oud screenshotbestand niet verwijderen: " + file.getName());
        }
      }
    }
  }

  private void deleteDirectoryIfEmpty(File dir) throws IOException
  {
    if ( dir == null || !dir.exists() ) return;
    if ( !dir.delete() )
    {
      throw new IOException("Kon tijdelijke map niet verwijderen: " + dir.getName());
    }
  }

  private void deleteDirectoryRecursive(File dir)
  {
    if ( dir == null || !dir.exists() ) return;
    File[] files = dir.listFiles();
    if ( files != null )
    {
      for ( int i=0; i<files.length; i++ )
      {
        File file = files[i];
        if ( file != null && file.isDirectory() )
        {
          deleteDirectoryRecursive(file);
        }
        else if ( file != null )
        {
          file.delete();
        }
      }
    }
    dir.delete();
  }

  private String formatCarouselOrderNumber(int n)
  {
    if ( n < 10 ) return "00" + n;
    if ( n < 100 ) return "0" + n;
    return String.valueOf(n);
  }

  private String uniqueCarouselOrderedBase(String base, Vector usedBases)
  {
    String candidate = base;
    int n = 2;
    while ( containsStringIgnoreCase(usedBases, candidate) )
    {
      candidate = base + "-" + n;
      n++;
    }
    usedBases.addElement(candidate);
    return candidate;
  }

  private boolean containsStringIgnoreCase(Vector items, String value)
  {
    if ( items == null ) return false;
    for ( int i=0; i<items.size(); i++ )
    {
      Object item = items.elementAt(i);
      if ( item != null && item.toString().equalsIgnoreCase(value) ) return true;
    }
    return false;
  }

  private String stripCarouselOrderPrefix(String base)
  {
    if ( base == null ) return "";
    if ( base.length() >= 4 && Character.isDigit(base.charAt(0)) && Character.isDigit(base.charAt(1)) && Character.isDigit(base.charAt(2)) && (base.charAt(3) == '-' || base.charAt(3) == '_') )
    {
      return base.substring(4);
    }
    if ( base.length() >= 3 && Character.isDigit(base.charAt(0)) && Character.isDigit(base.charAt(1)) && (base.charAt(2) == '-' || base.charAt(2) == '_') )
    {
      return base.substring(3);
    }
    return base;
  }

  private String sanitizeCarouselBase(String base)
  {
    if ( base == null ) return "";
    StringBuffer clean = new StringBuffer();
    for ( int i=0; i<base.length(); i++ )
    {
      char ch = base.charAt(i);
      if ( Character.isLetterOrDigit(ch) || ch == '-' || ch == '_' )
      {
        clean.append(ch);
      }
      else
      {
        clean.append('_');
      }
    }
    return clean.toString();
  }

  private String baseNameWithoutExtension(String name)
  {
    if ( name == null ) return "";
    int dot = name.lastIndexOf('.');
    return dot >= 0 ? name.substring(0, dot) : name;
  }

  private String extensionOf(String name)
  {
    if ( name == null ) return ".png";
    int dot = name.lastIndexOf('.');
    if ( dot < 0 ) return ".png";
    return name.substring(dot);
  }

  private void moveFile(File source, File target) throws IOException
  {
    if ( source == null || target == null ) throw new IOException("Bron of doel ontbreekt.");
    if ( target.exists() && !target.delete() )
    {
      throw new IOException("Kon bestaand doelbestand niet verwijderen: " + target.getName());
    }
    if ( source.renameTo(target) ) return;
    copyFile(source, target);
    if ( !source.delete() )
    {
      throw new IOException("Kon bronbestand niet verwijderen na kopiëren: " + source.getName());
    }
  }

  private File uniqueCarouselTargetFile(File dir, String originalName)
  {
    String clean = originalName == null ? "screenshot.png" : originalName.replace(' ', '_');
    File target = new File(dir, clean);
    if ( !target.exists() ) return target;
    int dot = clean.lastIndexOf('.');
    String base = dot >= 0 ? clean.substring(0, dot) : clean;
    String ext = dot >= 0 ? clean.substring(dot) : ".png";
    int n = 2;
    while ( target.exists() )
    {
      target = new File(dir, base + "-" + n + ext);
      n++;
    }
    return target;
  }

  private void copyFile(File source, File target) throws IOException
  {
    FileInputStream in = new FileInputStream(source);
    try
    {
      FileOutputStream out = new FileOutputStream(target);
      try
      {
        byte[] buffer = new byte[8192];
        int n;
        while ( (n = in.read(buffer)) >= 0 )
        {
          out.write(buffer, 0, n);
        }
      }
      finally
      {
        out.close();
      }
    }
    finally
    {
      in.close();
    }
  }

  private void selectCarouselFile(File target)
  {
    for ( int i=0; openGraphCarouselSlides != null && i<openGraphCarouselSlides.size(); i++ )
    {
      OpenGraphCarouselSlide slide = (OpenGraphCarouselSlide)openGraphCarouselSlides.elementAt(i);
      if ( slide.imageFile.equals(target) )
      {
        openGraphCarouselIndex = i;
        updateOpenGraphCarouselSlide();
        return;
      }
    }
  }

  private static class OpenGraphCarouselSlide
  {
    final File imageFile;
    final File captionFile;

    OpenGraphCarouselSlide(File imageFile, File captionFile)
    {
      this.imageFile = imageFile;
      this.captionFile = captionFile;
    }
  }

  private void openLanguageTreeSettingsDialog()
  {
    if ( graphEditor == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      settings = OpenGraphProjectionSupport.loadBestAvailableForStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    }
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);

    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

    JTextArea intro = new JTextArea(
      "Language Tree settings\n" +
      "Deze instellingen gelden specifiek voor Language Tree / Phrase.\n" +
      "Zinstypeknoppen tekenen direct; deze settings worden opgeslagen en gebruikt bij de volgende Language Tree draw."
    );
    intro.setEditable(false);
    intro.setOpaque(false);
    intro.setLineWrap(true);
    intro.setWrapStyleWord(true);
    root.add(intro, BorderLayout.NORTH);

    JPanel form = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(3, 3, 3, 3);
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 1.0;

    int row = 0;
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 1;
    form.add(new JLabel("V-cluster:"), c);

    JPanel verbPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    final JRadioButton pvVd = new JRadioButton("pv-VD  heeft gebeten");
    final JRadioButton vdPv = new JRadioButton("VD-pv  gebeten heeft");
    ButtonGroup group = new ButtonGroup();
    group.add(pvVd);
    group.add(vdPv);
    if ( OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV.equals(settings.getLanguageTreeVerbClusterOrder()) )
    {
      vdPv.setSelected(true);
    }
    else
    {
      pvVd.setSelected(true);
    }
    verbPanel.add(pvVd);
    verbPanel.add(vdPv);
    c.gridx = 1;
    c.gridy = row++;
    form.add(verbPanel, c);

    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("Projecties:"), c);
    final JCheckBox show = new JCheckBox("toon projecties", settings.getShowProjections());
    c.gridx = 1;
    c.gridy = row++;
    form.add(show, c);

    final JCheckBox leftEnabled = new JCheckBox("links", settings.getLeftProjectionEnabled());
    final JTextField leftCaption = new JTextField(settings.getLeftProjectionCaption(), 8);
    JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    leftPanel.add(leftEnabled);
    leftPanel.add(new JLabel("caption:"));
    leftPanel.add(leftCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("LEX-as:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(leftPanel, c);

    final JCheckBox rightEnabled = new JCheckBox("rechts", settings.getRightProjectionEnabled());
    final JTextField rightCaption = new JTextField(settings.getRightProjectionCaption(), 8);
    JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    rightPanel.add(rightEnabled);
    rightPanel.add(new JLabel("caption:"));
    rightPanel.add(rightCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("SYNT-as:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(rightPanel, c);

    final JCheckBox topEnabled = new JCheckBox("boven", settings.getTopProjectionEnabled());
    final JTextField topCaption = new JTextField(settings.getTopProjectionCaption(), 8);
    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    topPanel.add(topEnabled);
    topPanel.add(new JLabel("caption:"));
    topPanel.add(topCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("boven:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(topPanel, c);

    final JCheckBox bottomEnabled = new JCheckBox("onder", settings.getBottomProjectionEnabled());
    final JTextField bottomCaption = new JTextField(settings.getBottomProjectionCaption(), 8);
    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    bottomPanel.add(bottomEnabled);
    bottomPanel.add(new JLabel("caption:"));
    bottomPanel.add(bottomCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("onder:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(bottomPanel, c);

    root.add(form, BorderLayout.CENTER);

    int answer = JOptionPane.showConfirmDialog(this, root, "Language Tree settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if ( answer != JOptionPane.OK_OPTION )
    {
      return;
    }

    settings.setLanguageTreeVerbClusterOrder(vdPv.isSelected() ? OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV : OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD);
    settings.setShowProjections(show.isSelected());
    settings.setLeftProjectionEnabled(leftEnabled.isSelected());
    settings.setRightProjectionEnabled(rightEnabled.isSelected());
    settings.setTopProjectionEnabled(topEnabled.isSelected());
    settings.setBottomProjectionEnabled(bottomEnabled.isSelected());
    settings.setLeftProjectionCaption(leftCaption.getText());
    settings.setRightProjectionCaption(rightCaption.getText());
    settings.setTopProjectionCaption(topCaption.getText());
    settings.setBottomProjectionCaption(bottomCaption.getText());
    settings.normalize();

    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(true);
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.update();
    updateOpenGraphHeaderControls();
    saveProjectionProfile(settings);
  }



  public void openFunctionalTreeSettingsDialog()
  {
    final Properties props = loadFunctionalTreeProperties();

    final JCheckBox autoDetect = new JCheckBox("Auto-detect FT by top label", boolProp(props, "functional.layout.autoDetect.enabled", true));
    final JCheckBox syntaxProposal = new JCheckBox("Maak thematisch voorstel uit syntaxis (S/NP/VP)", boolProp(props, "functional.layout.syntaxProposal.enabled", true));
    final JTextField autoLabels = new JTextField(strProp(props, "functional.layout.autoDetectTopLabels", "S,CLAUSE,V"), 22);
    final java.util.LinkedHashMap coreRoleChecks = createFunctionalRoleChecklist(props, "functional.layout.coreRoles", true);
    final java.util.LinkedHashMap frameRoleChecks = createFunctionalRoleChecklist(props, "functional.layout.frameRoles", false);
    connectFunctionalRoleChecklistExclusion(coreRoleChecks, frameRoleChecks);
    final JCheckBox frameEnabled = new JCheckBox("Put frame roles in FRAME", boolProp(props, "functional.layout.frame.enabled", true));
    final JCheckBox frameVisible = new JCheckBox("Show frame roles in main FT tree", boolProp(props, "functional.layout.frameRolesVisibleInMainTree", false));
    final JTextField frameCaption = new JTextField(strProp(props, "functional.layout.frame.caption", "FRAME"), 12);
    final JSpinner verticalStep = new JSpinner(new SpinnerNumberModel(intProp(props, "functional.layout.verticalStep", 1), 1, 20, 1));
    final JSpinner verticalStart = new JSpinner(new SpinnerNumberModel(intProp(props, "functional.layout.verticalStart", 2), 0, 50, 1));
    final JComboBox horizontalSpread = new JComboBox(new String[] { "compact", "medium", "wide" });
    horizontalSpread.setSelectedItem(strProp(props, "functional.layout.horizontalSpread", "compact"));

    final JPanel coreRolesPanel = createFunctionalRoleHierarchyPanel(coreRoleChecks);
    final JPanel frameRolesPanel = createFunctionalRoleHierarchyPanel(frameRoleChecks);
    final JTable ftNodesTable = createFunctionalTreeNodesTable();

    JTabbedPane tabs = new JTabbedPane();
    JPanel basis = new JPanel(new GridBagLayout());
    basis.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(3, 3, 3, 3);
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 1.0;
    int row = 0;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(autoDetect, c); row++;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(syntaxProposal, c); row++;
    addFTDialogRow(basis, c, row++, "Auto labels", autoLabels);
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(new JLabel("Voorstel: S/CLAUSE/V=action; eerste NP/DP=agens; NP/DP onder VP/V=patiens; PP=Frame."), c); row++;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(frameEnabled, c); row++;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(frameVisible, c); row++;
    addFTDialogRow(basis, c, row++, "Frame caption", frameCaption);
    addFTDialogRow(basis, c, row++, "Vertical step", verticalStep);
    addFTDialogRow(basis, c, row++, "Vertical start", verticalStart);
    addFTDialogRow(basis, c, row++, "Horizontal spread", horizontalSpread);

    JPanel roles = new JPanel(new BorderLayout(6, 6));
    roles.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JTextArea roleInfo = new JTextArea("Rollen worden gekozen met vinklijsten in FT Basis.\nCore = hoofdrollen in compacte FT-boom.\nFrame = omstandigheden/adjuncten voor FRAME.");
    roleInfo.setEditable(false);
    roleInfo.setOpaque(false);
    roleInfo.setLineWrap(true);
    roleInfo.setWrapStyleWord(true);
    roles.add(roleInfo, BorderLayout.NORTH);
    roles.add(new JScrollPane(createFunctionalRoleOverviewPanel(coreRoleChecks, frameRoleChecks)), BorderLayout.CENTER);

    JPanel nodePanel = new JPanel(new BorderLayout(6, 6));
    nodePanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    nodePanel.add(new JLabel("Niet-eindknopen: Default FT is voorstel; Override FT past de knoop aan."), BorderLayout.NORTH);
    nodePanel.add(new JScrollPane(ftNodesTable), BorderLayout.CENTER);

    tabs.addTab("FT Basis", basis);
    tabs.addTab("FT Rollen", roles);
    tabs.addTab("FT Nodes", nodePanel);

    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JLabel intro = new JLabel("Functional Tree settings - vink rollen aan per hiërarchie; Save activeert de volgende Draw.");
    root.add(intro, BorderLayout.NORTH);
    root.add(tabs, BorderLayout.CENTER);
    root.setPreferredSize(new Dimension(780, 540));

    int answer = JOptionPane.showConfirmDialog(this, root, "FT Settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if ( answer != JOptionPane.OK_OPTION )
    {
      return;
    }

    props.setProperty("functional.layout.autoDetect.enabled", Boolean.toString(autoDetect.isSelected()));
    props.setProperty("functional.layout.syntaxProposal.enabled", Boolean.toString(syntaxProposal.isSelected()));
    props.setProperty("functional.layout.autoDetectTopLabels", autoLabels.getText().trim());
    String selectedCoreRoles = selectedFunctionalRolesCsv(coreRoleChecks);
    String selectedFrameRoles = selectedFunctionalRolesCsv(frameRoleChecks);
    props.setProperty("functional.layout.coreRoles", selectedCoreRoles);
    props.setProperty("functional.layout.frameRoles", selectedFrameRoles);
    props.setProperty("functional.layout.frame.enabled", Boolean.toString(frameEnabled.isSelected()));
    props.setProperty("functional.layout.frameRolesVisibleInMainTree", Boolean.toString(frameVisible.isSelected()));
    props.setProperty("functional.layout.frame.caption", frameCaption.getText().trim());
    props.setProperty("functional.layout.verticalStep", String.valueOf(((Integer)verticalStep.getValue()).intValue()));
    props.setProperty("functional.layout.verticalStart", String.valueOf(((Integer)verticalStart.getValue()).intValue()));
    props.setProperty("functional.layout.horizontalSpread", String.valueOf(horizontalSpread.getSelectedItem()));
    applyFunctionalTreeNodeTableOverrides(ftNodesTable);
    rememberCurrentGraphAsFunctionalTreeInputTest();
    String generatedRoleTable = functionalRoleTableFromChecklist(coreRoleChecks, frameRoleChecks);
    props.setProperty("functional.layout.roleTable", generatedRoleTable);
    applyFunctionalRoleTableToProperties(props, generatedRoleTable);

    try
    {
      OpenGraphDialogSettingsSupport.saveProperties("config/opengraph_user.properties", props, "OpenGraph user settings");
      OpenGraphTreeDrawOperation.resetFunctionalTreeConfigCache();
      JOptionPane.showMessageDialog(this, "FT config saved en actief. Gebruik Draw om opnieuw te tekenen.", "FT Settings", JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( IOException ioe )
    {
      JOptionPane.showMessageDialog(this, "FT config kon niet worden opgeslagen.", "FT Settings", JOptionPane.ERROR_MESSAGE);
    }
  }


  private JTable createFunctionalTreeNodesTable()
  {
    String[] columns = new String[] { "#", "Label", "Projectie-text", "Default FT", "Override FT", "Result FT" };
    javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel(columns, 0)
    {
      public boolean isCellEditable(int row, int column)
      {
        return column == 4;
      }
    };

    Graph graph = graphEditor == null ? null : graphEditor.getGraph();
    java.util.Vector nodes = graph == null ? null : graph.getNodes();
    for ( int i=0; nodes != null && i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node == null || !isFunctionalTreeNonTerminal(graph, node) ) continue;
      String projectionText = functionalTreeProjectionTextForNode(graph, node);
      String def = defaultFunctionalTreeProposalForNode(graph, node);
      String defDisplay = functionalTreeDefaultDisplay(def, projectionText);
      String override = node.hasFunctionalTreeMetadata() ? functionalTreeResultForNode(node) : "";
      String result = override.length() == 0 ? defDisplay : override;
      model.addRow(new Object[] { new Integer(node.getIndex()), node.getLabel(), projectionText, defDisplay, override, result });
    }

    JTable table = new JTable(model);
    table.setFillsViewportHeight(true);
    table.getColumnModel().getColumn(0).setMaxWidth(46);
    table.getColumnModel().getColumn(1).setPreferredWidth(70);
    table.getColumnModel().getColumn(2).setPreferredWidth(180);
    table.getColumnModel().getColumn(3).setPreferredWidth(145);
    table.getColumnModel().getColumn(4).setPreferredWidth(190);
    table.getColumnModel().getColumn(5).setPreferredWidth(145);

    table.getColumnModel().getColumn(4).setCellEditor(new FunctionalTreeNodeOverrideEditor(table));
    return table;
  }



  private String functionalTreeDefaultDisplay(String defaultValue, String projectionText)
  {
    if ( defaultValue == null ) defaultValue = "";
    if ( projectionText == null ) projectionText = "";
    projectionText = projectionText.trim();
    if ( projectionText.length() == 0 ) return defaultValue;
    if ( defaultValue.length() == 0 ) return "LEX(stellend): " + projectionText;
    return defaultValue + " | LEX(stellend): " + projectionText;
  }

  private String functionalTreeDefaultRoleValue(String displayValue)
  {
    if ( displayValue == null ) return "";
    String value = displayValue.trim();
    int bar = value.indexOf("|");
    if ( bar >= 0 ) value = value.substring(0, bar).trim();
    if ( value.startsWith("LEX")) return "";
    return value;
  }

  private String functionalTreeProjectionTextForNode(Graph graph, Node node)
  {
    java.util.Vector labels = new java.util.Vector();
    collectFunctionalTreeLeafLabels(graph, node, labels, new java.util.HashSet());
    if ( labels.size() == 0 )
    {
      String label = node == null ? "" : node.getLabel();
      return label == null ? "" : label;
    }
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<labels.size(); i++ )
    {
      if ( i > 0 ) buffer.append(" ");
      buffer.append((String)labels.elementAt(i));
    }
    return buffer.toString();
  }

  private void collectFunctionalTreeLeafLabels(Graph graph, Node node, java.util.Vector labels, java.util.HashSet seen)
  {
    if ( graph == null || node == null || seen.contains(node) ) return;
    seen.add(node);
    java.util.Vector children = functionalTreeChildren(graph, node);
    if ( children.size() == 0 )
    {
      String label = node.getLabel();
      if ( label != null && label.trim().length() > 0 ) labels.addElement(label.trim());
      return;
    }
    for ( int i=0; i<children.size(); i++ )
    {
      collectFunctionalTreeLeafLabels(graph, (Node)children.elementAt(i), labels, seen);
    }
  }

  private java.util.Vector functionalTreeChildren(Graph graph, Node node)
  {
    java.util.Vector result = new java.util.Vector();
    java.util.Vector edges = graph == null ? null : graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge != null && edge.getStartNode() == node && edge.getEndNode() instanceof Node )
      {
        result.addElement((Node)edge.getEndNode());
      }
    }
    sortFunctionalTreeNodesByPosition(result);
    return result;
  }

  private void sortFunctionalTreeNodesByPosition(java.util.Vector nodes)
  {
    for ( int i=0; nodes != null && i<nodes.size(); i++ )
    {
      for ( int j=i+1; j<nodes.size(); j++ )
      {
        Node a = (Node)nodes.elementAt(i);
        Node b = (Node)nodes.elementAt(j);
        if ( functionalTreeNodeComesAfter(a, b) )
        {
          nodes.setElementAt(b, i);
          nodes.setElementAt(a, j);
        }
      }
    }
  }

  private boolean functionalTreeNodeComesAfter(Node a, Node b)
  {
    if ( a == null || b == null ) return false;
    int ay = a.getLocation().intY();
    int by = b.getLocation().intY();
    if ( ay != by ) return ay > by;
    return a.getLocation().intX() > b.getLocation().intX();
  }

  private class FunctionalTreeNodeOverrideEditor extends DefaultCellEditor
  {
    private JTable table;

    FunctionalTreeNodeOverrideEditor(JTable table)
    {
      super(new JComboBox(new String[] { "" }));
      this.table = table;
    }

    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
    {
      JComboBox combo = new JComboBox(functionalTreeOverrideValuesForRow(row));
      combo.setSelectedItem(value == null ? "" : String.valueOf(value));
      delegate = new EditorDelegate()
      {
        public void setValue(Object value)
        {
          ((JComboBox)editorComponent).setSelectedItem(value == null ? "" : String.valueOf(value));
        }

        public Object getCellEditorValue()
        {
          return ((JComboBox)editorComponent).getSelectedItem();
        }
      };
      editorComponent = combo;
      return combo;
    }

    private String[] functionalTreeOverrideValuesForRow(int row)
    {
      String def = "";
      if ( table != null && row >= 0 && row < table.getRowCount() )
      {
        Object defObj = table.getValueAt(row, 3);
        def = defObj == null ? "" : functionalTreeDefaultRoleValue(String.valueOf(defObj));
      }

      if ( def.startsWith("frame/") )
      {
        return functionalTreeFrameOverrideValues();
      }
      return functionalTreeCentralOverrideValues();
    }
  }

  private String[] functionalTreeCentralOverrideValues()
  {
    return new String[] {
      "",
      "top/action", "top/event",
      "pred/process",
      "participant/agens", "participant/patiens", "participant/recipiens",
      "participant/actor/animate", "participant/actor/bezield",
      "participant/actor/inanimate", "participant/actor/onbezield",
      "participant/ervaarder", "participant/fenomeen", "participant/zegger", "participant/bewoording",
      "participant/drager", "participant/eigenschap", "participant/bestaande"
    };
  }

  private String[] functionalTreeFrameOverrideValues()
  {
    return new String[] {
      "",
      "frame/instrument", "frame/locatief", "frame/plaats", "frame/tijd", "frame/richting",
      "frame/bron", "frame/doel", "frame/manier", "frame/oorzaak", "frame/reden", "frame/motief", "frame/duur"
    };
  }

  private boolean isFunctionalTreeNonTerminal(Graph graph, Node node)
  {
    if ( graph == null || node == null ) return false;
    java.util.Vector edges = graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge != null && edge.getStartNode() == node ) return true;
    }
    return false;
  }

  private String defaultFunctionalTreeProposalForNode(Graph graph, Node node)
  {
    if ( node == null ) return "";
    String label = node.getLabel();
    if ( label == null ) label = "";
    String l = label.trim().toUpperCase();
    if ( l.equals("S") || l.equals("CLAUSE") ) return "top/action";
    if ( l.equals("V") || l.equals("VP") ) return "pred/process";
    if ( l.equals("NP") || l.equals("DP") )
    {
      return isUnderFunctionalVerb(graph, node) ? "participant/patiens" : "participant/agens";
    }
    if ( l.equals("PP") || l.equals("P") ) return "frame/locatief";
    if ( l.equals("ADV") || l.equals("ADVP") ) return "frame/tijd";
    if ( l.equals("AP") || l.equals("ADJP") ) return "participant/eigenschap";
    return "";
  }

  private boolean isUnderFunctionalVerb(Graph graph, Node node)
  {
    if ( graph == null || node == null ) return false;
    Node parent = findFunctionalTreeParent(graph, node);
    while ( parent != null )
    {
      String label = parent.getLabel();
      if ( label != null )
      {
        label = label.trim().toUpperCase();
        if ( label.equals("VP") || label.equals("V") ) return true;
        if ( label.equals("S") || label.equals("CLAUSE") ) return false;
      }
      parent = findFunctionalTreeParent(graph, parent);
    }
    return false;
  }

  private Node findFunctionalTreeParent(Graph graph, Node node)
  {
    java.util.Vector edges = graph == null ? null : graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge != null && edge.getEndNode() == node && edge.getStartNode() instanceof Node )
      {
        return (Node)edge.getStartNode();
      }
    }
    return null;
  }

  private String functionalTreeResultForNode(Node node)
  {
    if ( node == null ) return "";
    String type = node.getFunctionalTreeNodeType();
    String process = node.getFunctionalTreeProcessType();
    String role = node.getFunctionalTreeRolePath();
    if ( role != null && role.length() > 0 ) return role;
    if ( type != null && type.length() > 0 && process != null && process.length() > 0 ) return type + "/" + process;
    if ( type != null && type.length() > 0 ) return type;
    return "";
  }

  private void applyFunctionalTreeNodeTableOverrides(JTable table)
  {
    if ( table == null || graphEditor == null || graphEditor.getGraph() == null ) return;
    if ( table.isEditing() ) table.getCellEditor().stopCellEditing();
    Graph graph = graphEditor.getGraph();
    for ( int r=0; r<table.getRowCount(); r++ )
    {
      Object idObj = table.getValueAt(r, 0);
      Object overrideObj = table.getValueAt(r, 4);
      int index = Integer.parseInt(String.valueOf(idObj));
      String override = overrideObj == null ? "" : String.valueOf(overrideObj).trim();
      Node node = findFunctionalTreeNodeByIndex(graph, index);
      if ( node == null ) continue;
      if ( override.length() == 0 )
      {
        node.clearFunctionalTreeMetadata();
      }
      else
      {
        applyFunctionalTreeOverrideToNode(node, override);
      }
    }
  }

  private Node findFunctionalTreeNodeByIndex(Graph graph, int index)
  {
    java.util.Vector nodes = graph == null ? null : graph.getNodes();
    for ( int i=0; nodes != null && i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node != null && node.getIndex() == index ) return node;
    }
    return null;
  }

  private void applyFunctionalTreeOverrideToNode(Node node, String override)
  {
    if ( override.startsWith("top/"))
    {
      node.setFunctionalTreeMetadata("top", override.substring(4), override);
    }
    else if ( override.startsWith("participant/"))
    {
      node.setFunctionalTreeMetadata("participant", "", override);
    }
    else if ( override.startsWith("frame/"))
    {
      node.setFunctionalTreeMetadata("frame", "", override);
    }
    else if ( override.startsWith("pred/"))
    {
      node.setFunctionalTreeMetadata("pred", "", override);
    }
    else
    {
      node.setFunctionalTreeMetadata("", "", override);
    }
  }

  private void rememberCurrentGraphAsFunctionalTreeInputTest()
  {
    try
    {
      Graph graph = graphEditor == null ? null : graphEditor.getGraph();
      if ( graph == null ) return;
      java.io.File dir = new java.io.File("examples/ft-input-testset/runtime");
      dir.mkdirs();
      String name = graph.getFileName();
      if ( name == null || name.length() == 0 ) name = "graph";
      name = name.replace('\\', '_').replace('/', '_').replace(':', '_');
      java.io.File marker = new java.io.File(dir, "README-runtime-inputs.txt");
      java.io.FileWriter out = new java.io.FileWriter(marker, true);
      out.write(name + "\n");
      out.close();
    }
    catch ( Exception ignored )
    {
    }
  }

  private void addFTDialogRow(JPanel panel, GridBagConstraints c, int row, String label, Component field)
  {
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 1;
    c.weightx = 0.0;
    panel.add(new JLabel(label), c);
    c.gridx = 1;
    c.weightx = 1.0;
    panel.add(field, c);
  }


  private String[] defaultFunctionalRoleNames()
  {
    return new String[] {
      "pred", "proces", "action", "event", "materieel", "mentaal", "relationeel", "verbaal", "attributief", "identificerend", "gedragsmatig", "existentieel", "existentiëel",
      "participant", "animate", "inanimate", "bezield", "onbezield",
      "actor", "agens", "gever", "nemer", "voeler", "ervaarder", "ontvanger", "recipiënt", "recipiens", "beneficient", "beneficiënt", "zegger", "gedrager",
      "patiens", "thema", "fenomeen", "bewoording", "bestaande", "doel", "object", "natuurlijke oorzaak",
      "frame", "richting", "bron", "plaats", "locatief", "locatie", "tijd", "tijdsduur", "manier", "instrument", "oorzaak", "reden", "motief", "eigenschap"
    };
  }

  private java.util.LinkedHashMap createFunctionalRoleChecklist(Properties props, String propertyKey, boolean coreDefault)
  {
    java.util.LinkedHashMap map = new java.util.LinkedHashMap();
    String defaults = coreDefault
      ? "pred,proces,action,event,actor,agens,patiens,thema,recipiens,ontvanger,ervaarder,voeler,fenomeen,zegger,bewoording,gedrager,bestaande,beneficient,beneficiënt,doel,gever,nemer"
      : "frame,richting,bron,plaats,locatief,locatie,tijd,tijdsduur,manier,instrument,oorzaak,reden,motief,eigenschap,natuurlijke oorzaak";
    java.util.HashSet selected = csvToLowerSet(strProp(props, propertyKey, defaults));
    String[] names = defaultFunctionalRoleNames();
    for ( int i=0; i<names.length; i++ )
    {
      JCheckBox cb = new JCheckBox(names[i]);
      cb.setSelected(selected.contains(names[i].toLowerCase()));
      map.put(names[i], cb);
    }
    return map;
  }

  private java.util.HashSet csvToLowerSet(String csv)
  {
    java.util.HashSet set = new java.util.HashSet();
    if ( csv == null ) return set;
    String[] parts = csv.split(",");
    for ( int i=0; i<parts.length; i++ )
    {
      String v = parts[i].trim().toLowerCase();
      if ( v.length() > 0 ) set.add(v);
    }
    return set;
  }

  private JPanel createFunctionalRoleHierarchyPanel(java.util.LinkedHashMap checks)
  {
    JPanel body = new JPanel(new GridLayout(0, 2, 8, 8));
    body.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

    addFunctionalRoleGroup(body, checks, "PROCES", new String[] {
      "pred", "proces", "action", "event", "materieel", "mentaal", "relationeel", "verbaal", "attributief", "identificerend", "gedragsmatig", "existentieel", "existentiëel"
    });
    addFunctionalRoleGroup(body, checks, "PARTICIPANT", new String[] {
      "participant", "animate", "inanimate", "bezield", "onbezield"
    });
    addFunctionalRoleGroup(body, checks, "ANIMATE / BEZIELD", new String[] {
      "actor", "agens", "gever", "nemer", "voeler", "ervaarder", "ontvanger", "recipiënt", "recipiens", "beneficient", "beneficiënt", "zegger", "gedrager"
    });
    addFunctionalRoleGroup(body, checks, "INANIMATE / ONBEZIELD", new String[] {
      "patiens", "thema", "fenomeen", "bewoording", "bestaande", "doel", "object", "natuurlijke oorzaak"
    });
    addFunctionalRoleGroup(body, checks, "FRAME - RICHTING / STATISCH", new String[] {
      "frame", "richting", "bron", "plaats", "locatief", "locatie", "tijd", "tijdsduur"
    });
    addFunctionalRoleGroup(body, checks, "FRAME - HOE / DYNAMISCH", new String[] {
      "manier", "instrument", "oorzaak", "reden", "motief", "eigenschap"
    });

    return body;
  }

  private void addFunctionalRoleGroup(JPanel body, java.util.LinkedHashMap checks, String title, String[] roles)
  {
    JPanel group = new JPanel(new GridLayout(0, 2, 4, 1));
    group.setBorder(BorderFactory.createTitledBorder(title));
    for ( int i=0; i<roles.length; i++ )
    {
      JCheckBox box = (JCheckBox)checks.get(roles[i]);
      if ( box != null )
      {
        group.add(box);
      }
    }
    body.add(group);
  }

  private void connectFunctionalRoleChecklistExclusion(final java.util.LinkedHashMap coreChecks,
                                                       final java.util.LinkedHashMap frameChecks)
  {
    for ( java.util.Iterator it = coreChecks.keySet().iterator(); it.hasNext(); )
    {
      final String role = (String)it.next();
      final JCheckBox core = (JCheckBox)coreChecks.get(role);
      final JCheckBox frame = (JCheckBox)frameChecks.get(role);
      if ( core == null || frame == null ) continue;
      core.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( core.isSelected() ) frame.setSelected(false);
        }
      });
      frame.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( frame.isSelected() ) core.setSelected(false);
        }
      });
      if ( core.isSelected() && frame.isSelected() )
      {
        frame.setSelected(false);
      }
    }
  }

  private JPanel createFunctionalRoleChecklistPanel(java.util.LinkedHashMap checks, int columns)
  {
    JPanel panel = new JPanel(new GridLayout(0, columns, 4, 1));
    for ( java.util.Iterator it = checks.values().iterator(); it.hasNext(); )
    {
      panel.add((JCheckBox)it.next());
    }
    return panel;
  }

  private JPanel createFunctionalRoleOverviewPanel(java.util.LinkedHashMap coreChecks, java.util.LinkedHashMap frameChecks)
  {
    JPanel panel = new JPanel(new GridLayout(0, 3, 6, 1));
    panel.add(new JLabel("Role"));
    panel.add(new JLabel("Core"));
    panel.add(new JLabel("Frame"));
    for ( java.util.Iterator it = coreChecks.keySet().iterator(); it.hasNext(); )
    {
      String role = (String)it.next();
      panel.add(new JLabel(role));
      panel.add((JCheckBox)coreChecks.get(role));
      panel.add((JCheckBox)frameChecks.get(role));
    }
    return panel;
  }

  private String selectedFunctionalRolesCsv(java.util.LinkedHashMap checks)
  {
    StringBuffer sb = new StringBuffer();
    for ( java.util.Iterator it = checks.keySet().iterator(); it.hasNext(); )
    {
      String role = (String)it.next();
      JCheckBox cb = (JCheckBox)checks.get(role);
      if ( cb.isSelected() )
      {
        if ( sb.length() > 0 ) sb.append(',');
        sb.append(role);
      }
    }
    return sb.toString();
  }

  private String functionalRoleTableFromChecklist(java.util.LinkedHashMap coreChecks, java.util.LinkedHashMap frameChecks)
  {
    StringBuffer sb = new StringBuffer();
    int rank = 0;
    for ( java.util.Iterator it = coreChecks.keySet().iterator(); it.hasNext(); )
    {
      String role = (String)it.next();
      JCheckBox core = (JCheckBox)coreChecks.get(role);
      JCheckBox frame = (JCheckBox)frameChecks.get(role);
      if ( core.isSelected() )
      {
        sb.append(role).append(",core,true,").append(rank).append(",center\n");
        rank += 10;
      }
      else if ( frame.isSelected() )
      {
        sb.append(role).append(",frame,false,").append(rank).append(",frame\n");
        rank += 10;
      }
    }
    return sb.toString().trim();
  }

  private Properties loadFunctionalTreeProperties()
  {
    Properties merged = new Properties();
    mergePropertiesFromPath(merged, "config/opengraph_defaults.properties");
    mergePropertiesFromPath(merged, "config/opengraph_user.properties");
    mergePropertiesFromPath(merged, "config/opengraphed_user.properties");
    return merged;
  }

  private void mergePropertiesFromPath(Properties target, String path)
  {
    try
    {
      Properties loaded = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( loaded != null )
      {
        for ( java.util.Enumeration e = loaded.propertyNames(); e.hasMoreElements(); )
        {
          String key = (String)e.nextElement();
          target.setProperty(key, loaded.getProperty(key));
        }
      }
    }
    catch ( IOException ioe )
    {
      // Ignore unreadable optional config files; defaults stay active.
    }
  }

  private String strProp(Properties props, String key, String def)
  {
    String value = props == null ? null : props.getProperty(key);
    if ( value == null || value.trim().length() == 0 ) return def;
    return value.trim();
  }

  private boolean boolProp(Properties props, String key, boolean def)
  {
    String value = props == null ? null : props.getProperty(key);
    if ( value == null ) return def;
    return Boolean.valueOf(value.trim()).booleanValue();
  }

  private int intProp(Properties props, String key, int def)
  {
    try
    {
      String value = props == null ? null : props.getProperty(key);
      if ( value == null ) return def;
      return Integer.parseInt(value.trim());
    }
    catch ( Exception ex )
    {
      return def;
    }
  }

  private String defaultFunctionalRoleTable()
  {
    return "pred,core,true,0,center\n" +
           "agens,core,true,10,left\n" +
           "patiens,core,true,20,right\n" +
           "recipiens,core,true,30,right\n" +
           "instrument,frame,false,40,frame\n" +
           "locatief,frame,false,50,frame\n" +
           "plaats,frame,false,50,frame\n" +
           "tijd,frame,false,60,frame";
  }

  private void applyFunctionalRoleTableToProperties(Properties props, String table)
  {
    if ( props == null || table == null ) return;
    String[] lines = table.split("\\n");
    for ( int i=0; i<lines.length; i++ )
    {
      String line = lines[i].trim();
      if ( line.length() == 0 || line.startsWith("#") ) continue;
      String[] parts = line.split(",");
      if ( parts.length < 5 ) continue;
      String role = parts[0].trim().toLowerCase();
      if ( role.length() == 0 ) continue;
      props.setProperty("functional.layout.role." + role + ".scope", parts[1].trim());
      props.setProperty("functional.layout.role." + role + ".visible", parts[2].trim());
      props.setProperty("functional.layout.role." + role + ".rank", parts[3].trim());
      props.setProperty("functional.layout.role." + role + ".side", parts[4].trim());
    }
  }

  private JPanel createProjectionProfilePanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
    panel.setOpaque(false);
    panel.add(new JLabel("Projecties:"));

    projectionShowCheckBox = createProjectionCheckBox("aan", "Toon/verberg projecties voor het gekozen Tree.");
    panel.add(projectionShowCheckBox);

    projectionLeftCheckBox = createProjectionCheckBox("L", "Linkerprojectie aan/uit.");
    projectionLeftCaptionField = createProjectionCaptionField("LEX", "Caption voor de linkerprojectie.");
    panel.add(projectionLeftCheckBox);
    panel.add(projectionLeftCaptionField);

    projectionRightCheckBox = createProjectionCheckBox("R", "Rechterprojectie aan/uit.");
    projectionRightCaptionField = createProjectionCaptionField("SYNT", "Caption voor de rechterprojectie.");
    panel.add(projectionRightCheckBox);
    panel.add(projectionRightCaptionField);

    projectionTopCheckBox = createProjectionCheckBox("Boven", "Bovenprojectie aan/uit.");
    projectionTopCaptionField = createProjectionCaptionField("pm", "Caption voor de bovenprojectie.");
    panel.add(projectionTopCheckBox);
    panel.add(projectionTopCaptionField);

    projectionBottomCheckBox = createProjectionCheckBox("Onder", "Onderprojectie aan/uit.");
    projectionBottomCaptionField = createProjectionCaptionField("LF", "Caption voor de onderprojectie.");
    panel.add(projectionBottomCheckBox);
    panel.add(projectionBottomCaptionField);

    projectionSaveProfileButton = createOpenGraphButton("Save profile", "Sla deze projectieconfig op voor het gekozen Tree in config/opengraph_user.properties.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveProjectionProfileFromHeader();
      }
    });
    panel.add(projectionSaveProfileButton);

    updateProjectionProfileControlsFromEditor();
    return panel;
  }

  private JCheckBox createProjectionCheckBox(String text, String toolTip)
  {
    JCheckBox box = new JCheckBox(text);
    box.setFocusable(false);
    box.setOpaque(false);
    box.setToolTipText(toolTip);
    box.setMargin(new Insets(0, 0, 0, 0));
    box.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    return box;
  }

  private JTextField createProjectionCaptionField(String text, String toolTip)
  {
    final JTextField field = new JTextField(text, 4);
    field.setToolTipText(toolTip);
    field.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    field.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    return field;
  }

  private void updateProjectionProfileControlsFromEditor()
  {
    if ( graphEditor == null || projectionShowCheckBox == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    updatingProjectionProfileControls = true;
    try
    {
      projectionShowCheckBox.setSelected(settings.getShowProjections());
      projectionLeftCheckBox.setSelected(settings.getLeftProjectionEnabled());
      projectionRightCheckBox.setSelected(settings.getRightProjectionEnabled());
      projectionTopCheckBox.setSelected(settings.getTopProjectionEnabled());
      projectionBottomCheckBox.setSelected(settings.getBottomProjectionEnabled());

      projectionLeftCaptionField.setText(settings.getLeftProjectionCaption());
      projectionRightCaptionField.setText(settings.getRightProjectionCaption());
      projectionTopCaptionField.setText(settings.getTopProjectionCaption());
      projectionBottomCaptionField.setText(settings.getBottomProjectionCaption());

      boolean enabled = OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType());
      projectionShowCheckBox.setEnabled(enabled);
      projectionLeftCheckBox.setEnabled(enabled);
      projectionRightCheckBox.setEnabled(enabled);
      projectionTopCheckBox.setEnabled(enabled);
      projectionBottomCheckBox.setEnabled(enabled);
      projectionLeftCaptionField.setEnabled(enabled);
      projectionRightCaptionField.setEnabled(enabled);
      projectionTopCaptionField.setEnabled(enabled);
      projectionBottomCaptionField.setEnabled(enabled);
      projectionSaveProfileButton.setEnabled(enabled);
    }
    finally
    {
      updatingProjectionProfileControls = false;
    }
  }

  private void applyProjectionProfileControlsToEditor(boolean persist)
  {
    if ( updatingProjectionProfileControls || graphEditor == null || projectionShowCheckBox == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) )
    {
      updateProjectionProfileControlsFromEditor();
      return;
    }

    settings.setShowProjections(projectionShowCheckBox.isSelected());
    settings.setLeftProjectionEnabled(projectionLeftCheckBox.isSelected());
    settings.setRightProjectionEnabled(projectionRightCheckBox.isSelected());
    settings.setTopProjectionEnabled(projectionTopCheckBox.isSelected());
    settings.setBottomProjectionEnabled(projectionBottomCheckBox.isSelected());

    settings.setLeftProjectionCaption(projectionLeftCaptionField.getText());
    settings.setRightProjectionCaption(projectionRightCaptionField.getText());
    settings.setTopProjectionCaption(projectionTopCaptionField.getText());
    settings.setBottomProjectionCaption(projectionBottomCaptionField.getText());
    settings.normalize();

    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()));
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.update();

    if ( persist )
    {
      saveProjectionProfile(settings);
    }
  }

  private void saveProjectionProfileFromHeader()
  {
    applyProjectionProfileControlsToEditor(false);
    if ( graphEditor == null )
    {
      return;
    }
    saveProjectionProfile(graphEditor.getOpenGraphProjectionSettings());
  }

  private void saveProjectionProfile(OpenGraphProjectionSettings settings)
  {
    if ( settings == null || !OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) )
    {
      return;
    }

    try
    {
      Properties props = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(OpenGraphGridSettingsIO.USER_SETTINGS_PATH);
      if ( props == null )
      {
        props = new Properties();
      }

      String prefix = "projection.profile." + OpenGraphDialogSettingsSupport.projectionProfileName(settings.getStructureType()) + ".";
      props.setProperty("structure.type", String.valueOf(settings.getStructureType()));
      props.setProperty(prefix + "show", String.valueOf(settings.getShowProjections()));
      props.setProperty(prefix + "left.enabled", String.valueOf(settings.getLeftProjectionEnabled()));
      props.setProperty(prefix + "right.enabled", String.valueOf(settings.getRightProjectionEnabled()));
      props.setProperty(prefix + "top.enabled", String.valueOf(settings.getTopProjectionEnabled()));
      props.setProperty(prefix + "bottom.enabled", String.valueOf(settings.getBottomProjectionEnabled()));
      props.setProperty(prefix + "left.caption", settings.getLeftProjectionCaption());
      props.setProperty(prefix + "right.caption", settings.getRightProjectionCaption());
      props.setProperty(prefix + "top.caption", settings.getTopProjectionCaption());
      props.setProperty(prefix + "bottom.caption", settings.getBottomProjectionCaption());
      props.setProperty(prefix + "left.position", String.valueOf(settings.getLeftProjectionPosition()));
      props.setProperty(prefix + "right.position", String.valueOf(settings.getRightProjectionPosition()));
      props.setProperty(prefix + "top.position", String.valueOf(settings.getTopProjectionPosition()));
      props.setProperty(prefix + "bottom.position", String.valueOf(settings.getBottomProjectionPosition()));
      if ( settings.getStructureType() == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
      {
        props.setProperty(prefix + "verbcluster.order", settings.getLanguageTreeVerbClusterOrder());
        props.setProperty("language.verbcluster.order", settings.getLanguageTreeVerbClusterOrder());
      }

      OpenGraphDialogSettingsSupport.saveProperties(OpenGraphGridSettingsIO.USER_SETTINGS_PATH, props,
        "OpenGraphEd user settings - projection profile updated from header UI");
      JOptionPane.showMessageDialog(this,
        "Projectieprofiel opgeslagen voor " + currentStructureTypeLabel(settings.getStructureType()) + ".",
        "Projection profile", JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( IOException ex )
    {
      System.err.println("[OpenGraph] Could not save projection profile: " + ex);
      ex.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this,
        "Projectieprofiel kon niet worden opgeslagen:\n" + ex.getMessage(),
        "Projection profile", JOptionPane.ERROR_MESSAGE);
    }
  }

  private String currentStructureTypeLabel(int structureType)
  {
    if ( structureTypeCombo != null )
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          return item.toString();
        }
      }
    }
    return "tree " + structureType;
  }

  private void showCurrentTreeTypeExplanation()
  {
    int structureType = currentDisplayedTreeTypeValue();
    String title = "Tree-type: " + currentTreeTypeName(structureType);

    JTextArea area = new JTextArea(currentTreeTypeExplanation(structureType), 24, 74);
    area.setEditable(false);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setCaretPosition(0);

    JScrollPane scrollPane = new JScrollPane(area,
      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
      JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    JComponent content = scrollPane;
    ImageIcon explanationImage = treeTypeExplanationImageIcon(structureType, 780, 330);
    if ( explanationImage != null )
    {
      JLabel imageLabel = new JLabel(explanationImage, SwingConstants.CENTER);
      imageLabel.setOpaque(true);
      imageLabel.setBackground(Color.white);
      imageLabel.setBorder(BorderFactory.createTitledBorder(treeTypeExplanationImageTitle(structureType)));

      JPanel panel = new JPanel(new BorderLayout(8, 8));
      panel.add(imageLabel, BorderLayout.NORTH);
      panel.add(scrollPane, BorderLayout.CENTER);
      panel.setPreferredSize(new Dimension(840, 650));
      content = panel;
    }

    JOptionPane.showMessageDialog(this,
      content,
      title,
      JOptionPane.INFORMATION_MESSAGE);
  }

  private String treeTypeExplanationImageTitle(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      return "Simple: vrije plaatsing maakt projectieruimte links en beneden";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return "Language: links LEX, rechts SYNT, onder LOGical";
    }
    return "OpenGraph-projectie";
  }

  private ImageIcon treeTypeExplanationImageIcon(int structureType, int maxWidth, int maxHeight)
  {
    File imageFile = treeTypeExplanationImageFile(structureType);
    if ( imageFile == null || !imageFile.isFile() )
    {
      return null;
    }

    try
    {
      BufferedImage image = ImageIO.read(imageFile);
      if ( image == null ) return null;

      int width = image.getWidth();
      int height = image.getHeight();
      if ( width <= 0 || height <= 0 ) return null;

      double scale = Math.min((double)maxWidth / (double)width, (double)maxHeight / (double)height);
      if ( scale > 1.0 ) scale = 1.0;
      int scaledWidth = Math.max(1, (int)Math.round(width * scale));
      int scaledHeight = Math.max(1, (int)Math.round(height * scale));

      if ( scaledWidth == width && scaledHeight == height )
      {
        return new ImageIcon(image);
      }

      Image scaled = image.getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
      return new ImageIcon(scaled);
    }
    catch ( IOException ex )
    {
      return null;
    }
  }

  private File treeTypeExplanationImageFile(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      return firstExistingFile(new String[] {
        "help/tree-images/simple-free-space-projections.png",
        "images/simple-free-space-projections.png",
        "help/tree-images/simple-green-yellow-projections.png",
        "images/simple-green-yellow-projections.png"
      });
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return firstExistingFile(new String[] {
        "help/tree-images/language-lex-synt-logical.png",
        "images/language-lex-synt-logical.png"
      });
    }
    return null;
  }

  private File firstExistingFile(String[] relativePaths)
  {
    if ( relativePaths == null ) return null;
    for ( int i=0; i<relativePaths.length; i++ )
    {
      if ( relativePaths[i] == null ) continue;
      File file = new File(relativePaths[i]);
      if ( file.isFile() ) return file;
    }
    return null;
  }

  private int currentDisplayedTreeTypeValue()
  {
    if ( isOpenGraphCarouselSelected() )
    {
      return STRUCTURE_OPENGRAPH_CAROUSEL;
    }
    if ( structureTypeCombo != null )
    {
      Object selected = structureTypeCombo.getSelectedItem();
      if ( selected instanceof StructureTypeItem )
      {
        int selectedValue = ((StructureTypeItem)selected).getValue();
        if ( selectedValue != STRUCTURE_ORIGINAL_GRAPH )
        {
          return selectedValue;
        }
      }
    }

    /*
     * Simple has no external projection layer.  Several header refresh paths
     * therefore treat it like a non-projection state and may visually fall
     * back to "origineel".  For the Uitleg button that is wrong: after an
     * explicit user choice of Simple, the explanation must be Simple.
     */
    if ( lastExplicitTreeTypeSelection != STRUCTURE_ORIGINAL_GRAPH )
    {
      return lastExplicitTreeTypeSelection;
    }

    if ( graphEditor == null || !graphEditor.isOpenGraphProjectionContextActive() )
    {
      return STRUCTURE_ORIGINAL_GRAPH;
    }
    return graphEditor.getOpenGraphProjectionSettings().getStructureType();
  }

  private String currentTreeTypeName(int structureType)
  {
    if ( structureType == STRUCTURE_ORIGINAL_GRAPH ) return "origineel";
    if ( structureType == STRUCTURE_OPENGRAPH_CAROUSEL ) return "OpenGraph";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "Simple";
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ) return "Language";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "Functional";
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "Frame";
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ) return "Anaphor";
    return "onbekend";
  }

  private String currentTreeTypeExplanation(int structureType)
  {
    String newline = System.getProperty("line.separator");
    StringBuffer text = new StringBuffer();

    if ( structureType == STRUCTURE_ORIGINAL_GRAPH )
    {
      text.append("origineel").append(newline).append(newline);
      text.append("Dit toont de huidige OpenGraph-bronnotatie in de editor: de vrije graph met knopen, labels en takken zoals die nu in het venster staat.").append(newline);
      text.append("Het is dus niet automatisch de laatst opgeslagen .graph op schijf. Editorwijzigingen blijven staan.").append(newline);
      text.append("Als er een Draw-resultaat zichtbaar is, verwijdert origineel alleen die renderstap en keert terug naar de actuele bronboom.").append(newline);
      text.append("Voor een echte oudere toestand gebruik je de gewone Back/Undo-toets.").append(newline).append(newline);
      text.append("OpenGraph-notatie:").append(newline);
      text.append("De editorboom is bewust vrijer dan één klassieke boomtekening. Knopen hoeven nog niet in één definitieve projectierichting vast te liggen.").append(newline);
      text.append("Die vrije knopen vormen de werkruimte waaruit OpenGraphEd verschillende projecties kan maken: een compacte Simple-boom, een Language Tree met LEX/SYN/LF, later Functional/Frame/Anaphor.").append(newline);
      text.append("Dezelfde bronnotatie kan dus meerdere lezingen krijgen zonder de graph telkens structureel te herschrijven.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == STRUCTURE_OPENGRAPH_CAROUSEL )
    {
      text.append("OpenGraph").append(newline).append(newline);
      text.append("OpenGraph is hier de uitlegstand vóór Simple. De editor toont een carrousel met screenshots en toelichtingen.").append(newline);
      text.append("Doelgroep: de taalkundige/student. Uitgangspunt is de bekende syntactische boom: waarom staan woorden onderaan, alsof er zwaartekracht is?").append(newline).append(newline);
      text.append("De carrousel laat stap voor stap zien dat OpenGraph niet begint met één vast getekende eindboom. Eerst zijn er vrije knopen en takken. Daardoor ontstaat ruimte voor projecties.").append(newline);
      text.append("Een kale projectielijn naar links kan bijvoorbeeld kopieën van knopen tonen zonder dat die kopieën al een zware naam of theorie meekrijgen.").append(newline);
      text.append("Daarna kunnen dezelfde vrije knopen worden gebruikt voor LEX, SYN, LF en later Functional, Frame en Anaphor.").append(newline).append(newline);
      text.append("Screenshots toevoegen:").append(newline);
      text.append("- gebruik de knop 'Screenshot toevoegen', of").append(newline);
      text.append("- plaats PNG/JPG/GIF-bestanden in de map opengraph_carousel;").append(newline);
      text.append("- zet per afbeelding een gelijknamig .txt-bestand naast de afbeelding voor de toelichting.").append(newline).append(newline);
      text.append("Voor de inhoudelijke basisuitleg over de boom zelf: zie Simple.").append(newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      appendSimpleTreeExplanation(text, newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      text.append("Language").append(newline).append(newline);
      text.append("Kijk eerst naar de afbeelding bovenaan dit venster.").append(newline);
      text.append("De afbeelding toont in één beeld wat de Language Tree toevoegt aan Simple: één open bronstructuur op een raster, met eigen projectielijnen naar links, rechts en onder.").append(newline).append(newline);

      text.append("In deze afbeelding:").append(newline);
      text.append("- links staat LEX: de lexicale projectie met woorden zoals wie, heeft, de, hond, gebeten;").append(newline);
      text.append("- rechts staat SYNT: de syntactische projectie met combinaties zoals NP/vp, np/V, vp/VDW en det/N;").append(newline);
      text.append("- onder staat LOGical: de logische of functionele projectie met Subject, Object en Verb;").append(newline);
      text.append("- blauw is de centrale open bronstructuur; de projectielijnen hebben eigen kleuren en eigen richtingen.").append(newline).append(newline);

      text.append("1. Taalkundige insteek").append(newline);
      text.append("De traditionele boomnotatie vermengt vaak structuur en volgorde. Een regel als S -> NP VP zegt tegelijk: de zin heeft NP en VP, en NP staat vóór VP.").append(newline);
      text.append("Zelfs wanneer je alleen syntactisch tekent, ontstaan daardoor al volgordeproblemen. Bij topicalisatie, vraagzinnen of lange-afstandsrelaties moet de traditionele analyse dan extra mechanismen invoeren. Et voilà: transformaties, of in andere tradities filler-gap-regels en feature passing.").append(newline).append(newline);

      text.append("2. Open notatie").append(newline);
      text.append("Language gebruikt dezelfde vrije OpenGraph-bron als Simple, maar benut de projectieruimte inhoudelijk. De knopen liggen vrij op het raster. Daardoor kunnen projecties eigenstandig worden getekend, zonder dat de centrale boom telkens herschreven hoeft te worden.").append(newline);
      text.append("De bron is dus één. De lezingen zijn meervoudig.").append(newline).append(newline);

      text.append("3. LEX links").append(newline);
      text.append("LEX is de lexicale projectie. Links in de afbeelding staan de woorden van de uiting: wie, heeft, de, hond, gebeten.").append(newline);
      text.append("Deze projectie toont de woordlaag of uitingsvolgorde. De woorden staan niet als vanzelf 'onderaan' door boomzwaartekracht, maar worden volgens LEX-regels vanuit de bron naar de LEX-lijn geprojecteerd.").append(newline);
      text.append("Zinstypeknoppen zoals Basis, Bijzin, Stellend, Ja/Nee, WH en Topicalisatie sturen zulke LEX-regels. Ook de V-cluster-keuze, bijvoorbeeld pv-VD of VD-pv, hoort bij de LEX-weergave.").append(newline).append(newline);

      text.append("4. SYNT rechts").append(newline);
      text.append("SYNT is de syntactische projectie. Rechts in de afbeelding staan categorieën en combinaties, bijvoorbeeld NP/vp, np/V, vp/VDW en det/N.").append(newline);
      text.append("Deze projectie maakt zichtbaar hoe de bron syntactisch gelezen kan worden. Gebruikelijke categorieën zijn onder meer CP/S, NP/DP, VP, V, N en Det.").append(newline);
      text.append("SYNT is dus niet een tweede losse boom, maar een eigen projectie van dezelfde bronknopen.").append(newline).append(newline);

      text.append("5. LOGical onder").append(newline);
      text.append("LOGical is de logische of functionele projectie. Onderaan in de afbeelding staan rollen zoals Subject, Object en Verb.").append(newline);
      text.append("Deze laag toont niet primair de woordvolgorde en ook niet alleen de syntactische categorie, maar de logische/functionele rol die een knoop in de interpretatie krijgt.").append(newline);
      text.append("In termen van LF: logische vorm is een aparte interpretatielaag. OPN/JAN tekent die laag als projectie in dezelfde afbeelding, in plaats van alles in één boom te stoppen.").append(newline).append(newline);

      text.append("6. Projectieregels per projectie").append(newline);
      text.append("Elke projectie heeft eigen regels:").append(newline);
      text.append("- LEX bepaalt welke knopen als woorden op de uitingslijn komen en in welke volgorde;").append(newline);
      text.append("- SYNT bepaalt welke categoriale informatie rechts zichtbaar wordt;").append(newline);
      text.append("- LOGical bepaalt welke rollen onderaan zichtbaar worden.").append(newline);
      text.append("De centrale bronstructuur blijft daarbij intact. Een verandering in volgorde hoeft dus niet automatisch een andere bronboom te betekenen.").append(newline).append(newline);

      text.append("7. Kernformule").append(newline);
      text.append("Language Tree = open bronstructuur + raster + vrije plaatsing + eigen projectielijnen.").append(newline);
      text.append("Daarmee kan één afbeelding meerdere taalkundige lagen tegelijk tonen: LEX links, SYNT rechts, LOGical onder.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      text.append("Functional").append(newline).append(newline);
      text.append("Komt later inhoudelijker.").append(newline);
      text.append("Voor de basisnotatie: zie Simple. Functional gebruikt dezelfde vrije OpenGraph-bronboom, maar leest knopen functioneel: proces, participant, rol, core/frame.").append(newline);
      text.append("De vrije knopen geven ruimte om naast de centrale boom functionele projecties te plaatsen zonder de bronboom te herschrijven.").append(newline);
      text.append("FT Settings beheert rollen, frame/core-indeling en node-overrides.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      text.append("Frame").append(newline).append(newline);
      text.append("Komt later inhoudelijker.").append(newline);
      text.append("Voor de basisnotatie: zie Simple. Frame gebruikt dezelfde vrije OpenGraph-bronboom, maar reserveert projectieruimte voor frame- en rolstructuur.").append(newline);
      text.append("Het bovenlabel, bijvoorbeeld FRAME, staat horizontaal. De vrije knopen maken het mogelijk frame-informatie buiten de centrale boom te tonen.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      text.append("Anaphor").append(newline).append(newline);
      text.append("Komt later inhoudelijker.").append(newline);
      text.append("Voor de basisnotatie: zie Simple. Anaphor gebruikt dezelfde vrije OpenGraph-bronboom, maar zal anaforische relaties en verwijzingen als aparte projectie tonen.").append(newline);
      text.append("De centrale boom blijft intact; anaforische lijnen of labels worden als projectieve laag toegevoegd.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    return "Onbekend Tree-type.";
  }

  private void appendSimpleTreeExplanation(StringBuffer text, String newline)
  {
    text.append("Simple").append(newline).append(newline);
    text.append("Kijk eerst naar de afbeelding bovenaan dit venster.").append(newline);
    text.append("Daar zie je een centrale open structuur op een raster. De knopen zijn vrij geplaatst: niet willekeurig, maar op gecontroleerde rasterpunten. Daardoor blijft er ruimte voor eigen projectielijnen.").append(newline);
    text.append("De tweede helft van de afbeelding maakt dit nog concreter: doordat de boom niet tegen de linker- of onderrand wordt vastgedrukt, blijft links en beneden plaats over voor projecties.").append(newline).append(newline);

    text.append("In deze Simple-afbeelding zijn twee stappen zichtbaar:").append(newline);
    text.append("- links in de afbeelding: groen, horizontaal = zinprojectie; geel = een tweede projectielijn;").append(newline);
    text.append("- rechts in de afbeelding: dezelfde gedachte vóórdat de projecties zijn ingevuld: de vrije plaatsing op het raster laat open ruimte links en beneden.").append(newline);
    text.append("Die ruimte is geen decoratie. Zij is notationeel nodig: een projectie moet ergens kunnen landen zonder de centrale bronboom te overschrijven.").append(newline);
    text.append("Vooralsnog gebruiken we vooral projectieruimte naar links en naar beneden. Later kunnen andere projectierichtingen worden toegevoegd.").append(newline);
    text.append("Simple gebruikt deze afbeelding nog niet om LEX/SYNT/LOGical uit te werken. Dat gebeurt bij Language. Simple toont eerst het notationele principe: raster, vrije plaatsing, eigen lijnen, projectieruimte.").append(newline).append(newline);

    text.append("1. De traditionele boom als uitgangspunt").append(newline);
    text.append("In een klassieke syntactische boom staan woorden vaak onderaan, als eindknopen. Dat lijkt vanzelfsprekend, maar 'onder' is geen taalkundige eigenschap. Het is een tekenconventie.").append(newline);
    text.append("Een regel als S -> NP VP zegt tegelijk iets over structuur en volgorde: S bestaat uit NP en VP, en NP staat vóór VP. Zelfs met één laag, de syntactische laag, zit volgorde dus al in de boomtakken ingebakken.").append(newline);
    text.append("Zodra een zichtbare volgorde niet past bij die lokale vertakking, heeft de traditionele analyse extra mechanismen nodig: verplaatsing, lege posities, filler-gap-regels of transformaties.").append(newline).append(newline);

    text.append("2. OpenGraph-notatie: vrije bronknopen").append(newline);
    text.append("OpenGraphEd begint niet met één gesloten eindboom. De editor bevat vrije bronknopen met labels en takken. Die knopen liggen op een raster en kunnen vrijer in de notatieruimte worden geplaatst.").append(newline);
    text.append("Vrij betekent hier: niet meteen opgesloten in één traditionele boomrichting. Een knoop kan structureel verbonden zijn en tegelijk beschikbaar blijven voor een projectie naar links, rechts, onder of boven.").append(newline);
    text.append("De vrije plaatsing is dus ook een ruimtelijke afspraak: links van de bron kan een LEX-achtige lijn ontstaan; onder de bron kan een LOGical/functionele lijn ontstaan. In Simple wordt die projectieruimte nog alleen voorbereid.").append(newline);
    text.append("De afbeelding laat daarom vroeg zien waar de winst zit: één bronstructuur kan plaats bieden aan meerdere projecties in één beeld.").append(newline).append(newline);

    text.append("3. Projecties hebben eigen lijnen").append(newline);
    text.append("Een projectie is een gereguleerde lezing van dezelfde bron. De projectie gebruikt eigen lijnen en eigen plaatsingsregels. Daardoor hoeft niet alles in de centrale boomtakken te worden geperst.").append(newline);
    text.append("In Simple is de inhoud nog minimaal: groen toont de zinprojectie; geel toont dat een tweede projectielaag mogelijk is. De technische kern is al zichtbaar: raster + vrije plaatsing + eigen projectielijnen.").append(newline).append(newline);

    text.append("4. Waarom Simple belangrijk is").append(newline);
    text.append("Simple is de basiscontrole voor de vrije OpenGraph-bron. Klopt de graph als boom? Zijn er geen 1-kindknoopfouten? Kan de structuur compact worden getekend?").append(newline);
    text.append("Als Simple klopt, is er een stabiele basis waarop Language, Functional, Frame en Anaphor hun projecties kunnen plaatsen.").append(newline).append(newline);

    text.append("5. Minimum kindtakken").append(newline);
    text.append("Een knoop heeft 0 kindtakken of minimaal 2 kindtakken.").append(newline);
    text.append("0 kindtakken betekent: eindknoop/terminaal element.").append(newline);
    text.append("1 kindtak is fout: een tak onder een tak is geen geldige boomvertakking in deze OpenGraph-tree-weergave.").append(newline);
    text.append("Richting is hierbij irrelevant. Alleen het aantal kindtakken telt.").append(newline).append(newline);

    text.append("6. Binair en n-air").append(newline);
    text.append("2 kindtakken geeft een binaire vertakking.").append(newline);
    text.append("3, 4 of meer kindtakken geeft een n-air vertakking.").append(newline);
    text.append("De boom hoeft dus niet kunstmatig naar alleen binaire vertakkingen te worden teruggebracht. Waar je wel binair wilt testen, stel je Branches = 2 in op de relevante categoriale knoop.").append(newline).append(newline);

    text.append("7. Recursieve box-aanpak").append(newline);
    text.append("Simple tekent van onder naar boven. Elke subboom krijgt eerst een denkbeeldige box met breedte, hoogte, wortelpunt en kindposities.").append(newline);
    text.append("Daarna combineert de ouder de boxen van zijn kinderen compact naast elkaar en plaatst zichzelf erboven. De box is geen zichtbare rechthoek, maar een layout-hulpmiddel tegen overlap en overbodige lege gridlijnen.").append(newline);
  }

  private void appendCurrentTreeElements(StringBuffer text, String newline)
  {
    Graph graph = graphEditor == null ? null : graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 )
    {
      return;
    }

    java.util.Vector terminals = new java.util.Vector();
    java.util.Vector categories = new java.util.Vector();
    java.util.Vector marked = new java.util.Vector();

    for ( int i=0; i<graph.getNumNodes(); i++ )
    {
      Node node = graph.getNodeAt(i);
      if ( node == null ) continue;
      String label = cleanTreeExplanationLabel(node.getLabel());
      if ( label.length() == 0 ) continue;

      if ( label.indexOf('(') >= 0 || label.indexOf('[') >= 0 || label.indexOf(':') >= 0 )
      {
        addUniqueLimited(marked, label, 16);
      }

      if ( isLikelyTreeCategoryLabel(label) )
      {
        addUniqueLimited(categories, label, 16);
      }
      else
      {
        addUniqueLimited(terminals, label, 16);
      }
    }

    text.append(newline).append("Huidige boom:").append(newline);
    text.append("- knopen: ").append(graph.getNumNodes()).append("; takken: ").append(graph.getNumEdges()).append(newline);
    if ( categories.size() > 0 )
    {
      text.append("- categoriale knopen: ").append(joinVector(categories)).append(newline);
    }
    if ( terminals.size() > 0 )
    {
      text.append("- elementen/eindlabels: ").append(joinVector(terminals)).append(newline);
    }
    if ( marked.size() > 0 )
    {
      text.append("- elementen met rol/markering: ").append(joinVector(marked)).append(newline);
    }
  }

  private String cleanTreeExplanationLabel(String label)
  {
    return label == null ? "" : label.trim();
  }

  private void addUniqueLimited(java.util.Vector vector, String value, int limit)
  {
    if ( value == null || value.length() == 0 ) return;
    if ( vector.contains(value) ) return;
    if ( vector.size() < limit )
    {
      vector.addElement(value);
    }
    else if ( vector.size() == limit )
    {
      vector.addElement("...");
    }
  }

  private String joinVector(java.util.Vector vector)
  {
    StringBuffer result = new StringBuffer();
    for ( int i=0; vector != null && i<vector.size(); i++ )
    {
      if ( i > 0 ) result.append(", ");
      result.append(vector.elementAt(i));
    }
    return result.toString();
  }

  private boolean isLikelyTreeCategoryLabel(String label)
  {
    if ( label == null ) return false;
    String v = label.trim();
    if ( v.length() == 0 ) return false;
    if ( v.equals("S") || v.equals("CP") || v.equals("VP") || v.equals("DP") ||
         v.equals("NP") || v.equals("PP") || v.equals("AP") || v.equals("V") ||
         v.equals("N") || v.equals("A") || v.equals("P") || v.equals("Det") ||
         v.equals("Comp") || v.equals("PV") || v.equals("VD") )
    {
      return true;
    }
    return v.toUpperCase().equals(v) && v.length() <= 6;
  }

  private JComboBox createStructureTypeCombo()
  {
    final StructureTypeItem[] items = new StructureTypeItem[]
    {
      new StructureTypeItem(STRUCTURE_ORIGINAL_GRAPH, "origineel", "Huidige editorboom zonder Draw-resultaat. Herlaadt niet van schijf; aangepaste editorboom blijft behouden."),
      new StructureTypeItem(STRUCTURE_OPENGRAPH_CAROUSEL, "OpenGraph", "Uitlegstand met screenshot-carrousel: vrije knopen, projectieruimte en eerste projecties."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_SIMPLE_TREE, "Simple", "Simple tree: compact; binair en n-air via branch-config per categoriale knoop."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE, "Language", "Taalboom Nederlands: LEX-projectie, zinstypeprofielen, V-cluster en projectieprofiel."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE, "Functional", "Functional Tree: functionele rollen, role_box layout, projectiegestuurd."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_FRAME, "Frame", "Frame: rol-/functiestructuur met eigen projectieprofiel."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_ANAPHOR_TREE, "Anaphor", "Anaphor: anaforische/projectieve structuur.")
    };
    final JComboBox combo = new JComboBox(items);
    combo.setFocusable(false);
    combo.setToolTipText("Tree. Volgorde: origineel, OpenGraph, Simple, Language, Functional, Frame, Anaphor. Origineel toont de huidige editorboom zonder Draw-resultaat; OpenGraph toont de uitlegcarrousel.");
    combo.setRenderer(new DefaultListCellRenderer()
    {
      public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
      {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if ( value instanceof StructureTypeItem )
        {
          StructureTypeItem item = (StructureTypeItem)value;
          setText(item.toString());
          list.setToolTipText(item.getToolTip());
        }
        return this;
      }
    });
    combo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if ( updatingStructureTypeCombo )
        {
          return;
        }
        Object selected = combo.getSelectedItem();
        if ( selected instanceof StructureTypeItem )
        {
          int value = ((StructureTypeItem)selected).getValue();
          lastExplicitTreeTypeSelection = value;
          if ( value == STRUCTURE_ORIGINAL_GRAPH )
          {
            showGraphEditorCard();
            graphController.restoreOriginalOpenGraphTree(GraphEditorWindow.this);
          }
          else if ( value == STRUCTURE_OPENGRAPH_CAROUSEL )
          {
            showOpenGraphCarousel();
          }
          else
          {
            showGraphEditorCard();
            graphController.applyOpenGraphStructureType(GraphEditorWindow.this, value);
          }
        }
      }
    });
    return combo;
  }

  private static class StructureTypeItem
  {
    private final int value;
    private final String label;
    private final String toolTip;

    StructureTypeItem(int value, String label, String toolTip)
    {
      this.value = value;
      this.label = label;
      this.toolTip = toolTip;
    }

    int getValue()
    {
      return value;
    }

    String getToolTip()
    {
      return toolTip;
    }

    public String toString()
    {
      return label;
    }
  }

  private JToggleButton createZinstypeButton(String text, final String zinstype)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 6, 2, 6));
    button.setFocusable(false);
    button.setToolTipText(buildZinstypeToolTip(zinstype));
    if ( zinstypeButtonGroup != null )
    {
      zinstypeButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeZinstype(GraphEditorWindow.this, zinstype);
          updateZinstypeButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  private String buildZinstypeToolTip(String zinstype)
  {
    OpenGraphProjectionSettings settings = graphEditor == null ? new OpenGraphProjectionSettings() : new OpenGraphProjectionSettings(graphEditor.getOpenGraphProjectionSettings());
    settings.setLanguageTreeZinstype(zinstype);
    String[] lines = settings.getLanguageTreeZinstypeRulePreviewLines();
    StringBuffer html = new StringBuffer("<html><b>Zinstype: ");
    html.append(settings.getLanguageTreeZinstypeDisplayName());
    html.append("</b><br>");
    html.append("Language Tree / Phrase; geen Frame. DS blijft staan, regels werken op de LEX-as.<br><br>");
    for ( int i=0; i<lines.length; i++ )
    {
      if ( lines[i] != null && lines[i].trim().length() > 0 )
      {
        html.append("&#8226; ").append(lines[i]).append("<br>");
      }
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) )
    {
      html.append("<br>Klik eerst een categoriale knoop, bijvoorbeeld NP of DP.<br>");
      html.append("De lexicale vorm wordt als frase getoond, bijvoorbeeld NP(de man).");
    }
    html.append("</html>");
    return html.toString();
  }

  private JPanel createVerbClusterPanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    panel.setOpaque(false);
    JLabel label = new JLabel("V:");
    label.setToolTipText("V-cluster voor Language Tree: lokale vertakking/volgorde binnen V. Projectie blijft terminale knoop -> LEX-as.");
    panel.add(label);

    verbClusterButtonGroup = new ButtonGroup();
    pvVdVerbClusterButton = createVerbClusterButton("pv-VD", OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD,
      "heeft gebeten: pv kort/eerst, VD lang/tweede");
    vdPvVerbClusterButton = createVerbClusterButton("VD-pv", OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV,
      "gebeten heeft: VD kort/eerst, pv lang/tweede");
    panel.add(pvVdVerbClusterButton);
    panel.add(vdPvVerbClusterButton);
    return panel;
  }

  private JToggleButton createVerbClusterButton(String text, final String order, String toolTip)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 6, 2, 6));
    button.setFocusable(false);
    button.setToolTipText("<html><b>V-cluster " + text + "</b><br>" + toolTip + "<br>Alleen Language Tree / Phrase. De DS-projecties blijven onveranderd.</html>");
    if ( verbClusterButtonGroup != null )
    {
      verbClusterButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeVerbClusterOrder(GraphEditorWindow.this, order);
          updateVerbClusterButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  public void updateVerbClusterButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String order = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeVerbClusterOrder();
    if ( OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV.equals(order) && vdPvVerbClusterButton != null )
    {
      vdPvVerbClusterButton.setSelected(true);
    }
    else if ( pvVdVerbClusterButton != null )
    {
      pvVdVerbClusterButton.setSelected(true);
    }
  }

  public void updateZinstypeButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String zinstype = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeZinstype();
    if ( OpenGraphProjectionSettings.ZINSTYPE_BIJZIN.equals(zinstype) && bijzinZinstypeButton != null )
    {
      bijzinZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) && stellendZinstypeButton != null )
    {
      stellendZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) && jaNeeZinstypeButton != null )
    {
      jaNeeZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype) && whZinstypeButton != null )
    {
      whZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) && topicalisatieZinstypeButton != null )
    {
      topicalisatieZinstypeButton.setSelected(true);
    }
    else if ( basisZinstypeButton != null )
    {
      basisZinstypeButton.setSelected(true);
    }
  }

  public void updateStructureTypeComboSelection()
  {
    if ( graphEditor == null || structureTypeCombo == null )
    {
      return;
    }
    int structureType = isOpenGraphCarouselSelected() ? STRUCTURE_OPENGRAPH_CAROUSEL :
      (graphEditor.isOpenGraphProjectionContextActive() ?
       graphEditor.getOpenGraphProjectionSettings().getStructureType() :
       (lastExplicitTreeTypeSelection != STRUCTURE_ORIGINAL_GRAPH ? lastExplicitTreeTypeSelection : STRUCTURE_ORIGINAL_GRAPH));
    updatingStructureTypeCombo = true;
    try
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          structureTypeCombo.setSelectedIndex(i);
          return;
        }
      }
    }
    finally
    {
      updatingStructureTypeCombo = false;
    }
  }

  public void updateOpenGraphHeaderControls()
  {
    updateZinstypeButtonSelection();
    updateVerbClusterButtonSelection();
    updateStructureTypeComboSelection();
    updateProjectionProfileControlsFromEditor();
    updateOpenGraphHeaderControlsVisibility();
  }

  private void updateOpenGraphHeaderControlsVisibility()
  {
    if ( graphEditor == null )
    {
      return;
    }
    int structureType = currentDisplayedTreeTypeValue();
    boolean isOriginalTree = structureType == STRUCTURE_ORIGINAL_GRAPH;
    boolean isOpenGraphCarousel = structureType == STRUCTURE_OPENGRAPH_CAROUSEL;
    boolean isLanguageTree = structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    if ( zinstypePanel != null )
    {
      zinstypePanel.setVisible(isLanguageTree);
    }
    if ( verbClusterPanel != null )
    {
      verbClusterPanel.setVisible(isLanguageTree);
    }
    if ( languageTreeSettingsButton != null )
    {
      languageTreeSettingsButton.setVisible(isLanguageTree);
    }
    boolean isFunctionalTree = structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE;
    if ( functionalTreeSettingsButton != null )
    {
      functionalTreeSettingsButton.setVisible(isFunctionalTree);
    }
    if ( projectionProfilePanel != null )
    {
      projectionProfilePanel.setVisible(!isOpenGraphCarousel && OpenGraphProjectionSettings.isProjectionCapableStructureType(structureType));
    }
    if ( openGraphDrawButton != null )
    {
      openGraphDrawButton.setVisible(!isOriginalTree && !isOpenGraphCarousel && !isLanguageTree);
    }
    revalidate();
    repaint();
  }


  private JButton createOpenGraphButton(String text, String toolTip, ActionListener listener)
  {
    JButton button = new JButton(text);
    button.setMargin(new Insets(2, 8, 2, 8));
    button.setFocusable(false);
    button.setToolTipText(toolTip);
    button.addActionListener(listener);
    return button;
  }

  public void dispose()
  {
    graphEditor.prepareForClose();
    super.dispose();
  }

  public GraphEditor getGraphEditor()
  {
    return graphEditor;
  }

  public GraphEditorDialog getDialog() { return ged; }

  public void setDialog(GraphEditorDialog d) { ged = d; }

  public GraphEditorInfoWindow getInfoWindow()
  {
    return infoWindow;
  }
  
  public GraphEditorLogWindow getLogWindow()
  {
    return logWindow;
  }  
}