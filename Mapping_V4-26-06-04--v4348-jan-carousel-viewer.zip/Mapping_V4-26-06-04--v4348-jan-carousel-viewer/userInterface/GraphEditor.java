package userInterface;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
//tvo
//import com.sun.image.codec.jpeg.*; //replaced by:
import javax.imageio.ImageIO.*;
import graphStructure.*;
import userInterface.fileUtils.*;
import userInterface.modes.*;
/**
 * This class defines the GraphEditor object which is the core of the
 * application.<br>
 * <br>
 * The GraphEditor allows display of and operations on a Graph.
 *
 * @author Jon Harris
 */
public class GraphEditor extends JPanel
{
  private static Cursor rotateCursor = createRotateCursor();

  private static Cursor createRotateCursor()
  {
    try
    {
      java.net.URL url = GraphEditor.class.getResource("/images/RotateCursor.gif");
      if (url == null) return Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
      Image image = Toolkit.getDefaultToolkit().getImage(url);
      return Toolkit.getDefaultToolkit().createCustomCursor(image, new Point(16, 16), "Rotate");
    }
    catch (Throwable t)
    {
      return Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
    }
  }
  private static Cursor normalCursor = Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR);
  private static Cursor moveCursor = Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR);
  private static Cursor diagResizeCursor = Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR);
  private static Cursor horiResizeCursor = Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR);
  private static Cursor vertResizeCursor = Cursor.getPredefinedCursor(Cursor.S_RESIZE_CURSOR);

  public static Color borderColor = Color.lightGray;
  public static Color backgroundColor = Color.white;
  public static int DRAW_BUFFER = 15;

  private GraphEditorInfoWindow infoWindow;
  private GraphEditorLogWindow logWindow;
  private GraphEditorListener listener;
  private final GraphEditorOverlayState overlayState = new GraphEditorOverlayState();
  private final GraphEditorRenderState renderState = new GraphEditorRenderState();
  private static OpenGraphGridSettings sessionOpenGraphGridSettings;
  private static OpenGraphProjectionSettings sessionOpenGraphProjectionSettings;
  private static OpenGraphProjectionSettings sessionRememberedLanguageProjectionSettings;
  private OpenGraphGridSettings openGraphGridSettings = new OpenGraphGridSettings();
  private OpenGraphProjectionSettings openGraphProjectionSettings = new OpenGraphProjectionSettings();
  private OpenGraphProjectionSettings rememberedLanguageProjectionSettings = new OpenGraphProjectionSettings();
  private boolean openGraphProjectionContextActive;
  private boolean suppressUndirectedMidpointMarkers;
  private final GraphEditorModeSupport modeSupport = new GraphEditorModeSupport(this);
  private final GraphEditorLayoutSupport layoutSupport = new GraphEditorLayoutSupport(this);
  private final GraphEditorOverlaySupport overlaySupport = new GraphEditorOverlaySupport(this, overlayState);
  private final GraphEditorRenderSupport renderSupport = new GraphEditorRenderSupport(this, renderState);

  /**
   * Constructor for class GraphEditor.
   */
  public GraphEditor(GraphController controller, GraphEditorInfoWindow infoWindow,
                     GraphEditorLogWindow logWindow)
  {
    Graph newGraph = new Graph();
    newGraph.setGridArea(3, getDrawHeight(),
                         3, getDrawWidth(), false);
    initialize(controller, newGraph, infoWindow, logWindow);
  }

  /**
   * Constructor for class GraphEditor, specifying the Graph it contains.
   *
   * @param Graph g: The Graph Object that is displayed / modified by this component.
   */
  public GraphEditor(GraphController controller, Graph g,
                     GraphEditorInfoWindow infoWindow, GraphEditorLogWindow logWindow)
  {
    initialize(controller, g, infoWindow, logWindow);
  }

  public void changeToNormalCursor() {  setCursor(normalCursor); }
  public void changeToDiagonalResizeCursor() {  setCursor(diagResizeCursor); }
  public void changeToHorizontalResizeCursor() {  setCursor(horiResizeCursor); }
  public void changeToVerticalResizeCursor() {  setCursor(vertResizeCursor); }
  public void changeToRotateCursor() { setCursor(rotateCursor); }
  public void changeToMoveCursor() { setCursor(moveCursor); }

  // Initialize the editor's components.
  private void initialize(GraphController controller, Graph g,
                          GraphEditorInfoWindow infoWindow,
                          GraphEditorLogWindow logWindow)
  {
    listener = modeSupport.createInitialListener(controller, g);
    this.infoWindow = infoWindow;
    this.logWindow = logWindow;
    suppressUndirectedMidpointMarkers = false;
    setBackground(borderColor);
    loadSessionOpenGraphSettings();
    setPreferredSize();
    overlaySupport.initShapes();
    addEventHandlers();
    updateShapes();
  }

  public void changeToEditMode()
  {
    modeSupport.changeToEditMode();
  }

  public boolean isInEditMode() { return modeSupport.isInEditMode(); }

  public void changeToMoveMode()
  {
    modeSupport.changeToMoveMode();
  }

  public boolean isInMoveMode() { return modeSupport.isInMoveMode(); }

  public void changeToRotateMode()
  {
    modeSupport.changeToRotateMode();
  }

  public boolean isInRotateMode() { return modeSupport.isInRotateMode(); }

  public void changeToResizeMode()
  {
    modeSupport.changeToResizeMode();
  }

  public boolean isInGridMode() { return modeSupport.isInGridMode(); }

  void ensureGridListener()
  {
    modeSupport.ensureGridListener();
  }

  /**
   * Switch to grid mode using explicit grid counts and explicit cell sizes.
   * For OpenGraph drawings these parameters are row/column counts plus row height
   * and column width, not a total drawing area.
   */
  public void changeToOpenGraphGridMode(int rows, int rowHeight, int cols, int colWidth)
  {
    layoutSupport.changeToOpenGraphGridMode(rows, rowHeight, cols, colWidth);
  }

  /**
   * Apply the currently selected OpenGraph grid settings.
   */
  public void changeToOpenGraphGridMode(OpenGraphGridSettings settings)
  {
    layoutSupport.changeToOpenGraphGridMode(settings);
  }

  /**
   * Compatibility bridge for older callers that still request a dynamic
   * OpenGraph grid directly.
   */
  public void changeToDynamicOpenGraphGridMode(int rowHeight, int colWidth)
  {
    layoutSupport.changeToDynamicOpenGraphGridMode(rowHeight, colWidth);
  }

  public void changeToGridMode()
  {
    layoutSupport.changeToGridMode();
  }

  public boolean isInResizeMode() { return modeSupport.isInResizeMode(); }

  public String getModeString() { return modeSupport.getModeString(); }

  public String getShowString() { return getGraph().getShowString(); }

  public void allowNodeSelection(int numSelectionsAllowed)
  {
    modeSupport.allowNodeSelection(numSelectionsAllowed);
  }

  public void allowTriangleSelection()
  {
    modeSupport.allowTriangleSelection();
  }

  public Node[] getSpecialNodeSelections()
  {
    return modeSupport.getSpecialNodeSelections();
  }

  public void setGraph(Graph g)
  {
    listener.setGraph(g);
    openGraphProjectionContextActive = false;
    setPreferredSize();
  }

  public Graph getGraph() { return listener.getGraph(); }

  public GraphController getGraphController() { return listener.getGraphController(); }

  private synchronized void loadSessionOpenGraphSettings()
  {
    if ( sessionOpenGraphGridSettings == null )
    {
      sessionOpenGraphGridSettings = OpenGraphGridSettingsIO.loadBestAvailable();
    }
    if ( sessionOpenGraphProjectionSettings == null )
    {
      sessionOpenGraphProjectionSettings = OpenGraphProjectionSupport.loadBestAvailable();
    }
    if ( sessionRememberedLanguageProjectionSettings == null )
    {
      sessionRememberedLanguageProjectionSettings = sessionOpenGraphProjectionSettings.copy();
    }

    openGraphGridSettings = sessionOpenGraphGridSettings.copy();
    openGraphProjectionSettings = sessionOpenGraphProjectionSettings.copy();
    rememberedLanguageProjectionSettings = sessionRememberedLanguageProjectionSettings.copy();
  }

  private synchronized void syncSessionOpenGraphSettings()
  {
    sessionOpenGraphGridSettings = getOpenGraphGridSettings();
    sessionOpenGraphProjectionSettings = getOpenGraphProjectionSettings();
    sessionRememberedLanguageProjectionSettings = getRememberedLanguageProjectionSettings();
  }

  public OpenGraphGridSettings getOpenGraphGridSettings()
  {
    if ( openGraphGridSettings == null )
    {
      openGraphGridSettings = new OpenGraphGridSettings();
    }
    return openGraphGridSettings.copy();
  }

  public void setOpenGraphGridSettings(OpenGraphGridSettings settings)
  {
    if ( settings == null )
    {
      openGraphGridSettings = new OpenGraphGridSettings();
    }
    else
    {
      openGraphGridSettings = settings.copy();
    }
    syncSessionOpenGraphSettings();
  }

  public OpenGraphProjectionSettings getOpenGraphProjectionSettings()
  {
    if ( openGraphProjectionSettings == null )
    {
      openGraphProjectionSettings = new OpenGraphProjectionSettings();
    }
    return openGraphProjectionSettings.copy();
  }

  public void setOpenGraphProjectionSettings(OpenGraphProjectionSettings settings)
  {
    if ( settings == null )
    {
      openGraphProjectionSettings = new OpenGraphProjectionSettings();
    }
    else
    {
      openGraphProjectionSettings = settings.copy();
    }
    syncSessionOpenGraphSettings();
  }

  public OpenGraphProjectionSettings getRememberedLanguageProjectionSettings()
  {
    if ( rememberedLanguageProjectionSettings == null )
    {
      rememberedLanguageProjectionSettings = new OpenGraphProjectionSettings();
    }
    return rememberedLanguageProjectionSettings.copy();
  }

  public void rememberLanguageProjectionSettings(OpenGraphProjectionSettings settings)
  {
    if ( settings == null )
    {
      rememberedLanguageProjectionSettings = new OpenGraphProjectionSettings();
    }
    else
    {
      rememberedLanguageProjectionSettings = settings.copy();
    }
    syncSessionOpenGraphSettings();
  }

  public boolean isOpenGraphProjectionContextActive()
  {
    return openGraphProjectionContextActive;
  }

  public boolean isOpenGraphDisplayActive()
  {
    return isOpenGraphProjectionContextActive() || isOpenGraphDrawState();
  }

  public void setOpenGraphProjectionContextActive(boolean active)
  {
    openGraphProjectionContextActive = active;
    if ( active )
    {
      suppressUndirectedMidpointMarkers = true;
    }
    syncSessionOpenGraphSettings();
  }

  public boolean suppressUndirectedMidpointMarkers()
  {
    return suppressUndirectedMidpointMarkers;
  }

  public void setPreferredSize()
  {
    layoutSupport.refreshPreferredSize();
  }

  public Rectangle2D.Double getVisibleContentBounds()
  {
    return layoutSupport.getVisibleContentBounds();
  }

  public int getDrawWidth() { return layoutSupport.getDrawWidth(); }

  public int getDrawHeight() { return layoutSupport.getDrawHeight(); }

  public int getVisibleDrawWidth()
  {
    Rectangle vr = getVisibleRect();
    int width = vr != null ? vr.width : getWidth();
    return Math.max(1, width - 2 * GraphEditor.DRAW_BUFFER);
  }

  public int getVisibleDrawHeight()
  {
    Rectangle vr = getVisibleRect();
    int height = vr != null ? vr.height : getHeight();
    return Math.max(1, height - 2 * GraphEditor.DRAW_BUFFER);
  }

  GraphEditorListener getEditorListener() { return listener; }

  void setEditorListener(GraphEditorListener listener) { this.listener = listener; }

  void registerCurrentListener() { addEventHandlers(); }

  void unregisterCurrentListener() { removeEventHandlers(); }

  void clearTransientShapes() { overlaySupport.initShapes(); }

  public void saveImage(String fileName)
  {
    BufferedImage imageToSave = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
    paint(imageToSave.getGraphics());
    if (imageToSave != null)
    {
      try
      {
        FileOutputStream out = new FileOutputStream(fileName);
        try
        {
          if (fileName.substring(fileName.lastIndexOf('.')+1).equalsIgnoreCase(Utils.gif))
          {
            GIFOutputStream.writeGIF(out, imageToSave);
          }
          else
          {
  //tvo
	      //        JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
     //       JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(imageToSave);
     //       param.setQuality(1.0f, false);
      //      encoder.setJPEGEncodeParam(param);
       //     encoder.encode(imageToSave);
          }
          out.close();
        }
        catch (IOException ioe)
        {
          System.out.println("Error writing image to file");
          ioe.printStackTrace();
        }
      }
      catch (FileNotFoundException fnfe)
      {
        System.out.println("Could not locate the file to save the image to!\n");
        fnfe.printStackTrace();
      }
    }
  }

  // Add the event handlers to the canvas.
  private void addEventHandlers()
  {
    addMouseListener(listener);
    addMouseMotionListener(listener);
    addKeyListener(listener);
    if ( listener instanceof FocusListener )
    {
      addFocusListener((FocusListener)listener);
    }
    if ( listener instanceof AncestorListener )
    {
      addAncestorListener((AncestorListener)listener);
    }
  }

  // Remove the event handlers from the canvas.
  private void removeEventHandlers()
  {
    removeMouseListener(listener);
    removeMouseMotionListener(listener);
    removeKeyListener(listener);
    if ( listener instanceof FocusListener )
    {
      removeFocusListener((FocusListener)listener);
    }
    if ( listener instanceof AncestorListener )
    {
      removeAncestorListener((AncestorListener)listener);
    }
  }

  public void setLineToDraw( Line2D.Double lineToDraw )
  {
    overlaySupport.setLineToDraw(lineToDraw);
  }

  public void setLineToDrawColor(Color aColor)
  {
    overlaySupport.setLineToDrawColor(aColor);
  }

  public void setPointToDraw( Ellipse2D.Double pointToDraw )
  {
    overlaySupport.setPointToDraw(pointToDraw);
  }

  public void setRectangleToDraw( Rectangle2D.Double rectangleToDraw )
  {
    overlaySupport.setRectangleToDraw(rectangleToDraw);
  }

  public Rectangle2D.Double getRectangleToDraw() { return overlaySupport.getRectangleToDraw(); }

  public void setPolygonToDraw( Polygon polygonToDraw )
  {
    overlaySupport.setPolygonToDraw(polygonToDraw);
  }

  public Polygon getPolygonToDraw() { return overlaySupport.getPolygonToDraw(); }

  public void setPolygonToDrawColor(Color aColor)
  {
    overlaySupport.setPolygonToDrawColor(aColor);
  }

  public void setCurveToDraw( QuadCurve2D.Double curveToDraw )
  {
    overlaySupport.setCurveToDraw(curveToDraw);
  }

  public QuadCurve2D.Double getCurveToDraw() { return overlaySupport.getCurveToDraw(); }

  public void setCurveToDrawColor(Color aColor)
  {
    overlaySupport.setCurveToDrawColor(aColor);
  }

  public void resetTransientEditorArtifacts()
  {
    renderSupport.resetTransientRenderState();
    overlaySupport.initShapes();
  }

  public void redo()
  {
    resetTransientEditorArtifacts();
    boolean preserveGreedyGrowGrid = isGreedyGrowRedoState() || isGreedyGrowGraphWithGrid();
    getGraph().redo();
    if ( preserveGreedyGrowGrid ) restoreGreedyGrowGridAfterHistoryNavigation();
    else restoreOpenGraphStateAfterRedo();
    refreshLayoutAfterHistoryNavigation();
    resetTransientEditorArtifacts();
    //setDrawGrid(getGraph().peekUndo() != null && getGraph().peekUndo().getTitle().equals("Display Schnyder Embedding"));
    updateShapes();
    repaint();
  }

  public void undo()
  {
    boolean preserveGreedyGrowGrid = isGreedyGrowUndoState() || isGreedyGrowGraphWithGrid();
    getGraph().undo();
    if ( preserveGreedyGrowGrid ) restoreGreedyGrowGridAfterHistoryNavigation();
    else clearOpenGraphStateAfterUndo();
    refreshLayoutAfterHistoryNavigation();
    resetTransientEditorArtifacts();
    //setDrawGrid(getGraph().peekUndo() != null && getGraph().peekUndo().getTitle().equals("Display Schnyder Embedding"));
    updateShapes();
    repaint();
  }

  private void clearOpenGraphStateAfterUndo()
  {
    if ( !isOpenGraphDrawState() )
    {
      openGraphProjectionContextActive = false;
      getGraph().setDrawGrid(false);
      if ( isInGridMode() )
      {
        changeToEditMode();
      }
    }
    syncSessionOpenGraphSettings();
  }

  private void restoreOpenGraphStateAfterRedo()
  {
    openGraphProjectionContextActive = isProjectionDrawState();
    if ( isOpenGraphDrawState() )
    {
      changeToOpenGraphGridMode(getOpenGraphGridSettings());
    }
    syncSessionOpenGraphSettings();
  }

  private void restoreGreedyGrowGridAfterHistoryNavigation()
  {
    if ( getGraph() == null )
    {
      return;
    }
    getGraph().setDrawGrid(true);
    if ( !isInGridMode() )
    {
      ensureGridListener();
    }
    openGraphProjectionContextActive = false;
    syncSessionOpenGraphSettings();
  }

  private boolean isGreedyGrowUndoState()
  {
    return getGraph() != null && getGraph().peekUndo() != null &&
           isGreedyGrowHistoryTitle(getGraph().peekUndo().getTitle());
  }

  private boolean isGreedyGrowRedoState()
  {
    return getGraph() != null && getGraph().peekRedo() != null &&
           isGreedyGrowHistoryTitle(getGraph().peekRedo().getTitle());
  }

  private boolean isGreedyGrowHistoryTitle(String title)
  {
    return title != null && title.startsWith("Greedy Grow");
  }

  private boolean isGreedyGrowGraphWithGrid()
  {
    return getGraph() != null && getGraph().hasGreedySettingsSpecText() && getGraph().getDrawGrid();
  }

  private boolean isOpenGraphDrawState()
  {
    if ( getGraph() == null )
    {
      return false;
    }
    return getGraph().peekUndo() != null &&
           "Display OpenGraph Drawing".equals(getGraph().peekUndo().getTitle());
  }

  private boolean isProjectionDrawState()
  {
    return isOpenGraphDrawState() &&
           OpenGraphProjectionSettings.isProjectionCapableStructureType(
             getRememberedLanguageProjectionSettings().getStructureType());
  }

  private void refreshLayoutAfterHistoryNavigation()
  {
    if ( !isInGridMode() || getGraph() == null || !getGraph().getDrawGrid() )
    {
      setPreferredSize();
      return;
    }
    setPreferredSize();
  }

  private void reapplyLanguageProjectionGridIfNeeded()
  {
    if ( !isInGridMode() || getGraph() == null || !getGraph().getDrawGrid() )
    {
      return;
    }

    OpenGraphProjectionSettings settings = getOpenGraphProjectionSettings();
    if ( !openGraphProjectionContextActive ||
         !OpenGraphProjectionSupport.hasReservedLexicalProjection(settings) )
    {
      return;
    }

    changeToOpenGraphGridMode(getOpenGraphGridSettings());
    layoutSupport.centerVisibleContentInWindow();
  }

  public void updateShapes()
  {
    overlaySupport.updateShapes();
  }

  public void startTranslateNode(Node aNode)
  {
    renderSupport.startTranslateNode(aNode);
  }

  public void startTranslateNodes(Vector nodes)
  {
    renderSupport.startTranslateNodes(nodes);
  }

  public void stopTranslateNodes()
  {
    renderSupport.stopTranslateNodes();
  }

  public void startTranslateEdge(Edge anEdge)
  {
    renderSupport.startTranslateEdge(anEdge);
  }

  public void stopTranslateEdge()
  {
    renderSupport.stopTranslateEdge();
  }

  public void startTranslate()
  {
    renderSupport.startTranslate();
  }

  public void translate( int dx, int dy )
  {
    renderSupport.translate(dx, dy);
  }

  public void stopTranslate()
  {
    renderSupport.stopTranslate();
  }

  public void startRotate()
  {
    renderSupport.startRotate();
  }

  public void rotate( Location pivotPoint, double angle )
  {
    renderSupport.rotate(pivotPoint, angle);
  }

  public void stopRotate()
  {
    renderSupport.stopRotate();
  }

  public void startScaleTo()
  {
    renderSupport.startScaleTo();
  }

  public void scaleTo( Rectangle2D.Double newBounds )
  {
    renderSupport.scaleTo(newBounds);
  }

  public void stopScaleTo()
  {
    renderSupport.stopScaleTo();
  }

  /**
   * Draw the current the current graph plus the outline of any potential
   * edges being added to the screen.
   *
   * @param Graphics aPen: The Graphics object to draw with.
   */
  public void paint(Graphics aPen)
  {
    if ( getGraph().logChangedSinceLastDraw() )
    {
      logWindow.update();
    }
    super.paint(aPen);
    Graphics2D g2 = (Graphics2D)aPen;
    renderSupport.paintGraph(g2);
    overlaySupport.paintOverlayShapes(g2);
    revalidate();
  }

  public void update()
  {
    resetTransientEditorArtifacts();
    updateShapes();
    infoWindow.update();
    setPreferredSize();
    repaint();
  }

  public void prepareForClose()
  {
    modeSupport.prepareForClose();
  }
}