# PACKAGING MANIFEST — v4337

## Naam

Mapping_V4-26-06-01--v4337-greedy-grow-config.zip

## Basis

v4336 Greedy Grow Static.

## Inhoud

- code
- `OpenGraphEd.jar`
- `dist/OpenGraphEd.jar`
- docs
- master-spec
- changelog
- sources/pdf
- sources/text
- md-only sources zip

## Belangrijkste wijziging

```text
grid standaard aan + fit-content
graph.no_limit voor boven-30 Greedy-runs
configtab voor alle Greedy/Grow-instellingen
```

## Compile

`javac` gecontroleerd: geen errors.
