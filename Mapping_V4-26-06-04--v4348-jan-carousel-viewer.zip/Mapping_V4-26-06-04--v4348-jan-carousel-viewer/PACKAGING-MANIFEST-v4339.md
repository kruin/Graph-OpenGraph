# PACKAGING MANIFEST — v4339

## Package

```text
Mapping_V4-26-06-03--v4339-greedy-grow-json-export.zip
```

## Basis

```text
v4338-greedy-grow-grid-undo
```

## Doel

Greedy Grow JSON-export toevoegen als contract voor een latere PWA/mobile demo.

## Belangrijkste bestanden

```text
userInterface/GreedyInternalGenerator.java
userInterface/OpenGraphActions.java
userInterface/GraphController.java
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
docs/14-greedy-grow-json-export.md
chatlog/CHANGELOG-v4339.md
md/PATCH-MANIFEST-v4339-greedy-grow-json-export.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## Outputvoorbeeld

```text
tools/greedy_generator_gui/output/space3_gridH20W20_grow_demo.json
```

## Buildstatus

```text
javac: geen compile errors
warnings: bestaande Java-deprecation warnings
jar: vernieuwd in root en dist/
```

## Md-only zip

```text
md-only-sources-v4339.zip
```

## Sources

PDF- en tekstbronnen uit eerdere packages blijven opgenomen onder:

```text
sources/pdf/
sources/text/
```
