# Greedy Generator - OpenGraphEd workflow

## Kern

De Greedy Generator in het menu **Greedy** werkt document-eerst:

```text
Greedy > Greedy Generator > Genereren
fine-tune in OpenGraphEd
Greedy > Save As...
```

**Genereren schrijft geen bestanden.** De graph wordt direct in OpenGraphEd getoond. Daarna kan de gebruiker grid, labels, knopen, projecties of layout aanpassen. Pas bij **Save As...** wordt er bewaard of geëxporteerd.

## Menu Greedy

| menu-item | betekenis |
|---|---|
| `Greedy Generator` | instellingen kiezen en direct een graph tonen; geen YAML/OPN/GRAPH-output |
| `Generate Greedy Graph` | opnieuw genereren vanuit de huidige documentinstellingen |
| `Open Greedy OPN` | eerder opgeslagen herstelbare Greedy-OPN openen, inclusief embedded instellingen |
| `Save As...` | huidige zichtbare/fijngestelde document bewaren of exporteren |
| `Greedy Tools...` | fallback, externe Python-GUI en inspectiehulpmiddelen |


## Plaatsingsstijlen / STYLE

`STYLE` bepaalt alleen de **volgorde waarin kandidaatpunten worden geprobeerd**. De harde regels blijven daarna beslissen of een kandidaat geldig is. Omdat de generator greedy is, wordt de eerste geldige kandidaat genomen; er is geen backtracking en geen globale optimalisatie achteraf.

| style | Nederlandse uitleg | English explanation | Wanneer gebruiken |
|---|---|---|---|
| `near0` | near-null / dicht bij nul: probeer eerst punten met de kleinste afstand tot knoop 0. Daarna tellen o.a. hoek, staplengte en vaste volgorde. | near-zero: try points closest to node 0 first. Angle, step length and stable ordering are tie-breakers. | compacte testbeelden, eerste controle, kleine voorbeelden |
| `maxturn` | probeer eerst kandidaten die de grootste hoek maken met de vorige stap. Dit geeft sterke bochten en minder rechte voortzetting. | prefer candidates with the largest angle against the previous step. This produces stronger turns and less straight continuation. | zichtbare richtingswisseling, testen van hoek- en lijnregels |
| `quadrant` | verdeel de groei over de vier kwadranten rond 0. De generator volgt een vaste kwadrantvolgorde en gebruikt de minst gevulde kwadranten als tie-breaker. | distribute growth across the four quadrants around 0. The generator follows a fixed quadrant sequence and uses less-used quadrants as tie-breakers. | evenwichtige spreiding rond 0 |
| `ring` | werk van binnen naar buiten: eerst de kleinste ring rond 0, daarna de volgende ring. Een ring is gebaseerd op `max(abs(x), abs(y))`. | grow from inside to outside: first the smallest ring around 0, then the next ring. A ring uses `max(abs(x), abs(y))`. | systematische, schilvormige groei |

Er zijn nu bewust **geen extra styles**. Deze vier zijn transparant, deterministisch en goed te vergelijken: compact (`near0`), draaiend (`maxturn`), kwadrantspreiding (`quadrant`) en ringgroei (`ring`). Meer styles zouden nu vooral extra menu- en testvarianten geven zonder dat de basisworkflow al stabieler wordt. Nieuwe styles kunnen later worden toegevoegd als er een duidelijk nieuw tekenprincipe nodig is, bijvoorbeeld een expliciete random/seeded variant of een echte globale optimalisator.

## Save As

| keuze | inhoud | Greedy restore |
|---|---|---:|
| `Greedy package (.zip)` | `.opn`, `.graph`, `spec.yaml`, `effective_spec.yaml`, report, `.svg`, `.png`, README waar beschikbaar | ja |
| `OPN document (.opn)` | graph + embedded `GREEDY_SETTINGS_YAML` | ja |
| `Graph only (.graph)` | alleen graphstructuur | nee |
| `Image only (.gif/.jpg/.jpeg)` | alleen afbeelding | nee |

Gebruik **Greedy package** voor archief en overdracht. Gebruik **OPN document** voor een compact herstelbaar Greedy-document.

## Grid en bestandsnamen

De actieve gridcel bepaalt de gridtag in outputnamen:

```text
gridH<rijhoogte>W<kolombreedte>
```

Dus:

```text
Gridstap Y = 19
Gridstap X = 21
-> space3_gridH19W21.opn
```

## YAML

YAML is geen verplicht tussentijds werkbestand meer.

- `Genereren` schrijft geen `spec.yaml`.
- Een Greedy package bevat wel een YAML/spec als exportinformatie.
- Een OPN document bevat de instellingen embedded als `GREEDY_SETTINGS_YAML`.

## Externe Python-GUI

De externe GUI in deze map blijft bestaan als fallback/reference-tool. Die kan nog zelfstandig `.graph`, `.opn`, `.svg`, `.png`, reports en specs schrijven. Vanuit OpenGraphEd staat die onder:

```text
Greedy > Greedy Tools... > External GUI
```

Voor de normale OpenGraphEd-route is de externe GUI niet nodig.
