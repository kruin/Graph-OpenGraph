# Handleiding Greedy Generator in OpenGraphEd

## Waar gaat dit over?

De Greedy Generator maakt een groeiende graph:

```text
0 -> 1 -> 2 -> ... -> n
```

Elke knoop ligt op een gridpunt. Elke nieuwe knoop wordt verbonden met de vorige knoop. De generator kiest telkens de eerste kandidaat die voldoet aan de ingestelde regels.

## Hoofdworkflow

```text
Greedy > Greedy Generator > Genereren
fine-tune in OpenGraphEd
Greedy > Save As...
```

Belangrijk: **Genereren is geen opslagactie**.

Wanneer je op **Genereren** klikt:

1. OpenGraphEd leest de waarden uit het Greedy Generator-venster.
2. De graph wordt intern gemaakt.
3. De graph wordt direct in het huidige OpenGraphEd-document getoond.
4. Er wordt geen YAML, OPN, GRAPH, SVG of PNG geschreven.

Daarna kun je de graph in OpenGraphEd aanpassen: grid, labels, knopen, projecties, layout en andere fine-tune.

## Greedy Generator-venster

### Tab Basis

| veld | betekenis |
|---|---|
| Projectnaam | interne naam voor document/spec |
| Titel | titel voor latere package/export |
| Documentbasisnaam | basis voor latere bestandsnamen |
| COUNT | aantal knopen |
| MAX | zoekvenster rond 0 |
| Taal | taal voor venster, rapporten en metadata |

`COUNT=31` betekent labels 0 t/m 30.  
`MAX=20` betekent modelpunten x,y in `[-20,+20]`.

### Tab Grid

| veld | betekenis |
|---|---|
| Gridstap X | kolombreedte / W in bestandsnaam |
| Gridstap Y | rijhoogte / H in bestandsnaam |
| Gridhoogte rijen | zichtbare gridhoogte; `0` = automatisch |
| Gridbreedte kolommen | zichtbare gridbreedte; `0` = automatisch |
| Marge | extra gridruimte rond het model |
| Hoofdlijn elke | zwaardere gridlijn per N |

Bestandsnamen gebruiken de actieve gridcel:

```text
gridH<rijhoogte>W<kolombreedte>
```

Voorbeeld:

```text
Gridstap Y = 19
Gridstap X = 21
-> space3_gridH19W21.opn
```

### Tab Greedy

| veld | betekenis |
|---|---|
| STYLE | volgorde waarin kandidaten worden geprobeerd |
| RULE | harde rechte-lijnregel |
| DIAGONAL_FREE | vrije diagonalen afdwingen ja/nee/richting |
| ANGLE_MIN | minimumhoek bij `RULE=angle` |

### STYLE / plaatsingsstijl

`STYLE` bepaalt de sortering van kandidaatpunten. Daarna worden de harde regels (`RULE`, `DIAGONAL_FREE`, bezette x/y-lijnen) getest. De generator neemt de eerste geldige kandidaat. Dat is bewust greedy: geen terugzoeken, geen herschikken van eerdere knopen, geen globale optimalisatie achteraf.

| style | betekenis | wanneer nuttig |
|---|---|---|
| `near0` | near-null / dicht bij nul: probeer eerst kandidaatpunten die zo dicht mogelijk bij knoop 0 liggen. Bij gelijke afstand tellen o.a. hoek, staplengte en vaste volgorde. | compacte basisbeelden en snelle controle |
| `maxturn` | probeer eerst de kandidaat die de grootste draaihoek maakt ten opzichte van de vorige stap. | testen van bochten, minder doortrekken in dezelfde richting |
| `quadrant` | probeer de groei over kwadranten rond 0 te verdelen. De generator gebruikt een vaste kwadrantvolgorde en houdt rekening met hoeveel punten er al in elk kwadrant liggen. | evenwichtige spreiding over het vlak |
| `ring` | werk van binnen naar buiten. De ring is gebaseerd op `max(abs(x), abs(y))`, dus op de vierkante afstandsschil rond 0. | systematische schilvormige groei |

Er zijn nu bewust geen extra styles. Deze vier dekken vier duidelijk verschillende tekenprincipes af: compact, draaiend, kwadrantspreidend en ringvormig. Extra styles worden pas zinvol als ze een echt ander tekenprincipe toevoegen. Anders ontstaan vooral meer menu-opties en meer testgevallen, zonder duidelijk betere notatie.

### RULE

| rule | betekenis |
|---|---|
| none | geen extra rechte-lijnfilter |
| extension | doortrekken in dezelfde richting verboden |
| collinear | dezelfde rechte drager verboden |
| angle | hoeken kleiner dan ANGLE_MIN en groter dan 180-ANGLE_MIN verboden |

### DIAGONAL_FREE

| waarde | betekenis |
|---|---|
| none | alleen x/y-vrijheid |
| slash | `/`-diagonalen vrij: `x + y` uniek |
| backslash | `\`-diagonalen vrij: `x - y` uniek |
| both | x, y, `/` en `\` allemaal vrij |

## Save As

Na fine-tune kies je:

```text
Greedy > Save As...
```

| keuze | inhoud | Greedy restore |
|---|---|---:|
| Greedy package (.zip) | OPN, GRAPH, YAML/spec, SVG, PNG, report, README waar beschikbaar | ja |
| OPN document (.opn) | graph + embedded `GREEDY_SETTINGS_YAML` | ja |
| Graph only (.graph) | alleen graphstructuur | nee |
| Image only (.gif/.jpg/.jpeg) | alleen afbeelding | nee |

Gebruik **Greedy package** voor archief/overdracht. Gebruik **OPN document** voor een compact herstelbaar document.

## Open Greedy OPN

```text
Greedy > Open Greedy OPN
```

Een herstelbare Greedy-OPN bevat:

- graphstructuur;
- gridgegevens;
- embedded `GREEDY_SETTINGS_YAML`;
- OPN-broninformatie waar beschikbaar.

Na openen kan **Greedy Generator** de opgeslagen instellingen weer gebruiken.

## YAML

YAML is niet langer het verplichte tussenbestand.

- `Genereren` schrijft geen YAML.
- `Greedy package` bevat YAML/spec als exportinformatie.
- `OPN document` bewaart de instellingen embedded in de OPN.

## Externe Python-GUI

De externe GUI blijft beschikbaar als fallback/reference-tool:

```text
Greedy > Greedy Tools... > External GUI
```

Die externe GUI kan zelfstandig bestanden schrijven. De normale OpenGraphEd-route gebruikt eerst de documentweergave en pas daarna Save As.
