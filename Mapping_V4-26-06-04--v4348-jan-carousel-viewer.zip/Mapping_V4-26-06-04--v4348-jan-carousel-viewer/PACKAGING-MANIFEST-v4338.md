# PACKAGING MANIFEST — v4338

## Pakket

```text
Mapping_V4-26-06-01--v4338-greedy-grow-grid-undo.zip
```

## Basis

```text
v4337-greedy-grow-config
```

## Hoofdwijziging

```text
Greedy Grow laat de grid per stap meegroeien.
Undo/redo werkt per grow-step.
```

## Belangrijke bestanden

```text
OpenGraphEd.jar
dist/OpenGraphEd.jar
userInterface/GraphEditorWindow.java
userInterface/GraphEditor.java
userInterface/GraphEditorActions.java
graphStructure/Graph.java
graphStructure/Node.java
graphStructure/Edge.java
graphStructure/mementos/GreedyGrowVisibilityMemento.java
docs/13-greedy-grow-grid-undo.md
chatlog/CHANGELOG-v4338.md
md/PATCH-MANIFEST-v4338-greedy-grow-grid-undo.md
projectie-master-spec.md
md/projectie-master-spec.md
md-only-sources-v4338.zip
```

## Buildcontrole

```text
javac: geen errors
jar: vernieuwd in root en dist/
```
