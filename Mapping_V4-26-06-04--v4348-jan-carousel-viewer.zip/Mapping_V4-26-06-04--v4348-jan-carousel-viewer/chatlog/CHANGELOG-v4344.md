# Changelog v4344 — Greedy Grow PWA Free Nodes

Datum: 2026-06-03

## Vraag

De PWA-viewer toonde de standaard NoLimit-demo als een verbonden pad. De gebruiker gaf aan dat dit geen vrije knopen zijn. Ook moest de label/markering-correctie robuuster worden en moest NoLimit zichtbaar alle beschikbare nodes gebruiken.

## Wijzigingen

- Standaardweergave toont nu vrije knopen zonder verbindingslijnen.
- `Lijnen tonen` toegevoegd als aparte vieweroptie.
- Edges blijven ondersteund voor geïmporteerde JSON-bestanden, maar zijn standaard verborgen.
- De NoLimit 96-demo bevat geen verbindingsedges meer.
- Actieve stap wordt getoond als aparte rode buitenring.
- De knoopcirkel zelf behoudt dezelfde radius als alle andere knopen.
- Labels/getallen worden na cirkels en highlight-ringen getekend.
- Autosizing is aangepast zodat kleine/fitted rasters geen te grote knopen afdwingen.
- Service-worker-cache verhoogd naar v4344.
- Lokale testpoort gewijzigd naar 8084.

## Bestanden

- `mobile/greedy-grow-viewer/index.html`
- `mobile/greedy-grow-viewer/styles.css`
- `mobile/greedy-grow-viewer/viewer.js`
- `mobile/greedy-grow-viewer/sw.js`
- `mobile/greedy-grow-viewer/start-local-viewer.bat`
- `mobile/greedy-grow-viewer/samples/no_limit_96_demo.json`
- `mobile/greedy-grow-viewer/README.md`
