# CHANGELOG — v4338

## Datum

2026-06-01

## Samenvatting

Greedy Grow verfijnd: het grid groeit nu per grow-step mee met de zichtbare knopen, en grow-stappen zijn opgenomen in de normale undo/redo-historie.

## Gewijzigd

- `userInterface/GraphEditorWindow.java`
  - grow-step-logica gecentraliseerd;
  - grid-display-window wordt per zichtbare grow-prefix opnieuw gefit;
  - Next gebruikt redo wanneer een redo-grow-step beschikbaar is;
  - Vorige gebruikt undo wanneer een undo-grow-step beschikbaar is.
- `userInterface/GraphEditor.java`
  - undo/redo bewaart Greedy Grow grid-context in plaats van het grid uit te schakelen.
- `userInterface/GraphEditorActions.java`
  - synchroniseert Greedy Grow-status na normale undo/redo.
- `graphStructure/Graph.java`
  - custom mementos toegevoegd voor Greedy Grow-stappen.
- `graphStructure/Node.java`
  - zichtbaarheid uitleesbaar gemaakt.
- `graphStructure/Edge.java`
  - zichtbaarheid uitleesbaar gemaakt.
- `build.bat`
  - manifestversie bijgewerkt naar v4.33.8.

## Toegevoegd

- `graphStructure/mementos/GreedyGrowVisibilityMemento.java`
- `docs/13-greedy-grow-grid-undo.md`
- `md/PATCH-MANIFEST-v4338-greedy-grow-grid-undo.md`

## Gedrag

```text
Generate Greedy Grow
→ toont dezelfde statische Greedy-layout stap voor stap
→ grid past per stap rond zichtbare content
→ elke stap is undo/redo-baar
```

## Testadvies

1. Start `run.bat`.
2. Kies `Greedy → Generate Greedy Grow`.
3. Druk enkele keren `ENTER`.
4. Controleer dat het grid meegroeit.
5. Gebruik normale Undo/Redo.
6. Controleer dat elke actie één grow-step terug/vooruit gaat.
7. Laat `Start grow` enkele stappen lopen en test daarna Undo/Redo.

## Compile

Gecontroleerd met `javac`.

Resultaat:

```text
geen compile errors
alleen bestaande Java-deprecation warnings
```
