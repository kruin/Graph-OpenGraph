# CHANGELOG v4333 — Simple-uitleg: juiste tweede afbeelding gebruikt

## Aanleiding

De tweede afbeelding in de Simple-uitleg moest exact de aangeleverde vrije bronboom op raster gebruiken.

## Wijziging

- `help/tree-images/simple-open-space-left-down.png` vervangen door de aangeleverde afbeelding.
- `images/simple-open-space-left-down.png` idem.
- Gecombineerde Simple-uitlegafbeelding opnieuw opgebouwd:
  - links: groen/geel-projecties;
  - rechts: aangeleverde blauwe vrije bronboom op raster.
- Foutieve of eerdere tweede afbeelding wordt niet meer gebruikt in de Simple-uitleg.

## Test

- Java compile: OK
- JAR build: OK
