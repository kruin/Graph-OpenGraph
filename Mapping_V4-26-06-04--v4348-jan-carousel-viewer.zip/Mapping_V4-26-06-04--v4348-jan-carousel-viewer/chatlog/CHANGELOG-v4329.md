# CHANGELOG v4329 - Greedy style explanation

## Doel

De uitleg over de Greedy Generator-styles is verduidelijkt en overal gelijkgetrokken.

## Gewijzigd

- Uitleg in `Greedy Generator`-dialoog uitgebreid.
- Helptekst in de externe Python-GUI uitgebreid.
- `README.md` en `HANDLEIDING_GUI.md` bijgewerkt.
- Nederlandse en Engelse PDF-handleiding opnieuw gemaakt.
- `sources/pdf/` bijgewerkt met de nieuwe PDF's.
- `projectie-master-spec.md` bijgewerkt.

## Nieuwe vaste uitleg

`STYLE` bepaalt alleen de volgorde waarin kandidaatpunten worden geprobeerd. Daarna bepalen `RULE`, `DIAGONAL_FREE` en de bezette gridlijnen of een kandidaat geldig is.

Beschikbare styles:

- `near0`: near-null / dicht bij nul; compacte groei rond knoop 0.
- `maxturn`: grootste draai ten opzichte van de vorige stap.
- `quadrant`: spreiding over de vier kwadranten rond 0.
- `ring`: groei van binnen naar buiten op basis van `max(abs(x), abs(y))`.

Er zijn nu bewust geen extra styles. De vier huidige opties zijn deterministisch, transparant en goed vergelijkbaar. Extra styles worden pas toegevoegd als ze een echt nieuw tekenprincipe geven.

## Test

- Java compile: OK.
- JAR build: OK.
- PDF-rendercontrole NL/EN: OK.
