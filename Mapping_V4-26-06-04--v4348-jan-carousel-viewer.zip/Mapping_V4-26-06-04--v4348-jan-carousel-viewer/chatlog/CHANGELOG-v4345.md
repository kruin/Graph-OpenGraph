# Changelog v4345 — Greedy Grow PWA HOR/VER-vrij

## Aanleiding

De PWA-viewer corrigeerde in v4344 wel de zichtbare lijnen, maar de ingebouwde NoLimit-demo gebruikte nog een spiral/loop-achtige plaatsing. Daardoor deelden knopen horizontale en verticale lijnen.

Dat is niet de bedoelde vrije OpenGraph-bronplaatsing.

## Correcties

- Vrije plaatsing opnieuw gedefinieerd in de viewer als HOR/VER-vrijheid.
- `samples/no_limit_96_demo.json` vervangen door een 96-knoops HOR/VER-vrije demo.
- `samples/short_demo.json` vervangen door een korte HOR/VER-vrije demo.
- `viewer.js` controleert de zichtbare/geladen nodes op dubbele x_line/y_line.
- Statusregel toont nu `HOR/VER vrij` of `HOR/VER-conflict`.
- NoLimit blijft alle nodes/stappen gebruiken.
- Labels blijven boven cirkels en highlight-ringen.
- Service-worker-cache verhoogd naar v4345.
- Lokale testpoort gewijzigd naar 8085.

## Niet gewijzigd

- Java/OpenGraphEd desktop is niet gewijzigd.
- Dit is een PWA-viewer- en sample-correctie.
