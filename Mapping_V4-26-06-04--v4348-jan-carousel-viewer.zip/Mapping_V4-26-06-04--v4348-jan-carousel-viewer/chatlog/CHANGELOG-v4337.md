# CHANGELOG — v4337 Greedy Grow Config

## Datum

2026-06-01

## Samenvatting

Greedy/Grow-configuratie uitgebreid op basis van nieuwe specs.

## Gewijzigd

- `userInterface/GreedyGeneratorSettingsDialog.java`
  - `NO_LIMIT` toegevoegd.
  - Gridinstellingen uitgebreid met `fit_content` en `show_grid_in_editor`.
  - Grow-tab toegevoegd met interval/start/auto/reveal/stop/loop.
  - Count/max-spinners verruimd zodat de oude 0..30-lesgrens niet meer hard in de UI zit.
- `userInterface/GreedyInternalGenerator.java`
  - `grid.fit_content` ondersteund.
  - `grid.show_grid_in_editor` ondersteund.
  - `graph.no_limit` ondersteund.
  - Interne zoekruimte kan bij `no_limit: true` worden vergroot als constraints dat vereisen.
  - Rapportage vermeldt config max en werkelijk gebruikte generation max.
- `userInterface/GraphController.java`
  - Greedy-output opent standaard met zichtbaar fit-content-grid.
- `userInterface/GraphEditorWindow.java`
  - Grow leest extra grow-config: `start_step`, `auto_start`, `stop_at_end`, `loop`.
- `tools/greedy_generator_gui/spec.yaml`
  - bijgewerkt met volledige v4337-config.

## Toegevoegd

- `docs/12-greedy-grow-config.md`
- v4337-sectie in `projectie-master-spec.md`

## Gedrag

```text
Generate Greedy Graph = volledige statische Greedy-graph
Generate Greedy Grow  = dezelfde graph, stapsgewijs zichtbaar
```

Grid:

```text
standaard aan
fit-content standaard aan
```

NoLimit:

```text
graph.no_limit: true overrulet de oude 0..30-lesgrens
COUNT/MAX komen uit config
```

## Bekende beperking

`reveal_edges` heeft in v4337 één ondersteunde waarde:

```yaml
reveal_edges: when_both_nodes_visible
```

## Testadvies

1. Start `run.bat`.
2. Kies `Greedy → Greedy Generator`.
3. Controleer tab `Grid`: fit-content en editorgrid staan aan.
4. Controleer tab `Grow`: alle grow-instellingen zijn zichtbaar.
5. Genereer `Generate Greedy Graph`: grid moet zichtbaar zijn.
6. Genereer `Generate Greedy Grow`: laatste stap moet gelijk zijn aan static.
7. Test `graph.no_limit: true` met count boven 31.

## Compile

Gecontroleerd met `javac`:

```text
geen compile errors
alleen bestaande Java-deprecation warnings
```
