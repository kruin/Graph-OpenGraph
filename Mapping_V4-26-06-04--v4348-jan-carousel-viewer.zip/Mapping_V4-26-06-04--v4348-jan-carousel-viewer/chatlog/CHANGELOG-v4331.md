# CHANGELOG v4.33.1 — Simple uitleg: projectieruimte links en beneden

Gebruikersvraag:
- Voeg de nieuwe Simple-afbeelding toe.
- Laat zien en leg uit dat vrije plaatsing ruimte opent voor projecties, vooralsnog naar links en beneden.

Aangepast:
- Simple-uitleg gebruikt nu een gecombineerde afbeelding: groen/geel-projecties plus vrije bronboom met open projectieruimte.
- Uitlegtekst benoemt expliciet raster, vrije plaatsing, eigen lijnen, en projectieruimte links/beneden.
- Geen bedoelde wijziging in Language Tree-rendering of Greedy.

Test:
- Java build uitvoeren met `build.bat`.
