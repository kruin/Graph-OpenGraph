# CHANGELOG — v4339

## Datum

2026-06-03

## Samenvatting

Greedy Grow heeft nu een JSON-export voor een latere mobiele/PWA-demo. Dit is de brug tussen OpenGraphEd desktop en een zelfstandige mobile promo-viewer.

## Toegevoegd

- `Greedy → Export Greedy Grow JSON`
- JSON-exportbestand `*_grow_demo.json`
- `last_grow_demo_json.txt` in de Greedy-outputmap
- `docs/14-greedy-grow-json-export.md`
- `md/PATCH-MANIFEST-v4339-greedy-grow-json-export.md`

## Gewijzigd

- `userInterface/GreedyInternalGenerator.java`
  - exportmethoden voor Greedy Grow demo JSON toegevoegd;
  - JSON bevat metadata, grid, greedy-config, grow-config, nodes, edges en steps.
- `userInterface/OpenGraphActions.java`
  - menuactie koppelt naar JSON-export;
  - export gebruikt actieve embedded Greedy-settings indien aanwezig.
- `userInterface/GraphController.java`
  - nieuwe controlleractie `exportGreedyGrowJSON()`.
- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
  - nieuw Greedy-menu-item toegevoegd.
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
  - menu-item beschikbaar gemaakt zonder actieve graph.
- `build.bat`
  - manifestversie bijgewerkt naar v4.33.9.

## Gedrag

```text
Greedy → Export Greedy Grow JSON
→ maakt *_grow_demo.json
→ gebruikt actieve embedded Greedy-settings als die er zijn
→ anders gebruikt tools/greedy_generator_gui/spec.yaml
```

## JSON-inhoud

```text
format: opengraph-greedy-grow-demo
format_version: 1
grid: fit-content + grow_with_step
nodes: alle Greedy-knopen met model/grid/positie
edges: growth-edges
steps: zichtbare prefix per stap
source_spec: effectieve Greedy-config
```

## Niet gewijzigd

```text
Greedy static layout
Greedy Grow weergave
undo/redo per grow-step
Language Tree
OpenGraph-carrousel
```

## Testadvies

1. Start `run.bat`.
2. Kies `Greedy → Generate Greedy Grow` en controleer de bestaande grow-weergave.
3. Kies `Greedy → Export Greedy Grow JSON`.
4. Controleer `tools/greedy_generator_gui/output/*_grow_demo.json`.
5. Valideer JSON met een JSON-viewer of validator.
6. Controleer dat `nodes`, `edges` en `steps` gevuld zijn.

## Compile

Gecontroleerd met `javac`.

Resultaat:

```text
geen compile errors
alleen bestaande Java-deprecation warnings
```
