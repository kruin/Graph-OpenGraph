
# CHANGELOG — v4334

## Datum

2026-05-31 23:34 CEST

## Samenvatting

Alle nieuwe documentatiebestanden opnieuw opgebouwd op basis van de actuele v4333-sources. Geen Java-gedragswijziging.

## Toegevoegd / vernieuwd

- `docs/00-overzicht.md`
- `docs/01-installatie-en-start.md`
- `docs/02-gebruikershandleiding.md`
- `docs/03-tree-menu.md`
- `docs/04-opengraph-projecties.md`
- `docs/05-language-tree.md`
- `docs/06-carousel.md`
- `docs/07-graph-bestanden.md`
- `docs/08-ontwikkelaarsdocumentatie.md`
- `docs/09-theorie-achtergrond.md`
- `docs/10-versiebeheer-en-packaging.md`
- `md/README-documentatie-v4334.md`
- `md-only-sources-v4334.zip`

## Master-spec

- `projectie-master-spec.md` bijgewerkt naar v4334.
- `md/projectie-master-spec.md` bijgewerkt naar dezelfde inhoud.

## Bronbasis

- v4333 Simple-uitleg met juiste door gebruiker aangeleverde tweede afbeelding.
- v4330-v4332 Simple/Language projectie-afbeeldingen.
- v4320-v4328 Greedy document-first workflow.
- v4310-v4319 OPN vrije-bronnotatie en gridtag/gridcelregels.
- JGraphEd-documentatie, LF-bron, Van Trijp-bron, categorie- en herschrijfregelbronnen.

## Java

Geen Java-wijziging.

## Testadvies

1. Controleer `docs/00-overzicht.md` t/m `docs/10-versiebeheer-en-packaging.md`.
2. Controleer dat `projectie-master-spec.md` en `md/projectie-master-spec.md` v4334 vermelden.
3. Open `md-only-sources-v4334.zip` en controleer dat de `.md`-bestanden aanwezig zijn.
4. Start de app met `run.bat` alleen als ook runtimegedrag getest moet worden.
