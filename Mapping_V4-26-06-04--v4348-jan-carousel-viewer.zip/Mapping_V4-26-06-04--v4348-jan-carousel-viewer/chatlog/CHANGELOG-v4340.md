# CHANGELOG — v4340

## Datum

2026-06-03

## Samenvatting

Toegevoegd: eerste zelfstandige OpenGraph Greedy Grow PWA Viewer.

## Toegevoegd

- `mobile/greedy-grow-viewer/index.html`
- `mobile/greedy-grow-viewer/styles.css`
- `mobile/greedy-grow-viewer/viewer.js`
- `mobile/greedy-grow-viewer/manifest.webmanifest`
- `mobile/greedy-grow-viewer/sw.js`
- `mobile/greedy-grow-viewer/start-local-viewer.bat`
- `mobile/greedy-grow-viewer/samples/short_demo.json`
- `mobile/greedy-grow-viewer/samples/space3_gridH20W20_grow_demo.json`
- `START-GREEDY-GROW-VIEWER.bat`
- `docs/15-greedy-grow-pwa-viewer.md`
- `md/PATCH-MANIFEST-v4340-greedy-grow-pwa-viewer.md`

## Gewijzigd

- `projectie-master-spec.md`: v4340-status toegevoegd.

## Java

Geen Java-gedragswijziging.

## Testadvies

1. Pak de zip uit.
2. Start `START-GREEDY-GROW-VIEWER.bat`.
3. Open `http://localhost:8080`.
4. Test tap/click, play/pause, vorige/volgende, range-slider en JSON-load.
5. Test op telefoon via het IP-adres van de pc.
