# CHANGELOG v4330 — Simple/Language projectie-afbeeldingen vroeg in Uitleg

## Vraag

- Integreer de afbeelding met LEX/SYNT/LOGical bij de Language Tree.
- Gebruik bij Simple Tree de afbeelding met groen en geel projecties.
- Laat afbeeldingen in een zo vroeg mogelijk stadium zien.
- Leg expliciet uit: open notatie, vrije plaatsing, raster, eigen lijnen, eigenstandige projecties.

## Wijzigingen

- `GraphEditorWindow.showCurrentTreeTypeExplanation()` toont bij Simple en Language nu eerst een afbeelding boven de uitlegtekst.
- Toegevoegd:
  - `help/tree-images/simple-green-yellow-projections.png`
  - `help/tree-images/language-lex-synt-logical.png`
- Simple-uitleg herschreven:
  - start met de afbeelding;
  - benoemt groen horizontaal als zinprojectie;
  - benoemt geel als tweede projectielijn;
  - legt raster, vrije plaatsing en eigen projectielijnen uit.
- Language-uitleg herschreven:
  - start met de afbeelding;
  - links LEX;
  - rechts SYNT;
  - onder LOGical;
  - blauw als centrale open bronstructuur;
  - projectieregels per projectie.

## Test

- Java compile: OK.
- JAR build: OK.
