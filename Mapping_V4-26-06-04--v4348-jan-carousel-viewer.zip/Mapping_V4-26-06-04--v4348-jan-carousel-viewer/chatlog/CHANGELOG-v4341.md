# CHANGELOG v4341 — Greedy Grow PWA Viewer Fix

Datum: 2026-06-03

## Aanleiding

Gebruiker testte v4340 lokaal. De server draaide correct en leverde alle viewerbestanden met HTTP 200, maar de viewer bleef leeg en toonde:

```text
Cannot read properties of null (reading 'steps')
```

## Analyse

De fout zat in de volgorde van `setDemo()`:

```text
stopPlaying()
→ updateText()
→ demo is nog null
→ demo.steps geeft fout
```

## Wijzigingen

- `viewer.js` robuust gemaakt tegen `state.demo == null`.
- `setDemo()` zet nu eerst geldige state voordat rendering/status actief wordt.
- `stopPlaying(update = true)` toegevoegd zodat laden kan stoppen zonder status-update op lege state.
- Controls worden pas actief na geldige demo.
- `validateDemo()` normaliseert nodes, edges en steps.
- Ingebouwde fallback-demo toegevoegd.
- Sample-load valt terug op fallback-demo bij laad-/parsefout.
- `sw.js` cache verhoogd naar `opengraph-greedy-grow-v4341`.
- `index.html` kreeg favicon-link naar bestaand SVG-icon.
- Lokale testserver gewijzigd naar poort 8081 om oude v4340 service-worker/cache op 8080 te vermijden.
- README en documentatie bijgewerkt.

## Verwacht gedrag

- Viewer opent direct met sample/fallback-demo.
- Geen null/steps-fout.
- Knoppen zijn bruikbaar zodra data geladen is.
- Tap/click/Next/Play/Slider werken.

## Bestanden

```text
mobile/greedy-grow-viewer/viewer.js
mobile/greedy-grow-viewer/sw.js
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/start-local-viewer.bat
mobile/greedy-grow-viewer/README.md
docs/16-greedy-grow-pwa-viewer-fix.md
```
