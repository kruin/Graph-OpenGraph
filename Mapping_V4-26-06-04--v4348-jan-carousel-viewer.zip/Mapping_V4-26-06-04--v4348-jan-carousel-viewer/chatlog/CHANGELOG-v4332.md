# CHANGELOG v4332 — Simple-uitleg: tweede afbeelding opnieuw opgebouwd

## Aanleiding

In v4331 bevatte de gecombineerde Simple-uitlegafbeelding rechts een foutief plaatje: een screenshot van de Greedy Generator-instellingen.

## Correctie

De rechterhelft is opnieuw opgebouwd als Simple-beeld:

1. links: groen/geel-projecties;
2. rechts: blauwe vrije bronboom op raster;
3. doel: laten zien dat vrije plaatsing ruimte openlaat voor projecties, voorlopig vooral naar links en naar beneden.

## Bestanden

- `help/tree-images/simple-free-space-projections.png`
- `help/tree-images/simple-open-space-left-down.png`
- `images/simple-free-space-projections.png`
- `images/simple-open-space-left-down.png`

## Test

- Java compile: OK
- JAR build: OK
