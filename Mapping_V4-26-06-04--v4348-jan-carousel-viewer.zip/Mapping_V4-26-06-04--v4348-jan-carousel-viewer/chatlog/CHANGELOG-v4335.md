# CHANGELOG — v4335

## Datum

2026-06-01 CEST

## Samenvatting

v4335 voegt een eigen Greedy Grow Screen toe. Dit scherm tekent een Greedy-graph knoop voor knoop, handmatig via ENTER/SPACE/klik of automatisch via grow-mode.

## Toegevoegd

- `userInterface/GreedyGrowthWindow.java`
- menu-item `Greedy → Greedy Grow Screen`
- `docs/11-greedy-grow-screen.md`
- `grow.interval_ms` in `tools/greedy_generator_gui/spec.yaml`

## Gewijzigd

- `userInterface/GraphController.java`
- `userInterface/OpenGraphActions.java`
- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
- `userInterface/OpenGraphEdAppInfo.java`
- `build.bat` manifestversie
- documentatie-overzicht

## Gedrag

- `ENTER`, `SPACE`, rechterpijl, muisklik of `Next` toont de volgende knoop.
- `Start grow` of `G` start automatische groei.
- Grow-mode toont één knoop per interval.
- Interval wordt gelezen uit `grow.interval_ms` als die in de Greedy-spec staat.
- Het scherm is read-only en wijzigt de editorgraph niet.

## Testadvies

1. Start OpenGraphEd.
2. Kies `Greedy → Generate Greedy Graph`.
3. Kies `Greedy → Greedy Grow Screen`.
4. Test ENTER/SPACE/klik.
5. Test `Start grow`.
6. Pas interval aan en start grow opnieuw.
