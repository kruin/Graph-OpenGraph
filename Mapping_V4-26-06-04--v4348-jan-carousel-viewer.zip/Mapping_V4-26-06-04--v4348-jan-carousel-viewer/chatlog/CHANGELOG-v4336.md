# CHANGELOG — v4336

## Samenvatting

Greedy Grow is geïntegreerd in de normale statische Greedy-weergave.
Het aparte `GreedyGrowthWindow`-scherm is verwijderd.

## Beoordeling

`static` blijft bestaan.

Reden:

```text
static = normale eindweergave en testreferentie
grow   = dezelfde static graph, node-by-node zichtbaar gemaakt
```

Grow mag geen aparte renderer worden. Alle static-instellingen gelden ook voor grow.

## Gewijzigd

- `Greedy → Greedy Grow Screen` vervangen door `Greedy → Generate Greedy Grow`.
- Grow gebruikt nu hetzelfde graphvenster als `Generate Greedy Graph`.
- Grow gebruikt dezelfde instellingen/spec als static.
- Grow-bediening toegevoegd aan het graphvenster zelf.
- `build.bat` zet nu `Implementation-Version: v4.33.6-greedy-grow-static`.
- `build.bat` ruimt `out/` eerst op, zodat verwijderde classes niet blijven hangen.

## Verwijderd

- `userInterface/GreedyGrowthWindow.java`.
- Eigen read-only grow-scherm.

## Toegevoegd

- `docs/11-greedy-grow-static.md`.
- `md/PATCH-MANIFEST-v4336-greedy-grow-static.md`.

## Bediening

```text
ENTER / SPACE / RIGHT / klik / Next = volgende knoop
LEFT / BACKSPACE / Vorige = vorige stap
R / Reset = terug naar knoop 0
G / Start grow = automatische groei
Static/all = volledige statische eindweergave
```

## Configuratie

```yaml
grow:
  interval_ms: 700
```

## Testadvies

1. Kies `Greedy → Generate Greedy Graph` en controleer de volledige static weergave.
2. Kies `Greedy → Generate Greedy Grow` en controleer dat geen apart scherm opent.
3. Controleer dat `ENTER`, klik en `Next` telkens één knoop tonen.
4. Controleer `Start grow` / `G` met `grow.interval_ms`.
5. Controleer `Static/all`.
