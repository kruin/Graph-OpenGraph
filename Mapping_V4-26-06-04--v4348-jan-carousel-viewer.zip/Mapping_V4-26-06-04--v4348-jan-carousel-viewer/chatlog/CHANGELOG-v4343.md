# CHANGELOG v4343 — Greedy Grow PWA AutoSize

Datum: 2026-06-03

## Aanleiding

Gebruiker meldde:

```text
label (getallen) verdwijnen achter de cirkel
maak no limitvinkje actief (max blijft nog 31)
knoopgrootte, celgrootte, max hangen samen
config zou overbodig moeten zijn
```

## Gewijzigd

- `mobile/greedy-grow-viewer/viewer.js`
  - labels worden in aparte `node-labels`-laag ná alle cirkels getekend;
  - `No limit` negeert `Max knopen` en gebruikt alle nodes/stappen uit JSON;
  - `Auto size` toegevoegd;
  - automatische koppeling tussen grid/celgrootte, knoopgrootte, labelgrootte en visible/static bounds;
  - default sample gewijzigd naar `samples/no_limit_96_demo.json`;
  - `Max knopen` valt terug op config-max wanneer NoLimit wordt uitgezet.

- `mobile/greedy-grow-viewer/index.html`
  - `Auto size` checkbox toegevoegd;
  - defaults aangepast naar max 30, knoop 6, cel 28.

- `mobile/greedy-grow-viewer/styles.css`
  - label-halo toegevoegd;
  - label- en cirkellagen krijgen geen pointer-events.

- `mobile/greedy-grow-viewer/samples/no_limit_96_demo.json`
  - nieuwe 96-knoops NoLimit sample.

- `mobile/greedy-grow-viewer/sw.js`
  - cacheversie naar v4343;
  - nieuwe sample opgenomen.

- `mobile/greedy-grow-viewer/start-local-viewer.bat`
  - poort naar 8083.

## Resultaat

De viewer is minder afhankelijk van handmatige configuratie. Standaard bepaalt de viewer zelf een passende verhouding tussen grid, knoopgrootte en labels.
