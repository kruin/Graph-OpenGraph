# CHANGELOG v4347 — JAN Open Notation Viewer

Aanleiding: de viewer moet communiceren dat hij een demo is van JAN, de Open Notation voor taalbomen, met voorbeelden.

Wijzigingen:

- Viewerheader aangepast naar JAN/Open Notation.
- Introkaart toegevoegd met korte uitleg.
- Voorbeeldkiezer toegevoegd.
- Drie JAN JSON-demo's toegevoegd.
- Lange taallabels worden naast de knoop weergegeven.
- README, docs en projectie-master-spec bijgewerkt.
- Lokale testpoort: 8087.

Java/OpenGraphEd desktopcode is niet gewijzigd.
