# projectie-master-spec.md

## Status

- Project/chatreeks: **Mapping V4 / OpenGraphEd / Projectie**
- Actuele correctieversie: **v4300**
- Doel van deze versie: fase-2a integratie van de Greedy Graph Generator: instellingen direct in OpenGraphEd kunnen bewerken.
- Gedragswijziging in Java: nieuwe menu-items onder **OpenGraph** voor Greedy-instellingen en instellingen+genereren+laden.

Deze file is de centrale duurzame project-spec. Toekomstige projectzips horen deze file mee te leveren.

## 1. Projectdoel

OpenGraphEd ontwikkelt een notatie- en tekenomgeving waarin een taalkundige structuur niet wordt gereduceerd tot één traditionele boomtekening. De centrale gedachte is:

```text
vrije OpenGraph-bronknopen + projectieruimte = ruimte voor LEX, SYN, LF en latere projecties
```

De editor bewaart en toont een graph als bronnotatie. Tree-weergaven zijn afgeleide presentaties of didactische lagen op basis van die bron.

## 2. Belangrijke naamconventies

- GitHub-account/owner blijft: `kruin`.
- Interne Engelstalige projectnaam: **OpenGraph** / **OpenGraphEd**.
- Voor downloadpakketten geldt: gebruik de chatnaam of afgesproken downloadnaam met datum/tijd.
- Voor deze reeks is de werknaam: **Mapping V4**.

## 3. Tree-menu

De gewenste volgorde in het Tree-menu is:

```text
origineel - OpenGraph - Simple - Language - Functional - Frame - Anaphor
```

### 3.1 origineel

`origineel` toont de actuele editorboom in vrije OpenGraph-notatie.

Belangrijk: dit betekent **niet** automatisch: opnieuw laden vanaf het opgeslagen `.graph`-bestand. Als de gebruiker in de editor iets wijzigt, moet `origineel` die aangepaste versie tonen. De echte terugkeer naar een eerdere toestand gebeurt via de bestaande Back/Undo-functionaliteit.

### 3.2 OpenGraph

`OpenGraph` is een didactische laag vóór `Simple`. Deze laag toont een carrousel met screenshots en toelichtende teksten.

Doel van de carrousel:

1. eenvoudige vertakkingen tonen, eerst één level, daarna varianten;
2. projectie naar links tonen zonder projectienaam: een kale lijn met kopieën van knopen;
3. daarna stapsgewijs de projectieruimte uitbreiden;
4. de taalkundige/student laten zien waarom vrije knopen nuttig zijn.

### 3.3 Simple

`Simple` is de basiscontrole en basisuitleg van de boomlaag.

`Simple` legt voor de taalkundige/student uit waarom OpenGraphEd afwijkt van de traditionele boomtekening. Uitgangspunt:

- In traditionele syntactische bomen staan woorden vaak onderaan.
- Dat roept de vraag op: wat doen die woorden daar onderaan? Is dat een soort zwaartekracht?
- Nee: “onder” is een tekenconventie.
- De traditionele boom reconstrueert de uiting/woordvolgorde descriptief via vertakkingen en eventueel transformaties.

In de oude boomnotatie is dit structureel verschillend:

```text
S → NP VP
S → VP NP
```

De volgorde zit dus in de lokale vertakking ingebakken. In OpenGraphEd hoeft de centrale boom niet alle woordvolgorde te dragen. De LEX-projectie kan, als taklengte en projectieruimte goed verdeeld zijn, dezelfde leesvolgorde tonen als de klassieke boom, zonder dat de woorden letterlijk “onderaan” hoeven te vallen.

Daarmee worden LEX-regels een alternatief voor transformaties: niet de boom hoeft herschreven te worden, maar de lexicale projectie bepaalt de uitingsvolgorde.

### 3.4 Language

`Language` gebruikt de OpenGraph/Simple-basis voor een taalboom van het Nederlands.

Belangrijke projecties:

- **LEX**: lexicale projectie / uitingsvolgorde;
- **SYN**: syntactische categorieprojectie;
- **LF**: logical form / logische projectie.

Language werkt vanuit het principe:

```text
geen transformaties; projectie- en plaatsingsregels bepalen de zichtbare uitingsvolgorde
```

Voor Nederlands zijn onder meer relevant:

- bijzinvolgorde;
- stellende hoofdzin;
- V2 / persoonsvormpositie;
- WH-vraag;
- topicalisatie;
- V-cluster-varianten zoals `pv-VD` en `VD-pv`.

### 3.5 Functional, Frame, Anaphor

Deze onderdelen blijven voorlopig gereserveerd.

Werkafspraak:

- inhoudelijke uitwerking komt later;
- de uitleg verwijst voorlopig terug naar `Simple` en `OpenGraph`;
- latere uitbreiding mag dezelfde vrije OpenGraph-bron gebruiken en eigen projecties toevoegen.

## 4. Boomgeldigheid

Voor Tree-weergaven geldt de huidige controle:

```text
0 kindtakken  = toegestaan als eindknoop
1 kindtak     = fout
2+ kindtakken = toegestaan
```

Richting is irrelevant. De fout is dus niet “links onder rechts” of “zelfde schuine richting”, maar precies:

```text
een interne knoop mag niet precies één kindtak hebben
```

## 5. Branches-config

Alle Tree-types gebruiken dezelfde branch-configuratie per categoriale knoop:

```text
auto
2
3
4
many
```

Betekenis:

- `2`: binaire vertakking;
- `3`, `4`, `many`: n-air vertakking;
- `auto`: renderer kiest volgens de beschikbare structuur/config.

`Simple` mag dus niet meer hardcoded als uitsluitend binair worden behandeld. Binair gedrag hoort uit `Branches = 2` te komen.

## 6. Compacte layout

Tree-layout moet compact zijn:

- geen overbodige lege horizontale gridlijnen;
- geen overbodige lege verticale gridlijnen;
- recursieve box-aanpak blijft het uitgangspunt;
- elke subboom krijgt een denkbeeldige box;
- kindboxen worden compact geplaatst;
- de ouder komt erboven;
- projecties worden afgeleid uit de uiteindelijk geplaatste knopen.

## 7. Draw en editorstatus

`Draw` moet de actuele graph in de editor gebruiken.

Regel:

```text
editorwijziging → Draw ziet die wijziging
```

Draw mag dus niet stil terugvallen op de opgeslagen `.graph` van schijf. Alleen expliciete import/herlaad-acties mogen een bestand opnieuw laden.

## 8. OpenGraph-carrousel

De carrousel staat lokaal in:

```text
opengraph_carousel/
```

Bestanden worden genummerd:

```text
001-...
002-...
003-...
```

Elke afbeelding heeft een bijbehorend `.txt`-bestand met dezelfde basisnaam.

### 8.1 Functionaliteit

De carrousel ondersteunt:

- navigatie: Eerste, Vorige, Volgende, Laatste, Naar...;
- beheer: Screenshot toevoegen, Verwijder, Tekst opslaan, Ververs;
- volgorde: Plaats <, Plaats >, Verplaats..., Wissel...;
- Import carousel;
- Export carousel;
- Reminder.

Bij verplaatsen/wisselen moet de carrouselmap opnieuw opgebouwd worden, zodat oude posities geen residuen achterlaten.

### 8.2 Workflow-reminder

Na carrouselwijzigingen:

1. Controleer de carrousel in de app.
2. Gebruik **Export carousel**.
3. Upload die exportzip hier mee bij het volgende verzoek.
4. Dan kan de volgende projectzip de actuele carrouselstand meenemen.
5. De git-update blijft handwerk.

Voor git blijft de gebruiker zelf uitvoeren, bijvoorbeeld:

```bat
git status
git add .
git commit -m "Update OpenGraph carousel"
git push
```

## 9. Sources en md-bestanden

Aanbevolen voor projectbronnen/Sources:

- `projectie-master-spec.md`;
- compacte projectsource-notities zoals `Mapping_V4-26-05-23--v4298-projectsource-note.md`;
- inhoudelijke `.md`-bestanden onder `md/sources/`.

Niet aanbevolen als vaste Source:

- volledige projectzips;
- oude build-zips;
- gegenereerde `.class`, `out`, `dist`, `.jar`.

## 10. Packaging-regel voor volgende zips

Elke volgende projectzip in deze reeks moet bevatten:

```text
projectie-master-spec.md
md/projectie-master-spec.md
md-only-sources-vXXXX.zip
chatlog/CHANGELOG-vXXXX.md
```

De md-only zip moet alle relevante Markdown-bronnen bevatten, inclusief deze master-spec.

## 11. Huidige correctie v4299

v4298 miste `projectie-master-spec.md`. Dat was fout.

v4299 corrigeert dit door de master-spec toe te voegen op twee plaatsen:

```text
projectie-master-spec.md
md/projectie-master-spec.md
```

Daarnaast bevat v4299 een vernieuwde md-only sources zip waarin deze file ook is opgenomen.


## 12. Huidige uitbreiding v4300

v4300 voegt een eerste integratielaag toe voor de Greedy Graph Generator.

### 12.1 Nieuwe OpenGraph-menu-items

Onder **OpenGraph** staan nu:

```text
Greedy Generator
Open Greedy OPN
```

Betekenis:

- **Greedy Generator** start de meegeleverde externe generator in `tools/greedy_generator_gui/start_gui.bat`.
- **Open Greedy OPN** opent een bestandskiezer in de standaardoutputmap van de generator (`tools/greedy_generator_gui/output`) zodat de gebruiker de gegenereerde `.opn` direct terug in OpenGraphEd kan laden.

### 12.2 Integratiestrategie

Deze versie volgt fase 1 van de gekozen strategie:

```text
OpenGraphEd start de generator extern en gebruikt .opn als brugformaat.
```

De Python/Tkinter-generator blijft dus voorlopig intact. OpenGraphEd wordt nog niet belast met een volledige Java-port van de greedy-kern.

### 12.3 Meegeleverde generator

De map is meegeleverd als:

```text
tools/greedy_generator_gui/
```

Deze bevat onder meer:

```text
greedy_generator_gui.py
start_gui.bat
build_gui_exe.bat
spec.yaml
spec_english.yaml
GREEDY_GENERATOR_UITLEG_NL.pdf
GREEDY_GENERATOR_EXPLANATION_EN.pdf
```

### 12.4 OPN als brug

De generator schrijft `.opn` als uitvoer. OpenGraphEd kan die `.opn` laden via:

```text
OpenGraph > Open Greedy OPN
```

of via:

```text
File > Open OPN
```

Daarmee blijft de bronnotatie reproduceerbaar: de GUI/spec maakt de knopen en lijnen, en OpenGraphEd toont het resultaat als OpenGraph/OPN-graph.

### 12.5 Sources/PDF-regel

Deze projectzip bevat ook de beschikbare PDF-bronnen in:

```text
sources/pdf/
```


## 13. Huidige uitbreiding v4301

v4301 voegt een directe workflow toe bovenop v4300.

### 13.1 Nieuw menu-item

Onder **OpenGraph** staat nu ook:

```text
Generate + Load Greedy OPN
```

Betekenis:

1. OpenGraphEd start de generator headless via:

```text
tools/greedy_generator_gui/generate_default_opn.bat
```

2. De generator leest:

```text
tools/greedy_generator_gui/spec.yaml
```

3. De generator schrijft output naar:

```text
tools/greedy_generator_gui/output/
```

4. De generator schrijft een terugkoppelbestand:

```text
output/last_generated.txt
```

5. OpenGraphEd laadt de daarin genoemde `.opn` direct als graph.

### 13.2 Bestaande workflow blijft bestaan

Voor instellen en experimenteren blijft beschikbaar:

```text
OpenGraph > Greedy Generator
```

Voor handmatig laden blijft beschikbaar:

```text
OpenGraph > Open Greedy OPN
```

### 13.3 Integratiestatus

Dit is fase 1b:

```text
Python-generator blijft extern, maar OpenGraphEd kan nu direct genereren en laden.
```

De volgende inhoudelijke stap is een echte Java-port van de greedy-kern of een OpenGraphEd-dialoog die dezelfde spec-instellingen rechtstreeks in Java beheert.


## 13. Greedy Generator v4302

v4302 is de volgende integratiestap na het succesvol testen van v4301. De generator blijft technisch een meegeleverde Python-tool, maar OpenGraphEd kan nu de belangrijkste instellingen zelf bewerken.

Nieuw menu:

```text
OpenGraph
  Greedy Settings
  Settings + Generate + Load Greedy OPN
  Greedy Generator
  Generate + Load Greedy OPN
  Open Greedy OPN
```

### 13.1 Greedy Settings

`Greedy Settings` opent een Java/Swing-dialoog binnen OpenGraphEd. Deze dialoog leest en schrijft:

```text
tools/greedy_generator_gui/spec.yaml
```

Instelbaar zijn onder meer:

- projectnaam, titel en outputbasisnaam;
- `COUNT` en `MAX`;
- taal `nl` / `en`;
- gridstap X/Y, marge, hoofdlijnen, grid/assen tonen;
- `STYLE`;
- `RULE`;
- `DIAGONAL_FREE`;
- `ANGLE_MIN`;
- outputformaten `.graph`, `.opn`, `.svg`, `.png`;
- rapport en effective spec.

### 13.2 Settings + Generate + Load Greedy OPN

Deze optie opent eerst dezelfde instellingen-dialoog. Na opslaan wordt de bestaande headless-route uitgevoerd:

```text
tools/greedy_generator_gui/generate_default_opn.bat
```

Daarna laadt OpenGraphEd de laatst gegenereerde `.opn` direct in de editor.

### 13.3 Ontwerpstatus

Dit is een tussenstap:

```text
Python blijft voorlopig de greedy-kern.
OpenGraphEd beheert nu wel de spec.
.opn blijft het brugformaat.
```

De volgende inhoudelijke stap kan zijn: de greedy-kern naar Java porten, of eerst de Java-dialoog uitbreiden met preview/help.


## 12. Correctie v4303

v4302 crashte bij startup door een comma in een menu-action descriptor voor `Settings + Generate + Load Greedy OPN`. De menu-parser gebruikt comma-separated descriptors; daardoor ontstond een null-action. v4303 verwijdert de comma uit de descriptor en voegt defensieve controles toe in de menu builder.


## 15. Greedy Generator v4304

v4304 corrigeert de v4303-startupfout waarbij een bestaande placeholder in het Windows-menu werd afgewezen door de nieuwe strenge methodecontrole.

De descriptor:

```text
S,Windows,None,null,No Windows Are Open, ,true,1, 
```

heeft bewust geen `GraphController`-methode. De menu-builder accepteert nu lege methodvelden als `null`, maar controleert niet-lege methoden nog steeds streng.


## 16. Greedy Generator v4305 — taalcorrectie NL/EN

v4305 corrigeert de taalinstelling van de Greedy Generator-integratie.

Aanpassing:

```text
OpenGraphEd Greedy Settings volgt nu de taal uit spec.yaml.
Taalwijziging nl/en werkt direct op tabs, labels, knoppen, notities en helptekst.
De Python-GUI ververst de helptekst automatisch.
Engelse SVG/PNG-uitvoer gebruikt node 0 in plaats van knoop 0.
Engelse headless output schrijft een Engels rapport.
```

De generator blijft technisch hetzelfde; deze versie repareert vooral de presentatie- en documentatielaag rond `output.language`.


## 12. Greedy Generator-integratie

Vanaf v4300 is de Greedy Generator als externe tool meegeleverd onder:

```text
tools/greedy_generator_gui/
```

Integratiestappen:

- v4300: generator startbaar vanuit OpenGraphEd; `.opn` als brugformaat.
- v4301: headless genereren en direct laden van Greedy OPN.
- v4302: Greedy Settings-dialoog binnen OpenGraphEd.
- v4303/v4304: menu-parser fixes.
- v4305: NL/EN-taalwisseling in settings en generatoroutput gerepareerd.
- v4306: Greedy-output inspecteerbaar vanuit OpenGraphEd: preview PNG, rapport, effective spec, outputmap en PDF-handleiding.

De Greedy Generator blijft voorlopig extern draaien. OpenGraphEd gebruikt `.opn` als brugformaat en kan de gegenereerde OPN direct laden.


## 12. Huidige correctie v4307

v4307 voegt een expliciete Greedy-importworkflow toe aan OpenGraphEd.

Nieuwe OpenGraph-menuopties:

```text
Settings + Generate + Import Greedy OPN
Generate + Import Greedy OPN
```

Deze route genereert eerst de Greedy-output en toont daarna een result/importdialoog. De gebruiker kan daar de Preview PNG, het rapport en de effective spec openen voordat de gegenereerde `.opn` in OpenGraphEd wordt geïmporteerd.

De oudere directe laadroute blijft behouden:

```text
Settings + Generate + Load Greedy OPN
Generate + Load Greedy OPN
```

Daarmee blijven snelle tests mogelijk, terwijl de nieuwe importworkflow beter past bij `.opn` als bronformaat.


## 12. Greedy-generator integratie v4308

Vanaf v4308 bestaat naast de externe Python/Tkinter-generator ook een eerste interne Java-route.

Menu-items:

```text
OpenGraph -> Settings + Generate Internal + Import Greedy OPN
OpenGraph -> Generate Internal + Import Greedy OPN
```

Deze route leest dezelfde `tools/greedy_generator_gui/spec.yaml`, genereert de Greedy-punten intern in OpenGraphEd/Java, schrijft `.opn` en overige output naar dezelfde outputmap, en opent daarna de importworkflow.

De externe generator blijft behouden voor vergelijking, GUI-gebruik en fallback. v4308 is daarmee de eerste stap naar volledige opname van de Greedy-kern in OpenGraphEd.

## 12. Greedy Generator integratie v4300-v4309

De Greedy Generator is stapsgewijs geïntegreerd in OpenGraphEd.

Status vanaf **v4309**:

```text
interne Java-engine = standaardroute
externe Python/Tkinter-generator = GUI/fallback/debugroute
```

### 12.1 Standaardroute

De normale route in het OpenGraph-menu is:

```text
OpenGraph -> Generate + Import Greedy OPN
```

Deze route gebruikt de interne Java-engine. De engine leest:

```text
tools/greedy_generator_gui/spec.yaml
```

en schrijft output naar:

```text
tools/greedy_generator_gui/output/
```

Daarna opent OpenGraphEd de importworkflow, zodat de gebruiker eerst kan inspecteren en daarna expliciet kan importeren.

### 12.2 Instellingenroute

```text
OpenGraph -> Settings + Generate + Import Greedy OPN
```

opent eerst het Greedy Settings-venster binnen OpenGraphEd, schrijft daarna `spec.yaml`, genereert met de interne Java-engine, en opent vervolgens de importworkflow.

### 12.3 Externe fallback

De externe Python/Tkinter-generator blijft aanwezig onder:

```text
OpenGraph -> Greedy Generator GUI
OpenGraph -> Generate External + Import Greedy OPN
```

Deze route blijft nuttig voor vergelijking, debug en verdere standalone ontwikkeling.

## 13. OPN-bronnotatie en vrije knopen v4310

v4310 werkt de vrije knoop verder uit als basis van OPN.

Kernregel:

```text
OPN begint met vrije bronknopen op een grid.
```

Een vrije knoop is in deze fase:

```text
label + gridpositie + optionele verbindingen + optionele metadata
```

De vrije knoop is dus nog niet verplicht tot een klassieke boompositie, woordvolgorde of projectierichting. LEX, SYN, LF en latere projecties worden afgeleide lagen bovenop deze bron.

### 13.1 OPN v0.3

Greedy-output en Save OPN schrijven nu:

```text
OPN_VERSION: 0.3
OPN_SOURCE_MODEL: free-nodes-on-grid
```

Daarnaast zijn deze bronsecties toegevoegd:

```text
OPN_SOURCE_NOTATION:
FREE_NODES:
GROWTH_ORDER:
```

`STRUCTURE_NODES` en `STRUCTURE_EDGES` blijven de compatibele tekenlaag die de bestaande OPN-loader gebruikt.

### 13.2 FREE_NODES

`FREE_NODES` maakt per knoop zichtbaar welke vrije gridlijnen en diagonalen door die knoop gebruikt worden:

```text
id | label | model_x | model_y | source_x | source_y | x_line | y_line | slash_diag | backslash_diag | order | kind
```

Daarmee wordt expliciet zichtbaar waarom een kandidaatplaats vrij of onvrij kan zijn:

```text
x_line uniek
y_line uniek
slash_diag uniek indien diagonal_free=slash/both
backslash_diag uniek indien diagonal_free=backslash/both
```

### 13.3 GROWTH_ORDER

`GROWTH_ORDER` noteert de groeivolgorde van de Greedy-generator:

```text
order | node_id | previous | incoming_vector | accepted_as
```

Deze verbindingen zijn geen klassieke boomderivatie. Ze registreren de volgorde waarin vrije knopen zijn geplaatst.

### 13.4 Info-venster

Bij het laden van OPN v0.3 herkent OpenGraphEd de vrije-bronnotatie. Het Info-venster toont dat de graph OPN-bronnotatie bevat en hoeveel vrije knopen gevonden zijn.


## 14. Grid-dimensies in outputnamen en OPN-input v4311

v4311 maakt de zichtbare grid-dimensies expliciet. Elke Greedy-outputnaam bevat voortaan:

```text
gridH<hoogte>W<breedte>
```

Voorbeeld:

```text
space3_gridH20W20.opn
space3_gridH20W20.graph
space3_gridH20W20.svg
space3_gridH20W20.png
```

De spec ondersteunt nu:

```yaml
grid:
  height: 0   # 0 = afleiden uit max en margin
  width: 0    # 0 = afleiden uit max en margin
```

Betekenis:

- `height` = aantal gridrijen;
- `width` = aantal gridkolommen;
- bij `0` wordt de waarde automatisch bepaald als `2*max + 1 + 2*margin`.

OPN-output bevat daarnaast een expliciete `GRID:`-sectie met `height`, `width`, `step_x`, `step_y`, `origin_x` en `origin_y`. De OPN-loader leest deze sectie bij import. Doel: een gegenereerde OPN moet bij laden direct op de bedoelde gridknooppunten terechtkomen.

## v4312 — Algemene gridnaam en gridinput

Vanaf v4312 geldt de gridconventie niet alleen voor Greedy, maar voor alle OpenGraphEd-output.

Correctie v4315: bestandsnamen bevatten bij output standaard:

```text
gridH<celhoogte>W<celbreedte>
```

Hierbij betekent `hoogte` de gridcelhoogte en `breedte` de gridcelbreedte. Het betekent niet het aantal rijen/kolommen. Voorbeelden:

```text
voorbeeld_gridH20W20.graph
voorbeeld_gridH20W20.opn
voorbeeld_gridH20W20.jpg
```

Bij input leest OpenGraphEd deze tag terug uit de bestandsnaam. Als de tag aanwezig is, wordt de editorgrid op deze dimensies gezet. Daarna worden knopen op het dichtstbijzijnde gridknooppunt geplaatst, zodat een geladen bestand direct in de bedoelde rasterruimte staat.

Voor OPN schrijft gewone `Save OPN` nu bovendien een `GRID:`-sectie. Daardoor is de grid niet alleen uit de naam, maar ook uit de inhoud afleidbaar.

## v4313 — Alert bij input zonder gridnaam

Vanaf v4313 controleert OpenGraphEd bij het laden van `.graph`- en `.opn`-bestanden of de bestandsnaam een gridtag bevat:

```text
gridH<hoogte>W<breedte>
```

Ontbreekt deze tag, dan verschijnt een waarschuwing. Het bestand wordt nog steeds geladen. De waarschuwing is bedoeld om oude of handmatig benoemde bestanden zichtbaar te maken als niet-gridexpliciet.

Bij opnieuw opslaan krijgt de outputnaam automatisch een gridtag, bijvoorbeeld:

```text
oudbestand.graph
→ oudbestand_gridH24W30.graph
```

Doel: invoer, uitvoer en herladen moeten steeds expliciet maken op welk grid de knopen moeten liggen.

## v4314 — Input zonder gridnaam: alert + save-voorstel

Bij het openen van een bestaand `.graph`- of `.opn`-bestand zonder gridnaam moet OpenGraphEd niet alleen waarschuwen, maar ook direct een nieuwe naam voorstellen.

Conventie:

```text
<oude_naam>_gridH<hoogte>W<breedte>.<extensie>
```

De voorgestelde naam staat altijd in dezelfde map als de inputfile.

Voorbeeld:

```text
input:  examples/graph/lextest.graph
nieuw:  examples/graph/lextest_gridH18W32.graph
```

De waarschuwing toont voortaan expliciet:

- volledig inputpad;
- gedetecteerde gridhoogte en gridbreedte;
- voorgestelde gridtag;
- gridcelhoogte en gridcelbreedte;
- melding dat veel oude `.graph`-bestanden gridcel `20,20` gebruiken;
- voorgestelde nieuwe bestandsnaam.

Bij `File → Save Graph` gebruikt de filechooser dit voorgestelde pad als default. Daardoor verschijnt niet langer `untitled.graph` wanneer de gebruiker een bestaand bestand had geladen.

Na laden worden knopen altijd naar het actieve grid gesnapt. Als de bestandsnaam een gridtag bevat, wordt dat grid eerst toegepast. Als de bestandsnaam geen gridtag bevat, wordt het in de file opgeslagen grid gebruikt en verschijnt de waarschuwing.



## v4315 — Gridtag betekent gridcelgrootte

Vanaf v4315 betekent de bestandsnaamtag `gridH...W...` altijd de ingestelde gridcelgrootte: `gridH<celhoogte>W<celbreedte>`. De tag betekent niet het aantal rijen/kolommen.

Voor oude `.graph`-bestanden zonder gridtag is `gridH20W20` de standaardverwachting, omdat veel oude bestanden `rowHeight=20` en `colWidth=20` bevatten. Rijen/kolommen blijven afzonderlijke tekenveldgegevens.

## v4316 — Gridcelkeuze via dropdown

De tweede stap van `Set Grid Size` gebruikt voortaan een dropdown in plaats van een vrij tekstvoorstel. De eerste optie is standaard `20,20`, omdat dit voor oude bestanden meestal de juiste legacy-gridcel is. Andere opties, zoals de uit het venster afgeleide waarde, worden daarnaast aangeboden.

## v4317 — Legacy-optie toonbaar/verbergbaar

De vaste legacy-optie `20,20` in de gridcel-dropdown kan aan of uit worden gezet. Daarmee blijft de oude standaard beschikbaar, maar kan de gebruiker deze keuze ook uit de lijst verwijderen wanneer hij bewust alleen de actuele/afgeleide gridcelwaarden wil gebruiken.

## v4318 — Legacybestand veilig hernoemen na grid-save

Wanneer een bestand zonder gridtag wordt geladen en daarna succesvol wordt opgeslagen onder een nieuwe gridtag-naam, kan het oude bestand optioneel worden hernoemd in plaats van verwijderd.

Voorbeelden:

```text
lextest.graph
→ lextest_gridH20W20.graph
→ optioneel: lextest.oldgraph
```

```text
voorbeeld.opn
→ voorbeeld_gridH20W20.opn
→ optioneel: voorbeeld.oldopn
```

De rename-vraag verschijnt pas na geslaagde opslag van het nieuwe bestand. OpenGraphEd verwijdert het oude bestand niet automatisch. Als de doelnaam al bestaat, wordt een genummerde naam gebruikt, bijvoorbeeld `lextest_1.oldgraph`.

## v4319 — Gridkeuze met previewbevestiging

Bij `Set Grid Size` wordt de gekozen gridcelgrootte eerst zichtbaar gemaakt in het editorvenster. Daarna bevestigt de gebruiker met `OK?`. Dit is vooral bedoeld voor de legacy-keuze `20,20`: oude `.graph`-bestanden gebruiken meestal die gridcelgrootte, maar de gebruiker kan nu eerst visueel controleren of dat inderdaad klopt. Bij annuleren wordt de vorige gridstatus hersteld.


---

## v4320 — Greedy: eerst afbeelden, pas later opslaan

Vanaf v4320 is de normale Greedy-route interactief:

```text
Greedy -> Greedy Settings
Greedy -> Generate Greedy Graph
[fine-tune: grid, knopen, lijnen, labels]
Greedy -> Save As...
```

`Generate Greedy Graph` gebruikt de interne Java-engine en opent het resultaat direct als OpenGraphEd-graph in geheugen. Er wordt niet eerst een `.opn` of `.graph` geschreven en daarna opnieuw geladen. De gebruiker werkt eerst visueel door en kiest pas later een outputvorm.

`Save As...` biedt:

```text
Graph (.graph)
OPN (.opn)
Image (.gif/.jpg/.jpeg)
```

De oude externe generator en inspectie-opties blijven beschikbaar via `Greedy Tools...`, maar zijn niet meer de hoofdroute.


## v4321 — Menu OpenGraph hernoemd naar Greedy

Vanaf v4321 geldt de document-first workflow alleen voor het voormalige menu `OpenGraph`, dat in de gebruikersinterface is hernoemd naar `Greedy`. De algemene OpenGraphEd-app start en werkt verder zoals voorheen; de wijziging is beperkt tot het menu waarin de Greedy-generatorworkflow staat.

Nieuwe hoofdroute:

```text
Greedy -> Greedy Settings
Greedy -> Generate Greedy Graph
[fine-tune: grid, knopen, lijnen, labels]
Greedy -> Save As...
```

In `Greedy Generator-instellingen` heet de tweede hoofdknop nu `Genereren` / `Generate`. Deze knop betekent: instellingen opslaan en de Greedy-graph direct in het actieve OpenGraphEd-werkbeeld afbeelden. Opslaan als `.graph`, `.opn` of image blijft een aparte stap via `Greedy -> Save As...`.

Het Greedy-menu is versimpeld tot de hoofdacties voor Greedy:

```text
Greedy Settings
Generate Greedy Graph
Open Greedy OPN
Grid Settings
Save As...
Greedy Tools...
```

## 12. Greedy workflow v4322

Vanaf v4322 geldt voor het menu **Greedy**:

```text
Greedy Settings → Genereren = alleen afbeelden, niet opslaan
```

De instellingen uit het venster worden direct gebruikt door de interne Java Greedy-engine. Er wordt geen verplicht `spec.yaml`-tussenbestand geschreven. De gebruiker kan daarna in OpenGraphEd fine-tunen.

Opslaan is een aparte handeling:

```text
Greedy → Save As... → Graph / OPN / Image
```

Voor Greedy-documenten is OPN leidend. Bij Save OPN worden de gebruikte Greedy-instellingen embedded in de OPN als `GREEDY_SETTINGS_YAML`. Bij openen van zo'n Greedy-OPN worden deze instellingen terug gekoppeld aan het document, zodat Greedy Settings vanuit het actieve document kan worden heropend.


## 12. Greedy save/export workflow vanaf v4323

Voor het menu **Greedy** geldt de document-first workflow:

```text
Greedy Settings → Genereren → fine-tunen in OpenGraphEd → Save As...
```

`Genereren` schrijft geen verplicht YAML/OPN/GRAPH-tussenbestand. De graph wordt eerst in het actieve document getoond. Daarna kiest de gebruiker zelf wat wordt opgeslagen.

`Greedy → Save As...` onderscheidt expliciet:

```text
Greedy package (.zip)          volledige herstelbare export
OPN document (.opn)            graph plus embedded Greedy settings
Graph only (.graph)            alleen graphstructuur, geen Greedy restore
Image only (.gif/.jpg/.jpeg)   alleen afbeelding, geen restore
```

Een herstelbaar Greedy-document moet de instellingen meedragen. Daarom schrijft `OPN document (.opn)` de Greedy-instellingen in de sectie:

```text
GREEDY_SETTINGS_YAML:
...
END_GREEDY_SETTINGS_YAML:
```

`Greedy package (.zip)` is bedoeld voor archief en overdracht en bevat minstens `.opn`, `.graph`, `spec.yaml`, `effective_spec.yaml`, rapport/README en waar mogelijk een preview-afbeelding.

## 22. Correctie v4324 — Save As gridtag volgt gekozen gridcel

Vanaf v4324 moet `Greedy -> Save As...` de gekozen of actuele gridcelgrootte gebruiken voor de outputnaam.

Voorbeeld:

```text
gekozen gridcel hoogte,breedte = 14,20
```

geeft:

```text
*_gridH14W20.opn
*_gridH14W20.graph
*_gridH14W20.zip
```

Niet:

```text
*_gridH20W20.*
```

Regel:

- `gridH...W...` betekent nog steeds **gridcelhoogte,gridcelbreedte**;
- als de gebruiker in de save chooser expliciet een `gridH...W...`-naam kiest, mag OpenGraphEd die niet stil vervangen;
- bij Greedy OPN en Greedy package wordt de embedded `GREEDY_SETTINGS_YAML` gesynchroniseerd met de actuele graph-gridcel.

## 12. Greedy document-first workflow update v4326

For the Greedy menu, generation is display-first:

```text
Greedy Settings -> Genereren -> graph zichtbaar in editor -> fine-tune -> Save As
```

Generation must not open a second grid dialog and must not write a YAML/OPN/GRAPH file. The visible OpenGraphGrid cell size is initialized directly from the generated Greedy settings:

```text
grid.step_y = row height = gridH value
grid.step_x = column width = gridW value
```

If the user later changes `Greedy -> Grid Settings`, the active graph grid becomes authoritative for Save As filename proposals and embedded OPN/YAML grid settings.

## 14. v4327 — Greedy package en menuvereenvoudiging

Vanaf v4327 heet het hoofdmenu-item niet meer `Greedy Settings` maar:

```text
Greedy -> Greedy Generator
```

De hoofdworkflow blijft:

```text
Greedy -> Greedy Generator -> Genereren -> fine-tune -> Greedy -> Save As...
```

`Grid Settings` is niet meer zichtbaar in het hoofdmenu `Greedy`, omdat dit daar verwarrend en grotendeels dubbel was. De functie blijft beschikbaar als herstel/advanced optie via:

```text
Greedy -> Greedy Tools... -> Grid Settings / Reapply Grid
```

Een herstelbaar Greedy package bevat vanaf v4327 naast `.opn`, `.graph`, YAML en rapport ook visuele exports:

```text
<base>.svg
<base>.png
```

Daarmee is het package zowel herstelbaar als direct visueel controleerbaar.
