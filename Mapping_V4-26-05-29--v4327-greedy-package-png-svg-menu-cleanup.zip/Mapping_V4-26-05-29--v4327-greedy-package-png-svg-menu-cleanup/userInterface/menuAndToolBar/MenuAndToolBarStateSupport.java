package userInterface.menuAndToolBar;

import javax.swing.*;
import userInterface.GraphController;
import userInterface.GraphEditor;
import graphStructure.Graph;
import java.util.Vector;

public class MenuAndToolBarStateSupport
{
  private MenuAndToolBar owner;
  private GraphController controller;

  public MenuAndToolBarStateSupport(MenuAndToolBar owner, GraphController controller)
  {
    this.owner = owner;
    this.controller = controller;
  }

  public void showControls(GraphEditor graphEditor)
  {
    MenuAndToolBarAction action = getActionWithText(graphEditor.getModeString());
    CompoundMenuAndToolBarAction compoundAction = action.getParentAction();

    compoundAction.getButtonChooser().setSelected(action.getButton());
    action.getMenuItem().setSelected(true);

    action = getActionWithText(graphEditor.getShowString());
    compoundAction = action.getParentAction();

    compoundAction.getButtonChooser().setSelected(action.getButton());
    action.getMenuItem().setSelected(true);

    enableAllControls();
    refreshTestControls(true);
    syncOptionStates();
    updateUndo(graphEditor.getGraph());
  }

  public void hideControls()
  {
    disableAllControls();
  }

  private void enableAllControls()
  {
    Vector actions = owner.getActions();
    for ( int i=0; i<actions.size(); i++ )
    {
      ((MenuAndToolBarAction)actions.elementAt(i)).setEnabled(true);
    }
    getActionWithText("Load Graph").setEnabled(controller.isApplication());
    getActionWithText("Open OPN").setEnabled(controller.isApplication());
    getActionWithText("Save Graph").setEnabled(controller.isApplication());
    owner.setSaveOPNEnabled(controller.isApplication());
    setEnabled("General", true);
  }

  private void disableAllControls()
  {
    Vector actions = owner.getActions();
    for ( int i=0; i<actions.size(); i++ )
    {
      ((MenuAndToolBarAction)actions.elementAt(i)).setEnabled(false);
    }
    getActionWithText("New Graph").setEnabled(true);
    getActionWithText("Load Graph").setEnabled(controller.isApplication());
    getActionWithText("Open OPN").setEnabled(controller.isApplication());
    getActionWithText("Preferences").setEnabled(true);
    setActionEnabled("Greedy Generator", controller.isApplication());
    setActionEnabled("Settings + Generate + Import Greedy OPN", controller.isApplication());
    setActionEnabled("Generate + Import Greedy OPN", controller.isApplication());
    setActionEnabled("Greedy Generator GUI", controller.isApplication());
    setActionEnabled("Generate External + Import Greedy OPN", controller.isApplication());
    setActionEnabled("Open Greedy OPN", controller.isApplication());
    setActionEnabled("Open Greedy Preview PNG", controller.isApplication());
    setActionEnabled("Open Greedy Report", controller.isApplication());
    setActionEnabled("Open Greedy Effective Spec", controller.isApplication());
    setActionEnabled("Open Greedy Output Folder", controller.isApplication());
    setActionEnabled("Open Greedy Manual PDF", controller.isApplication());
    owner.setSaveOPNEnabled(false);
    setEnabled("Help", true);
    setEnabled("Window", true);
    setEnabled("General", true);
    refreshTestControls(false);
    syncOptionStates();
  }

  private void setEnabled(String group, boolean enabled)
  {
    Vector controls = owner.getGroup(group);
    if ( controls != null )
    {
      for ( int i=0; i<controls.size(); i++ )
      {
        ((MenuAndToolBarAction)controls.elementAt(i)).setEnabled(enabled);
      }
    }
  }

  public MenuAndToolBarAction getActionWithText(String text)
  {
    Vector actions = owner.getActions();
    for ( int i=0; i<actions.size(); i++ )
    {
      if ( ((MenuAndToolBarAction)actions.elementAt(i)).equalsText(text) )
      {
        return ((MenuAndToolBarAction)actions.elementAt(i)).getActionWithText(text);
      }
    }
    return null;
  }

  public void syncOptionStates()
  {
    setActionSelected("Test", controller.getTestFeaturesEnabled());
  }

  private void refreshTestControls(boolean hasActiveGraph)
  {
    boolean testEnabled = controller.getTestFeaturesEnabled();
    boolean graphTestsEnabled = testEnabled && hasActiveGraph;

    setActionEnabled("Connectivity Test", graphTestsEnabled);
    setActionEnabled("Biconnectivity Test", graphTestsEnabled);
    setActionEnabled("Planarity Test", graphTestsEnabled);
  }

  private void setActionSelected(String text, boolean selected)
  {
    MenuAndToolBarAction action = getActionWithText(text);
    if ( action != null && action.getMenuItem() instanceof JCheckBoxMenuItem )
    {
      ((JCheckBoxMenuItem)action.getMenuItem()).setSelected(selected);
    }
  }

  private void setActionEnabled(String text, boolean enabled)
  {
    MenuAndToolBarAction action = getActionWithText(text);
    if ( action != null )
    {
      action.setEnabled(enabled);
    }
  }

  public void updateUndo(Graph g)
  {
    MenuAndToolBarAction action;
    JMenuItem menuItem;
    if ( g.getTrackUndos() )
    {
      action = getActionWithText("Redo");
      menuItem = action.getMenuItem();
      if ( !g.hasMoreRedos() )
      {
        action.putValue(Action.SHORT_DESCRIPTION, "No more commands to Redo" );
        menuItem.setText("Redo");
        action.setEnabled(false);
      }
      else
      {
        action.putValue(Action.SHORT_DESCRIPTION, "Redo " + g.peekRedo() );
        menuItem.setText("Redo " + g.peekRedo());
        action.setEnabled(true);
      }
      action = getActionWithText("Undo");
      menuItem = action.getMenuItem();
      if ( !g.hasMoreUndos() )
      {
        action.putValue(Action.SHORT_DESCRIPTION, "No more commands to Undo" );
        menuItem.setText("Undo");
        action.setEnabled(false);
      }
      else
      {
        action.putValue(Action.SHORT_DESCRIPTION, "Undo " + g.peekUndo() );
        menuItem.setText("Undo " + g.peekUndo());
        action.setEnabled(true);
      }

      action = getActionWithText("Toggle Undos");
      action.putValue(Action.SHORT_DESCRIPTION, "Disable Undos" );
      action.setEnabled(true);
      if ( action.getButton() != null )
      {
        action.getButton().setIcon(new ImageIcon(GraphController.class.getResource("/images/DisableUndos.gif")));
      }
      action.getMenuItem().setText("Disable Undos");
    }
    else
    {
      action = getActionWithText("Redo");
      menuItem = action.getMenuItem();
      action.putValue(Action.SHORT_DESCRIPTION, "Redo" );
      menuItem.setText("Redo");
      action.setEnabled(false);

      action = getActionWithText("Undo");
      menuItem = action.getMenuItem();
      action.putValue(Action.SHORT_DESCRIPTION, "Undo" );
      menuItem.setText("Undo");
      action.setEnabled(false);

      action = getActionWithText("Toggle Undos");
      action.putValue(Action.SHORT_DESCRIPTION, "Enable Undos" );
      action.setEnabled(true);
      if ( action.getButton() != null )
      {
        action.getButton().setIcon(new ImageIcon(GraphController.class.getResource("/images/EnableUndos.gif")));
      }
      action.getMenuItem().setText("Enable Undos");
    }
  }
}
