# MD index

Alle markdown-documentatie in deze zip staat onder deze map.

## Hoofdmap

- `README.md` — oorspronkelijke project-README
- `CHANGELOG.md` — wijziglog

## Mapping-bronnen

- `sources/mapping-v3/` — actuele project-/mappingbronnen

## Meta-notities

- `meta-inf/` — fase-notities en tijdelijke placeholders
- `meta-inf/frame_md.tmp` — placeholder voor latere Frame/WH/DET/NEG/uitingstype-fasen

## Voorbeelden

- `examples/opn/mapping-v3-expected-output-manifest.md` — expected-output manifest

## Afspraak

Deze map is documentatie/config-context. De runtime-code gebruikt de `.opn`, `.java`, `.class`, `.bat` en voorbeeldbestanden buiten deze map.

## Mapping V40

- `md/meta-inf/2026-04-27-mapping-v40-md-folder-check.md`
- `run-md-folder-check.bat`
- `tools/check-md-folder.sh`
- `tools/CheckMdFolder.java`

## Mapping v3.10 stable checkpoint

- `md/meta-inf/2026-04-27-mapping-v310-core-stable-checkpoint.md`
- `md/sources/mapping-v3/current-state.md` — bijgewerkt naar `MAPPING_V3_CORE_STABLE`
