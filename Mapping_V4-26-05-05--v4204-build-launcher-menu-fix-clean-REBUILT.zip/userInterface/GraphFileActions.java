package userInterface;

import javax.swing.*;
import java.io.*;
import graphStructure.*;
import userInterface.fileUtils.*;

public class GraphFileActions
{
  private static final int MAX_V3_ALTERNATIVES = 3;
  private static final int MAX_V3_PAIR_CANDIDATES = 24;
  private static final int OPN_PIPE_GRID_CELL = 20;
  private static final int OPN_PIPE_GRID_MARGIN = 2;
  private static final int OPN_PIPE_MIN_ROWS = 24;
  private static final int OPN_PIPE_MIN_COLS = 30;

  private static boolean lastStartInGraphDir = true;
  private static boolean lastStartInOPNDir = true;
  private static boolean lastGraphOnly = false;

  public void loadGraph(GraphWindow graphWindow, GraphController controller)
  {
    File baseDir = new File(System.getProperty("user.dir"));
    File graphDir = getPreferredGraphDirectory(controller);

    lastStartInGraphDir = controller.getLoadGraphFromGraphDir();
    JFileChooser fc = createGraphLoadChooser(lastStartInGraphDir ? graphDir : baseDir, lastGraphOnly);
    fc.setDialogTitle("Load GRAPH / OPN File");
    fc.setApproveButtonText("Load GRAPH / OPN");

    JPanel accessory = new JPanel();
    accessory.setLayout(new BoxLayout(accessory, BoxLayout.Y_AXIS));

    JCheckBox startInGraphDir = new JCheckBox("Start in Graph dir", lastStartInGraphDir);
    JCheckBox graphOnly = new JCheckBox("Only .graph", lastGraphOnly);
    JLabel currentDirLabel = new JLabel(shortDirectoryLabel(graphDir));
    JButton chooseGraphDirButton = new JButton("Set Default Graph Dir...");

    startInGraphDir.addActionListener(e ->
    {
      lastStartInGraphDir = startInGraphDir.isSelected();
      controller.setLoadGraphFromGraphDir(lastStartInGraphDir);
      fc.setCurrentDirectory(lastStartInGraphDir ? getPreferredGraphDirectory(controller) : baseDir);
      currentDirLabel.setText(shortDirectoryLabel(getPreferredGraphDirectory(controller)));
    });

    graphOnly.addActionListener(e ->
    {
      lastGraphOnly = graphOnly.isSelected();
      fc.setFileFilter(lastGraphOnly ? getGraphOnlyFilter(fc) : getGraphFilter(fc));
    });

    chooseGraphDirButton.addActionListener(e ->
    {
      chooseDefaultGraphDirectory(graphWindow, controller);
      File updatedGraphDir = getPreferredGraphDirectory(controller);
      currentDirLabel.setText(shortDirectoryLabel(updatedGraphDir));
      startInGraphDir.setSelected(true);
      lastStartInGraphDir = true;
      controller.setLoadGraphFromGraphDir(true);
      fc.setCurrentDirectory(updatedGraphDir);
    });

    accessory.add(startInGraphDir);
    accessory.add(graphOnly);
    accessory.add(Box.createVerticalStrut(8));
    accessory.add(new JLabel("Default Graph dir:"));
    accessory.add(currentDirLabel);
    accessory.add(Box.createVerticalStrut(6));
    accessory.add(chooseGraphDirButton);
    fc.setAccessory(accessory);

    loadGraphFromChooser(fc, graphWindow, controller, "Load GRAPH File");
  }


  public void loadOPN(GraphWindow graphWindow, GraphController controller)
  {
    File baseDir = new File(System.getProperty("user.dir"));
    File opnDir = getPreferredOPNDirectory(controller);
    lastStartInOPNDir = controller.getLoadOPNFromOPNDir();
    JFileChooser fc = createOPNLoadChooser(lastStartInOPNDir ? opnDir : baseDir);
    fc.setDialogTitle("Open OPN / GRAPH File");
    fc.setApproveButtonText("Open OPN / GRAPH");

    JPanel accessory = new JPanel();
    accessory.setLayout(new BoxLayout(accessory, BoxLayout.Y_AXIS));

    JCheckBox startInOPNDir = new JCheckBox("Start in OPN dir", lastStartInOPNDir);
    JLabel currentDirLabel = new JLabel(shortDirectoryLabel(opnDir));
    JButton chooseOPNDirButton = new JButton("Set Default OPN Dir...");

    startInOPNDir.addActionListener(e ->
    {
      lastStartInOPNDir = startInOPNDir.isSelected();
      controller.setLoadOPNFromOPNDir(lastStartInOPNDir);
      fc.setCurrentDirectory(lastStartInOPNDir ? getPreferredOPNDirectory(controller) : baseDir);
      currentDirLabel.setText(shortDirectoryLabel(getPreferredOPNDirectory(controller)));
    });

    chooseOPNDirButton.addActionListener(e ->
    {
      chooseDefaultOPNDirectory(graphWindow, controller);
      File updatedOPNDir = getPreferredOPNDirectory(controller);
      currentDirLabel.setText(shortDirectoryLabel(updatedOPNDir));
      startInOPNDir.setSelected(true);
      lastStartInOPNDir = true;
      controller.setLoadOPNFromOPNDir(true);
      fc.setCurrentDirectory(updatedOPNDir);
    });

    accessory.add(startInOPNDir);
    accessory.add(Box.createVerticalStrut(8));
    accessory.add(new JLabel("Default OPN dir:"));
    accessory.add(currentDirLabel);
    accessory.add(Box.createVerticalStrut(6));
    accessory.add(chooseOPNDirButton);
    fc.setAccessory(accessory);

    loadGraphFromChooser(fc, graphWindow, controller, "Open OPN / GRAPH");
  }

  public void chooseDefaultGraphDirectory(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = new JFileChooser(getPreferredGraphDirectory(controller));
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setDialogTitle("Set Default Graph Directory");
    fc.setApproveButtonText("Set Graph Dir");

    int returnVal = fc.showDialog(graphWindow, "Set Graph Dir");
    if ( returnVal == JFileChooser.APPROVE_OPTION && fc.getSelectedFile() != null )
    {
      try
      {
        File selected = fc.getSelectedFile().getCanonicalFile();
        controller.setPreferredGraphDirectoryPath(selected.getPath());
        controller.setLoadGraphFromGraphDir(true);
      }
      catch ( IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to use the selected directory as the default Graph directory.",
                                      "Unable to Set Graph Directory",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void chooseDefaultOPNDirectory(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = new JFileChooser(getPreferredOPNDirectory(controller));
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setDialogTitle("Set Default OPN Directory");
    fc.setApproveButtonText("Set OPN Dir");

    int returnVal = fc.showDialog(graphWindow, "Set OPN Dir");
    if ( returnVal == JFileChooser.APPROVE_OPTION && fc.getSelectedFile() != null )
    {
      try
      {
        File selected = fc.getSelectedFile().getCanonicalFile();
        controller.setPreferredOPNDirectoryPath(selected.getPath());
        controller.setLoadOPNFromOPNDir(true);
      }
      catch ( IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to use the selected directory as the default OPN directory.",
                                      "Unable to Set OPN Directory",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void loadGraphFromDir(GraphWindow graphWindow, GraphController controller)
  {
    JFileChooser fc = createGraphLoadChooser(getPreferredGraphDirectory(controller), false);
    fc.setDialogTitle("Load GRAPH / OPN from Graph directory");
    fc.setApproveButtonText("Load GRAPH / OPN");
    loadGraphFromChooser(fc, graphWindow, controller, "Load GRAPH File");
  }

  public boolean loadGraphFromPath(GraphWindow graphWindow, GraphController controller, String graphPath)
  {
    if ( graphPath == null || graphPath.trim().length() == 0 )
    {
      return false;
    }

    File selectedFile = new File(graphPath.trim());
    Graph graph = loadGraphFile(selectedFile, graphWindow);
    if ( graph == null )
    {
      return false;
    }

    rememberDirectoryForLoadedFile(controller, selectedFile);
    GraphEditorWindow editorWindow = openGraphInEditor(graphWindow, controller, graph, selectedFile.getPath());
    if ( editorWindow != null )
    {
      showOPNMappingValidationFailureInfo(graphWindow, editorWindow, graph, selectedFile);
      return true;
    }
    return false;
  }

  public void saveGraph(GraphWindow graphWindow, GraphEditorWindow editorWindow)
  {
    JFileChooser fc = createSaveChooser();
    GraphFilter graphFilter = getGraphFilter(fc);
    ImageFilter imageFilter = getImageFilter(fc);

    int returnVal = fc.showDialog(graphWindow, "Save Current Graph to File");

    if ( returnVal == JFileChooser.APPROVE_OPTION )
    {
      String savePath = "";
      try
      {
        savePath = fc.getSelectedFile().getCanonicalPath();
        String fileExt = Utils.getExtension(fc.getSelectedFile());
        if ( fc.getFileFilter() == graphFilter )
        {
          saveGraphFile(graphWindow, editorWindow, savePath, fileExt);
        }
        else if ( fc.getFileFilter() == imageFilter )
        {
          saveImageFile(graphWindow, editorWindow, savePath, fileExt);
        }
      }
      catch ( java.io.IOException ioe )
      {
        JOptionPane.showMessageDialog(graphWindow,
                                      "Unable to write to the selected file.",
                                      "Unable to Save Graph",
                                      JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  private void loadGraphFromChooser(JFileChooser fc,
                                    GraphWindow graphWindow,
                                    GraphController controller,
                                    String approveText)
  {
    int returnVal = fc.showDialog(graphWindow, approveText);

    if ( returnVal == JFileChooser.APPROVE_OPTION )
    {
      File selectedFile = fc.getSelectedFile();
      Graph graph = loadGraphFile(selectedFile, graphWindow);
      if ( graph != null )
      {
        rememberDirectoryForLoadedFile(controller, selectedFile);
        GraphEditorWindow editorWindow = openGraphInEditor(graphWindow, controller, graph, selectedFile.getPath());
        if ( editorWindow != null )
        {
          showOPNMappingValidationFailureInfo(graphWindow, editorWindow, graph, selectedFile);
        }
      }
    }
  }

  private Graph loadGraphFile(File selectedFile, GraphWindow graphWindow)
  {
    String loadGraphPath = "";
    Graph graph = null;
    try
    {
      loadGraphPath = selectedFile.getCanonicalPath();
      if ( isOPNFile(selectedFile) )
      {
        graph = loadOPNFileAsGraph(selectedFile);
      }
      else
      {
        BufferedReader aReader = new BufferedReader(new FileReader(loadGraphPath));
        try
        {
          graph = Graph.loadFrom(aReader);
        }
        finally
        {
          aReader.close();
        }
      }
      graph.setFilePath(loadGraphPath);
      return graph;
    }
    catch ( java.io.IOException ioe )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The selected file could not be parsed as a GRAPH / OPN file.\n\n" +
                                    "Path: " + loadGraphPath + "\n" +
                                    "Reason: " + ioe.getMessage(),
                                    "Unable to load graph file",
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
    catch ( Exception ex )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The selected file could not be loaded as a GRAPH / OPN file.\n\n" +
                                    "Path: " + loadGraphPath + "\n" +
                                    "Reason: " + ex.getClass().getName() +
                                    (ex.getMessage() != null ? ": " + ex.getMessage() : ""),
                                    "Unable to load graph file",
                                    JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
      return null;
    }
  }

  private GraphEditorWindow openGraphInEditor(GraphWindow graphWindow,
                                               GraphController controller,
                                               Graph graph,
                                               String loadGraphPath)
  {
    try
    {
      GraphEditorWindow window = graphWindow.addGraphEditorWindow(controller, graph);
      applyOPNLanguageTreeProjectionDefaults(window, graph);
      return window;
    }
    catch ( Exception ex )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "The GRAPH / OPN file was parsed, but the editor window could not be opened.\n\n" +
                                    "Path: " + loadGraphPath + "\n" +
                                    "Reason: " + ex.getClass().getName() +
                                    (ex.getMessage() != null ? ": " + ex.getMessage() : ""),
                                    "Unable to open loaded graph",
                                    JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
      return null;
    }
  }


  private void applyOPNLanguageTreeProjectionDefaults(GraphEditorWindow editorWindow, Graph graph)
  {
    if ( editorWindow == null || graph == null || !graph.isOPNLanguageTreePreferred() )
    {
      return;
    }
    GraphEditor editor = editorWindow.getGraphEditor();
    if ( editor == null )
    {
      return;
    }
    OpenGraphProjectionSettings settings = editor.getOpenGraphProjectionSettings();
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    settings.setShowProjections(true);
    settings.setLeftProjectionEnabled(true);
    settings.setRightProjectionEnabled(true);
    settings.setTopProjectionEnabled(false);
    settings.setBottomProjectionEnabled(false);
    editor.setOpenGraphProjectionSettings(settings);
    editor.rememberLanguageProjectionSettings(settings);
    editor.setOpenGraphProjectionContextActive(true);
    graph.rebuildProjections();
    graph.markForRepaint();
  }

  private boolean isLanguageTreeOPN(java.util.List lines)
  {
    if ( lines == null ) return false;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      if ( raw == null ) continue;
      String normalized = raw.trim().toUpperCase().replace('-', '_').replace(' ', '_');
      if ( normalized.indexOf("STRUCTURE_TYPE") >= 0 &&
           (normalized.indexOf("LANGUAGE_TREE") >= 0 ||
            normalized.indexOf("S_TREE") >= 0 ||
            normalized.indexOf("VTREE") >= 0 ||
            normalized.indexOf("V_TREE") >= 0 ||
            normalized.endsWith("=L1") || normalized.endsWith(":L1")) )
      {
        return true;
      }
      if ( normalized.indexOf("LANGUAGE_TREE:TRUE") >= 0 || normalized.indexOf("LANGUAGE_TREE=TRUE") >= 0 )
      {
        return true;
      }
    }
    return false;
  }

  private void applyLanguageTreeInfo(Graph graph,
                                     java.util.List lines,
                                     java.util.Map idToNode,
                                     java.util.List edgeFrom,
                                     java.util.List edgeTo)
  {
    if ( graph == null ) return;
    boolean languageTree = isLanguageTreeOPN(lines);
    graph.setOPNLanguageTreePreferred(languageTree);
    if ( !languageTree )
    {
      graph.setOPNLanguageTreeTypeSummary("");
      return;
    }

    Node topNode = findLanguageTreeTopNode(idToNode, edgeFrom, edgeTo);
    String topLabel = topNode == null ? "" : topNode.getLabel();
    graph.setOPNLanguageTreeTypeFromTopLabel(topLabel);
  }

  private Node findLanguageTreeTopNode(java.util.Map idToNode,
                                       java.util.List edgeFrom,
                                       java.util.List edgeTo)
  {
    if ( idToNode == null || idToNode.size() == 0 ) return null;

    java.util.Set targets = new java.util.HashSet();
    if ( edgeTo != null )
    {
      for ( int i=0; i<edgeTo.size(); i++ )
      {
        Object value = edgeTo.get(i);
        if ( value != null ) targets.add(value.toString());
      }
    }
    if ( edgeFrom != null )
    {
      for ( int i=0; i<edgeFrom.size(); i++ )
      {
        Object value = edgeFrom.get(i);
        if ( value == null ) continue;
        String id = value.toString();
        if ( !targets.contains(id) )
        {
          Node node = (Node)idToNode.get(id);
          if ( node != null ) return node;
        }
      }
    }

    Node best = null;
    java.util.Iterator it = idToNode.values().iterator();
    while ( it.hasNext() )
    {
      Node node = (Node)it.next();
      if ( best == null || node.getLocation().intY() < best.getLocation().intY() ||
           (node.getLocation().intY() == best.getLocation().intY() &&
            node.getLocation().intX() < best.getLocation().intX()) )
      {
        best = node;
      }
    }
    return best;
  }

  private void showOPNMappingValidationFailureInfo(GraphWindow graphWindow,
                                                   GraphEditorWindow editorWindow,
                                                   Graph graph,
                                                   File selectedFile)
  {
    if ( graph == null || !graph.hasOPNMappingV1ValidationFailures() ) return;

    if ( graphWindow != null && editorWindow != null )
    {
      graphWindow.showInfo(editorWindow);
    }
  }


  private boolean isOPNFile(File selectedFile)
  {
    String extension = Utils.getExtension(selectedFile);
    return extension != null && extension.equalsIgnoreCase(Utils.opn);
  }

  private Graph loadOPNFileAsGraph(File selectedFile) throws IOException
  {
    java.util.List lines = readAllLines(selectedFile);
    if ( containsTrimmedLine(lines, "structure:") )
    {
      return loadStructuredYamlOPN(lines, selectedFile);
    }
    if ( containsTrimmedLine(lines, "STRUCTURE_NODES:") )
    {
      return loadPipeStructureOPN(lines, selectedFile);
    }
    if ( containsLine(lines, "LEXICAL_ITEMS:") )
    {
      return loadFramePlacementDemoOPN(lines, selectedFile);
    }
    throw new IOException("No drawable OPN structure found. Expected structure.nodes/structure.edges or STRUCTURE_NODES/STRUCTURE_EDGES.");
  }

  private Graph loadStructuredYamlOPN(java.util.List lines, File selectedFile) throws IOException
  {
    Graph graph = new Graph(displayNameWithoutExtension(selectedFile));
    graph.setGrid(16, 20, 28, 20, false);
    java.util.Map idToNode = new java.util.LinkedHashMap();
    java.util.List edgeFrom = new java.util.ArrayList();
    java.util.List edgeTo = new java.util.ArrayList();
    boolean inStructure = false;
    boolean inNodes = false;
    boolean inEdges = false;
    java.util.Map currentNode = null;
    java.util.Map currentEdge = null;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.length() == 0 || line.startsWith("#") ) continue;
      if ( line.equals("structure:") ) { inStructure = true; inNodes = false; inEdges = false; continue; }
      if ( !inStructure ) continue;
      if ( line.equals("notes:") || line.equals("meta:") ) break;
      if ( line.equals("nodes:") )
      {
        if ( currentEdge != null ) { addStructuredEdgeLists(edgeFrom, edgeTo, currentEdge); currentEdge = null; }
        inNodes = true; inEdges = false; continue;
      }
      if ( line.equals("edges:") )
      {
        if ( currentNode != null ) { addStructuredNode(graph, idToNode, currentNode); currentNode = null; }
        inNodes = false; inEdges = true; continue;
      }
      if ( inNodes )
      {
        if ( line.startsWith("- ") )
        {
          if ( currentNode != null ) addStructuredNode(graph, idToNode, currentNode);
          currentNode = new java.util.LinkedHashMap();
          parseKeyValueInto(currentNode, line.substring(2).trim());
        }
        else if ( currentNode != null ) parseKeyValueInto(currentNode, line);
      }
      else if ( inEdges )
      {
        if ( line.startsWith("- ") )
        {
          if ( currentEdge != null ) addStructuredEdgeLists(edgeFrom, edgeTo, currentEdge);
          currentEdge = new java.util.LinkedHashMap();
          parseKeyValueInto(currentEdge, line.substring(2).trim());
        }
        else if ( currentEdge != null ) parseKeyValueInto(currentEdge, line);
      }
    }
    if ( currentNode != null ) addStructuredNode(graph, idToNode, currentNode);
    if ( currentEdge != null ) addStructuredEdgeLists(edgeFrom, edgeTo, currentEdge);
    connectStructuredEdges(graph, idToNode, edgeFrom, edgeTo);
    applyMappingV1Info(graph, lines, selectedFile);
    applyLanguageTreeInfo(graph, lines, idToNode, edgeFrom, edgeTo);
    if ( idToNode.size() == 0 ) throw new IOException("OPN structure.nodes section contained no nodes.");
    return graph;
  }

  private Graph loadPipeStructureOPN(java.util.List lines, File selectedFile) throws IOException
  {
    Graph graph = new Graph(displayNameWithoutExtension(selectedFile));
    graph.setGrid(OPN_PIPE_MIN_ROWS, OPN_PIPE_GRID_CELL,
                  OPN_PIPE_MIN_COLS, OPN_PIPE_GRID_CELL, false);
    java.util.Map idToNode = new java.util.LinkedHashMap();
    java.util.List edgeFrom = new java.util.ArrayList();
    java.util.List edgeTo = new java.util.ArrayList();
    int maxGridX = OPN_PIPE_GRID_MARGIN;
    int maxGridY = OPN_PIPE_GRID_MARGIN;
    boolean inNodes = false;
    boolean inEdges = false;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.length() == 0 || line.startsWith("#") ) continue;
      if ( line.equals("STRUCTURE_NODES:") ) { inNodes = true; inEdges = false; continue; }
      if ( line.equals("STRUCTURE_EDGES:") ) { inNodes = false; inEdges = true; continue; }
      if ( line.endsWith(":") ) { inNodes = false; inEdges = false; continue; }
      if ( inNodes )
      {
        String[] parts = splitPipe(line);
        if ( parts.length >= 4 )
        {
          String id = parts[0];
          String label = parts[1];
          int gridX = parseIntSafe(parts[2], 0) + OPN_PIPE_GRID_MARGIN;
          int gridY = parseIntSafe(parts[3], 0) + OPN_PIPE_GRID_MARGIN;
          maxGridX = Math.max(maxGridX, gridX);
          maxGridY = Math.max(maxGridY, gridY);
          Node node = labeledNode(gridX * OPN_PIPE_GRID_CELL,
                                  gridY * OPN_PIPE_GRID_CELL,
                                  label);
          graph.addNode(node, false);
          idToNode.put(id, node);
        }
      }
      else if ( inEdges )
      {
        String[] parts = splitPipe(line);
        if ( parts.length >= 2 ) { edgeFrom.add(parts[0]); edgeTo.add(parts[1]); }
      }
    }
    graph.setGrid(Math.max(OPN_PIPE_MIN_ROWS, maxGridY + 2), OPN_PIPE_GRID_CELL,
                  Math.max(OPN_PIPE_MIN_COLS, maxGridX + 2), OPN_PIPE_GRID_CELL, false);
    connectStructuredEdges(graph, idToNode, edgeFrom, edgeTo);
    applyMappingV1Info(graph, lines, selectedFile);
    applyLanguageTreeInfo(graph, lines, idToNode, edgeFrom, edgeTo);
    if ( idToNode.size() == 0 ) throw new IOException("OPN STRUCTURE_NODES section contained no nodes.");
    return graph;
  }

  private void applyMappingV1Info(Graph graph, java.util.List lines, File selectedFile)
  {
    if ( graph == null || lines == null ) return;
    applyFrameGraphInfo(graph, lines, selectedFile);
    applyLexiconInfo(graph, lines, selectedFile);
    boolean hasMapping = containsTrimmedLine(lines, "MAPPING_V4:") ||
      containsTrimmedLine(lines, "MAPPING_V3:") ||
      containsTrimmedLine(lines, "MAPPING_V2:") ||
      containsTrimmedLine(lines, "MAPPING_V1:") || containsTrimmedLine(lines, "MAPPING:");
    if ( !hasMapping ) return;

    String endMarker = getMappingEndMarker(lines);
    int lexicalItems = countPipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    int verbDomains = countPipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    int placementRules = countPipeSectionRows(lines, "PLACEMENT_RULES:", endMarker);
    graph.setOPNMappingInfo(getMappingVersionLabel(lines), lexicalItems, verbDomains, placementRules);

    if ( isRankedMapping(lines) )
    {
      MappingValidationResult validation = validateMappingV3ForOpen(lines, selectedFile);
      graph.setOPNMappingV1Validation(validation.passed, validation.failed, validation.details());
      if ( validation.failed == 0 ) applyMappingV1Generation(graph, lines);
      else graph.setOPNMappingV1GeneratedUtterance("none (invalid mapping)");
      return;
    }

    applyMappingV1Validation(graph, lines);
    applyMappingV1Generation(graph, lines);
  }


  private void applyLexiconInfo(Graph graph, java.util.List lines, File selectedFile)
  {
    if ( graph == null || lines == null ) return;
    LexiconValidationResult result = validateLexiconForOpen(lines, selectedFile);
    if ( !result.present ) return;
    MorphologyValidationResult morphology = validateMorphologyForOpen(lines, selectedFile);
    graph.setOPNLexiconInfo(result.entries, result.passed, result.failed, result.details(),
      morphology.present, morphology.passed, morphology.failed, morphology.details());
  }

  private static class LexiconValidationResult
  {
    boolean present = false;
    int entries = 0;
    int passed = 0;
    int failed = 0;
    java.util.List messages = new java.util.ArrayList();
    String fileName = "";

    void pass()
    {
      passed++;
    }

    void fail(String message)
    {
      failed++;
      if ( message != null && message.length() > 0 ) messages.add(message);
    }

    String details()
    {
      if ( failed == 0 ) return "";
      StringBuffer buffer = new StringBuffer();
      if ( fileName != null && fileName.length() > 0 ) buffer.append("file: ").append(fileName);
      for ( int i=0; i<messages.size(); i++ )
      {
        if ( buffer.length() > 0 ) buffer.append("; ");
        buffer.append(messages.get(i).toString());
        if ( i >= 3 && messages.size() > 4 )
        {
          buffer.append("; ...");
          break;
        }
      }
      return buffer.toString();
    }
  }

  private LexiconValidationResult validateLexiconForOpen(java.util.List lines, File selectedFile)
  {
    LexiconValidationResult result = new LexiconValidationResult();
    result.fileName = selectedFile == null ? "" : selectedFile.getName();
    java.util.List rows = pipeSectionRows(lines, "LEXICON:", "END_LEXICON:");
    if ( rows.size() == 0 ) return result;
    result.present = true;
    result.entries = rows.size();

    java.util.Map mappingRoles = readLexiconCheckedMappingRoles(lines);
    java.util.Set frameNames = readFrameGraphNames(lines);
    boolean frameGraphPresent = containsTrimmedLine(lines, "FRAME_GRAPH:");
    java.util.Set seenKeys = new java.util.LinkedHashSet();

    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      boolean rowFailed = false;
      if ( parts.length < 2 || !parts[0].equalsIgnoreCase("lex") )
      {
        result.fail("malformed LEXICON row");
        continue;
      }

      String key = parts[1];
      String lemma = "";
      String form = "";
      String role = "";
      String frame = "";
      if ( key == null || key.length() == 0 )
      {
        result.fail("missing lexical key");
        rowFailed = true;
      }
      else if ( seenKeys.contains(key) )
      {
        result.fail("duplicate lexical key " + key);
        rowFailed = true;
      }
      else
      {
        seenKeys.add(key);
      }

      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("lemma:") ) lemma = part.substring("lemma:".length()).trim();
        else if ( part.startsWith("form:") ) form = part.substring("form:".length()).trim();
        else if ( part.startsWith("role:") ) role = canonicalRoleToken(part.substring("role:".length()));
        else if ( part.startsWith("frame:") ) frame = part.substring("frame:".length()).trim();
      }

      if ( lemma.length() == 0 )
      {
        result.fail("missing lemma for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      if ( form.length() == 0 )
      {
        result.fail("missing form for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      if ( role.length() == 0 )
      {
        result.fail("missing lexical role for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      else if ( !isKnownMappingV3Role(role) )
      {
        result.fail("unknown lexical role " + role + " for lexicon key " + printableLexiconKey(key));
        rowFailed = true;
      }
      else if ( mappingRoles.get(role) == null )
      {
        result.fail("lexical role " + role + " is not present in explicit MAPPING_V4 items");
        rowFailed = true;
      }

      if ( frameGraphPresent && frame.length() > 0 && !frameNames.contains(frame) )
      {
        result.fail("lexicon frame " + frame + " is not present in FRAME_GRAPH");
        rowFailed = true;
      }

      if ( !rowFailed ) result.pass();
    }

    return result;
  }

  private static class MorphologyValidationResult
  {
    boolean present = false;
    int passed = 0;
    int failed = 0;
    java.util.List messages = new java.util.ArrayList();
    String fileName = "";

    void pass()
    {
      passed++;
    }

    void fail(String message)
    {
      failed++;
      if ( message != null && message.length() > 0 ) messages.add(message);
    }

    String details()
    {
      if ( failed == 0 ) return "";
      StringBuffer buffer = new StringBuffer();
      if ( fileName != null && fileName.length() > 0 ) buffer.append("file: ").append(fileName);
      for ( int i=0; i<messages.size(); i++ )
      {
        if ( buffer.length() > 0 ) buffer.append("; ");
        buffer.append(messages.get(i).toString());
        if ( i >= 3 && messages.size() > 4 )
        {
          buffer.append("; ...");
          break;
        }
      }
      return buffer.toString();
    }
  }

  private MorphologyValidationResult validateMorphologyForOpen(java.util.List lines, File selectedFile)
  {
    MorphologyValidationResult result = new MorphologyValidationResult();
    result.fileName = selectedFile == null ? "" : selectedFile.getName();
    java.util.List rows = pipeSectionRows(lines, "LEXICON:", "END_LEXICON:");
    if ( rows.size() == 0 ) return result;

    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 || !parts[0].equalsIgnoreCase("lex") ) continue;

      String entryKey = printableLexiconKey(parts[1]);
      String pos = "";
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("pos:") ) pos = part.substring("pos:".length()).trim();
      }

      boolean hasMorphology = false;
      boolean rowFailed = false;
      java.util.Set seenFeatures = new java.util.LinkedHashSet();

      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        int colon = part.indexOf(':');
        String feature = colon >= 0 ? part.substring(0, colon).trim() : part.trim();
        String value = colon >= 0 ? part.substring(colon + 1).trim() : "";
        if ( feature.length() == 0 || isBaseLexiconFeature(feature) ) continue;

        result.present = true;
        if ( !isKnownMorphologyFeature(feature) )
        {
          result.fail("unknown morphology feature " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }

        hasMorphology = true;
        if ( seenFeatures.contains(feature) )
        {
          result.fail("duplicate morphology feature " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
        seenFeatures.add(feature);

        if ( value.length() == 0 )
        {
          result.fail("missing morphology feature value for " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
        if ( !isKnownMorphologyFeatureValue(feature, value) )
        {
          result.fail("unknown morphology feature value " + value + " for " + feature + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
        if ( !isMorphologyFeatureCompatibleWithPos(feature, pos) )
        {
          result.fail("morphology feature " + feature + " incompatible with pos:" + printablePos(pos) + " at lexicon entry " + entryKey);
          rowFailed = true;
          continue;
        }
      }

      if ( hasMorphology && !rowFailed ) result.pass();
    }

    return result;
  }

  private boolean isBaseLexiconFeature(String feature)
  {
    return "lemma".equals(feature) || "form".equals(feature) || "role".equals(feature) ||
      "frame".equals(feature) || "pos".equals(feature) ||
      "det-target".equals(feature) || "det_target".equals(feature) ||
      "wh-target".equals(feature) || "wh_target".equals(feature);
  }

  private boolean isKnownMorphologyFeature(String feature)
  {
    return "tense".equals(feature) || "number".equals(feature) || "person".equals(feature) ||
      "gender".equals(feature) || "case".equals(feature) || "mood".equals(feature) ||
      "aspect".equals(feature) || "finite".equals(feature);
  }

  private boolean isKnownMorphologyFeatureValue(String feature, String value)
  {
    if ( "tense".equals(feature) ) return hasValue(value, new String[] { "present", "past" });
    if ( "number".equals(feature) ) return hasValue(value, new String[] { "sg", "pl" });
    if ( "person".equals(feature) ) return hasValue(value, new String[] { "1", "2", "3" });
    if ( "gender".equals(feature) ) return hasValue(value, new String[] { "common", "neuter", "masc", "fem" });
    if ( "case".equals(feature) ) return hasValue(value, new String[] { "nom", "acc", "dat", "gen" });
    if ( "mood".equals(feature) ) return hasValue(value, new String[] { "indicative", "imperative", "subjunctive" });
    if ( "aspect".equals(feature) ) return hasValue(value, new String[] { "simple", "perfect", "progressive" });
    if ( "finite".equals(feature) ) return hasValue(value, new String[] { "true", "false" });
    return false;
  }

  private boolean hasValue(String value, String[] values)
  {
    String normalized = value == null ? "" : value.trim().toLowerCase();
    for ( int i=0; i<values.length; i++ )
    {
      if ( values[i].equals(normalized) ) return true;
    }
    return false;
  }

  private boolean isMorphologyFeatureCompatibleWithPos(String feature, String pos)
  {
    String p = pos == null ? "" : pos.trim().toUpperCase();
    if ( p.length() == 0 ) return false;
    if ( "finite".equals(feature) ) return isVerbPos(p);
    if ( "person".equals(feature) ) return isVerbPos(p) || "PRON".equals(p);
    if ( "case".equals(feature) ) return isNominalMorphologyPos(p);
    if ( "tense".equals(feature) || "mood".equals(feature) || "aspect".equals(feature) ) return isVerbPos(p);
    if ( "gender".equals(feature) ) return isNominalMorphologyPos(p);
    if ( "number".equals(feature) ) return isVerbPos(p) || isNominalMorphologyPos(p);
    return false;
  }

  private boolean isVerbPos(String pos)
  {
    return pos != null && pos.startsWith("V");
  }

  private boolean isNominalMorphologyPos(String pos)
  {
    return "N".equals(pos) || "PRON".equals(pos) || "DET".equals(pos) || "ADJ".equals(pos);
  }

  private String printablePos(String pos)
  {
    return pos == null || pos.trim().length() == 0 ? "<missing>" : pos.trim();
  }

  private java.util.Map readLexiconCheckedMappingRoles(java.util.List lines)
  {
    java.util.Map roles = new java.util.LinkedHashMap();
    java.util.List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("role:") )
        {
          String role = canonicalRoleToken(part.substring("role:".length()));
          if ( role.length() > 0 ) roles.put(role, Boolean.TRUE);
        }
      }
    }
    return roles;
  }

  private java.util.Set readFrameGraphNames(java.util.List lines)
  {
    java.util.Set frames = new java.util.LinkedHashSet();
    java.util.List rows = pipeSectionRows(lines, "FRAME_GRAPH:", "END_FRAME_GRAPH:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 2 && parts[0].equalsIgnoreCase("frame") && parts[1].length() > 0 )
      {
        frames.add(parts[1]);
      }
    }
    return frames;
  }

  private String printableLexiconKey(String key)
  {
    return key == null || key.length() == 0 ? "<missing>" : key;
  }

  private void applyFrameGraphInfo(Graph graph, java.util.List lines, File selectedFile)
  {
    if ( graph == null || lines == null ) return;
    FrameGraphValidationResult result = validateFrameGraphForOpen(lines, selectedFile);
    if ( !result.present ) return;
    graph.setOPNFrameGraphInfo(result.frames, result.slots, result.passed, result.failed, result.details());
  }

  private static class FrameGraphValidationResult
  {
    boolean present = false;
    int frames = 0;
    int slots = 0;
    int passed = 0;
    int failed = 0;
    java.util.List messages = new java.util.ArrayList();
    String fileName = "";

    void pass()
    {
      passed++;
    }

    void fail(String message)
    {
      failed++;
      if ( message != null && message.length() > 0 ) messages.add(message);
    }

    String details()
    {
      if ( failed == 0 ) return "frame slots satisfied";
      StringBuffer buffer = new StringBuffer();
      if ( fileName != null && fileName.length() > 0 ) buffer.append("file: ").append(fileName);
      for ( int i=0; i<messages.size(); i++ )
      {
        if ( buffer.length() > 0 ) buffer.append("; ");
        buffer.append(messages.get(i).toString());
        if ( i >= 3 && messages.size() > 4 )
        {
          buffer.append("; ...");
          break;
        }
      }
      return buffer.toString();
    }
  }

  private FrameGraphValidationResult validateFrameGraphForOpen(java.util.List lines, File selectedFile)
  {
    FrameGraphValidationResult result = new FrameGraphValidationResult();
    result.fileName = selectedFile == null ? "" : selectedFile.getName();

    java.util.List rows = pipeSectionRows(lines, "FRAME_GRAPH:", "END_FRAME_GRAPH:");
    if ( rows.size() == 0 ) return result;
    result.present = true;

    java.util.Set frames = new java.util.LinkedHashSet();
    java.util.Map frameSlots = new java.util.LinkedHashMap();
    java.util.List requiredSlots = new java.util.ArrayList();

    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 3 || !parts[0].equalsIgnoreCase("frame") || parts[1].length() == 0 )
      {
        result.fail("malformed FRAME_GRAPH row");
        continue;
      }

      String frameName = parts[1];
      frames.add(frameName);
      java.util.Set slotsForFrame = (java.util.Set)frameSlots.get(frameName);
      if ( slotsForFrame == null )
      {
        slotsForFrame = new java.util.LinkedHashSet();
        frameSlots.put(frameName, slotsForFrame);
      }

      boolean hasSlot = false;
      boolean required = false;
      java.util.List currentRowSlots = new java.util.ArrayList();
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("slot:") )
        {
          hasSlot = true;
          String slotRole = canonicalRoleToken(part.substring("slot:".length()));
          result.slots++;
          slotsForFrame.add(slotRole);
          currentRowSlots.add(slotRole);
          if ( !isKnownFrameSlotRole(slotRole) )
          {
            result.fail("unknown frame slot role " + slotRole + " for frame " + frameName);
          }
        }
        else if ( part.equalsIgnoreCase("required") )
        {
          required = true;
        }
      }
      if ( !hasSlot )
      {
        result.fail("malformed FRAME_GRAPH row");
        continue;
      }
      if ( required )
      {
        for ( int j=0; j<currentRowSlots.size(); j++ )
        {
          String slotRole = (String)currentRowSlots.get(j);
          if ( isKnownFrameSlotRole(slotRole) ) requiredSlots.add(new String[] { frameName, slotRole });
        }
      }
    }

    result.frames = frames.size();

    java.util.Set lexicalRoles = readFrameCheckedLexicalRoles(lines);
    for ( int i=0; i<requiredSlots.size(); i++ )
    {
      String[] row = (String[])requiredSlots.get(i);
      String frameName = row[0];
      String role = row[1];
      if ( lexicalRoles.contains(role) ) result.pass();
      else result.fail("missing required frame slot " + role + " for frame " + frameName);
    }

    java.util.Iterator frameIt = frameSlots.keySet().iterator();
    while ( frameIt.hasNext() )
    {
      String frameName = (String)frameIt.next();
      java.util.Set slotsForFrame = (java.util.Set)frameSlots.get(frameName);
      java.util.Iterator roleIt = lexicalRoles.iterator();
      while ( roleIt.hasNext() )
      {
        String role = (String)roleIt.next();
        if ( isLicensableLexicalFrameRole(role) && !slotsForFrame.contains(role) )
        {
          result.fail("lexical role " + role + " is not licensed by frame " + frameName);
        }
      }
    }

    return result;
  }

  private java.util.Set readFrameCheckedLexicalRoles(java.util.List lines)
  {
    java.util.Set roles = new java.util.LinkedHashSet();
    java.util.List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("role:") )
        {
          String role = canonicalRoleToken(part.substring("role:".length()));
          if ( isFrameCheckedLexicalRole(role) ) roles.add(role);
        }
      }
    }
    return roles;
  }

  private boolean isKnownFrameSlotRole(String role)
  {
    String r = canonicalRoleToken(role);
    return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") || r.equals("THEME");
  }

  private boolean isFrameCheckedLexicalRole(String role)
  {
    String r = canonicalRoleToken(role);
    return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") ||
      r.equals("THEME") || r.equals("TIME") || r.equals("PLACE");
  }

  private boolean isLicensableLexicalFrameRole(String role)
  {
    return isFrameCheckedLexicalRole(role);
  }

  private String getMappingEndMarker(java.util.List lines)
  {
    if ( containsTrimmedLine(lines, "END_MAPPING_V4:") ) return "END_MAPPING_V4:";
    if ( containsTrimmedLine(lines, "END_MAPPING_V3:") ) return "END_MAPPING_V3:";
    if ( containsTrimmedLine(lines, "END_MAPPING_V2:") ) return "END_MAPPING_V2:";
    return "END_MAPPING_V1:";
  }


  private String getMappingVersionLabel(java.util.List lines)
  {
    if ( containsTrimmedLine(lines, "MAPPING_V4:") ) return "v4";
    if ( containsTrimmedLine(lines, "MAPPING_V3:") ) return "v3";
    if ( containsTrimmedLine(lines, "MAPPING_V2:") ) return "v2";
    return "v1";
  }

  private int countPipeSectionRows(java.util.List lines, String startMarker, String endMarker)
  {
    return pipeSectionRows(lines, startMarker, endMarker).size();
  }


  private static class MappingValidationResult
  {
    int passed = 0;
    int failed = 0;
    java.util.List messages = new java.util.ArrayList();
    String fileName = "";

    void pass()
    {
      passed++;
    }

    void fail(String message)
    {
      failed++;
      if ( message != null && message.length() > 0 ) messages.add(message);
    }

    String details()
    {
      if ( failed == 0 ) return "best placement rules satisfied";
      StringBuffer buffer = new StringBuffer();
      if ( fileName != null && fileName.length() > 0 )
      {
        buffer.append("file: ").append(fileName);
      }
      for ( int i=0; i<messages.size(); i++ )
      {
        if ( buffer.length() > 0 ) buffer.append("; ");
        buffer.append(messages.get(i).toString());
        if ( i >= 3 && messages.size() > 4 )
        {
          buffer.append("; ...");
          break;
        }
      }
      return buffer.toString();
    }
  }

  private MappingValidationResult validateMappingV3ForOpen(java.util.List lines, File selectedFile)
  {
    MappingValidationResult result = new MappingValidationResult();
    result.fileName = selectedFile == null ? "" : selectedFile.getName();

    java.util.Map roleToX = new java.util.HashMap();
    java.util.Map roleToWord = new java.util.HashMap();
    java.util.Map xToWord = new java.util.HashMap();
    java.util.Map xIds = new java.util.HashMap();
    java.util.List detTargets = new java.util.ArrayList();
    readLexicalItemsForV3Validation(lines, roleToX, roleToWord, xToWord, xIds, detTargets, result);
    validateDetTargetsForV3(roleToX, detTargets, result);

    java.util.Map verbDomain = new java.util.HashMap();
    readVerbDomainForV3Validation(lines, verbDomain, xIds, result);

    java.util.List rules = new java.util.ArrayList();
    readPlacementRulesForValidation(lines, rules);
    java.util.List validationRules = bestPlacementRules(rules);

    java.util.Map before = new java.util.HashMap();
    java.util.List roles = sortedRolesByX(roleToX);
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new java.util.ArrayList());
    java.util.List afterClauseRoles = rolesWithRelation(validationRules, roleToWord, "after_clause");

    for ( int i=0; i<validationRules.size(); i++ )
    {
      String[] rule = (String[])validationRules.get(i);
      validateMappingV3RuleForOpen(rule, roleToX, roleToWord, verbDomain, before, roles, afterClauseRoles, result);
    }

    if ( result.failed == 0 && roles.size() > 0 )
    {
      java.util.List ordered = topologicalRoleOrder(roles, before);
      if ( ordered.size() == 0 ) result.fail("ordering cycle in best placement rules");
    }
    return result;
  }

  private void readLexicalItemsForV3Validation(java.util.List lines,
                                               java.util.Map roleToX,
                                               java.util.Map roleToWord,
                                               java.util.Map xToWord,
                                               java.util.Map xIds,
                                               java.util.List detTargets,
                                               MappingValidationResult result)
  {
    java.util.List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 )
      {
        result.fail("invalid lexical item row");
        continue;
      }
      String xId = parts[0];
      String word = parts[1];
      if ( xIds.get(xId) != null ) result.fail("duplicate lexical id " + xId);
      xIds.put(xId, Boolean.TRUE);
      xToWord.put(xId, word);

      String role = null;
      String detTarget = null;
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("role:") ) role = canonicalRoleToken(part.substring("role:".length()));
        else if ( part.startsWith("det-target:") ) detTarget = canonicalRoleToken(part.substring("det-target:".length()));
        else if ( part.startsWith("det_target:") ) detTarget = canonicalRoleToken(part.substring("det_target:".length()));
      }

      if ( role == null || role.length() == 0 )
      {
        result.fail(xId + " missing role");
        continue;
      }
      if ( !isKnownMappingV3Role(role) )
      {
        result.fail("unknown role " + role + " at " + xId);
        continue;
      }
      int x = parseXIndex(xId);
      roleToX.put(role, new Integer(x));
      roleToWord.put(role, word);
      if ( role.equals("DET") ) detTargets.add(new String[] { xId, detTarget });
    }
  }

  private void validateDetTargetsForV3(java.util.Map roleToX,
                                       java.util.List detTargets,
                                       MappingValidationResult result)
  {
    if ( detTargets == null ) return;
    for ( int i=0; i<detTargets.size(); i++ )
    {
      String[] row = (String[])detTargets.get(i);
      String xId = row[0];
      String target = row.length > 1 ? row[1] : null;
      if ( target == null || target.length() == 0 )
      {
        result.fail("missing det-target for role DET at " + xId);
        continue;
      }
      if ( !isKnownMappingV3Role(target) || target.equals("DET") )
      {
        result.fail("unknown det-target " + target + " for role DET at " + xId);
        continue;
      }
      if ( resolveRoleKey(roleToX, target) == null )
      {
        result.fail("missing lexical target " + target + " for DET at " + xId);
      }
    }
  }

  private void readVerbDomainForV3Validation(java.util.List lines,
                                             java.util.Map verbDomain,
                                             java.util.Map xIds,
                                             MappingValidationResult result)
  {
    java.util.List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 3 )
      {
        result.fail("invalid verb-domain row");
        continue;
      }
      String ids = parts[2];
      verbDomain.put(parts[0], ids);
      String[] refs = ids.split(",");
      for ( int j=0; j<refs.length; j++ )
      {
        String ref = refs[j].trim();
        if ( ref.length() > 0 && xIds.get(ref) == null )
        {
          result.fail("verb-domain " + parts[0] + " references unknown lexical item " + ref);
        }
      }
    }
  }

  private boolean isKnownMappingV3Role(String role)
  {
    String r = canonicalRoleToken(role);
    return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") ||
      r.equals("THEME") || r.equals("TIME") || r.equals("PLACE") || r.equals("NEG") ||
      r.equals("WH") || r.equals("DET") || r.equals("C") || r.equals("V") || r.equals("V-AUX") || r.equals("V-PART");
  }

  private void validateMappingV3RuleForOpen(String[] rule,
                                            java.util.Map roleToX,
                                            java.util.Map roleToWord,
                                            java.util.Map verbDomain,
                                            java.util.Map before,
                                            java.util.List roles,
                                            java.util.List afterClauseRoles,
                                            MappingValidationResult result)
  {
    if ( rule == null || rule.length < 2 )
    {
      result.fail("invalid placement rule");
      return;
    }
    String role = resolveRoleKey(roleToX, rule[0]);
    String relation = rule[1];
    String target = rule.length > 2 ? rule[2] : "";
    String label = rule[0] + " " + relation + (target != null && target.length() > 0 ? " " + target : "");
    if ( role == null )
    {
      result.fail("missing role for rule " + label);
      return;
    }

    if ( relation.equals("left_of") && target.equals("V") )
    {
      String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
      if ( vAnchorRole == null ) result.fail("missing V-anchor for rule " + label);
      else { addOrderingConstraint(before, role, vAnchorRole); result.pass(); }
      return;
    }
    if ( relation.equals("right_of") && target.equals("V") )
    {
      String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
      if ( vAnchorRole == null ) result.fail("missing V-anchor for rule " + label);
      else { addOrderingConstraint(before, vAnchorRole, role); result.pass(); }
      return;
    }
    if ( relation.equals("realizes_before") || relation.equals("before") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      if ( resolvedTarget == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, role, resolvedTarget); result.pass(); }
      return;
    }
    if ( relation.equals("realizes_after") || relation.equals("after") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      if ( resolvedTarget == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, resolvedTarget, role); result.pass(); }
      return;
    }
    if ( relation.equals("after_aux_before_object") )
    {
      String auxRole = resolveRoleKey(roleToX, "V-AUX");
      String objectRole = resolveRoleKey(roleToX, target == null || target.length() == 0 ? "Patiens" : target);
      if ( auxRole == null ) result.fail("missing V-AUX for rule " + label);
      else if ( objectRole == null ) result.fail("missing target " + target + " for rule " + label);
      else
      {
        addOrderingConstraint(before, auxRole, role);
        addOrderingConstraint(before, role, objectRole);
        result.pass();
      }
      return;
    }
    if ( relation.equals("before_clause") )
    {
      addClauseBoundaryConstraints(before, roles, role, true);
      result.pass();
      return;
    }
    if ( relation.equals("after_clause") )
    {
      addClauseBoundaryConstraints(before, roles, role, false);
      result.pass();
      return;
    }
    if ( relation.equals("clause_end") )
    {
      addClauseEndConstraints(before, roles, role, afterClauseRoles);
      result.pass();
      return;
    }
    if ( relation.equals("anchor") )
    {
      result.pass();
      return;
    }
    result.fail("unknown placement relation " + relation + " for rule " + label);
  }

  private void applyMappingV1Validation(Graph graph, java.util.List lines)
  {
    java.util.Map roleToX = new java.util.HashMap();
    java.util.Map roleToWord = new java.util.HashMap();
    java.util.Map xToWord = new java.util.HashMap();
    java.util.Map verbDomain = new java.util.HashMap();
    java.util.List rules = new java.util.ArrayList();

    readLexicalItemsForValidation(lines, roleToX, roleToWord, xToWord);
    readVerbDomainForValidation(lines, verbDomain);
    readPlacementRulesForValidation(lines, rules);

    int passed = 0;
    int failed = 0;
    java.util.List failures = new java.util.ArrayList();
    int vAnchor = getVerbAnchorX(verbDomain);

    java.util.List validationRules = isRankedMapping(lines) ? bestPlacementRules(rules) : rules;

    for ( int i=0; i<validationRules.size(); i++ )
    {
      String[] rule = (String[])validationRules.get(i);
      String role = rule[0];
      String relation = rule[1];
      String target = rule[2];
      boolean ok = validatePlacementRule(role, relation, target, roleToX, vAnchor);
      if ( ok ) passed++;
      else
      {
        failed++;
        failures.add(role + " " + relation + " " + target);
      }
    }

    String details = "";
    if ( failed > 0 ) details = joinFailureList(failures);
    else if ( validationRules.size() > 0 ) details = "best placement rules satisfied";
    graph.setOPNMappingV1Validation(passed, failed, details);
  }

  private void applyMappingV1Generation(Graph graph, java.util.List lines)
  {
    java.util.Map roleToWord = new java.util.HashMap();
    java.util.Map roleToX = new java.util.HashMap();
    readLexicalItemsForGenerator(lines, roleToWord, roleToX);

    java.util.Map verbDomain = new java.util.HashMap();
    readVerbDomainForValidation(lines, verbDomain);

    java.util.List rules = new java.util.ArrayList();
    readPlacementRulesForValidation(lines, rules);

    if ( isRankedMapping(lines) )
    {
      String generated = generateV3UtteranceSummary(roleToWord, roleToX, verbDomain, rules);
      if ( generated.length() > 0 ) graph.setOPNMappingV1GeneratedUtterance(generated);
    }
    else
    {
      java.util.List generated = generateUtteranceFromPlacementRules(roleToWord, roleToX, verbDomain, rules);
      if ( generated.size() == 0 ) return;
      graph.setOPNMappingV1GeneratedUtterance(joinWords(generated));
    }
  }

  private boolean isMappingV3(java.util.List lines)
  {
    return containsTrimmedLine(lines, "MAPPING_V3:");
  }

  private boolean isMappingV4(java.util.List lines)
  {
    return containsTrimmedLine(lines, "MAPPING_V4:");
  }

  private boolean isRankedMapping(java.util.List lines)
  {
    return isMappingV3(lines) || isMappingV4(lines);
  }

  private java.util.List bestPlacementRules(java.util.List rules)
  {
    java.util.List filtered = new java.util.ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      if ( isCoreRule(rule) || getRuleRank(rule) == 1 ) filtered.add(rule);
    }
    return filtered;
  }

  private boolean isCoreRule(String[] rule)
  {
    if ( rule == null || rule.length < 4 ) return true;
    String marker = rule[3] == null ? "" : rule[3].trim();
    return marker.length() == 0 || marker.equalsIgnoreCase("core") || marker.equals("-");
  }

  private int getRuleRank(String[] rule)
  {
    if ( rule == null || rule.length < 4 ) return 0;
    String marker = rule[3] == null ? "" : rule[3].trim();
    if ( marker.startsWith("rank:") ) marker = marker.substring("rank:".length());
    if ( marker.startsWith("pref:") ) marker = marker.substring("pref:".length());
    try { return Integer.parseInt(marker); } catch ( Exception e ) { return 0; }
  }

  private String generateV3UtteranceSummary(java.util.Map roleToWord,
                                            java.util.Map roleToX,
                                            java.util.Map verbDomain,
                                            java.util.List rules)
  {
    java.util.List bestRules = bestPlacementRules(rules);
    java.util.List bestWords = generateUtteranceFromPlacementRules(roleToWord, roleToX, verbDomain, bestRules);
    if ( bestWords.size() == 0 ) return "";
    String best = joinWords(bestWords);

    java.util.List candidates = new java.util.ArrayList();
    java.util.List optionRules = nonBestOptionRules(rules);
    int order = 0;

    for ( int i=0; i<optionRules.size(); i++ )
    {
      String[] option = (String[])optionRules.get(i);
      java.util.List candidateRules = replaceBestRuleForRole(bestRules, option);
      addV3Candidate(candidates, roleToWord, roleToX, verbDomain, candidateRules, best, order++);
    }

    int pairCount = 0;
    for ( int i=0; i<optionRules.size(); i++ )
    {
      String[] first = (String[])optionRules.get(i);
      for ( int j=i+1; j<optionRules.size(); j++ )
      {
        String[] second = (String[])optionRules.get(j);
        if ( sameRuleRole(first, second) ) continue;
        java.util.List candidateRules = replaceBestRuleForRole(bestRules, first);
        candidateRules = replaceBestRuleForRole(candidateRules, second);
        addV3Candidate(candidates, roleToWord, roleToX, verbDomain, candidateRules, best, order++);
        pairCount++;
        if ( pairCount >= MAX_V3_PAIR_CANDIDATES ) break;
      }
      if ( pairCount >= MAX_V3_PAIR_CANDIDATES ) break;
    }

    java.util.Collections.sort(candidates, new java.util.Comparator() {
      public int compare(Object a, Object b)
      {
        Object[] ca = (Object[])a;
        Object[] cb = (Object[])b;
        int sa = ((Integer)ca[0]).intValue();
        int sb = ((Integer)cb[0]).intValue();
        if ( sa != sb ) return sa - sb;
        return ((Integer)ca[1]).intValue() - ((Integer)cb[1]).intValue();
      }
    });

    java.util.List alternatives = uniqueV3AlternativeTexts(candidates, best, MAX_V3_ALTERNATIVES);

    StringBuffer result = new StringBuffer();
    result.append("best: ").append(best);
    if ( alternatives.size() > 0 )
    {
      result.append("; alternatives: ");
      for ( int i=0; i<alternatives.size(); i++ )
      {
        if ( i > 0 ) result.append(" | ");
        result.append(alternatives.get(i).toString());
      }
    }
    return result.toString();
  }

  private java.util.List nonBestOptionRules(java.util.List rules)
  {
    java.util.List result = new java.util.ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      int rank = getRuleRank(rule);
      if ( rank > 1 ) result.add(rule);
    }
    java.util.Collections.sort(result, new java.util.Comparator() {
      public int compare(Object a, Object b)
      {
        String[] ra = (String[])a;
        String[] rb = (String[])b;
        int rankCompare = getRuleRank(ra) - getRuleRank(rb);
        if ( rankCompare != 0 ) return rankCompare;
        return ruleSortKey(ra).compareTo(ruleSortKey(rb));
      }
    });
    return result;
  }

  private void addV3Candidate(java.util.List candidates,
                              java.util.Map roleToWord,
                              java.util.Map roleToX,
                              java.util.Map verbDomain,
                              java.util.List candidateRules,
                              String best,
                              int order)
  {
    java.util.List candidateWords = generateUtteranceFromPlacementRules(roleToWord, roleToX, verbDomain, candidateRules);
    if ( candidateWords.size() == 0 ) return;
    String candidate = joinWords(candidateWords);
    if ( candidate.length() == 0 || candidate.equals(best) ) return;
    candidates.add(new Object[] { Integer.valueOf(ruleSetRankScore(candidateRules)),
                                  Integer.valueOf(order),
                                  candidate });
  }

  private java.util.List uniqueV3AlternativeTexts(java.util.List candidates, String best, int maxCount)
  {
    java.util.List alternatives = new java.util.ArrayList();
    for ( int i=0; i<candidates.size(); i++ )
    {
      Object[] row = (Object[])candidates.get(i);
      String text = (String)row[2];
      if ( text == null || text.length() == 0 || text.equals(best) ) continue;
      if ( alternatives.contains(text) ) continue;
      alternatives.add(text);
      if ( alternatives.size() >= maxCount ) break;
    }
    return alternatives;
  }

  private int ruleSetRankScore(java.util.List rules)
  {
    int score = 0;
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      if ( isCoreRule(rule) ) continue;
      int rank = getRuleRank(rule);
      score += rank > 0 ? rank : 10;
    }
    return score;
  }

  private boolean sameRuleRole(String[] a, String[] b)
  {
    if ( a == null || b == null || a.length == 0 || b.length == 0 ) return false;
    return a[0].equals(b[0]);
  }

  private String ruleSortKey(String[] rule)
  {
    if ( rule == null ) return "";
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<rule.length; i++ )
    {
      if ( i > 0 ) buffer.append("|");
      buffer.append(rule[i] == null ? "" : rule[i]);
    }
    return buffer.toString();
  }

  private java.util.List replaceBestRuleForRole(java.util.List bestRules, String[] option)
  {
    java.util.List result = new java.util.ArrayList();
    String role = option != null && option.length > 0 ? option[0] : "";
    for ( int i=0; i<bestRules.size(); i++ )
    {
      String[] rule = (String[])bestRules.get(i);
      if ( rule.length > 0 && rule[0].equals(role) && !isCoreRule(rule) ) continue;
      result.add(rule);
    }
    result.add(option);
    return result;
  }


  private void readLexicalItemsForGenerator(java.util.List lines, java.util.Map roleToWord, java.util.Map roleToX)
  {
    java.util.Map xToWord = new java.util.HashMap();
    readLexicalItemsForValidation(lines, roleToX, roleToWord, xToWord);
  }

  private java.util.List generateUtteranceFromPlacementRules(java.util.Map roleToWord,
                                                            java.util.Map roleToX,
                                                            java.util.Map verbDomain,
                                                            java.util.List rules)
  {
    java.util.List roles = sortedRolesByX(roleToX);
    if ( roles.size() == 0 ) return new java.util.ArrayList();

    java.util.Map before = new java.util.HashMap();
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new java.util.ArrayList());

    java.util.List afterClauseRoles = rolesWithRelation(rules, roleToWord, "after_clause");
    String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      String role = resolveRoleKey(roleToWord, rule[0]);
      String relation = rule[1];
      String target = rule.length > 2 ? rule[2] : "";
      if ( role == null ) continue;

      if ( relation.equals("left_of") && target.equals("V") )
      {
        addOrderingConstraint(before, role, vAnchorRole);
      }
      else if ( relation.equals("right_of") && target.equals("V") )
      {
        addOrderingConstraint(before, vAnchorRole, role);
      }
      else if ( relation.equals("realizes_before") || relation.equals("before") )
      {
        addOrderingConstraint(before, role, resolveRoleKey(roleToWord, target));
      }
      else if ( relation.equals("realizes_after") || relation.equals("after") )
      {
        addOrderingConstraint(before, resolveRoleKey(roleToWord, target), role);
      }
      else if ( relation.equals("after_aux_before_object") )
      {
        String objectRole = resolveRoleKey(roleToWord, target.length() == 0 ? "Patiens" : target);
        addOrderingConstraint(before, resolveRoleKey(roleToWord, "V-AUX"), role);
        addOrderingConstraint(before, role, objectRole);
      }
      else if ( relation.equals("before_clause") )
      {
        addClauseBoundaryConstraints(before, roles, role, true);
      }
      else if ( relation.equals("after_clause") )
      {
        addClauseBoundaryConstraints(before, roles, role, false);
      }
      else if ( relation.equals("clause_end") )
      {
        addClauseEndConstraints(before, roles, role, afterClauseRoles);
      }
      else if ( relation.equals("anchor") )
      {
        // Anchor is declarative: it identifies the verb-domain anchor without adding order constraints.
      }
    }

    java.util.List orderedRoles = topologicalRoleOrder(roles, before);
    java.util.List words = new java.util.ArrayList();
    for ( int i=0; i<orderedRoles.size(); i++ )
    {
      Object word = roleToWord.get((String)orderedRoles.get(i));
      if ( word != null && word.toString().length() > 0 ) words.add(word.toString());
    }
    return words;
  }

  private java.util.List rolesWithRelation(java.util.List rules, java.util.Map roleMap, String relation)
  {
    java.util.List result = new java.util.ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      if ( rule.length < 2 || !relation.equals(rule[1]) ) continue;
      String role = resolveRoleKey(roleMap, rule[0]);
      if ( role != null && !result.contains(role) ) result.add(role);
    }
    return result;
  }

  private String resolveRoleKey(java.util.Map roleMap, String requested)
  {
    if ( requested == null ) return null;
    String wanted = canonicalRoleToken(requested);
    if ( wanted.length() == 0 ) return null;
    if ( roleMap.get(wanted) != null ) return wanted;

    java.util.Iterator it = roleMap.keySet().iterator();
    while ( it.hasNext() )
    {
      String candidate = (String)it.next();
      if ( sameRoleToken(candidate, wanted) ) return candidate;
    }
    return null;
  }

  private boolean sameRoleToken(String a, String b)
  {
    String aa = canonicalRoleToken(a).replace('-', '_');
    String bb = canonicalRoleToken(b).replace('-', '_');
    return aa.equalsIgnoreCase(bb);
  }

  private java.util.List sortedRolesByX(final java.util.Map roleToX)
  {
    java.util.List roles = new java.util.ArrayList(roleToX.keySet());
    java.util.Collections.sort(roles, new java.util.Comparator() {
      public int compare(Object a, Object b)
      {
        Integer xa = (Integer)roleToX.get(a);
        Integer xb = (Integer)roleToX.get(b);
        int av = xa == null ? Integer.MAX_VALUE : xa.intValue();
        int bv = xb == null ? Integer.MAX_VALUE : xb.intValue();
        if ( av != bv ) return av - bv;
        return a.toString().compareTo(b.toString());
      }
    });
    return roles;
  }

  private String findVerbAnchorRole(java.util.Map roleToX, java.util.Map verbDomain)
  {
    Object value = verbDomain.get("V");
    if ( value == null ) return null;
    String[] xs = value.toString().split(",");
    int bestX = Integer.MAX_VALUE;
    String bestRole = null;
    for ( int i=0; i<xs.length; i++ )
    {
      int x = parseXIndex(xs[i].trim());
      if ( x < 0 ) continue;
      java.util.Iterator it = roleToX.keySet().iterator();
      while ( it.hasNext() )
      {
        String role = (String)it.next();
        Integer rx = (Integer)roleToX.get(role);
        if ( rx != null && rx.intValue() == x && x < bestX )
        {
          bestX = x;
          bestRole = role;
        }
      }
    }
    return bestRole;
  }

  private void addOrderingConstraint(java.util.Map before, String first, String second)
  {
    if ( first == null || second == null || first.equals(second) ) return;
    java.util.List list = (java.util.List)before.get(first);
    if ( list == null )
    {
      list = new java.util.ArrayList();
      before.put(first, list);
    }
    if ( !list.contains(second) ) list.add(second);
    if ( before.get(second) == null ) before.put(second, new java.util.ArrayList());
  }

  private void addClauseBoundaryConstraints(java.util.Map before, java.util.List roles, String role, boolean beforeClause)
  {
    if ( role == null ) return;
    for ( int i=0; i<roles.size(); i++ )
    {
      String other = (String)roles.get(i);
      if ( other == null || other.equals(role) ) continue;
      if ( beforeClause ) addOrderingConstraint(before, role, other);
      else addOrderingConstraint(before, other, role);
    }
  }

  private void addClauseEndConstraints(java.util.Map before, java.util.List roles, String role, java.util.List afterClauseRoles)
  {
    if ( role == null ) return;
    for ( int i=0; i<roles.size(); i++ )
    {
      String other = (String)roles.get(i);
      if ( other == null || other.equals(role) ) continue;
      if ( afterClauseRoles != null && afterClauseRoles.contains(other) ) continue;
      addOrderingConstraint(before, other, role);
    }
  }

  private java.util.List topologicalRoleOrder(java.util.List initialRoles, java.util.Map before)
  {
    java.util.List remaining = new java.util.ArrayList(initialRoles);
    java.util.List ordered = new java.util.ArrayList();
    while ( remaining.size() > 0 )
    {
      String candidate = null;
      for ( int i=0; i<remaining.size(); i++ )
      {
        String role = (String)remaining.get(i);
        if ( hasNoIncomingConstraints(role, remaining, before) )
        {
          candidate = role;
          break;
        }
      }
      if ( candidate == null ) return new java.util.ArrayList();
      ordered.add(candidate);
      remaining.remove(candidate);
    }
    return ordered;
  }

  private boolean hasNoIncomingConstraints(String role, java.util.List remaining, java.util.Map before)
  {
    for ( int i=0; i<remaining.size(); i++ )
    {
      String other = (String)remaining.get(i);
      java.util.List list = (java.util.List)before.get(other);
      if ( list != null && list.contains(role) ) return false;
    }
    return true;
  }

  private void addGeneratedRole(java.util.List generated, java.util.Map roleToWord, String role)
  {
    Object word = roleToWord.get(role);
    if ( word != null && word.toString().length() > 0 ) generated.add(word.toString());
  }

  private String joinWords(java.util.List words)
  {
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<words.size(); i++ )
    {
      if ( i > 0 ) buffer.append(" ");
      buffer.append(words.get(i).toString());
    }
    return buffer.toString();
  }

  private void readLexicalItemsForValidation(java.util.List lines, java.util.Map roleToX,
                                             java.util.Map roleToWord, java.util.Map xToWord)
  {
    java.util.List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 ) continue;
      String xId = parts[0];
      String word = parts[1];
      int x = parseXIndex(xId);
      xToWord.put(xId, word);
      for ( int j=2; j<parts.length; j++ )
      {
        String part = parts[j];
        if ( part.startsWith("role:") )
        {
          String role = canonicalRoleToken(part.substring("role:".length()));
          roleToX.put(role, new Integer(x));
          roleToWord.put(role, word);
        }
      }
    }
  }

  private void readVerbDomainForValidation(java.util.List lines, java.util.Map verbDomain)
  {
    java.util.List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 3 ) verbDomain.put(parts[0], parts[2]);
    }
  }

  private void readPlacementRulesForValidation(java.util.List lines, java.util.List rules)
  {
    java.util.List rows = pipeSectionRows(lines, "PLACEMENT_RULES:", getMappingEndMarker(lines));
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      String[] rule = normalizePlacementRule(parts);
      if ( rule != null ) rules.add(rule);
    }
  }

  private String[] normalizePlacementRule(String[] parts)
  {
    if ( parts == null || parts.length < 2 ) return null;

    String role = safeTrim(parts[0]);
    String relation = safeTrim(parts[1]);
    String target = "";
    String marker = "";

    if ( parts.length >= 4 )
    {
      target = safeTrim(parts[2]);
      marker = safeTrim(parts[3]);
    }
    else if ( parts.length == 3 )
    {
      String third = safeTrim(parts[2]);
      if ( isRuleMarker(third) || relationImpliesTarget(relation) || isUnaryPlacementRelation(relation) ) marker = third;
      else target = third;
    }

    String[] expanded = expandPlacementRelation(relation, target);
    relation = expanded[0];
    target = expanded[1];

    if ( role.length() == 0 || relation.length() == 0 ) return null;
    return new String[] { canonicalRoleToken(role), relation, canonicalRoleToken(target), marker };
  }

  private String[] expandPlacementRelation(String relation, String target)
  {
    String original = safeTrim(relation);
    String lower = original.toLowerCase();
    String compact = lower.replace('-', '_');
    String resolvedTarget = safeTrim(target);

    if ( compact.equals("left_of_v") ) return new String[] { "left_of", "V" };
    if ( compact.equals("right_of_v") ) return new String[] { "right_of", "V" };

    if ( compact.startsWith("before_") && !compact.equals("before_clause") )
    {
      String relationForSuffix = original.replace('-', '_');
      String suffix = relationForSuffix.substring(relationForSuffix.indexOf('_') + 1);
      return new String[] { "before", suffix };
    }
    if ( compact.startsWith("after_") && !compact.equals("after_clause") && !compact.equals("after_aux_before_object") )
    {
      String relationForSuffix = original.replace('-', '_');
      String suffix = relationForSuffix.substring(relationForSuffix.indexOf('_') + 1);
      return new String[] { "after", suffix };
    }

    if ( compact.equals("before_clause") ) return new String[] { "before_clause", "" };
    if ( compact.equals("after_clause") ) return new String[] { "after_clause", "" };
    if ( compact.equals("after_aux_before_object") )
      return new String[] { "after_aux_before_object", resolvedTarget.length() == 0 ? "Patiens" : resolvedTarget };
    if ( compact.equals("anchor") ) return new String[] { "anchor", "" };
    if ( compact.equals("clause_end") ) return new String[] { "clause_end", "" };

    if ( compact.equals("realizes_before") ) return new String[] { "realizes_before", resolvedTarget };
    if ( compact.equals("realizes_after") ) return new String[] { "realizes_after", resolvedTarget };

    return new String[] { original, resolvedTarget };
  }

  private boolean relationImpliesTarget(String relation)
  {
    String compact = safeTrim(relation).toLowerCase().replace('-', '_');
    return compact.equals("left_of_v") || compact.equals("right_of_v") ||
      (compact.startsWith("before_") && !compact.equals("before_clause")) ||
      (compact.startsWith("after_") && !compact.equals("after_clause") && !compact.equals("after_aux_before_object"));
  }

  private boolean isUnaryPlacementRelation(String relation)
  {
    String compact = safeTrim(relation).toLowerCase().replace('-', '_');
    return compact.equals("before_clause") || compact.equals("after_clause") ||
      compact.equals("anchor") || compact.equals("clause_end");
  }

  private boolean isRuleMarker(String value)
  {
    String marker = safeTrim(value).toLowerCase();
    return marker.length() == 0 || marker.equals("-") || marker.equals("core") ||
      marker.startsWith("rank:") || marker.startsWith("pref:");
  }

  private String canonicalRoleToken(String value)
  {
    String token = safeTrim(value);
    if ( token.length() == 0 ) return token;
    token = token.replace('_', '-');
    if ( token.equalsIgnoreCase("v") ) return "V";
    if ( token.equalsIgnoreCase("v-aux") ) return "V-AUX";
    if ( token.equalsIgnoreCase("v-part") ) return "V-PART";
    if ( token.equalsIgnoreCase("recipient") ) return "RECIPIENT";
    if ( token.equalsIgnoreCase("theme") ) return "THEME";
    if ( token.equalsIgnoreCase("time") ) return "TIME";
    if ( token.equalsIgnoreCase("place") ) return "PLACE";
    if ( token.equalsIgnoreCase("neg") ) return "NEG";
    if ( token.equalsIgnoreCase("wh") ) return "WH";
    if ( token.equalsIgnoreCase("det") ) return "DET";
    if ( token.equalsIgnoreCase("agens") ) return "Agens";
    if ( token.equalsIgnoreCase("patiens") ) return "Patiens";
    return token;
  }

  private String safeTrim(String value)
  {
    return value == null ? "" : value.trim();
  }

  private java.util.List pipeSectionRows(java.util.List lines, String startMarker, String endMarker)
  {
    java.util.List rows = new java.util.ArrayList();
    boolean inSection = false;
    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.equals(startMarker) )
      {
        inSection = true;
        continue;
      }
      if ( inSection && line.equals(endMarker) ) break;
      if ( inSection )
      {
        if ( line.length() == 0 || line.startsWith("#") ) continue;
        if ( line.endsWith(":") ) break;
        if ( line.indexOf("|") >= 0 ) rows.add(line);
      }
    }
    return rows;
  }

  private boolean validatePlacementRule(String role, String relation, String target,
                                        java.util.Map roleToX, int vAnchor)
  {
    String resolvedRole = resolveRoleKey(roleToX, role);
    if ( resolvedRole == null ) return false;

    if ( relation.equals("left_of") && target.equals("V") )
    {
      Integer x = (Integer)roleToX.get(resolvedRole);
      return x != null && vAnchor >= 0 && x.intValue() < vAnchor;
    }
    if ( relation.equals("right_of") && target.equals("V") )
    {
      Integer x = (Integer)roleToX.get(resolvedRole);
      return x != null && vAnchor >= 0 && x.intValue() > vAnchor;
    }
    if ( relation.equals("realizes_before") || relation.equals("before") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      Integer x = (Integer)roleToX.get(resolvedRole);
      Integer y = resolvedTarget == null ? null : (Integer)roleToX.get(resolvedTarget);
      return x != null && y != null && x.intValue() < y.intValue();
    }
    if ( relation.equals("realizes_after") || relation.equals("after") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      Integer x = (Integer)roleToX.get(resolvedRole);
      Integer y = resolvedTarget == null ? null : (Integer)roleToX.get(resolvedTarget);
      return x != null && y != null && x.intValue() > y.intValue();
    }
    if ( relation.equals("after_aux_before_object") )
    {
      String objectRole = resolveRoleKey(roleToX, target == null || target.length() == 0 ? "Patiens" : target);
      Integer x = (Integer)roleToX.get(resolvedRole);
      Integer aux = (Integer)roleToX.get(resolveRoleKey(roleToX, "V-AUX"));
      Integer obj = objectRole == null ? null : (Integer)roleToX.get(objectRole);
      return x != null && aux != null && obj != null &&
        aux.intValue() < x.intValue() && x.intValue() < obj.intValue();
    }
    if ( relation.equals("before_clause") )
    {
      Integer x = (Integer)roleToX.get(resolvedRole);
      return x != null && x.intValue() == minRoleX(roleToX);
    }
    if ( relation.equals("after_clause") )
    {
      Integer x = (Integer)roleToX.get(resolvedRole);
      return x != null && x.intValue() == maxRoleX(roleToX);
    }
    if ( relation.equals("anchor") || relation.equals("clause_end") ) return true;
    return true;
  }

  private int minRoleX(java.util.Map roleToX)
  {
    int best = Integer.MAX_VALUE;
    java.util.Iterator it = roleToX.values().iterator();
    while ( it.hasNext() )
    {
      Integer x = (Integer)it.next();
      if ( x != null && x.intValue() < best ) best = x.intValue();
    }
    return best == Integer.MAX_VALUE ? -1 : best;
  }

  private int maxRoleX(java.util.Map roleToX)
  {
    int best = Integer.MIN_VALUE;
    java.util.Iterator it = roleToX.values().iterator();
    while ( it.hasNext() )
    {
      Integer x = (Integer)it.next();
      if ( x != null && x.intValue() > best ) best = x.intValue();
    }
    return best == Integer.MIN_VALUE ? -1 : best;
  }

  private int getVerbAnchorX(java.util.Map verbDomain)
  {
    Object value = verbDomain.get("V");
    if ( value == null ) return -1;
    String text = value.toString();
    String[] parts = text.split(",");
    int best = Integer.MAX_VALUE;
    for ( int i=0; i<parts.length; i++ )
    {
      int x = parseXIndex(parts[i].trim());
      if ( x >= 0 && x < best ) best = x;
    }
    return best == Integer.MAX_VALUE ? -1 : best;
  }

  private int parseXIndex(String xId)
  {
    if ( xId == null ) return -1;
    String s = xId.trim();
    if ( s.length() > 0 && (s.charAt(0) == 'x' || s.charAt(0) == 'X') ) s = s.substring(1);
    return parseIntSafe(s, -1);
  }

  private String joinFailureList(java.util.List failures)
  {
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<failures.size(); i++ )
    {
      if ( i > 0 ) buffer.append(", ");
      buffer.append((String)failures.get(i));
      if ( i >= 2 && failures.size() > 3 )
      {
        buffer.append(", ...");
        break;
      }
    }
    return buffer.toString();
  }

  private void addStructuredNode(Graph graph, java.util.Map idToNode, java.util.Map nodeData) throws IOException
  {
    String id = (String)nodeData.get("id");
    if ( id == null || id.length() == 0 ) throw new IOException("OPN node without id.");
    String label = (String)nodeData.get("label");
    int x = parseIntSafe((String)nodeData.get("x"), 0);
    int y = parseIntSafe((String)nodeData.get("y"), 0);
    Node node = labeledNode(x, y, label == null ? id : label);
    graph.addNode(node, false);
    idToNode.put(id, node);
  }

  private void addStructuredEdgeLists(java.util.List edgeFrom, java.util.List edgeTo, java.util.Map edgeData)
  {
    String from = (String)edgeData.get("from");
    String to = (String)edgeData.get("to");
    if ( from != null && to != null ) { edgeFrom.add(from); edgeTo.add(to); }
  }

  private void connectStructuredEdges(Graph graph, java.util.Map idToNode, java.util.List edgeFrom, java.util.List edgeTo)
  {
    for ( int i=0; i<edgeFrom.size() && i<edgeTo.size(); i++ )
    {
      Node from = (Node)idToNode.get((String)edgeFrom.get(i));
      Node to = (Node)idToNode.get((String)edgeTo.get(i));
      if ( from != null && to != null ) graph.addEdgeNoCheck(from, to, false);
    }
  }

  private void parseKeyValueInto(java.util.Map map, String line)
  {
    int idx = line.indexOf(':');
    if ( idx < 0 ) return;
    String key = line.substring(0, idx).trim();
    String value = stripQuotes(line.substring(idx + 1).trim());
    map.put(key, value);
  }

  private String[] splitPipe(String line)
  {
    java.util.List parts = new java.util.ArrayList();
    String[] rawParts = line.split("\\|", -1);
    for ( int i=0; i<rawParts.length; i++ ) parts.add(rawParts[i].trim());
    return (String[])parts.toArray(new String[parts.size()]);
  }

  private boolean containsTrimmedLine(java.util.List lines, String text)
  {
    for ( int i=0; i<lines.size(); i++ )
    {
      String line = (String)lines.get(i);
      if ( line != null && line.trim().equals(text) ) return true;
    }
    return false;
  }

  private int parseIntSafe(String value, int fallback)
  {
    if ( value == null ) return fallback;
    try { return Integer.parseInt(value.trim()); } catch ( Exception ex ) { return fallback; }
  }

  private String displayNameWithoutExtension(File selectedFile)
  {
    String name = selectedFile == null ? "OPN" : selectedFile.getName();
    int idx = name.lastIndexOf('.');
    if ( idx > 0 ) return name.substring(0, idx);
    return name;
  }

  private java.util.List readAllLines(File selectedFile) throws IOException
  {
    java.util.List lines = new java.util.ArrayList();
    BufferedReader reader = new BufferedReader(new FileReader(selectedFile));
    try
    {
      String line;
      while ( (line = reader.readLine()) != null )
      {
        lines.add(line);
      }
    }
    finally
    {
      reader.close();
    }
    return lines;
  }

  private boolean containsLine(java.util.List lines, String text)
  {
    for ( int i=0; i<lines.size(); i++ )
    {
      String line = (String)lines.get(i);
      if ( line != null && line.trim().equals(text) )
      {
        return true;
      }
    }
    return false;
  }

  private Graph loadFramePlacementDemoOPN(java.util.List lines, File selectedFile)
  {
    Graph graph = new Graph("OPN: " + selectedFile.getName());
    graph.setGrid(12, 50, 12, 90, false);

    java.util.Map forms = new java.util.LinkedHashMap();
    java.util.Map positions = new java.util.LinkedHashMap();
    java.util.Map roles = new java.util.LinkedHashMap();
    java.util.Map syns = new java.util.LinkedHashMap();
    String currentItem = null;

    for ( int i=0; i<lines.size(); i++ )
    {
      String raw = (String)lines.get(i);
      String line = raw == null ? "" : raw.trim();
      if ( line.startsWith("- id: w") )
      {
        currentItem = valueAfterColon(line);
      }
      else if ( currentItem != null && line.startsWith("form:") )
      {
        forms.put(currentItem, valueAfterColon(line));
      }
      else if ( currentItem != null && line.startsWith("lex_position:") )
      {
        positions.put(currentItem, valueAfterColon(line));
      }
      else if ( line.startsWith("lexical_item: w") )
      {
        currentItem = valueAfterColon(line);
      }
      else if ( currentItem != null && line.startsWith("syntactic_label:") )
      {
        syns.put(currentItem, valueAfterColon(line));
      }
      else if ( currentItem != null && line.startsWith("role_label:") )
      {
        roles.put(currentItem, valueAfterColon(line));
      }
    }

    java.util.Map lexNodes = new java.util.LinkedHashMap();
    int index = 0;
    java.util.Iterator it = forms.keySet().iterator();
    while ( it.hasNext() )
    {
      String id = (String)it.next();
      String form = (String)forms.get(id);
      int x = 120 + index * 140;

      Node lex = labeledNode(x, 420, form);
      graph.addNode(lex, false);
      lexNodes.put(id, lex);

      String syn = (String)syns.get(id);
      if ( syn != null )
      {
        Node synNode = labeledNode(x, 320, syn);
        graph.addNode(synNode, false);
        graph.addEdgeNoCheck(synNode, lex, false);
      }

      String role = (String)roles.get(id);
      if ( role != null )
      {
        Node roleNode = labeledNode(x, 220, role);
        graph.addNode(roleNode, false);
        Node target = syn != null ? graph.nodeNamed(syn) : lex;
        graph.addEdgeNoCheck(roleNode, lex, false);
      }
      index++;
    }

    Node frame = labeledNode(120, 80, "FRAME");
    Node bezield = labeledNode(260, 80, "BEZIELD");
    Node onbezield = labeledNode(400, 80, "ONBEZIELD");
    graph.addNode(frame, false);
    graph.addNode(bezield, false);
    graph.addNode(onbezield, false);
    graph.addEdgeNoCheck(bezield, frame, false);
    graph.addEdgeNoCheck(onbezield, frame, false);

    Node v = labeledNode(260, 160, "V-centered OPN");
    graph.addNode(v, false);
    graph.addEdgeNoCheck(v, frame, false);
    return graph;
  }

  private Graph loadGenericOPNSummary(java.util.List lines, File selectedFile)
  {
    Graph graph = new Graph("OPN: " + selectedFile.getName());
    graph.setGrid(10, 50, 10, 100, false);
    Node root = labeledNode(160, 80, "OPN");
    graph.addNode(root, false);

    int row = 0;
    for ( int i=0; i<lines.size() && row < 8; i++ )
    {
      String line = ((String)lines.get(i)).trim();
      if ( line.length() == 0 || line.startsWith("#") )
      {
        continue;
      }
      if ( line.startsWith("[") || line.indexOf("OPN_VERSION") >= 0 || line.indexOf("STRUCTURE_TYPE") >= 0 ||
           line.indexOf("PROJECTION_") >= 0 || line.indexOf("output:") >= 0 )
      {
        Node node = labeledNode(160 + (row % 2) * 220, 170 + row * 45, trimOPNLabel(line));
        graph.addNode(node, false);
        graph.addEdgeNoCheck(root, node, false);
        row++;
      }
    }
    return graph;
  }

  private Node labeledNode(int x, int y, String label)
  {
    Node node = new Node(x, y);
    node.setLabel(label == null ? "" : label);
    return node;
  }

  private String valueAfterColon(String line)
  {
    int idx = line.indexOf(':');
    if ( idx < 0 )
    {
      return line.trim();
    }
    return stripQuotes(line.substring(idx + 1).trim());
  }

  private String stripQuotes(String value)
  {
    if ( value == null )
    {
      return "";
    }
    if ( value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"") )
    {
      return value.substring(1, value.length() - 1);
    }
    return value;
  }

  private String trimOPNLabel(String line)
  {
    if ( line == null )
    {
      return "";
    }
    String label = stripQuotes(line.trim());
    if ( label.length() > 48 )
    {
      return label.substring(0, 45) + "...";
    }
    return label;
  }

  private JFileChooser createGraphLoadChooser(File currentDirectory, boolean graphOnly)
  {
    JFileChooser fc = new JFileChooser();
    GraphFilter graphFilter = new GraphFilter();
    GraphOnlyFilter graphOnlyFilter = new GraphOnlyFilter();
    OPNFilter opnFilter = new OPNFilter();
    fc.addChoosableFileFilter(graphFilter);
    fc.addChoosableFileFilter(graphOnlyFilter);
    fc.addChoosableFileFilter(opnFilter);
    fc.setFileFilter(graphOnly ? graphOnlyFilter : graphFilter);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setFileView(new GraphFileView());
    fc.setCurrentDirectory(currentDirectory);
    return fc;
  }


  private JFileChooser createOPNLoadChooser(File currentDirectory)
  {
    JFileChooser fc = new JFileChooser();
    OPNFilter opnFilter = new OPNFilter();
    GraphFilter graphFilter = new GraphFilter();
    GraphOnlyFilter graphOnlyFilter = new GraphOnlyFilter();
    fc.addChoosableFileFilter(opnFilter);
    fc.addChoosableFileFilter(graphFilter);
    fc.addChoosableFileFilter(graphOnlyFilter);
    fc.setFileFilter(opnFilter);
    fc.setAcceptAllFileFilterUsed(false);
    fc.setFileView(new GraphFileView());
    fc.setCurrentDirectory(currentDirectory);
    return fc;
  }

  private GraphOnlyFilter getGraphOnlyFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter[] filters = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof GraphOnlyFilter ) return (GraphOnlyFilter)filters[i];
    }
    return new GraphOnlyFilter();
  }

  private File getPreferredGraphDirectory(GraphController controller)
  {
    if ( controller != null )
    {
      String preferredPath = controller.getPreferredGraphDirectoryPath();
      if ( preferredPath != null && preferredPath.trim().length() > 0 )
      {
        File preferredDir = new File(preferredPath.trim());
        if ( preferredDir.exists() && preferredDir.isDirectory() )
        {
          return preferredDir;
        }
      }
    }

    File graphDir = new File(System.getProperty("user.dir"), "GRAPH");
    if ( graphDir.exists() && graphDir.isDirectory() )
    {
      return graphDir;
    }
    return new File(System.getProperty("user.dir"));
  }

  private File getPreferredOPNDirectory(GraphController controller)
  {
    if ( controller != null )
    {
      String preferredPath = controller.getPreferredOPNDirectoryPath();
      if ( preferredPath != null && preferredPath.trim().length() > 0 )
      {
        File preferredDir = new File(preferredPath.trim());
        if ( preferredDir.exists() && preferredDir.isDirectory() )
        {
          return preferredDir;
        }
      }
    }

    File examplesOPNDir = new File(System.getProperty("user.dir"), "examples" + File.separator + "opn");
    if ( examplesOPNDir.exists() && examplesOPNDir.isDirectory() )
    {
      return examplesOPNDir;
    }
    return getPreferredGraphDirectory(controller);
  }

  private void rememberDirectoryForLoadedFile(GraphController controller, File selectedFile)
  {
    if ( controller == null || selectedFile == null ) return;
    File parent = selectedFile.getParentFile();
    if ( parent == null || !parent.exists() || !parent.isDirectory() ) return;
    try
    {
      String path = parent.getCanonicalPath();
      if ( isOPNFile(selectedFile) )
      {
        controller.setPreferredOPNDirectoryPath(path);
        controller.setLoadOPNFromOPNDir(true);
        lastStartInOPNDir = true;
      }
      else
      {
        controller.setPreferredGraphDirectoryPath(path);
        controller.setLoadGraphFromGraphDir(true);
        lastStartInGraphDir = true;
      }
    }
    catch ( IOException ioe )
    {
      // Ignore directory persistence failures; loading already succeeded.
    }
  }

  private String shortDirectoryLabel(File dir)
  {
    String path = dir.getPath();
    if ( path.length() > 36 )
    {
      return "..." + path.substring(path.length() - 33);
    }
    return path;
  }

  private JFileChooser createSaveChooser()
  {
    JFileChooser fc = new JFileChooser();
    GraphFilter graphFilter = new GraphFilter();
    ImageFilter imageFilter = new ImageFilter();
    fc.addChoosableFileFilter(graphFilter);
    fc.addChoosableFileFilter(imageFilter);
    fc.setFileFilter(graphFilter);
    fc.setFileView(new GraphFileView());
    File startDir = new File(System.getProperty("user.dir"));
    fc.setCurrentDirectory(startDir);
    fc.setSelectedFile(new File(startDir, "untitled.graph"));
    return fc;
  }

  private GraphFilter getGraphFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter filters[] = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof GraphFilter )
      {
        return (GraphFilter)filters[i];
      }
    }
    return null;
  }

  private ImageFilter getImageFilter(JFileChooser fc)
  {
    javax.swing.filechooser.FileFilter filters[] = fc.getChoosableFileFilters();
    for ( int i=0; i<filters.length; i++ )
    {
      if ( filters[i] instanceof ImageFilter )
      {
        return (ImageFilter)filters[i];
      }
    }
    return null;
  }

  private void saveGraphFile(GraphWindow graphWindow, GraphEditorWindow editorWindow, String savePath, String fileExt) throws IOException
  {
    String targetPath = savePath;
    String targetExtension = fileExt;

    if ( targetExtension == null )
    {
      targetPath = targetPath + ".graph";
      targetExtension = Utils.graph;
    }

    if ( targetExtension != null && targetExtension.equalsIgnoreCase(Utils.graph) )
    {
      File aFile = new File(targetPath);
      if ( !aFile.exists() || confirmOverwrite(graphWindow, targetPath) )
      {
        PrintWriter aWriter = new PrintWriter(new FileWriter(targetPath));
        editorWindow.getGraphEditor().getGraph().saveTo(aWriter);
        aWriter.close();
      }
    }
    else
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Graphs may only be saved as .graph files.",
                                    "Unable to Save Graph",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private void saveImageFile(GraphWindow graphWindow, GraphEditorWindow editorWindow, String savePath, String fileExt)
  {
    if ( fileExt != null &&
         ( fileExt.equalsIgnoreCase(Utils.gif) ||
           fileExt.equalsIgnoreCase(Utils.jpg) ||
           fileExt.equalsIgnoreCase(Utils.jpeg) ) )
    {
      File aFile = new File(savePath);
      if ( !aFile.exists() || confirmOverwrite(graphWindow, savePath) )
      {
        editorWindow.getGraphEditor().saveImage(savePath);
      }
    }
    else
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Images may only be saved as .gif, .jpg, or .jpeg files.",
                                    "Unable to Save Graph Image",
                                    JOptionPane.ERROR_MESSAGE);
    }
  }

  private boolean confirmOverwrite(GraphWindow graphWindow, String targetPath)
  {
    int option = JOptionPane.showConfirmDialog(graphWindow,
                                               "Overwrite existing file?\n\n" + targetPath,
                                               "Confirm overwrite",
                                               JOptionPane.YES_NO_OPTION,
                                               JOptionPane.WARNING_MESSAGE);
    return option == JOptionPane.YES_OPTION;
  }
}
