package userInterface;

import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import graphStructure.*;
import graphException.*;
import operation.*;
import userInterface.menuAndToolBar.*;

public class OpenGraphActions
{
  private static final int DEFAULT_VISIBLE_PADDING_CELLS = 2;
  private final GraphWindow graphWindow;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;
  private final OpenTreeStructureSupport opnSupport;
  private final MenuAndToolBar menuAndToolBar;

  public OpenGraphActions(GraphWindow graphWindow,
                           GraphWindowCoordinator graphWindowCoordinator,
                           GraphEditorActions graphEditorActions,
                           OpenTreeStructureSupport opnSupport,
                           MenuAndToolBar menuAndToolBar)
  {
    this.graphWindow = graphWindow;
    this.graphWindowCoordinator = graphWindowCoordinator;
    this.graphEditorActions = graphEditorActions;
    this.opnSupport = opnSupport;
    this.menuAndToolBar = menuAndToolBar;
  }

  public void refreshOPNMenuVisibility(GraphEditorWindow activeWindow)
  {
    if ( menuAndToolBar == null )
    {
      return;
    }

    menuAndToolBar.showSaveOPN();
    menuAndToolBar.setSaveOPNEnabled(activeWindow != null);
  }

  public void toggleLexicalProjection(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      return;
    }

    GraphEditor editor = activeWindow.getGraphEditor();
    OpenGraphProjectionSettings projectionSettings = editor.getOpenGraphProjectionSettings();
    boolean currentlyVisible = editor.isOpenGraphProjectionContextActive() &&
                               projectionSettings.isLexicalProjectionActive();
    boolean enable = !currentlyVisible;

    if ( enable )
    {
      if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) ||
           (!projectionSettings.getLeftProjectionEnabled() &&
            !projectionSettings.getRightProjectionEnabled() &&
            !projectionSettings.getTopProjectionEnabled() &&
            !projectionSettings.getBottomProjectionEnabled()) )
      {
        projectionSettings = editor.getRememberedLanguageProjectionSettings();
      }

      if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
      {
        projectionSettings.setStructureType(OpenGraphDialog.STRUCTURE_FRAME);
      }
      projectionSettings.setShowProjections(true);
      if ( !projectionSettings.getLeftProjectionEnabled() &&
           !projectionSettings.getRightProjectionEnabled() &&
           !projectionSettings.getTopProjectionEnabled() &&
           !projectionSettings.getBottomProjectionEnabled() )
      {
        projectionSettings.setLeftProjectionEnabled(true);
        projectionSettings.setRightProjectionEnabled(false);
        projectionSettings.setTopProjectionEnabled(false);
        projectionSettings.setBottomProjectionEnabled(true);
      }
    }
    else
    {
      projectionSettings.setShowProjections(false);
    }

    editor.setOpenGraphProjectionSettings(projectionSettings);
    if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
    {
      editor.rememberLanguageProjectionSettings(projectionSettings);
    }

    if ( !editor.isOpenGraphProjectionContextActive() )
    {
      editor.resetTransientEditorArtifacts();
      editor.update();
      return;
    }

    OpenGraphGridSettings gridSettings = editor.getOpenGraphGridSettings();
    if ( enable &&
         gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
    {
      gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
      editor.setOpenGraphGridSettings(gridSettings);
    }

    if ( editor.isInGridMode() )
    {
      // Do not refit or recalculate the OpenGraph grid window on a visibility
      // toggle. The project specification keeps the structure grid fixed while
      // projections are rendered in extra margin/render space. Reapplying the
      // fit-content grid here made Toggle ON appear to move the source graph
      // left by about two grid lines in FRAME examples.
    }
    editor.resetTransientEditorArtifacts();
    editor.update();
  }
  private void ensureProjectionContentVisible(GraphEditor graphEditor, OpenGraphGridSettings gridSettings)
  {
    centerVisibleContentInWindow(graphEditor);
  }

  private void centerVisibleContentInWindow(GraphEditor graphEditor)
  {
    if ( graphEditor == null )
    {
      return;
    }

    Graph graph = graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !graphEditor.isInGridMode() )
    {
      return;
    }

    OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
    int cellWidth = Math.max(2, gridSettings.getCellWidth());
    int cellHeight = Math.max(2, gridSettings.getCellHeight());
    int drawWidth = Math.max(cellWidth * 2, graphEditor.getVisibleDrawWidth());
    int drawHeight = Math.max(cellHeight * 2, graphEditor.getVisibleDrawHeight());
    int paddingX = DEFAULT_VISIBLE_PADDING_CELLS * cellWidth;
    int paddingY = DEFAULT_VISIBLE_PADDING_CELLS * cellHeight;

    Rectangle2D.Double visibleBounds = graphEditor.getVisibleContentBounds();
    double visibleWidth = visibleBounds.getWidth();
    double visibleHeight = visibleBounds.getHeight();

    double desiredMinX;
    if ( visibleWidth + (2 * paddingX) <= drawWidth )
    {
      desiredMinX = (drawWidth - visibleWidth) / 2.0;
    }
    else
    {
      desiredMinX = paddingX;
    }

    double desiredMinY;
    if ( visibleHeight + (2 * paddingY) <= drawHeight )
    {
      desiredMinY = (drawHeight - visibleHeight) / 2.0;
    }
    else
    {
      desiredMinY = paddingY;
    }

    int dx = snapToGrid((int)Math.round(desiredMinX - visibleBounds.getMinX()), cellWidth);
    int dy = snapToGrid((int)Math.round(desiredMinY - visibleBounds.getMinY()), cellHeight);

    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    graphEditor.changeToOpenGraphGridMode(gridSettings);
  }

  private int snapToGrid(int value, int step)
  {
    if ( step <= 1 )
    {
      return value;
    }
    return (int)Math.round((double)value / (double)step) * step;
  }


  public void clearOPNState(GraphEditorWindow activeWindow)
  {
    opnSupport.clear();
    refreshOPNMenuVisibility(activeWindow);
  }

  public void saveOPN(GraphEditorWindow activeWindow)
  {
    if ( activeWindow == null )
    {
      JOptionPane.showMessageDialog(graphWindow,
                                    "Save OPN requires an open graph or OPN window.",
                                    "Save OPN",
                                    JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    try
    {
      Graph currentGraph = activeWindow.getGraphEditor().getGraph();
      if ( opnSupport.isSaveAvailableFor(activeWindow) )
      {
        opnSupport.saveResult(graphWindow, currentGraph);
        clearOPNState(activeWindow);
      }
      else
      {
        opnSupport.saveCurrentGraph(graphWindow, currentGraph);
      }
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                    "Error During Save OPN", JOptionPane.ERROR_MESSAGE);
    }
  }

  public void displayOpenGraphTree(final GraphController controller,
                               final GraphEditorWindow editorWindow)
  {
    if ( editorWindow != null )
    {
      clearOPNState(editorWindow);
      if ( editorWindow.getDialog() != null )
      {
        graphWindowCoordinator.closeCurrentDialog(editorWindow);
      }
      OpenGraphDialog dialog = new OpenGraphDialog( controller,
        editorWindow,
        "OpenGraph Draw",
        "<html>Select structure type, then Draw.</html>" )
      {
        public void actionPerformed(ActionEvent e)
        {
          displayOpenGraphTreeHelper(getOwner(), this);
        }
      };
      dialog.preloadFromEditor(editorWindow.getGraphEditor());
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.attachAndShowDialog(editorWindow, dialog);
    }
  }

  private void displayOpenGraphTreeHelper(GraphEditorWindow editorWindow, OpenGraphDialog dialog)
  {
    try
    {
      GraphEditor graphEditor = editorWindow.getGraphEditor();
      Graph graph = graphEditor.getGraph();
      int rootIndex = OpenGraphRootSelector.getRootIndex(editorWindow);
      graph.newMemento("Display OpenGraph Drawing");

      int structureType = dialog.getStructureType();
      if ( structureType != OpenGraphDialog.STRUCTURE_SIMPLE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE &&
           structureType != OpenGraphDialog.STRUCTURE_FRAME )
      {
        throw new GraphException("Only Simple, Phrase, and Frame are implemented reliably at the moment.");
      }

      OpenGraphProjectionSettings projectionSettings = OpenGraphProjectionSupport.fromDialog(dialog);
      graphEditor.setOpenGraphProjectionSettings(projectionSettings);
      boolean projectionContext =
        OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType());
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);

      OpenGraphGridSettings gridSettings = graphEditor.getOpenGraphGridSettings();
      if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) &&
           gridSettings.getGridMode() == OpenGraphGridSettings.MODE_FIT_CONTENT &&
           gridSettings.getFitScope() < OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS )
      {
        gridSettings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
        graphEditor.setOpenGraphGridSettings(gridSettings);
      }
      OpenGraphTreeDrawOperation.displayOpenGraphTreeDrawing(
        graph,
        graph.getNodeAt(rootIndex),
        dialog.getSelectedMethodNumber(),
        dialog.getStructureOffsetFromLeft(),
        dialog.getStructureOffsetFromTop(),
        gridSettings.getCellWidth(),
        gridSettings.getCellHeight(),
        graphEditor.getDrawWidth(),
        graphEditor.getDrawHeight() );
      graphEditor.changeToOpenGraphGridMode(gridSettings);
      centerVisibleContentInWindow(graphEditor);
      if ( OpenGraphProjectionSettings.isProjectionCapableStructureType(projectionSettings.getStructureType()) )
      {
        graphEditor.rememberLanguageProjectionSettings(projectionSettings);
      }
      graphEditor.setOpenGraphProjectionContextActive(projectionContext);
      graphEditor.resetTransientEditorArtifacts();
      graphEditor.update();
      editorWindow.getGraphEditor().allowNodeSelection(0);
      graphWindowCoordinator.closeDialogAndClearOwner(editorWindow);
      graph.doneMemento();
      graphEditorActions.updateUndo(editorWindow);
      opnSupport.rememberResult(editorWindow, graph);
      refreshOPNMenuVisibility(editorWindow);
    }
    catch ( Exception e )
    {
      if ( !(e instanceof GraphException) )
      {
        e.printStackTrace();
      }

      Graph graph = editorWindow.getGraphEditor().getGraph();
      graph.undoMemento();
      graph.abortMemento();

      JOptionPane.showMessageDialog(graphWindow, e.getMessage(),
                                    "Error During OpenGraph Drawing Display", JOptionPane.ERROR_MESSAGE);
    }
  }
}
