package userInterface;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import graphStructure.*;

public class GraphEditorWindow extends OpenGraphEdInternalFrame
{
  public static int WIDTH = 1150;//400;//SET MAX, see below:setSize
  public static int HEIGHT = 750;//400;

  private GraphController graphController;
  private GraphEditor graphEditor;
  private static int newCount = 0;
  private GraphEditorDialog ged;
  private GraphEditorInfoWindow infoWindow;
  private GraphEditorLogWindow logWindow;

  public GraphEditorWindow(GraphController graphController, Graph graph)
  {
    super(graphController, graph.getFileName(),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    if ( graph.getLabel().length() == 0 )
    {
      setTitle(graph.getFileName());
    }
    init(graphController);
    graphEditor.setGraph(graph);
  }

  public GraphEditorWindow(GraphController graphController)
  {
    super(graphController, "Untitled " + ++newCount,
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    init(graphController);
  }

  private void init(GraphController graphController)
  {
    this.graphController = graphController;
    infoWindow = new GraphEditorInfoWindow(graphController, this);
    logWindow = new GraphEditorLogWindow(graphController, this);
    graphEditor = new GraphEditor(graphController, infoWindow, logWindow);
    ged = null;

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    getContentPane().setLayout(layout);

    JPanel openGraphActionBar = createOpenGraphActionBar();
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.HORIZONTAL;
    layoutCons.insets = new Insets(3,3,0,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 0.0;
    layout.setConstraints(openGraphActionBar, layoutCons);
    getContentPane().add(openGraphActionBar);

    JScrollPane scrollPane = new JScrollPane(graphEditor,
                                             JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = GridBagConstraints.REMAINDER;
    layoutCons.fill = GridBagConstraints.BOTH;
    layoutCons.insets = new Insets(3,3,3,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 1.0;
    layout.setConstraints(scrollPane, layoutCons);
    getContentPane().add(scrollPane);

    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    addInternalFrameListener(graphController);

  //  setSize(WIDTH, HEIGHT);
    
    setSize(graphController.getGraphWindow().getWidth(), graphController.getGraphWindow().getHeight());
    setVisible(true);
  }

  private JPanel createOpenGraphActionBar()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
    panel.setBorder(BorderFactory.createEtchedBorder());
    panel.add(new JLabel("OpenGraph:"));
    panel.add(createOpenGraphButton("Draw", "Draw or redraw the OpenGraph structure", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.displayOpenGraphTree(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Grid", "Set or reapply the OpenGraph grid without clearing the current OPN result", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.openGraphGridMode(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Toggle Proj.", "Show or hide OpenGraph projections without moving the structure grid", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.toggleLexicalProjection(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Save OPN", "Save the current OpenGraph result as .opn", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.saveOPN(GraphEditorWindow.this);
      }
    }));
    return panel;
  }

  private JButton createOpenGraphButton(String text, String toolTip, ActionListener listener)
  {
    JButton button = new JButton(text);
    button.setMargin(new Insets(2, 8, 2, 8));
    button.setFocusable(false);
    button.setToolTipText(toolTip);
    button.addActionListener(listener);
    return button;
  }

  public void dispose()
  {
    graphEditor.prepareForClose();
    super.dispose();
  }

  public GraphEditor getGraphEditor()
  {
    return graphEditor;
  }

  public GraphEditorDialog getDialog() { return ged; }

  public void setDialog(GraphEditorDialog d) { ged = d; }

  public GraphEditorInfoWindow getInfoWindow()
  {
    return infoWindow;
  }
  
  public GraphEditorLogWindow getLogWindow()
  {
    return logWindow;
  }  
}