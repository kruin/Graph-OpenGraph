# OpenGraph Greedy Grow Viewer — PWA v4346

Mobiele/desktop PWA-viewer voor OpenGraphEd Greedy Grow JSON-exporten.

## Nieuw in v4346

- `Lijnen tonen` werkt nu ook wanneer de geladen JSON geen `edges[]` bevat.
- Bij echte JSON-edges toont de viewer de JSON-lijnen.
- Bij vrije demo's zonder edges toont de viewer afgeleide groeilijnen tussen opeenvolgende stappen.
- Afgeleide groeilijnen zijn alleen visuele hulplijnen; ze leggen geen HOR/VER-plaatsing op.
- Knop `Fit` is hernoemd naar `Passend maken`.
- Knop `JSON` is hernoemd naar `JSON laden`.
- De viewer bevat korte uitleg bij beide knoppen.
- Lokale poort is gewijzigd naar `8086` om oude PWA-cache te vermijden.

## Start lokaal

Dubbelklik in de projectroot op:

```bat
START-GREEDY-GROW-VIEWER.bat
```

Of start in deze map:

```bat
start-local-viewer.bat
```

Open daarna:

```text
http://localhost:8086
```

Voor telefoon op hetzelfde netwerk:

```text
http://<pc-ip>:8086
```

Voorbeeld:

```text
http://192.168.178.16:8086
```

## Knoppen

- `Passend maken`: herberekent de zichtbare tekening en past de SVG-viewBox opnieuw aan de zichtbare knopen aan. Dit verandert geen JSON en geen stappen.
- `JSON laden`: opent een eigen `*_grow_demo.json`, bijvoorbeeld uit OpenGraphEd via `Greedy → Export Greedy Grow JSON`.
- `Lijnen tonen`: toont echte JSON-edges, of — als die ontbreken — afgeleide groeilijnen tussen opeenvolgende stappen.
