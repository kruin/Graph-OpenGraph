@echo off
setlocal
cd /d "%~dp0"
echo.
echo OpenGraph Greedy Grow Viewer v4346
echo.
echo Start lokale server op http://localhost:8086
echo Gebruik 8086 zodat oude service-worker/cache van v4340/v4341/v4342/v4343/v4344/v4345 niet stoort.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -m http.server 8086 --bind 0.0.0.0
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  python -m http.server 8086 --bind 0.0.0.0
  goto :eof
)
echo FOUT: Python niet gevonden. Installeer Python of publiceer deze map via GitHub Pages.
pause
