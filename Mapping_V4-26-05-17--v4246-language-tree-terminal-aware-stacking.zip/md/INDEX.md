- `PATCH-MANIFEST-v4246-language-tree-terminal-aware-stacking.md` — terminal-aware row spacing for Language Tree boxes.
- [PATCH-MANIFEST-v4245-language-tree-box-bottom-stacking.md](PATCH-MANIFEST-v4245-language-tree-box-bottom-stacking.md)
- PATCH-MANIFEST-v4242-language-tree-lrrl-inherited-avoid-bound.md
- [PATCH-MANIFEST-v4244-language-tree-unary-aware-nary-boxes.md](PATCH-MANIFEST-v4244-language-tree-unary-aware-nary-boxes.md)
- `PATCH-MANIFEST-v4239-launcher-classpath-quoting-fix.md` — Windows launcherfix: classpath nu relatief `out;.` zodat Java de main class weer correct ontvangt.
- `PATCH-MANIFEST-v4238-runtime-resource-fix.md` — runtimefix: `run.bat`/classes in `out\` vinden image-resources weer; `GraphEditor` crasht niet meer als de rotate cursor ontbreekt.
- `PATCH-MANIFEST-v4237-language-tree-side-aware-lrrl.md` — Language Tree n-binair compact LR/RL: rechtertakken recursief rechts-links, linkertakken links-rechts; terminals blijven buiten de hogere ouder-as.
# Documentation index
- `PATCH-MANIFEST-v4236-language-tree-nary-compact-lr.md` — n-binair/n-ary Language Tree-layout: compact LR-plaatsing voor 3+ kinderen via configstrategie.
- `PATCH-MANIFEST-v4235-language-tree-d-lite-free-layout.md` — D-lite vrije Language Tree-layout: recursief, occupied-cell boxes, unary fan-out en binary validation.
- `sources/mapping-v4/language-tree-free-layout.md` — ontwerpbesluit voor vrije boomlayout en latere strategieën/config.

- `PATCH-MANIFEST-v4232-language-tree-zinstype-anchor.md` — DS-root blijft vast bij Language Tree-zinstypewissel; `Bijzin` schuift niet meer één gridpositie naar rechts.

- `PATCH-MANIFEST-v4230-vcluster-anchor-stability.md` — V-cluster root-anchor stabiliteit; wisselen `pv-VD`/`VD-pv` verschuift de DS-boom niet.
## Actueel

- `CHANGELOG.md` — lopende wijziggeschiedenis.
- `PATCH-MANIFEST-v4228-prune-docs-tests-examples-tools.md` — opschoning van deze distributie.
- `PATCH-MANIFEST-v4229-vcluster-stable-pv-spelling.md` — V-cluster redraw-stabiliteit en `pv`-spelling.
- `sources/mapping-v4/current-state.md` — actuele projectstatus.
- `sources/mapping-v4/language-tree-zinstype-placement-rules.md` — zinstype, slot0/slot1, FIN/V2 en topicalisatie.
- `sources/mapping-v4/language-tree-vcluster-order.md` — pv-VD / VD-pv keuze.
- `sources/mapping-v4/opengraph-projection-config.md` — basisconfiguratie projecties.
- `sources/mapping-v4/opengraph-projection-profiles.md` — projectieprofielen per structure type.

## Niet meer in hoofdzip

Historische patchmanifests, oude Mapping V3/V4 regressiemanifests en oude experimentele voorbeeldsets zijn gesnoeid. Bewaar zulke bestanden voortaan in een aparte test- of archiefbundle.
