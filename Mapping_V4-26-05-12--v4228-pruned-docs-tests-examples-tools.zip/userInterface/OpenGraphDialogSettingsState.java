package userInterface;

final class OpenGraphDialogSettingsState
{
  int structureType = OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;

  boolean showProjections;
  boolean leftProjectionEnabled;
  boolean rightProjectionEnabled;
  boolean topProjectionEnabled;
  boolean bottomProjectionEnabled;

  int structureOffsetLeft = 2;
  int structureOffsetRight = 0;
  int structureOffsetTop = 2;
  int structureOffsetBottom = 0;

  int leftProjectionPosition = 2;
  int rightProjectionPosition = 30;
  int topProjectionPosition = 2;
  int bottomProjectionPosition = 30;

  String leftProjectionCaption = "LEX";
  String rightProjectionCaption = "SYNT";
  String topProjectionCaption = "pm";
  String bottomProjectionCaption = "LF";

  String languageTreeVerbClusterOrder = OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD;

  int gridColumnWidth = 20;
  int gridRowHeight = 20;
  int gridMarginLeft = 2;
  int gridMarginRight = 2;
  int gridMarginTop = 2;
  int gridMarginBottom = 2;

  int gridMode = OpenGraphGridSettings.MODE_FIT_CONTENT;
  int fitScope = OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS;
}
