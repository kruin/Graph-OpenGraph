package operation;

import graphException.*;
import graphStructure.*;
import java.util.Vector;
import operation.extenders.*;

public class OpenGraphTreeDrawOperation
{
  private static final int DEFAULT_DRAWING_OFFSET_X = 4;
  private static final int DEFAULT_DRAWING_OFFSET_Y = 4;
  private static final int DEFAULT_CELL_WIDTH = 20;
  private static final int DEFAULT_CELL_HEIGHT = 20;

  /**
   * Keep one empty grid column between the root axis and each child box.
   * This preserves the open-tree character while keeping the reserved box minimal.
   */
  private static final int ROOT_SIDE_GAP = 1;
  private static final int LANGUAGE_TREE_TOP_SLOT_ROWS = 1;

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                            int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method,
                            DEFAULT_DRAWING_OFFSET_X,
                            DEFAULT_DRAWING_OFFSET_Y,
                            DEFAULT_CELL_WIDTH, DEFAULT_CELL_HEIGHT,
                            width, height, false);
  }


  /**
   * Compatibility overload for older callers. Right and bottom structure offsets
   * are intentionally ignored: tree positioning is anchored by left/top only.
   */
  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int rightOffset,
                                             int topOffset, int bottomOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method,
                            leftOffset, topOffset,
                            cellWidth, cellHeight,
                            width, height, false);
  }
  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height, false);
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height,
                                reserveLanguageSlots, false);
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots,
                                             boolean lengthenLanguageTreeRootBranch) throws Exception
  {
    displayOpenGraphTreeDrawing(g, root, method, leftOffset, topOffset,
                                cellWidth, cellHeight, width, height,
                                reserveLanguageSlots, lengthenLanguageTreeRootBranch,
                                "pv_vd");
  }

  public static void displayOpenGraphTreeDrawing(Graph g, Node root, int method,
                                             int leftOffset, int topOffset,
                                             int cellWidth, int cellHeight,
                                             int width, int height,
                                             boolean reserveLanguageSlots,
                                             boolean lengthenLanguageTreeRootBranch,
                                             String languageTreeVerbClusterOrder) throws Exception
  {
    boolean oldSpecialSelected = root.isSpecialSelected();
    root.setSpecialSelected(true);
    LogEntry logEntry = g.startLogEntry("OpenGraph Tree Drawing");
    try
    {
      if ( !ConnectivityOperation.isConnected(g) )
      {
        logEntry.setData("Graph was not connected");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph is not connected!");
      }
      else if ( TreeOperation.hasCycles(g) )
      {
        logEntry.setData("Graph had cycles");
        g.stopLogEntry(logEntry);
        throw new GraphException("Graph has Cycles!");
      }
      else
      {
        Vector nodes = g.createNodeExtenders(OpenGraphNodeEx.class);
        Vector edges = g.createEdgeExtenders(OpenGraphEdgeEx.class);
        OpenGraphNodeEx rootEx = (OpenGraphNodeEx)root.getExtender();
        rootEx.setParent(null);

        buildTree(rootEx);

        if ( method == 1 )
        {
          domainTreeMethod(rootEx, languageTreeVerbClusterOrder);
          if ( lengthenLanguageTreeRootBranch )
          {
            lengthenFirstRootBranch(rootEx);
          }
        }
        else if ( method == 5 )
        {
          logEntry.setData("Method 5 is not implemented reliably");
          g.stopLogEntry(logEntry);
          throw new GraphException("OpenGraph method 5 is not implemented reliably. Use the Simple open-tree renderer.");
        }
        else
        {
          logEntry.setData("Unsupported OpenGraph method: " + method);
          g.stopLogEntry(logEntry);
          throw new GraphException("Unsupported OpenGraph drawing method: " + method);
        }

        int gridWidth = rootEx.getBoundWidth();
        int gridHeight = rootEx.getBoundHeight();

        leftOffset = Math.max(0, leftOffset);
        topOffset = Math.max(0, topOffset);
        if ( reserveLanguageSlots )
        {
          topOffset += LANGUAGE_TREE_TOP_SLOT_ROWS;
        }
        cellWidth = Math.max(2, cellWidth);
        cellHeight = Math.max(2, cellHeight);

        correctGridCoordinates(rootEx, leftOffset + rootEx.getBoundX(), topOffset);

        int totalGridCols = gridWidth + leftOffset + 1;
        int totalGridRows = gridHeight + topOffset + 1;

        g.setGrid(totalGridRows, cellHeight,
                  totalGridCols, cellWidth, true);

        OpenGraphNodeEx aNode;
        OpenGraphEdgeEx anEdge;
        for ( int i=0; i<nodes.size(); i++ )
        {
          aNode = (OpenGraphNodeEx)nodes.elementAt(i);
          g.relocateNode(aNode.getRef(),
                         new Location(aNode.getGridX()*cellWidth,
                                      aNode.getGridY()*cellHeight),
                         true);
        }

        for ( int i=0; i<edges.size(); i++ )
        {
          anEdge = (OpenGraphEdgeEx)edges.elementAt(i);
          g.straightenEdge(anEdge.getRef(), true);
        }

        g.stopLogEntry(logEntry);
      }
    }
    finally
    {
      root.setSpecialSelected(oldSpecialSelected);
    }
  }

  private static int buildTree(OpenGraphNodeEx root)
  {
    Vector children = root.getChildren();
    OpenGraphNodeEx child;
    int size = 1;
    for ( int i=0; i<children.size(); i++ )
    {
      child = (OpenGraphNodeEx)children.elementAt(i);
      if ( child != root.getParent() )
      {
        child.setParent(root);
        size += buildTree(child);
      }
    }
    root.setSubTreeSize(size);
    root.setSubTreeDone(false);
    return size;
  }

  private static void domainTreeMethod(OpenGraphNodeEx root, String languageTreeVerbClusterOrder)
  {
    Vector children = root.getChildren();

    if ( children.size() == 0 )
    {
      initializeLeaf(root);
      return;
    }

    for ( int i=0; i<children.size(); i++ )
    {
      domainTreeMethod((OpenGraphNodeEx)children.elementAt(i), languageTreeVerbClusterOrder);
    }

    if ( children.size() == 1 )
    {
      otherRule(root, (OpenGraphNodeEx)children.elementAt(0));
      return;
    }

    if ( children.size() == 2 )
    {
      OpenGraphNodeEx leftChild = (OpenGraphNodeEx)children.elementAt(0);
      OpenGraphNodeEx rightChild = (OpenGraphNodeEx)children.elementAt(1);

      if ( isVerbClusterNode(root) )
      {
        OpenGraphNodeEx[] ordered = orderVerbClusterChildren(leftChild, rightChild, languageTreeVerbClusterOrder);
        if ( ordered != null )
        {
          domainRule(root, ordered[0], ordered[1]);
          return;
        }
      }

      if ( !(root.getNode().isSelected()) )
      {
        domainRule(root, leftChild, rightChild);
      }
      else
      {
        /*
         * Do not mutate the actual node label during rendering.
         * Focus still affects the binary subtree ordering, but the visual
         * label is left untouched.
         */
        domainRule(root, rightChild, leftChild);
      }
      return;
    }

    nAryRule(root, children);
  }

  private static boolean isVerbClusterNode(OpenGraphNodeEx root)
  {
    String label = cleanLabel(root == null || root.getNode() == null ? null : root.getNode().getLabel());
    return label.equals("v") || label.equals("v-cluster") || label.equals("vcluster") ||
           label.equals("werkwoordgroep") || label.equals("wwgroep");
  }

  private static OpenGraphNodeEx[] orderVerbClusterChildren(OpenGraphNodeEx a,
                                                            OpenGraphNodeEx b,
                                                            String order)
  {
    int aKind = verbClusterKind(a);
    int bKind = verbClusterKind(b);
    if ( aKind == 0 || bKind == 0 || aKind == bKind )
    {
      return null;
    }

    OpenGraphNodeEx pv = aKind == 1 ? a : b;
    OpenGraphNodeEx vd = aKind == 2 ? a : b;
    if ( isVdPvOrder(order) )
    {
      return new OpenGraphNodeEx[] { vd, pv };
    }
    return new OpenGraphNodeEx[] { pv, vd };
  }

  private static boolean isVdPvOrder(String order)
  {
    if ( order == null )
    {
      return false;
    }
    String value = order.trim().toLowerCase();
    return value.equals("vd_pv") || value.equals("vd-pv") || value.equals("gebeten heeft");
  }

  /**
   * Returns 1 for PV/finite auxiliary, 2 for VD/participle, 0 if unknown.
   * The detection first checks explicit category labels and then descends into
   * terminal labels so both V->PV/VD and V->heeft/gebeten drawings work.
   */
  private static int verbClusterKind(OpenGraphNodeEx node)
  {
    String label = cleanLabel(node == null || node.getNode() == null ? null : node.getNode().getLabel());
    if ( isFiniteVerbLabel(label) ) return 1;
    if ( isParticipleLabel(label) ) return 2;

    Vector children = node == null ? null : node.getChildren();
    if ( children == null )
    {
      return 0;
    }
    int result = 0;
    for ( int i=0; i<children.size(); i++ )
    {
      int childKind = verbClusterKind((OpenGraphNodeEx)children.elementAt(i));
      if ( childKind != 0 )
      {
        if ( result != 0 && result != childKind )
        {
          return 0;
        }
        result = childKind;
      }
    }
    return result;
  }

  private static boolean isFiniteVerbLabel(String label)
  {
    if ( label == null ) return false;
    String value = label.trim().toLowerCase();
    return value.equals("pv") || value.equals("fin") || value.equals("vfin") ||
           value.equals("v-aux") || value.equals("aux") || value.equals("heeft") ||
           value.equals("heb") || value.equals("hebt") || value.equals("hebben") ||
           value.equals("had") || value.equals("is") || value.equals("zijn") ||
           value.equals("was") || value.equals("wordt") || value.equals("werd") ||
           value.equals("zal") || value.equals("kan") || value.equals("moet") ||
           value.equals("mag") || value.equals("wil");
  }

  private static boolean isParticipleLabel(String label)
  {
    if ( label == null ) return false;
    String value = label.trim().toLowerCase();
    return value.equals("vd") || value.equals("vpart") || value.equals("v-part") ||
           value.equals("part") || value.equals("vpp") || value.equals("voltooid deelwoord") ||
           value.equals("gebeten") || value.equals("gebreid") || value.equals("gegeven") ||
           (value.startsWith("ge") && value.length() > 4 && !isFiniteVerbLabel(value));
  }

  private static String cleanLabel(String label)
  {
    if ( label == null )
    {
      return "";
    }
    return label.trim().toLowerCase();
  }

  private static void initializeLeaf(OpenGraphNodeEx root)
  {
    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(0);
    root.setBoundY(0);
    root.setBoundWidth(0);
    root.setBoundHeight(0);
  }

  /**
   * Compact bottom-up box integration for the open tree.
   *
   * Each child first owns its smallest reserved bounding box.
   * The left subtree is placed completely left of the root axis;
   * the right subtree is placed completely right of the root axis and below
   * the reserved left box, so sibling leaves do not collapse onto one line.
   */
  static void domainRule(OpenGraphNodeEx root, OpenGraphNodeEx left, OpenGraphNodeEx right)
  {
    int leftShiftX = -(rightExtent(left) + ROOT_SIDE_GAP);
    int leftShiftY = 1;

    int rightShiftX = leftExtent(right) + ROOT_SIDE_GAP;
    int rightShiftY = leftShiftY + left.getBoundHeight() + 1;

    left.shiftX(leftShiftX);
    left.shiftY(leftShiftY);

    right.shiftX(rightShiftX);
    right.shiftY(rightShiftY);

    int minX = Math.min(0, Math.min(boxMinX(left), boxMinX(right)));
    int maxX = Math.max(0, Math.max(boxMaxX(left), boxMaxX(right)));
    int maxY = Math.max(0, Math.max(boxMaxY(left), boxMaxY(right)));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundX(-minX);
    root.setBoundY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
  }

  /**
   * General open-tree rule for nodes with three or more children.
   *
   * Children are processed in deterministic structural order and stacked on
   * successive grid rows below the parent.  A small horizontal spread keeps
   * the outgoing edges visually distinguishable, while the vertical stacking
   * preserves the left lexical-axis reading order used by language trees.
   */
  private static void nAryRule(OpenGraphNodeEx root, Vector children)
  {
    int currentY = 1;
    int minX = 0;
    int maxX = 0;
    int maxY = 0;
    int count = children == null ? 0 : children.size();
    int horizontalStep = ROOT_SIDE_GAP + 1;

    for ( int i=0; i<count; i++ )
    {
      OpenGraphNodeEx child = (OpenGraphNodeEx)children.elementAt(i);
      int childShiftX = ((2 * i) - (count - 1)) * horizontalStep;
      child.shiftX(childShiftX);
      child.shiftY(currentY);

      minX = Math.min(minX, boxMinX(child));
      maxX = Math.max(maxX, boxMaxX(child));
      maxY = Math.max(maxY, boxMaxY(child));

      currentY += child.getBoundHeight() + 1;
    }

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
    root.setBoundX(-minX);
    root.setBoundY(0);
  }

  /**
   * Dutch Language Tree layout convention.
   *
   * The first branching under the DS root is drawn one grid row longer.  This
   * reserves a normal grid row on the lexical axis for FIN/V2 between slot1
   * and the first real DS child row.  It replaces the earlier half-row FIN
   * placement and keeps surface-order positions visually independent of DS
   * node levels.
   */
  private static void lengthenFirstRootBranch(OpenGraphNodeEx root)
  {
    if ( root == null )
    {
      return;
    }

    Vector children = root.getChildren();
    if ( children == null || children.size() == 0 )
    {
      return;
    }

    for ( int i=0; i<children.size(); i++ )
    {
      shiftSubtreeY((OpenGraphNodeEx)children.elementAt(i), 1);
    }
    root.setBoundHeight(root.getBoundHeight() + 1);
  }

  private static void shiftSubtreeY(OpenGraphNodeEx node, int shiftY)
  {
    if ( node == null )
    {
      return;
    }

    node.shiftY(shiftY);
    Vector children = node.getChildren();
    for ( int i=0; i<children.size(); i++ )
    {
      shiftSubtreeY((OpenGraphNodeEx)children.elementAt(i), shiftY);
    }
  }

  private static void otherRule(OpenGraphNodeEx root, OpenGraphNodeEx child)
  {
    child.shiftY(1);

    int minX = Math.min(0, boxMinX(child));
    int maxX = Math.max(0, boxMaxX(child));
    int maxY = Math.max(0, boxMaxY(child));

    root.setGridX(0);
    root.setGridY(0);
    root.setBoundWidth(maxX - minX);
    root.setBoundHeight(maxY);
    root.setBoundX(-minX);
    root.setBoundY(0);
  }

  private static int leftExtent(OpenGraphNodeEx node)
  {
    return node.getBoundX();
  }

  private static int rightExtent(OpenGraphNodeEx node)
  {
    return node.getBoundWidth() - node.getBoundX();
  }

  private static int boxMinX(OpenGraphNodeEx node)
  {
    return node.getGridX() - node.getBoundX();
  }

  private static int boxMaxX(OpenGraphNodeEx node)
  {
    return node.getGridX() + node.getBoundWidth() - node.getBoundX();
  }

  private static int boxMaxY(OpenGraphNodeEx node)
  {
    return node.getGridY() + node.getBoundHeight();
  }

  private static void correctGridCoordinates(OpenGraphNodeEx root, int shiftX, int shiftY)
  {
    root.shiftX(shiftX);
    root.shiftY(shiftY);

    Vector children = root.getChildren();
    for ( int i=0; i<children.size(); i++ )
    {
      correctGridCoordinates((OpenGraphNodeEx)children.elementAt(i),
                             root.getGridX(), root.getGridY());
    }
  }
}
