# projectie-master-spec.md

## Status

- Project/chatreeks: **Mapping V4 / OpenGraphEd / Projectie**
- Actuele correctieversie: **v4300**
- Doel van deze versie: fase-2a integratie van de Greedy Graph Generator: instellingen direct in OpenGraphEd kunnen bewerken.
- Gedragswijziging in Java: nieuwe menu-items onder **OpenGraph** voor Greedy-instellingen en instellingen+genereren+laden.

Deze file is de centrale duurzame project-spec. Toekomstige projectzips horen deze file mee te leveren.

## 1. Projectdoel

OpenGraphEd ontwikkelt een notatie- en tekenomgeving waarin een taalkundige structuur niet wordt gereduceerd tot één traditionele boomtekening. De centrale gedachte is:

```text
vrije OpenGraph-bronknopen + projectieruimte = ruimte voor LEX, SYN, LF en latere projecties
```

De editor bewaart en toont een graph als bronnotatie. Tree-weergaven zijn afgeleide presentaties of didactische lagen op basis van die bron.

## 2. Belangrijke naamconventies

- GitHub-account/owner blijft: `kruin`.
- Interne Engelstalige projectnaam: **OpenGraph** / **OpenGraphEd**.
- Voor downloadpakketten geldt: gebruik de chatnaam of afgesproken downloadnaam met datum/tijd.
- Voor deze reeks is de werknaam: **Mapping V4**.

## 3. Tree-menu

De gewenste volgorde in het Tree-menu is:

```text
origineel - OpenGraph - Simple - Language - Functional - Frame - Anaphor
```

### 3.1 origineel

`origineel` toont de actuele editorboom in vrije OpenGraph-notatie.

Belangrijk: dit betekent **niet** automatisch: opnieuw laden vanaf het opgeslagen `.graph`-bestand. Als de gebruiker in de editor iets wijzigt, moet `origineel` die aangepaste versie tonen. De echte terugkeer naar een eerdere toestand gebeurt via de bestaande Back/Undo-functionaliteit.

### 3.2 OpenGraph

`OpenGraph` is een didactische laag vóór `Simple`. Deze laag toont een carrousel met screenshots en toelichtende teksten.

Doel van de carrousel:

1. eenvoudige vertakkingen tonen, eerst één level, daarna varianten;
2. projectie naar links tonen zonder projectienaam: een kale lijn met kopieën van knopen;
3. daarna stapsgewijs de projectieruimte uitbreiden;
4. de taalkundige/student laten zien waarom vrije knopen nuttig zijn.

### 3.3 Simple

`Simple` is de basiscontrole en basisuitleg van de boomlaag.

`Simple` legt voor de taalkundige/student uit waarom OpenGraphEd afwijkt van de traditionele boomtekening. Uitgangspunt:

- In traditionele syntactische bomen staan woorden vaak onderaan.
- Dat roept de vraag op: wat doen die woorden daar onderaan? Is dat een soort zwaartekracht?
- Nee: “onder” is een tekenconventie.
- De traditionele boom reconstrueert de uiting/woordvolgorde descriptief via vertakkingen en eventueel transformaties.

In de oude boomnotatie is dit structureel verschillend:

```text
S → NP VP
S → VP NP
```

De volgorde zit dus in de lokale vertakking ingebakken. In OpenGraphEd hoeft de centrale boom niet alle woordvolgorde te dragen. De LEX-projectie kan, als taklengte en projectieruimte goed verdeeld zijn, dezelfde leesvolgorde tonen als de klassieke boom, zonder dat de woorden letterlijk “onderaan” hoeven te vallen.

Daarmee worden LEX-regels een alternatief voor transformaties: niet de boom hoeft herschreven te worden, maar de lexicale projectie bepaalt de uitingsvolgorde.

### 3.4 Language

`Language` gebruikt de OpenGraph/Simple-basis voor een taalboom van het Nederlands.

Belangrijke projecties:

- **LEX**: lexicale projectie / uitingsvolgorde;
- **SYN**: syntactische categorieprojectie;
- **LF**: logical form / logische projectie.

Language werkt vanuit het principe:

```text
geen transformaties; projectie- en plaatsingsregels bepalen de zichtbare uitingsvolgorde
```

Voor Nederlands zijn onder meer relevant:

- bijzinvolgorde;
- stellende hoofdzin;
- V2 / persoonsvormpositie;
- WH-vraag;
- topicalisatie;
- V-cluster-varianten zoals `pv-VD` en `VD-pv`.

### 3.5 Functional, Frame, Anaphor

Deze onderdelen blijven voorlopig gereserveerd.

Werkafspraak:

- inhoudelijke uitwerking komt later;
- de uitleg verwijst voorlopig terug naar `Simple` en `OpenGraph`;
- latere uitbreiding mag dezelfde vrije OpenGraph-bron gebruiken en eigen projecties toevoegen.

## 4. Boomgeldigheid

Voor Tree-weergaven geldt de huidige controle:

```text
0 kindtakken  = toegestaan als eindknoop
1 kindtak     = fout
2+ kindtakken = toegestaan
```

Richting is irrelevant. De fout is dus niet “links onder rechts” of “zelfde schuine richting”, maar precies:

```text
een interne knoop mag niet precies één kindtak hebben
```

## 5. Branches-config

Alle Tree-types gebruiken dezelfde branch-configuratie per categoriale knoop:

```text
auto
2
3
4
many
```

Betekenis:

- `2`: binaire vertakking;
- `3`, `4`, `many`: n-air vertakking;
- `auto`: renderer kiest volgens de beschikbare structuur/config.

`Simple` mag dus niet meer hardcoded als uitsluitend binair worden behandeld. Binair gedrag hoort uit `Branches = 2` te komen.

## 6. Compacte layout

Tree-layout moet compact zijn:

- geen overbodige lege horizontale gridlijnen;
- geen overbodige lege verticale gridlijnen;
- recursieve box-aanpak blijft het uitgangspunt;
- elke subboom krijgt een denkbeeldige box;
- kindboxen worden compact geplaatst;
- de ouder komt erboven;
- projecties worden afgeleid uit de uiteindelijk geplaatste knopen.

## 7. Draw en editorstatus

`Draw` moet de actuele graph in de editor gebruiken.

Regel:

```text
editorwijziging → Draw ziet die wijziging
```

Draw mag dus niet stil terugvallen op de opgeslagen `.graph` van schijf. Alleen expliciete import/herlaad-acties mogen een bestand opnieuw laden.

## 8. OpenGraph-carrousel

De carrousel staat lokaal in:

```text
opengraph_carousel/
```

Bestanden worden genummerd:

```text
001-...
002-...
003-...
```

Elke afbeelding heeft een bijbehorend `.txt`-bestand met dezelfde basisnaam.

### 8.1 Functionaliteit

De carrousel ondersteunt:

- navigatie: Eerste, Vorige, Volgende, Laatste, Naar...;
- beheer: Screenshot toevoegen, Verwijder, Tekst opslaan, Ververs;
- volgorde: Plaats <, Plaats >, Verplaats..., Wissel...;
- Import carousel;
- Export carousel;
- Reminder.

Bij verplaatsen/wisselen moet de carrouselmap opnieuw opgebouwd worden, zodat oude posities geen residuen achterlaten.

### 8.2 Workflow-reminder

Na carrouselwijzigingen:

1. Controleer de carrousel in de app.
2. Gebruik **Export carousel**.
3. Upload die exportzip hier mee bij het volgende verzoek.
4. Dan kan de volgende projectzip de actuele carrouselstand meenemen.
5. De git-update blijft handwerk.

Voor git blijft de gebruiker zelf uitvoeren, bijvoorbeeld:

```bat
git status
git add .
git commit -m "Update OpenGraph carousel"
git push
```

## 9. Sources en md-bestanden

Aanbevolen voor projectbronnen/Sources:

- `projectie-master-spec.md`;
- compacte projectsource-notities zoals `Mapping_V4-26-05-23--v4298-projectsource-note.md`;
- inhoudelijke `.md`-bestanden onder `md/sources/`.

Niet aanbevolen als vaste Source:

- volledige projectzips;
- oude build-zips;
- gegenereerde `.class`, `out`, `dist`, `.jar`.

## 10. Packaging-regel voor volgende zips

Elke volgende projectzip in deze reeks moet bevatten:

```text
projectie-master-spec.md
md/projectie-master-spec.md
md-only-sources-vXXXX.zip
chatlog/CHANGELOG-vXXXX.md
```

De md-only zip moet alle relevante Markdown-bronnen bevatten, inclusief deze master-spec.

## 11. Huidige correctie v4299

v4298 miste `projectie-master-spec.md`. Dat was fout.

v4299 corrigeert dit door de master-spec toe te voegen op twee plaatsen:

```text
projectie-master-spec.md
md/projectie-master-spec.md
```

Daarnaast bevat v4299 een vernieuwde md-only sources zip waarin deze file ook is opgenomen.


## 12. Huidige uitbreiding v4300

v4300 voegt een eerste integratielaag toe voor de Greedy Graph Generator.

### 12.1 Nieuwe OpenGraph-menu-items

Onder **OpenGraph** staan nu:

```text
Greedy Generator
Open Greedy OPN
```

Betekenis:

- **Greedy Generator** start de meegeleverde externe generator in `tools/greedy_generator_gui/start_gui.bat`.
- **Open Greedy OPN** opent een bestandskiezer in de standaardoutputmap van de generator (`tools/greedy_generator_gui/output`) zodat de gebruiker de gegenereerde `.opn` direct terug in OpenGraphEd kan laden.

### 12.2 Integratiestrategie

Deze versie volgt fase 1 van de gekozen strategie:

```text
OpenGraphEd start de generator extern en gebruikt .opn als brugformaat.
```

De Python/Tkinter-generator blijft dus voorlopig intact. OpenGraphEd wordt nog niet belast met een volledige Java-port van de greedy-kern.

### 12.3 Meegeleverde generator

De map is meegeleverd als:

```text
tools/greedy_generator_gui/
```

Deze bevat onder meer:

```text
greedy_generator_gui.py
start_gui.bat
build_gui_exe.bat
spec.yaml
spec_english.yaml
GREEDY_GENERATOR_UITLEG_NL.pdf
GREEDY_GENERATOR_EXPLANATION_EN.pdf
```

### 12.4 OPN als brug

De generator schrijft `.opn` als uitvoer. OpenGraphEd kan die `.opn` laden via:

```text
OpenGraph > Open Greedy OPN
```

of via:

```text
File > Open OPN
```

Daarmee blijft de bronnotatie reproduceerbaar: de GUI/spec maakt de knopen en lijnen, en OpenGraphEd toont het resultaat als OpenGraph/OPN-graph.

### 12.5 Sources/PDF-regel

Deze projectzip bevat ook de beschikbare PDF-bronnen in:

```text
sources/pdf/
```


## 13. Huidige uitbreiding v4301

v4301 voegt een directe workflow toe bovenop v4300.

### 13.1 Nieuw menu-item

Onder **OpenGraph** staat nu ook:

```text
Generate + Load Greedy OPN
```

Betekenis:

1. OpenGraphEd start de generator headless via:

```text
tools/greedy_generator_gui/generate_default_opn.bat
```

2. De generator leest:

```text
tools/greedy_generator_gui/spec.yaml
```

3. De generator schrijft output naar:

```text
tools/greedy_generator_gui/output/
```

4. De generator schrijft een terugkoppelbestand:

```text
output/last_generated.txt
```

5. OpenGraphEd laadt de daarin genoemde `.opn` direct als graph.

### 13.2 Bestaande workflow blijft bestaan

Voor instellen en experimenteren blijft beschikbaar:

```text
OpenGraph > Greedy Generator
```

Voor handmatig laden blijft beschikbaar:

```text
OpenGraph > Open Greedy OPN
```

### 13.3 Integratiestatus

Dit is fase 1b:

```text
Python-generator blijft extern, maar OpenGraphEd kan nu direct genereren en laden.
```

De volgende inhoudelijke stap is een echte Java-port van de greedy-kern of een OpenGraphEd-dialoog die dezelfde spec-instellingen rechtstreeks in Java beheert.


## 13. Greedy Generator v4302

v4302 is de volgende integratiestap na het succesvol testen van v4301. De generator blijft technisch een meegeleverde Python-tool, maar OpenGraphEd kan nu de belangrijkste instellingen zelf bewerken.

Nieuw menu:

```text
OpenGraph
  Greedy Settings
  Settings + Generate + Load Greedy OPN
  Greedy Generator
  Generate + Load Greedy OPN
  Open Greedy OPN
```

### 13.1 Greedy Settings

`Greedy Settings` opent een Java/Swing-dialoog binnen OpenGraphEd. Deze dialoog leest en schrijft:

```text
tools/greedy_generator_gui/spec.yaml
```

Instelbaar zijn onder meer:

- projectnaam, titel en outputbasisnaam;
- `COUNT` en `MAX`;
- taal `nl` / `en`;
- gridstap X/Y, marge, hoofdlijnen, grid/assen tonen;
- `STYLE`;
- `RULE`;
- `DIAGONAL_FREE`;
- `ANGLE_MIN`;
- outputformaten `.graph`, `.opn`, `.svg`, `.png`;
- rapport en effective spec.

### 13.2 Settings + Generate + Load Greedy OPN

Deze optie opent eerst dezelfde instellingen-dialoog. Na opslaan wordt de bestaande headless-route uitgevoerd:

```text
tools/greedy_generator_gui/generate_default_opn.bat
```

Daarna laadt OpenGraphEd de laatst gegenereerde `.opn` direct in de editor.

### 13.3 Ontwerpstatus

Dit is een tussenstap:

```text
Python blijft voorlopig de greedy-kern.
OpenGraphEd beheert nu wel de spec.
.opn blijft het brugformaat.
```

De volgende inhoudelijke stap kan zijn: de greedy-kern naar Java porten, of eerst de Java-dialoog uitbreiden met preview/help.


## 12. Correctie v4303

v4302 crashte bij startup door een comma in een menu-action descriptor voor `Settings + Generate + Load Greedy OPN`. De menu-parser gebruikt comma-separated descriptors; daardoor ontstond een null-action. v4303 verwijdert de comma uit de descriptor en voegt defensieve controles toe in de menu builder.


## 15. Greedy Generator v4304

v4304 corrigeert de v4303-startupfout waarbij een bestaande placeholder in het Windows-menu werd afgewezen door de nieuwe strenge methodecontrole.

De descriptor:

```text
S,Windows,None,null,No Windows Are Open, ,true,1, 
```

heeft bewust geen `GraphController`-methode. De menu-builder accepteert nu lege methodvelden als `null`, maar controleert niet-lege methoden nog steeds streng.


## 16. Greedy Generator v4305 — taalcorrectie NL/EN

v4305 corrigeert de taalinstelling van de Greedy Generator-integratie.

Aanpassing:

```text
OpenGraphEd Greedy Settings volgt nu de taal uit spec.yaml.
Taalwijziging nl/en werkt direct op tabs, labels, knoppen, notities en helptekst.
De Python-GUI ververst de helptekst automatisch.
Engelse SVG/PNG-uitvoer gebruikt node 0 in plaats van knoop 0.
Engelse headless output schrijft een Engels rapport.
```

De generator blijft technisch hetzelfde; deze versie repareert vooral de presentatie- en documentatielaag rond `output.language`.


## 12. Greedy Generator-integratie

Vanaf v4300 is de Greedy Generator als externe tool meegeleverd onder:

```text
tools/greedy_generator_gui/
```

Integratiestappen:

- v4300: generator startbaar vanuit OpenGraphEd; `.opn` als brugformaat.
- v4301: headless genereren en direct laden van Greedy OPN.
- v4302: Greedy Settings-dialoog binnen OpenGraphEd.
- v4303/v4304: menu-parser fixes.
- v4305: NL/EN-taalwisseling in settings en generatoroutput gerepareerd.
- v4306: Greedy-output inspecteerbaar vanuit OpenGraphEd: preview PNG, rapport, effective spec, outputmap en PDF-handleiding.

De Greedy Generator blijft voorlopig extern draaien. OpenGraphEd gebruikt `.opn` als brugformaat en kan de gegenereerde OPN direct laden.


## 12. Huidige correctie v4307

v4307 voegt een expliciete Greedy-importworkflow toe aan OpenGraphEd.

Nieuwe OpenGraph-menuopties:

```text
Settings + Generate + Import Greedy OPN
Generate + Import Greedy OPN
```

Deze route genereert eerst de Greedy-output en toont daarna een result/importdialoog. De gebruiker kan daar de Preview PNG, het rapport en de effective spec openen voordat de gegenereerde `.opn` in OpenGraphEd wordt geïmporteerd.

De oudere directe laadroute blijft behouden:

```text
Settings + Generate + Load Greedy OPN
Generate + Load Greedy OPN
```

Daarmee blijven snelle tests mogelijk, terwijl de nieuwe importworkflow beter past bij `.opn` als bronformaat.


## 12. Greedy-generator integratie v4308

Vanaf v4308 bestaat naast de externe Python/Tkinter-generator ook een eerste interne Java-route.

Menu-items:

```text
OpenGraph -> Settings + Generate Internal + Import Greedy OPN
OpenGraph -> Generate Internal + Import Greedy OPN
```

Deze route leest dezelfde `tools/greedy_generator_gui/spec.yaml`, genereert de Greedy-punten intern in OpenGraphEd/Java, schrijft `.opn` en overige output naar dezelfde outputmap, en opent daarna de importworkflow.

De externe generator blijft behouden voor vergelijking, GUI-gebruik en fallback. v4308 is daarmee de eerste stap naar volledige opname van de Greedy-kern in OpenGraphEd.

## 12. Greedy Generator integratie v4300-v4309

De Greedy Generator is stapsgewijs geïntegreerd in OpenGraphEd.

Status vanaf **v4309**:

```text
interne Java-engine = standaardroute
externe Python/Tkinter-generator = GUI/fallback/debugroute
```

### 12.1 Standaardroute

De normale route in het OpenGraph-menu is:

```text
OpenGraph -> Generate + Import Greedy OPN
```

Deze route gebruikt de interne Java-engine. De engine leest:

```text
tools/greedy_generator_gui/spec.yaml
```

en schrijft output naar:

```text
tools/greedy_generator_gui/output/
```

Daarna opent OpenGraphEd de importworkflow, zodat de gebruiker eerst kan inspecteren en daarna expliciet kan importeren.

### 12.2 Instellingenroute

```text
OpenGraph -> Settings + Generate + Import Greedy OPN
```

opent eerst het Greedy Settings-venster binnen OpenGraphEd, schrijft daarna `spec.yaml`, genereert met de interne Java-engine, en opent vervolgens de importworkflow.

### 12.3 Externe fallback

De externe Python/Tkinter-generator blijft aanwezig onder:

```text
OpenGraph -> Greedy Generator GUI
OpenGraph -> Generate External + Import Greedy OPN
```

Deze route blijft nuttig voor vergelijking, debug en verdere standalone ontwikkeling.
