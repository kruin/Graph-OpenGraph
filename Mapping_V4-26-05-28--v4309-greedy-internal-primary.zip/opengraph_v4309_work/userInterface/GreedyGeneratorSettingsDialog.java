package userInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class GreedyGeneratorSettingsDialog extends JDialog
{
  public static final int RESULT_CANCEL = 0;
  public static final int RESULT_SAVE = 1;
  public static final int RESULT_SAVE_AND_GENERATE = 2;

  private final File specFile;
  private int result = RESULT_CANCEL;
  private String uiLang = "nl";

  private JTabbedPane tabs;
  private JButton saveButton;
  private JButton saveGenerateButton;
  private JButton cancelButton;

  private Hashtable labels = new Hashtable();
  private Hashtable notes = new Hashtable();
  private Hashtable buttons = new Hashtable();
  private Vector rows = new Vector();

  private JTextField projectNameField;
  private JTextField projectTitleField;
  private JTextField baseNameField;
  private JTextField outputDirField;
  private JSpinner countSpinner;
  private JSpinner maxSpinner;
  private JSpinner stepXSpinner;
  private JSpinner stepYSpinner;
  private JSpinner marginSpinner;
  private JSpinner majorSpinner;
  private JCheckBox showGridBox;
  private JCheckBox showAxesBox;
  private JComboBox styleCombo;
  private JComboBox ruleCombo;
  private JComboBox diagonalCombo;
  private JSpinner angleSpinner;
  private JComboBox languageCombo;
  private JComboBox namingCombo;
  private JCheckBox graphBox;
  private JCheckBox opnBox;
  private JCheckBox svgBox;
  private JCheckBox pngBox;
  private JCheckBox reportBox;
  private JCheckBox effectiveSpecBox;
  private JTextArea helpArea;

  public GreedyGeneratorSettingsDialog(Component owner, File specFile)
  {
    super(JOptionPane.getFrameForComponent(owner), "Greedy Generator Settings", true);
    this.specFile = specFile;
    GreedySpecValues values = readValuesFromFile();
    uiLang = cleanLanguage(values.language);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    buildUI();
    applyValues(values);
    updateLanguageTexts();
    pack();
    setMinimumSize(new Dimension(660, 590));
    setLocationRelativeTo(owner);
  }

  public int showDialog()
  {
    setVisible(true);
    return result;
  }

  private void buildUI()
  {
    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    setContentPane(root);

    tabs = new JTabbedPane();
    tabs.addTab("", createBasisPanel());
    tabs.addTab("", createGridPanel());
    tabs.addTab("", createGreedyPanel());
    tabs.addTab("", createOutputPanel());
    tabs.addTab("", createHelpPanel());
    root.add(tabs, BorderLayout.CENTER);

    JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    saveButton = new JButton();
    saveGenerateButton = new JButton();
    cancelButton = new JButton();

    saveButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { saveAndClose(RESULT_SAVE); }
    });
    saveGenerateButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { saveAndClose(RESULT_SAVE_AND_GENERATE); }
    });
    cancelButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { result = RESULT_CANCEL; dispose(); }
    });

    footer.add(saveButton);
    footer.add(saveGenerateButton);
    footer.add(cancelButton);
    root.add(footer, BorderLayout.SOUTH);
  }

  private JPanel createBasisPanel()
  {
    JPanel p = formPanel();
    projectNameField = new JTextField(24);
    projectTitleField = new JTextField(24);
    baseNameField = new JTextField(24);
    countSpinner = spinner(31, 1, 500, 1);
    maxSpinner = spinner(20, 0, 500, 1);
    languageCombo = new JComboBox(new String[] { "nl", "en" });
    languageCombo.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        uiLang = cleanLanguage(String.valueOf(languageCombo.getSelectedItem()));
        updateLanguageTexts();
      }
    });

    addRow(p, 0, "projectName", projectNameField);
    addRow(p, 1, "projectTitle", projectTitleField);
    addRow(p, 2, "baseName", baseNameField);
    addRow(p, 3, "count", countSpinner);
    addRow(p, 4, "max", maxSpinner);
    addRow(p, 5, "language", languageCombo);
    addNote(p, 6, "basisNote");
    return p;
  }

  private JPanel createGridPanel()
  {
    JPanel p = formPanel();
    stepXSpinner = spinner(20, 1, 500, 1);
    stepYSpinner = spinner(20, 1, 500, 1);
    marginSpinner = spinner(2, 0, 100, 1);
    majorSpinner = spinner(5, 1, 50, 1);
    showGridBox = new JCheckBox();
    showAxesBox = new JCheckBox();

    addRow(p, 0, "stepX", stepXSpinner);
    addRow(p, 1, "stepY", stepYSpinner);
    addRow(p, 2, "margin", marginSpinner);
    addRow(p, 3, "majorEvery", majorSpinner);
    addRow(p, 4, "showGrid", showGridBox);
    addRow(p, 5, "showAxes", showAxesBox);
    addNote(p, 6, "gridNote");
    return p;
  }

  private JPanel createGreedyPanel()
  {
    JPanel p = formPanel();
    styleCombo = new JComboBox(new String[] { "near0", "maxturn", "quadrant", "ring" });
    ruleCombo = new JComboBox(new String[] { "none", "extension", "collinear", "angle" });
    diagonalCombo = new JComboBox(new String[] { "none", "slash", "backslash", "both" });
    angleSpinner = spinner(30, 0, 89, 1);

    addRow(p, 0, "style", styleCombo);
    addRow(p, 1, "rule", ruleCombo);
    addRow(p, 2, "diagonalFree", diagonalCombo);
    addRow(p, 3, "angleMin", angleSpinner);
    addNote(p, 4, "greedyNote");
    return p;
  }

  private JPanel createOutputPanel()
  {
    JPanel p = formPanel();
    outputDirField = new JTextField(24);
    JButton browse = new JButton("...");
    browse.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { chooseOutputDirectory(); }
    });
    JPanel outDirPanel = new JPanel(new BorderLayout(4, 0));
    outDirPanel.add(outputDirField, BorderLayout.CENTER);
    outDirPanel.add(browse, BorderLayout.EAST);

    namingCombo = new JComboBox(new String[] { "short", "full" });
    graphBox = new JCheckBox(".graph", true);
    opnBox = new JCheckBox(".opn", true);
    svgBox = new JCheckBox(".svg", true);
    pngBox = new JCheckBox(".png", true);
    reportBox = new JCheckBox();
    effectiveSpecBox = new JCheckBox();

    JPanel formats = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    formats.add(graphBox);
    formats.add(opnBox);
    formats.add(svgBox);
    formats.add(pngBox);

    addRow(p, 0, "outputDir", outDirPanel);
    addRow(p, 1, "naming", namingCombo);
    addRow(p, 2, "formats", formats);
    addRow(p, 3, "report", reportBox);
    addRow(p, 4, "effectiveSpec", effectiveSpecBox);
    addNote(p, 5, "outputNote");
    return p;
  }

  private JPanel createHelpPanel()
  {
    JPanel p = new JPanel(new BorderLayout());
    helpArea = new JTextArea();
    helpArea.setEditable(false);
    helpArea.setLineWrap(true);
    helpArea.setWrapStyleWord(true);
    helpArea.setFont(UIManager.getFont("Label.font"));
    p.add(new JScrollPane(helpArea), BorderLayout.CENTER);
    return p;
  }

  private JPanel formPanel()
  {
    JPanel p = new JPanel(new GridBagLayout());
    p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    return p;
  }

  private JSpinner spinner(int value, int min, int max, int step)
  {
    return new JSpinner(new SpinnerNumberModel(value, min, max, step));
  }

  private void addRow(JPanel p, int row, String key, JComponent comp)
  {
    JLabel label = new JLabel();
    labels.put(key, label);

    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = row;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(4, 4, 4, 8);
    p.add(label, c);

    c = new GridBagConstraints();
    c.gridx = 1;
    c.gridy = row;
    c.weightx = 1.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(4, 4, 4, 4);
    p.add(comp, c);
  }

  private void addNote(JPanel p, int row, String key)
  {
    JTextArea area = new JTextArea();
    area.setEditable(false);
    area.setOpaque(false);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setFont(UIManager.getFont("Label.font"));
    notes.put(key, area);

    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 2;
    c.weightx = 1.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(12, 4, 4, 4);
    p.add(area, c);
  }

  private void updateLanguageTexts()
  {
    setTitle(t("dialogTitle"));
    tabs.setTitleAt(0, t("tabBasis"));
    tabs.setTitleAt(1, t("tabGrid"));
    tabs.setTitleAt(2, t("tabGreedy"));
    tabs.setTitleAt(3, t("tabOutput"));
    tabs.setTitleAt(4, t("tabHelp"));

    saveButton.setText(t("save"));
    saveGenerateButton.setText(t("saveGenerate"));
    cancelButton.setText(t("cancel"));

    String[] labelKeys = {
      "projectName", "projectTitle", "baseName", "count", "max", "language",
      "stepX", "stepY", "margin", "majorEvery", "showGrid", "showAxes",
      "style", "rule", "diagonalFree", "angleMin", "outputDir", "naming",
      "formats", "report", "effectiveSpec"
    };
    for ( int i=0; i<labelKeys.length; i++ )
    {
      JLabel label = (JLabel)labels.get(labelKeys[i]);
      if ( label != null ) label.setText(t(labelKeys[i]));
    }

    showGridBox.setText(t("showGridBox"));
    showAxesBox.setText(t("showAxesBox"));
    reportBox.setText(t("reportBox"));
    effectiveSpecBox.setText(t("effectiveSpecBox"));

    String[] noteKeys = { "basisNote", "gridNote", "greedyNote", "outputNote" };
    for ( int i=0; i<noteKeys.length; i++ )
    {
      JTextArea area = (JTextArea)notes.get(noteKeys[i]);
      if ( area != null ) area.setText(t(noteKeys[i]));
    }
    helpArea.setText(t("helpText"));
    helpArea.setCaretPosition(0);
  }

  private String t(String key)
  {
    boolean en = "en".equals(uiLang);

    if ( "dialogTitle".equals(key) ) return en ? "Greedy Generator Settings" : "Greedy Generator-instellingen";
    if ( "tabBasis".equals(key) ) return en ? "Basic" : "Basis";
    if ( "tabGrid".equals(key) ) return "Grid";
    if ( "tabGreedy".equals(key) ) return "Greedy";
    if ( "tabOutput".equals(key) ) return "Output";
    if ( "tabHelp".equals(key) ) return en ? "Explanation" : "Uitleg";
    if ( "save".equals(key) ) return en ? "Save Spec" : "Spec opslaan";
    if ( "saveGenerate".equals(key) ) return en ? "Save + Generate + Load" : "Opslaan + genereren + laden";
    if ( "cancel".equals(key) ) return en ? "Cancel" : "Annuleren";

    if ( "projectName".equals(key) ) return en ? "Project name" : "Projectnaam";
    if ( "projectTitle".equals(key) ) return en ? "Title" : "Titel";
    if ( "baseName".equals(key) ) return en ? "Output base name" : "Uitvoerbasisnaam";
    if ( "count".equals(key) ) return "COUNT";
    if ( "max".equals(key) ) return "MAX";
    if ( "language".equals(key) ) return en ? "Language" : "Taal";
    if ( "stepX".equals(key) ) return en ? "Grid step X" : "Gridstap X";
    if ( "stepY".equals(key) ) return en ? "Grid step Y" : "Gridstap Y";
    if ( "margin".equals(key) ) return en ? "Margin" : "Marge";
    if ( "majorEvery".equals(key) ) return en ? "Major grid every" : "Hoofdlijn elke";
    if ( "showGrid".equals(key) ) return en ? "Grid" : "Grid";
    if ( "showAxes".equals(key) ) return en ? "Axes" : "Assen";
    if ( "style".equals(key) ) return "STYLE";
    if ( "rule".equals(key) ) return "RULE";
    if ( "diagonalFree".equals(key) ) return "DIAGONAL_FREE";
    if ( "angleMin".equals(key) ) return "ANGLE_MIN";
    if ( "outputDir".equals(key) ) return en ? "Output folder" : "Outputmap";
    if ( "naming".equals(key) ) return en ? "Naming" : "Naamgeving";
    if ( "formats".equals(key) ) return en ? "Formats" : "Formaten";
    if ( "report".equals(key) ) return en ? "Report" : "Rapport";
    if ( "effectiveSpec".equals(key) ) return en ? "Effective spec" : "Effective spec";

    if ( "showGridBox".equals(key) ) return en ? "Show grid in SVG/PNG" : "Toon grid in SVG/PNG";
    if ( "showAxesBox".equals(key) ) return en ? "Show axes through node 0" : "Toon assen door knoop 0";
    if ( "reportBox".equals(key) ) return en ? "write report" : "schrijf rapport";
    if ( "effectiveSpecBox".equals(key) ) return en ? "write effective spec" : "schrijf effective spec";

    if ( "basisNote".equals(key) ) return en ?
      "COUNT=31 gives labels 0 through 30. MAX=20 means model points x,y in [-20,+20].\nThe language setting controls this dialog, the generator GUI help, report text, SVG/PNG metadata and the effective spec." :
      "COUNT=31 geeft labels 0 t/m 30. MAX=20 betekent modelpunten x,y in [-20,+20].\nDe taalinstelling stuurt deze dialoog, de generator-GUI-help, rapporttekst, SVG/PNG-metadata en de effective spec.";
    if ( "gridNote".equals(key) ) return en ?
      "The grid step determines .graph coordinates. With step 20, model point (1,0) is written 20 units to the right. SVG/PNG show the full max-grid." :
      "De gridstap bepaalt de .graph-coördinaten. Bij stap 20 wordt modelpunt (1,0) 20 eenheden naar rechts geschreven. SVG/PNG tonen het volledige max-grid.";
    if ( "greedyNote".equals(key) ) return en ?
      "STYLE decides which candidate is tried first. RULE decides what counts as forbidden straightness.\nDIAGONAL_FREE can keep /, \\ or both diagonal directions free. With angle=30, allowed angles are 30 through 150 degrees." :
      "STYLE bepaalt welke kandidaat eerst wordt geprobeerd. RULE bepaalt wat als verboden rechtheid telt.\nDIAGONAL_FREE kan ook /, \\ of beide diagonalen vrij houden. Bij angle=30 is de toegestane hoek 30 t/m 150 graden.";
    if ( "outputNote".equals(key) ) return en ?
      ".opn is the bridge format for OpenGraphEd. .graph is the older graph file. SVG/PNG are visual checks with a visible grid." :
      ".opn is het brugformaat voor OpenGraphEd. .graph is het oudere graph-bestand. SVG/PNG zijn bedoeld als zichtbare controle met grid.";
    if ( "helpText".equals(key) ) return en ? helpTextEN() : helpTextNL();

    return key;
  }

  private String helpTextNL()
  {
    return "Greedy Generator in OpenGraphEd\n\n" +
      "Deze dialoog schrijft tools/greedy_generator_gui/spec.yaml. Daarna kan OpenGraphEd de generator headless uitvoeren en de gegenereerde .opn direct laden.\n\n" +
      "Vrije knoop\n" +
      "Een vrije knoop is een bronknoop in OPN: label + gridpositie + verbindingen. De knoop is nog niet verplicht tot een klassieke boompositie zoals links, rechts of onder.\n\n" +
      "Grid\n" +
      "Alle gegenereerde knopen liggen op gridpunten. De gridstap, standaard 20, bepaalt de afstand in .graph, SVG en PNG. In OPN blijft de bron-gridpositie zelf zichtbaar.\n\n" +
      "Greedy\n" +
      "De generator sorteert alle kandidaten en neemt de eerste kandidaat die aan de harde regels voldoet. Er is geen backtracking en geen globale optimalisatie achteraf. Daarom is de graph reproduceerbaar: dezelfde spec geeft dezelfde uitkomst.\n\n" +
      "Styles\n" +
      "near0 blijft compact rond 0; maxturn zoekt grote draaihoeken; quadrant balanceert over kwadranten; ring zoekt per ring rond 0.\n\n" +
      "Rules\n" +
      "none heeft geen extra rechte-lijnfilter; extension verbiedt alleen doortrekken; collinear verbiedt dezelfde rechte drager; angle verbiedt hoeken kleiner dan ANGLE_MIN en groter dan 180-ANGLE_MIN.\n\n" +
      "Diagonal freedom\n" +
      "slash houdt /-diagonalen vrij (x+y uniek); backslash houdt \\-diagonalen vrij (x-y uniek); both eist beide.";
  }

  private String helpTextEN()
  {
    return "Greedy Generator in OpenGraphEd\n\n" +
      "This dialog writes tools/greedy_generator_gui/spec.yaml. OpenGraphEd can then run the generator headlessly and load the generated .opn directly.\n\n" +
      "Free node\n" +
      "A free node is an OPN source node: label + grid position + connections. It is not yet forced into a traditional tree position such as left, right or below.\n\n" +
      "Grid\n" +
      "All generated nodes are placed on grid points. The grid step, normally 20, determines the distance in .graph, SVG and PNG. In OPN the source-grid position itself remains visible.\n\n" +
      "Greedy\n" +
      "The generator sorts all candidates and takes the first candidate that satisfies the hard rules. There is no backtracking and no global optimization afterwards. This makes the graph reproducible: the same spec gives the same result.\n\n" +
      "Styles\n" +
      "near0 keeps the path compact around 0; maxturn prefers large turn angles; quadrant balances over quadrants; ring searches ring by ring around 0.\n\n" +
      "Rules\n" +
      "none adds no straight-line filter; extension only forbids continuing in the same direction; collinear forbids the same straight carrier line; angle forbids angles smaller than ANGLE_MIN and larger than 180-ANGLE_MIN.\n\n" +
      "Diagonal freedom\n" +
      "slash keeps / diagonals free (unique x+y); backslash keeps \\ diagonals free (unique x-y); both requires both.";
  }

  private void chooseOutputDirectory()
  {
    JFileChooser chooser = new JFileChooser();
    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    File current = new File(outputDirField.getText());
    if ( current.exists() ) chooser.setCurrentDirectory(current);
    int choice = chooser.showOpenDialog(this);
    if ( choice == JFileChooser.APPROVE_OPTION ) outputDirField.setText(chooser.getSelectedFile().getPath());
  }

  private GreedySpecValues readValuesFromFile()
  {
    GreedySpecValues values = new GreedySpecValues();
    if ( specFile != null && specFile.exists() )
    {
      try
      {
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(specFile), "UTF-8"));
        try
        {
          String section = "";
          String line;
          while ( (line = reader.readLine()) != null )
          {
            String trimmed = line.trim();
            if ( trimmed.length() == 0 || trimmed.startsWith("#") ) continue;
            if ( !line.startsWith(" ") && trimmed.endsWith(":"))
            {
              section = trimmed.substring(0, trimmed.length()-1);
              continue;
            }
            if ( trimmed.indexOf(":") < 0 ) continue;
            String key = trimmed.substring(0, trimmed.indexOf(":"));
            String value = trimmed.substring(trimmed.indexOf(":") + 1).trim();
            values.set(section, key, value);
          }
        }
        finally { reader.close(); }
      }
      catch ( Exception ignored ) {}
    }
    return values;
  }

  private void applyValues(GreedySpecValues values)
  {
    projectNameField.setText(values.projectName);
    projectTitleField.setText(values.projectTitle);
    baseNameField.setText(values.baseName);
    outputDirField.setText(values.outputDir);
    countSpinner.setValue(Integer.valueOf(values.count));
    maxSpinner.setValue(Integer.valueOf(values.max));
    stepXSpinner.setValue(Integer.valueOf(values.stepX));
    stepYSpinner.setValue(Integer.valueOf(values.stepY));
    marginSpinner.setValue(Integer.valueOf(values.margin));
    majorSpinner.setValue(Integer.valueOf(values.majorEvery));
    showGridBox.setSelected(values.showGrid);
    showAxesBox.setSelected(values.showAxes);
    styleCombo.setSelectedItem(values.style);
    ruleCombo.setSelectedItem(values.rule);
    diagonalCombo.setSelectedItem(values.diagonalFree);
    angleSpinner.setValue(Integer.valueOf(values.angleMin));
    languageCombo.setSelectedItem(cleanLanguage(values.language));
    namingCombo.setSelectedItem(values.naming);
    graphBox.setSelected(values.formatGraph);
    opnBox.setSelected(values.formatOPN);
    svgBox.setSelected(values.formatSVG);
    pngBox.setSelected(values.formatPNG);
    reportBox.setSelected(values.writeReport);
    effectiveSpecBox.setSelected(values.writeEffectiveSpec);
  }

  private String cleanLanguage(String lang)
  {
    if ( "en".equalsIgnoreCase(lang) ) return "en";
    return "nl";
  }

  private void saveAndClose(int closeResult)
  {
    try
    {
      validateValues();
      writeSpecFile();
      result = closeResult;
      dispose();
    }
    catch ( Exception e )
    {
      JOptionPane.showMessageDialog(this, e.getMessage(), en() ? "Invalid Greedy Settings" : "Ongeldige Greedy-instellingen", JOptionPane.ERROR_MESSAGE);
    }
  }

  private boolean en() { return "en".equals(uiLang); }

  private void validateValues()
  {
    int count = intValue(countSpinner);
    int max = intValue(maxSpinner);
    if ( count < 1 ) throw new IllegalArgumentException(en() ? "COUNT must be at least 1." : "COUNT moet minstens 1 zijn.");
    if ( max < 0 ) throw new IllegalArgumentException(en() ? "MAX must be at least 0." : "MAX moet minstens 0 zijn.");
    if ( count > 2 * max + 1 )
    {
      int needed = (count - 1) / 2;
      throw new IllegalArgumentException(en() ?
        ("COUNT=" + count + " does not fit MAX=" + max + ". Minimum MAX for unique x/y lines: " + needed + ".") :
        ("COUNT=" + count + " past niet bij MAX=" + max + ". Minimale MAX voor unieke x/y-lijnen: " + needed + "."));
    }
    if ( !graphBox.isSelected() && !opnBox.isSelected() && !svgBox.isSelected() && !pngBox.isSelected() )
    {
      throw new IllegalArgumentException(en() ? "Choose at least one output format." : "Kies minstens één outputformaat.");
    }
  }

  private int intValue(JSpinner spinner)
  {
    Object v = spinner.getValue();
    if ( v instanceof Number ) return ((Number)v).intValue();
    return Integer.parseInt(String.valueOf(v));
  }

  private void writeSpecFile() throws IOException
  {
    if ( specFile == null ) throw new IOException("No spec file configured.");
    File dir = specFile.getParentFile();
    if ( dir != null && !dir.exists() ) dir.mkdirs();

    if ( specFile.exists() )
    {
      File backup = new File(specFile.getParentFile(), specFile.getName() + ".bak");
      copyFile(specFile, backup);
    }

    OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(specFile), "UTF-8");
    try { writer.write(buildSpecText()); }
    finally { writer.close(); }
  }

  private void copyFile(File source, File target) throws IOException
  {
    FileInputStream in = new FileInputStream(source);
    FileOutputStream out = new FileOutputStream(target);
    try
    {
      byte[] buffer = new byte[8192];
      int read;
      while ( (read = in.read(buffer)) != -1 ) out.write(buffer, 0, read);
    }
    finally
    {
      try { in.close(); } catch ( IOException ignored ) {}
      try { out.close(); } catch ( IOException ignored ) {}
    }
  }

  private String buildSpecText()
  {
    StringBuffer b = new StringBuffer();
    b.append("project:\n");
    b.append("  name: ").append(safeYaml(projectNameField.getText())).append("\n");
    b.append("  title: ").append(safeYaml(projectTitleField.getText())).append("\n");
    b.append("  description: Greedy spec edited from OpenGraphEd\n\n");

    b.append("grid:\n");
    b.append("  step_x: ").append(intValue(stepXSpinner)).append("\n");
    b.append("  step_y: ").append(intValue(stepYSpinner)).append("\n");
    b.append("  show_grid_in_svg_png: ").append(showGridBox.isSelected()).append("\n");
    b.append("  show_axes_through_origin: ").append(showAxesBox.isSelected()).append("\n");
    b.append("  show_major_grid_every: ").append(intValue(majorSpinner)).append("\n");
    b.append("  margin: ").append(intValue(marginSpinner)).append("\n\n");

    b.append("graph:\n");
    b.append("  count: ").append(intValue(countSpinner)).append("\n");
    b.append("  max: ").append(intValue(maxSpinner)).append("\n");
    b.append("  start: [0, 0]\n\n");

    b.append("constraints:\n");
    b.append("  diagonal_free: ").append(String.valueOf(diagonalCombo.getSelectedItem())).append("\n\n");

    b.append("greedy:\n");
    b.append("  style: ").append(String.valueOf(styleCombo.getSelectedItem())).append("\n");
    b.append("  rule: ").append(String.valueOf(ruleCombo.getSelectedItem())).append("\n");
    b.append("  angle_min: ").append(intValue(angleSpinner)).append("\n\n");

    b.append("output:\n");
    b.append("  dir: ").append(safeYaml(outputDirField.getText())).append("\n");
    b.append("  base_name: ").append(safeYaml(baseNameField.getText())).append("\n");
    b.append("  formats: [").append(formatsText()).append("]\n");
    b.append("  naming: ").append(String.valueOf(namingCombo.getSelectedItem())).append("\n");
    b.append("  language: ").append(cleanLanguage(String.valueOf(languageCombo.getSelectedItem()))).append("\n");
    b.append("  write_report: ").append(reportBox.isSelected()).append("\n");
    b.append("  write_effective_spec: ").append(effectiveSpecBox.isSelected()).append("\n");
    return b.toString();
  }

  private String formatsText()
  {
    Vector parts = new Vector();
    if ( graphBox.isSelected() ) parts.add("graph");
    if ( opnBox.isSelected() ) parts.add("opn");
    if ( svgBox.isSelected() ) parts.add("svg");
    if ( pngBox.isSelected() ) parts.add("png");

    StringBuffer b = new StringBuffer();
    for ( int i=0; i<parts.size(); i++ )
    {
      if ( i > 0 ) b.append(", ");
      b.append(parts.get(i));
    }
    return b.toString();
  }

  private String safeYaml(String value)
  {
    if ( value == null ) return "";
    value = value.trim();
    if ( value.length() == 0 ) return "";
    if ( value.indexOf(':') >= 0 || value.indexOf('#') >= 0 || value.indexOf('[') >= 0 || value.indexOf(']') >= 0 )
    {
      return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
    return value;
  }

  private static class GreedySpecValues
  {
    String projectName = "space3";
    String projectTitle = "Space3 Greedy Graph";
    String baseName = "space3";
    String outputDir = "output";
    int count = 31;
    int max = 20;
    int stepX = 20;
    int stepY = 20;
    int margin = 2;
    int majorEvery = 5;
    boolean showGrid = true;
    boolean showAxes = true;
    String style = "near0";
    String rule = "collinear";
    String diagonalFree = "none";
    int angleMin = 30;
    String language = "nl";
    String naming = "short";
    boolean formatGraph = true;
    boolean formatOPN = true;
    boolean formatSVG = true;
    boolean formatPNG = true;
    boolean writeReport = true;
    boolean writeEffectiveSpec = true;

    void set(String section, String key, String value)
    {
      value = stripQuotes(value);
      if ( "project".equals(section) )
      {
        if ( "name".equals(key) ) projectName = value;
        if ( "title".equals(key) ) projectTitle = value;
      }
      else if ( "grid".equals(section) )
      {
        if ( "step_x".equals(key) ) stepX = parseInt(value, stepX);
        if ( "step_y".equals(key) ) stepY = parseInt(value, stepY);
        if ( "show_grid_in_svg_png".equals(key) ) showGrid = parseBool(value, showGrid);
        if ( "show_axes_through_origin".equals(key) ) showAxes = parseBool(value, showAxes);
        if ( "show_major_grid_every".equals(key) ) majorEvery = parseInt(value, majorEvery);
        if ( "margin".equals(key) ) margin = parseInt(value, margin);
      }
      else if ( "graph".equals(section) )
      {
        if ( "count".equals(key) ) count = parseInt(value, count);
        if ( "max".equals(key) ) max = parseInt(value, max);
      }
      else if ( "constraints".equals(section) )
      {
        if ( "diagonal_free".equals(key) ) diagonalFree = value;
      }
      else if ( "greedy".equals(section) )
      {
        if ( "style".equals(key) ) style = value;
        if ( "rule".equals(key) ) rule = value;
        if ( "angle_min".equals(key) ) angleMin = parseInt(value, angleMin);
      }
      else if ( "output".equals(section) )
      {
        if ( "dir".equals(key) ) outputDir = value;
        if ( "base_name".equals(key) ) baseName = value;
        if ( "naming".equals(key) ) naming = value;
        if ( "language".equals(key) ) language = value;
        if ( "write_report".equals(key) ) writeReport = parseBool(value, writeReport);
        if ( "write_effective_spec".equals(key) ) writeEffectiveSpec = parseBool(value, writeEffectiveSpec);
        if ( "formats".equals(key) ) parseFormats(value);
      }
    }

    private void parseFormats(String value)
    {
      formatGraph = false;
      formatOPN = false;
      formatSVG = false;
      formatPNG = false;
      value = value.replace("[", "").replace("]", "");
      String[] parts = value.split(",");
      for ( int i=0; i<parts.length; i++ )
      {
        String part = stripQuotes(parts[i].trim());
        if ( "graph".equals(part) ) formatGraph = true;
        if ( "opn".equals(part) ) formatOPN = true;
        if ( "svg".equals(part) ) formatSVG = true;
        if ( "png".equals(part) ) formatPNG = true;
      }
    }

    private static int parseInt(String value, int fallback)
    {
      try { return Integer.parseInt(value.trim()); } catch ( Exception e ) { return fallback; }
    }

    private static boolean parseBool(String value, boolean fallback)
    {
      if ( "true".equalsIgnoreCase(value) ) return true;
      if ( "false".equalsIgnoreCase(value) ) return false;
      return fallback;
    }

    private static String stripQuotes(String value)
    {
      if ( value == null ) return "";
      value = value.trim();
      if ( value.length() >= 2 && ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) )
      {
        value = value.substring(1, value.length()-1);
      }
      return value;
    }
  }
}
