
package userInterface;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;

/**
 * Internal Java implementation of the Greedy Graph generator.
 *
 * This is intentionally parallel to the bundled Python generator but writes
 * files directly from OpenGraphEd without starting Python.
 * First integration target: deterministic OPN/GRAPH/SVG/PNG/report output
 * from tools/greedy_generator_gui/spec.yaml.
 */
public class GreedyInternalGenerator
{
  private static final int NODE_NORMAL = -13369549;
  private static final int NODE_ZERO = -205;
  private static final int EDGE_COLOR = -16776961;

  private static class PointI
  {
    final int x;
    final int y;
    PointI(int x, int y) { this.x = x; this.y = y; }
    public String toString() { return "(" + x + "," + y + ")"; }
  }

  private static class Spec
  {
    String projectName = "space3";
    String projectTitle = "Space3 Greedy Graph";
    String language = "nl";
    int count = 31;
    int max = 20;
    int stepX = 20;
    int stepY = 20;
    int margin = 2;
    int majorEvery = 5;
    boolean showGrid = true;
    boolean showAxes = true;
    String style = "near0";
    String rule = "collinear";
    String diagonalFree = "none";
    int angleMin = 30;
    String outputDir = "output";
    String baseName = "space3";
    String naming = "short";
    boolean fmtGraph = true;
    boolean fmtSvg = true;
    boolean fmtPng = true;
    boolean fmtOpn = true;
    boolean writeReport = true;
    boolean writeEffectiveSpec = true;
    File specFile;
    String originalSpecText = "";
  }

  private static class Stats
  {
    int tested = 0;
    int rejectedRowCol = 0;
    int rejectedDiagonal = 0;
    int rejectedStraight = 0;
    int rejectedLine = 0;
  }

  private static class Result
  {
    Spec spec;
    java.util.List<PointI> points;
    java.util.List<PointI> mapped;
    int rows;
    int cols;
    PointI origin;
    Stats stats;
    File opnFile;
    File outputDir;
    String stem;
  }

  public static File generateFromDefaultSpec(File greedyDir) throws IOException
  {
    if ( greedyDir == null ) throw new IOException("Greedy directory is null.");
    File specFile = new File(greedyDir, "spec.yaml");
    return generateFromSpec(specFile, greedyDir).opnFile;
  }

  public static Result generateFromSpec(File specFile, File greedyDir) throws IOException
  {
    Spec spec = readSpec(specFile);
    if ( greedyDir != null && !new File(spec.outputDir).isAbsolute() )
    {
      spec.outputDir = new File(greedyDir, spec.outputDir).getPath();
    }
    validateSpec(spec);

    Result result = new Result();
    result.spec = spec;
    result.points = generatePoints(spec, result);
    validatePoints(result.points, spec);
    mapToFullGrid(result);
    result.outputDir = new File(spec.outputDir);
    if ( !result.outputDir.exists() && !result.outputDir.mkdirs() )
    {
      throw new IOException("Could not create output directory: " + result.outputDir.getPath());
    }
    result.stem = buildStem(spec);

    // Always force OPN for OpenGraphEd import.
    File opn = new File(result.outputDir, result.stem + ".opn");
    writeOPN(opn, result);
    result.opnFile = opn;

    if ( spec.fmtGraph ) writeGraph(new File(result.outputDir, result.stem + ".graph"), result);
    if ( spec.fmtSvg ) writeSVG(new File(result.outputDir, result.stem + ".svg"), result);
    if ( spec.fmtPng ) writePNG(new File(result.outputDir, result.stem + ".png"), result);
    if ( spec.writeReport ) writeReport(new File(result.outputDir, result.stem + "_report.txt"), result);
    if ( spec.writeEffectiveSpec ) writeEffectiveSpec(new File(result.outputDir, result.stem + "_effective_spec.yaml"), result);
    writeLastGenerated(new File(result.outputDir, "last_generated.txt"), result);

    return result;
  }

  private static Spec readSpec(File specFile) throws IOException
  {
    if ( specFile == null || !specFile.exists() )
    {
      throw new FileNotFoundException("Spec file not found: " + (specFile == null ? "null" : specFile.getPath()));
    }

    Spec spec = new Spec();
    spec.specFile = specFile;

    BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(specFile), "UTF-8"));
    String section = "";
    String line;
    StringBuffer original = new StringBuffer();
    while ( (line = reader.readLine()) != null )
    {
      original.append(line).append('\n');
      String stripped = stripComment(line).trim();
      if ( stripped.length() == 0 ) continue;
      if ( stripped.endsWith(":") && stripped.indexOf(':') == stripped.length() - 1 )
      {
        section = stripped.substring(0, stripped.length() - 1).trim();
        continue;
      }
      int idx = stripped.indexOf(':');
      if ( idx < 0 ) continue;
      String key = stripped.substring(0, idx).trim();
      String value = stripped.substring(idx + 1).trim();
      value = unquote(value);

      if ( "project".equals(section) )
      {
        if ( "name".equals(key) ) spec.projectName = value;
        else if ( "title".equals(key) ) spec.projectTitle = value;
      }
      else if ( "grid".equals(section) )
      {
        if ( "step_x".equals(key) ) spec.stepX = parseInt(value, spec.stepX);
        else if ( "step_y".equals(key) ) spec.stepY = parseInt(value, spec.stepY);
        else if ( "show_grid_in_svg_png".equals(key) ) spec.showGrid = parseBool(value, spec.showGrid);
        else if ( "show_axes_through_origin".equals(key) ) spec.showAxes = parseBool(value, spec.showAxes);
        else if ( "show_major_grid_every".equals(key) ) spec.majorEvery = parseInt(value, spec.majorEvery);
        else if ( "margin".equals(key) ) spec.margin = parseInt(value, spec.margin);
      }
      else if ( "graph".equals(section) )
      {
        if ( "count".equals(key) ) spec.count = parseInt(value, spec.count);
        else if ( "max".equals(key) ) spec.max = parseInt(value, spec.max);
      }
      else if ( "constraints".equals(section) )
      {
        if ( "diagonal_free".equals(key) ) spec.diagonalFree = value;
      }
      else if ( "greedy".equals(section) )
      {
        if ( "style".equals(key) ) spec.style = value;
        else if ( "rule".equals(key) ) spec.rule = value;
        else if ( "angle_min".equals(key) ) spec.angleMin = parseInt(value, spec.angleMin);
      }
      else if ( "output".equals(section) )
      {
        if ( "dir".equals(key) ) spec.outputDir = value;
        else if ( "base_name".equals(key) ) spec.baseName = value;
        else if ( "naming".equals(key) ) spec.naming = value;
        else if ( "language".equals(key) ) spec.language = value;
        else if ( "formats".equals(key) ) parseFormats(value, spec);
        else if ( "write_report".equals(key) ) spec.writeReport = parseBool(value, spec.writeReport);
        else if ( "write_effective_spec".equals(key) ) spec.writeEffectiveSpec = parseBool(value, spec.writeEffectiveSpec);
      }
    }
    reader.close();
    spec.originalSpecText = original.toString();
    return spec;
  }

  private static String stripComment(String line)
  {
    int idx = line.indexOf('#');
    if ( idx >= 0 ) return line.substring(0, idx);
    return line;
  }

  private static String unquote(String value)
  {
    if ( value == null ) return "";
    String v = value.trim();
    if ( (v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'")) )
    {
      return v.substring(1, v.length() - 1);
    }
    return v;
  }

  private static int parseInt(String value, int def)
  {
    try { return Integer.parseInt(value.trim()); } catch ( Exception e ) { return def; }
  }

  private static boolean parseBool(String value, boolean def)
  {
    if ( value == null ) return def;
    String v = value.trim().toLowerCase();
    if ( "true".equals(v) || "yes".equals(v) || "ja".equals(v) || "1".equals(v) ) return true;
    if ( "false".equals(v) || "no".equals(v) || "nee".equals(v) || "0".equals(v) ) return false;
    return def;
  }

  private static void parseFormats(String value, Spec spec)
  {
    spec.fmtGraph = false;
    spec.fmtSvg = false;
    spec.fmtPng = false;
    spec.fmtOpn = false;
    String v = value == null ? "" : value.trim();
    v = v.replace("[", "").replace("]", "");
    String[] parts = v.split(",");
    for ( int i=0; i<parts.length; i++ )
    {
      String p = parts[i].trim().toLowerCase();
      if ( "graph".equals(p) ) spec.fmtGraph = true;
      else if ( "svg".equals(p) ) spec.fmtSvg = true;
      else if ( "png".equals(p) ) spec.fmtPng = true;
      else if ( "opn".equals(p) ) spec.fmtOpn = true;
    }
  }

  private static void validateSpec(Spec spec)
  {
    if ( spec.count < 1 ) throw new IllegalArgumentException("count must be >= 1");
    if ( spec.max < 0 ) throw new IllegalArgumentException("max must be >= 0");
    if ( spec.count > 2 * spec.max + 1 )
    {
      throw new IllegalArgumentException("count=" + spec.count + " does not fit max=" + spec.max + " with unique x/y lines.");
    }
    if ( spec.stepX <= 0 || spec.stepY <= 0 ) throw new IllegalArgumentException("grid step must be > 0");
    if ( spec.majorEvery <= 0 ) spec.majorEvery = 5;
    if ( !isOneOf(spec.style, new String[] { "near0", "maxturn", "quadrant", "ring" }) )
      throw new IllegalArgumentException("Unknown style: " + spec.style);
    if ( !isOneOf(spec.rule, new String[] { "none", "extension", "collinear", "angle" }) )
      throw new IllegalArgumentException("Unknown rule: " + spec.rule);
    if ( !isOneOf(spec.diagonalFree, new String[] { "none", "slash", "backslash", "both" }) )
      throw new IllegalArgumentException("Unknown diagonal_free: " + spec.diagonalFree);
    if ( spec.angleMin < 0 || spec.angleMin >= 90 ) throw new IllegalArgumentException("angle_min must be in [0,90).");
  }

  private static boolean isOneOf(String value, String[] allowed)
  {
    for ( int i=0; i<allowed.length; i++ ) if ( allowed[i].equals(value) ) return true;
    return false;
  }

  private static java.util.List<PointI> generatePoints(Spec spec, Result result)
  {
    Stats stats = new Stats();
    result.stats = stats;
    java.util.List<PointI> points = new ArrayList<PointI>();
    points.add(new PointI(0, 0));
    HashSet<Integer> usedX = new HashSet<Integer>();
    HashSet<Integer> usedY = new HashSet<Integer>();
    HashSet<Integer> usedSlash = new HashSet<Integer>();
    HashSet<Integer> usedBackslash = new HashSet<Integer>();
    usedX.add(0); usedY.add(0); usedSlash.add(0); usedBackslash.add(0);

    java.util.List<PointI> pool = candidatePool(spec.max);

    while ( points.size() < spec.count )
    {
      final PointI prev = points.get(points.size() - 1);
      final PointI prevDir = points.size() < 2 ? null : vec(points.get(points.size() - 2), prev);
      final java.util.List<PointI> pointsForSort = points;
      Collections.sort(pool, new Comparator<PointI>()
      {
        public int compare(PointI a, PointI b)
        {
          return compareKeys(candidateKey(spec.style, a, pointsForSort, prevDir),
                             candidateKey(spec.style, b, pointsForSort, prevDir));
        }
      });

      boolean placed = false;
      for ( int i=0; i<pool.size(); i++ )
      {
        PointI p = pool.get(i);
        stats.tested++;
        if ( usedX.contains(p.x) || usedY.contains(p.y) )
        {
          stats.rejectedRowCol++;
          continue;
        }
        if ( !diagonalFree(spec.diagonalFree, p, usedSlash, usedBackslash) )
        {
          stats.rejectedDiagonal++;
          continue;
        }
        PointI newDir = vec(prev, p);
        if ( forbiddenByRule(spec.rule, prevDir, newDir, spec.angleMin) )
        {
          stats.rejectedStraight++;
          continue;
        }
        if ( !lineFree(points, p) )
        {
          stats.rejectedLine++;
          continue;
        }
        points.add(p);
        usedX.add(p.x); usedY.add(p.y); usedSlash.add(slash(p)); usedBackslash.add(backslash(p));
        placed = true;
        break;
      }
      if ( !placed )
      {
        throw new IllegalStateException("No valid candidate after " + points.size() + " nodes. Try larger max or weaker constraints.");
      }
    }
    return points;
  }

  private static java.util.List<PointI> candidatePool(int limit)
  {
    java.util.List<PointI> list = new ArrayList<PointI>();
    for ( int x=-limit; x<=limit; x++ )
      for ( int y=-limit; y<=limit; y++ )
        if ( x != 0 || y != 0 ) list.add(new PointI(x, y));
    return list;
  }

  private static double[] candidateKey(String style, PointI p, java.util.List<PointI> points, PointI prevDir)
  {
    PointI prev = points.get(points.size() - 1);
    PointI nd = vec(prev, p);
    double d0 = p.x * p.x + p.y * p.y;
    double step = nd.x * nd.x + nd.y * nd.y;
    double angle = prevDir == null ? 90.0 : angleDegrees(prevDir, nd);
    double angle90 = Math.abs(angle - 90.0);
    int q = quadrant(p);
    if ( "near0".equals(style) ) return new double[] { d0, angle90, step, q, p.y, p.x };
    if ( "maxturn".equals(style) ) return new double[] { -angle, d0, step, q, p.y, p.x };
    if ( "quadrant".equals(style) )
    {
      int[] counts = new int[] { 0, 0, 0, 0 };
      for ( int i=0; i<points.size(); i++ ) counts[quadrant(points.get(i))]++;
      int[] seq = new int[] { 0, 2, 1, 3, 0, 3, 1, 2 };
      int target = seq[(points.size() - 1) % seq.length];
      return new double[] { q == target ? 0 : 1, counts[q], d0, angle90, step, p.y, p.x };
    }
    if ( "ring".equals(style) )
    {
      int radius = Math.max(Math.abs(p.x), Math.abs(p.y));
      return new double[] { radius, step, angle90, q, p.y, p.x };
    }
    return new double[] { d0, angle90, step, q, p.y, p.x };
  }

  private static int compareKeys(double[] a, double[] b)
  {
    int n = Math.min(a.length, b.length);
    for ( int i=0; i<n; i++ )
    {
      if ( a[i] < b[i] ) return -1;
      if ( a[i] > b[i] ) return 1;
    }
    return a.length - b.length;
  }

  private static boolean diagonalFree(String mode, PointI p, Set<Integer> usedSlash, Set<Integer> usedBackslash)
  {
    if ( "none".equals(mode) ) return true;
    if ( "slash".equals(mode) ) return !usedSlash.contains(slash(p));
    if ( "backslash".equals(mode) ) return !usedBackslash.contains(backslash(p));
    if ( "both".equals(mode) ) return !usedSlash.contains(slash(p)) && !usedBackslash.contains(backslash(p));
    return true;
  }

  private static int slash(PointI p) { return p.x + p.y; }
  private static int backslash(PointI p) { return p.x - p.y; }
  private static PointI vec(PointI a, PointI b) { return new PointI(b.x - a.x, b.y - a.y); }
  private static int cross(PointI v1, PointI v2) { return v1.x * v2.y - v1.y * v2.x; }
  private static int dot(PointI v1, PointI v2) { return v1.x * v2.x + v1.y * v2.y; }
  private static boolean collinear(PointI v1, PointI v2) { return cross(v1, v2) == 0; }
  private static boolean sameDirection(PointI v1, PointI v2) { return collinear(v1, v2) && dot(v1, v2) > 0; }

  private static double angleDegrees(PointI v1, PointI v2)
  {
    double n1 = Math.hypot(v1.x, v1.y);
    double n2 = Math.hypot(v2.x, v2.y);
    if ( n1 == 0 || n2 == 0 ) return 0.0;
    double c = dot(v1, v2) / (n1 * n2);
    if ( c < -1.0 ) c = -1.0;
    if ( c > 1.0 ) c = 1.0;
    return Math.toDegrees(Math.acos(c));
  }

  private static boolean forbiddenByRule(String rule, PointI prevDir, PointI newDir, int angleMin)
  {
    if ( prevDir == null ) return false;
    if ( "none".equals(rule) ) return false;
    if ( "extension".equals(rule) ) return sameDirection(prevDir, newDir);
    if ( "collinear".equals(rule) ) return collinear(prevDir, newDir);
    if ( "angle".equals(rule) )
    {
      double angle = angleDegrees(prevDir, newDir);
      return angle < angleMin || angle > (180.0 - angleMin);
    }
    return false;
  }

  private static int quadrant(PointI p)
  {
    if ( p.x >= 0 && p.y < 0 ) return 0;
    if ( p.x < 0 && p.y < 0 ) return 1;
    if ( p.x < 0 && p.y >= 0 ) return 2;
    return 3;
  }

  private static int orient(PointI a, PointI b, PointI c)
  {
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  }

  private static boolean onSegment(PointI a, PointI b, PointI c)
  {
    return Math.min(a.x, b.x) <= c.x && c.x <= Math.max(a.x, b.x) &&
           Math.min(a.y, b.y) <= c.y && c.y <= Math.max(a.y, b.y) &&
           orient(a, b, c) == 0;
  }

  private static boolean segmentsIntersect(PointI a, PointI b, PointI c, PointI d)
  {
    int o1 = orient(a, b, c);
    int o2 = orient(a, b, d);
    int o3 = orient(c, d, a);
    int o4 = orient(c, d, b);
    if ( o1 == 0 && onSegment(a, b, c) ) return true;
    if ( o2 == 0 && onSegment(a, b, d) ) return true;
    if ( o3 == 0 && onSegment(c, d, a) ) return true;
    if ( o4 == 0 && onSegment(c, d, b) ) return true;
    return (o1 > 0) != (o2 > 0) && (o3 > 0) != (o4 > 0);
  }

  private static boolean lineFree(java.util.List<PointI> points, PointI candidate)
  {
    PointI a = points.get(points.size() - 1);
    PointI b = candidate;
    for ( int i=0; i<points.size() - 1; i++ )
    {
      if ( onSegment(a, b, points.get(i)) ) return false;
    }
    for ( int i=0; i<points.size() - 2; i++ )
    {
      if ( segmentsIntersect(a, b, points.get(i), points.get(i + 1)) ) return false;
    }
    return true;
  }

  private static void validatePoints(java.util.List<PointI> points, Spec spec)
  {
    HashSet<Integer> xs = new HashSet<Integer>();
    HashSet<Integer> ys = new HashSet<Integer>();
    HashSet<Integer> slash = new HashSet<Integer>();
    HashSet<Integer> backslash = new HashSet<Integer>();
    for ( int i=0; i<points.size(); i++ )
    {
      PointI p = points.get(i);
      if ( Math.max(Math.abs(p.x), Math.abs(p.y)) > spec.max ) throw new IllegalStateException("Point outside max: " + p);
      if ( xs.contains(p.x) ) throw new IllegalStateException("Duplicate x: " + p.x);
      if ( ys.contains(p.y) ) throw new IllegalStateException("Duplicate y: " + p.y);
      xs.add(p.x); ys.add(p.y);
      if ( ("slash".equals(spec.diagonalFree) || "both".equals(spec.diagonalFree)) && slash.contains(slash(p)) )
        throw new IllegalStateException("Duplicate slash diagonal: " + slash(p));
      if ( ("backslash".equals(spec.diagonalFree) || "both".equals(spec.diagonalFree)) && backslash.contains(backslash(p)) )
        throw new IllegalStateException("Duplicate backslash diagonal: " + backslash(p));
      slash.add(slash(p)); backslash.add(backslash(p));
    }
    for ( int i=0; i<points.size() - 1; i++ )
      for ( int j=i + 2; j<points.size() - 1; j++ )
        if ( segmentsIntersect(points.get(i), points.get(i+1), points.get(j), points.get(j+1)) )
          throw new IllegalStateException("Line crossing between " + i + " and " + j);
  }

  private static void mapToFullGrid(Result result)
  {
    Spec spec = result.spec;
    result.cols = 2 * spec.max + 1 + 2 * spec.margin;
    result.rows = 2 * spec.max + 1 + 2 * spec.margin;
    result.origin = new PointI(spec.max + spec.margin, spec.max + spec.margin);
    result.mapped = new ArrayList<PointI>();
    for ( int i=0; i<result.points.size(); i++ )
    {
      PointI p = result.points.get(i);
      result.mapped.add(new PointI(result.origin.x + p.x, result.origin.y + p.y));
    }
  }

  private static String buildStem(Spec spec)
  {
    String base = sanitize(spec.baseName.length() == 0 ? spec.projectName : spec.baseName);
    if ( "full".equals(spec.naming) )
    {
      return base + "_" + spec.style + "_" + ruleLabel(spec) + "_diag" + spec.diagonalFree +
             "_max" + spec.max + "_n" + (spec.count - 1) + "_grid" + spec.stepX + "x" + spec.stepY;
    }
    return base;
  }

  private static String sanitize(String s)
  {
    if ( s == null || s.trim().length() == 0 ) return "graph";
    return s.trim().replaceAll("\\s+", "_").replaceAll("[^A-Za-z0-9._-]", "_");
  }

  private static String ruleLabel(Spec spec)
  {
    if ( "angle".equals(spec.rule) ) return "angle" + spec.angleMin + "_" + (180 - spec.angleMin);
    return spec.rule;
  }

  private static String pipeSafe(String s)
  {
    if ( s == null ) return "";
    return s.replace('|', '/').replace('\r', ' ').replace('\n', ' ').trim();
  }

  private static void writeOPN(File file, Result r) throws IOException
  {
    Spec s = r.spec;
    PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    out.println("OPN_VERSION: 0.2");
    out.println("STRUCTURE_TYPE: GreedyGraph");
    out.println("TITLE: " + pipeSafe(s.projectTitle));
    out.println();
    out.println("# OPN pipe-safe drawable view generated by OpenGraphEd internal Greedy engine");
    out.println("# Source-grid: x=model_x+MAX, y=model_y+MAX. OpenGraphEd adds its own OPN margin when loading.");
    out.println("# max=" + s.max + "; count=" + r.points.size() + "; style=" + s.style + "; rule=" + ruleLabel(s) + "; diagonal_free=" + s.diagonalFree + "; engine=java-internal");
    out.println();
    out.println("STRUCTURE_NODES:");
    out.println("# id | label | x | y | kind");
    for ( int i=0; i<r.points.size(); i++ )
    {
      PointI p = r.points.get(i);
      out.println(String.format("n%03d | %d | %d | %d | %s", i, i, p.x + s.max, p.y + s.max, i == 0 ? "start" : "greedy-node"));
    }
    out.println();
    out.println("STRUCTURE_EDGES:");
    out.println("# from | to");
    for ( int i=0; i<r.points.size()-1; i++ ) out.println(String.format("n%03d | n%03d", i, i+1));
    out.println();
    out.println("CONSTRAINTS:");
    out.println("style | " + s.style);
    out.println("rule | " + ruleLabel(s));
    out.println("diagonal_free | " + s.diagonalFree);
    out.println("max | " + s.max);
    out.println("count | " + r.points.size());
    out.println("engine | java-internal");
    out.println("END_STRUCTURE:");
    out.close();
  }

  private static void writeGraph(File file, Result r) throws IOException
  {
    PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    out.println("");
    out.println(r.rows);
    out.println(r.spec.stepY);
    out.println(r.cols);
    out.println(r.spec.stepX);
    out.println(r.mapped.size());
    int edgeCount = r.mapped.size() - 1;
    for ( int i=0; i<r.mapped.size(); i++ )
    {
      PointI p = r.mapped.get(i);
      out.println(i+1);
      out.println(format1(p.x * r.spec.stepX));
      out.println(format1(p.y * r.spec.stepY));
      out.println(i);
      out.println(i == 0 ? NODE_ZERO : NODE_NORMAL);
      if ( i == 0 ) out.println(edgeCount > 0 ? "1" : "");
      else if ( i == edgeCount ) out.println(edgeCount);
      else out.println(i + "," + (i+1));
    }
    out.println(edgeCount);
    for ( int i=1; i<=edgeCount; i++ )
    {
      PointI a = r.mapped.get(i-1);
      PointI b = r.mapped.get(i);
      out.println(i);
      out.println(i);
      out.println(i+1);
      out.println("-1");
      out.println(format1(((a.x + b.x) / 2.0) * r.spec.stepX));
      out.println(format1(((a.y + b.y) / 2.0) * r.spec.stepY));
      out.println("false");
      out.println("false");
      out.println("false");
      out.println(EDGE_COLOR);
    }
    out.close();
  }

  private static String format1(double d)
  {
    return String.format(java.util.Locale.US, "%.1f", d);
  }

  private static void writeSVG(File file, Result r) throws IOException
  {
    int cell = 24, margin = 56, titleH = 62, metaH = 92;
    int left = margin;
    int top = margin + titleH + metaH;
    int right = left + (r.cols - 1) * cell;
    int bottom = top + (r.rows - 1) * cell;
    int width = right + margin;
    int height = bottom + margin;
    PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    out.println("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + width + "\" height=\"" + height + "\" viewBox=\"0 0 " + width + " " + height + "\">");
    out.println("<rect width=\"100%\" height=\"100%\" fill=\"white\"/>");
    out.println("<text x=\"" + margin + "\" y=\"30\" font-family=\"Arial\" font-size=\"20\" fill=\"#111\">" + xml(r.spec.projectTitle) + "</text>");
    out.println("<text x=\"" + margin + "\" y=\"52\" font-family=\"Arial\" font-size=\"14\" fill=\"#555\">" + xml(r.stem) + "</text>");
    java.util.List<String> meta = metaLines(r.spec);
    for ( int i=0; i<meta.size(); i++ ) out.println("<text x=\"" + margin + "\" y=\"" + (82+i*16) + "\" font-family=\"Arial\" font-size=\"12\" fill=\"#333\">" + xml(meta.get(i)) + "</text>");
    if ( r.spec.showGrid )
    {
      for ( int c=0; c<r.cols; c++ )
      {
        int x = left + c * cell;
        boolean major = ((c - r.origin.x) % r.spec.majorEvery) == 0;
        out.println("<line x1=\"" + x + "\" y1=\"" + top + "\" x2=\"" + x + "\" y2=\"" + bottom + "\" stroke=\"" + (major ? "#d7d7d7" : "#eeeeee") + "\" stroke-width=\"" + (major ? "1.3" : "1") + "\"/>");
      }
      for ( int rr=0; rr<r.rows; rr++ )
      {
        int y = top + rr * cell;
        boolean major = ((rr - r.origin.y) % r.spec.majorEvery) == 0;
        out.println("<line x1=\"" + left + "\" y1=\"" + y + "\" x2=\"" + right + "\" y2=\"" + y + "\" stroke=\"" + (major ? "#d7d7d7" : "#eeeeee") + "\" stroke-width=\"" + (major ? "1.3" : "1") + "\"/>");
      }
    }
    if ( r.spec.showAxes )
    {
      int ox = left + r.origin.x * cell;
      int oy = top + r.origin.y * cell;
      out.println("<line x1=\"" + ox + "\" y1=\"" + top + "\" x2=\"" + ox + "\" y2=\"" + bottom + "\" stroke=\"#c06b00\" stroke-width=\"2\"/>");
      out.println("<line x1=\"" + left + "\" y1=\"" + oy + "\" x2=\"" + right + "\" y2=\"" + oy + "\" stroke=\"#c06b00\" stroke-width=\"2\"/>");
    }
    out.println("<rect x=\"" + left + "\" y=\"" + top + "\" width=\"" + (right-left) + "\" height=\"" + (bottom-top) + "\" fill=\"none\" stroke=\"#aaa\" stroke-width=\"1.5\"/>");
    for ( int i=0; i<r.mapped.size()-1; i++ )
    {
      int x1 = left + r.mapped.get(i).x * cell, y1 = top + r.mapped.get(i).y * cell;
      int x2 = left + r.mapped.get(i+1).x * cell, y2 = top + r.mapped.get(i+1).y * cell;
      out.println("<line x1=\"" + x1 + "\" y1=\"" + y1 + "\" x2=\"" + x2 + "\" y2=\"" + y2 + "\" stroke=\"#1f5eff\" stroke-width=\"2.4\"/>");
    }
    for ( int i=0; i<r.mapped.size(); i++ )
    {
      int x = left + r.mapped.get(i).x * cell, y = top + r.mapped.get(i).y * cell;
      out.println("<circle cx=\"" + x + "\" cy=\"" + y + "\" r=\"8\" fill=\"" + (i==0 ? "#ffd348" : "#44c36a") + "\" stroke=\"#111\" stroke-width=\"1.5\"/>");
      out.println("<text x=\"" + (x+10) + "\" y=\"" + (y+4) + "\" font-family=\"Arial\" font-size=\"11\" fill=\"#111\">" + i + "</text>");
    }
    out.println("</svg>");
    out.close();
  }

  private static void writePNG(File file, Result r) throws IOException
  {
    int cell = 24, margin = 56, titleH = 62, metaH = 92;
    int left = margin;
    int top = margin + titleH + metaH;
    int right = left + (r.cols - 1) * cell;
    int bottom = top + (r.rows - 1) * cell;
    int width = right + margin;
    int height = bottom + margin;
    BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    Graphics2D g = img.createGraphics();
    g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g.setFont(new Font("Arial", Font.BOLD, 20)); g.setColor(new Color(17,17,17)); g.drawString(r.spec.projectTitle, margin, 30);
    g.setFont(new Font("Arial", Font.PLAIN, 12)); g.setColor(new Color(80,80,80)); g.drawString(r.stem, margin, 52);
    java.util.List<String> meta = metaLines(r.spec);
    g.setColor(new Color(50,50,50));
    for ( int i=0; i<meta.size(); i++ ) g.drawString(meta.get(i), margin, 82+i*16);
    if ( r.spec.showGrid )
    {
      for ( int c=0; c<r.cols; c++ )
      {
        int x = left + c * cell;
        boolean major = ((c - r.origin.x) % r.spec.majorEvery) == 0;
        g.setColor(major ? new Color(215,215,215) : new Color(238,238,238));
        g.drawLine(x, top, x, bottom);
      }
      for ( int rr=0; rr<r.rows; rr++ )
      {
        int y = top + rr * cell;
        boolean major = ((rr - r.origin.y) % r.spec.majorEvery) == 0;
        g.setColor(major ? new Color(215,215,215) : new Color(238,238,238));
        g.drawLine(left, y, right, y);
      }
    }
    if ( r.spec.showAxes )
    {
      g.setColor(new Color(192,107,0));
      g.setStroke(new BasicStroke(2));
      int ox = left + r.origin.x * cell;
      int oy = top + r.origin.y * cell;
      g.drawLine(ox, top, ox, bottom);
      g.drawLine(left, oy, right, oy);
      g.setStroke(new BasicStroke(1));
    }
    g.setColor(new Color(170,170,170)); g.drawRect(left, top, right-left, bottom-top);
    g.setColor(new Color(31,94,255)); g.setStroke(new BasicStroke(2));
    for ( int i=0; i<r.mapped.size()-1; i++ )
    {
      int x1 = left + r.mapped.get(i).x * cell, y1 = top + r.mapped.get(i).y * cell;
      int x2 = left + r.mapped.get(i+1).x * cell, y2 = top + r.mapped.get(i+1).y * cell;
      g.drawLine(x1, y1, x2, y2);
    }
    g.setStroke(new BasicStroke(1));
    g.setFont(new Font("Arial", Font.PLAIN, 11));
    for ( int i=0; i<r.mapped.size(); i++ )
    {
      int x = left + r.mapped.get(i).x * cell, y = top + r.mapped.get(i).y * cell;
      g.setColor(i==0 ? new Color(255,211,72) : new Color(68,195,106));
      g.fillOval(x-8, y-8, 16, 16);
      g.setColor(Color.BLACK); g.drawOval(x-8, y-8, 16, 16);
      g.drawString(String.valueOf(i), x+10, y+4);
    }
    g.dispose();
    ImageIO.write(img, "png", file);
  }

  private static java.util.List<String> metaLines(Spec s)
  {
    boolean en = "en".equalsIgnoreCase(s.language);
    java.util.List<String> list = new ArrayList<String>();
    list.add((en ? "labels 0 to " : "labels 0 t/m ") + (s.count - 1));
    list.add((en ? "max-grid x,y in " : "max-grid x,y in ") + "[-" + s.max + ", +" + s.max + "]");
    list.add((en ? "grid step " : "gridstap ") + s.stepX + " x " + s.stepY);
    list.add("style " + s.style);
    list.add("rule " + ruleLabel(s));
    list.add("diagonal_free " + s.diagonalFree);
    list.add("engine java-internal");
    return list;
  }

  private static String xml(String s)
  {
    if ( s == null ) return "";
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
  }

  private static void writeReport(File file, Result r) throws IOException
  {
    Spec s = r.spec;
    boolean en = "en".equalsIgnoreCase(s.language);
    int[] next = possibleNextCount(r);
    PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    out.println(en ? "Greedy internal Java generator report" : "Greedy interne Java-generator rapport");
    out.println("=====================================");
    out.println();
    out.println(en ? "Engine: java-internal OpenGraphEd" : "Engine: java-internal OpenGraphEd");
    out.println((en ? "Project: " : "Project: ") + s.projectName);
    out.println((en ? "Title: " : "Titel: ") + s.projectTitle);
    out.println();
    out.println(en ? "Grid" : "Grid");
    out.println("----");
    out.println("model window: x,y in [-" + s.max + ", +" + s.max + "]");
    out.println("graph grid: " + r.cols + " columns x " + r.rows + " rows");
    out.println("grid step: " + s.stepX + " x " + s.stepY);
    out.println("origin in graph grid: " + r.origin);
    out.println();
    out.println("Settings");
    out.println("--------");
    out.println("count: " + s.count + " labels 0.." + (s.count - 1));
    out.println("style: " + s.style);
    out.println("rule: " + ruleLabel(s));
    out.println("angle_min: " + s.angleMin);
    out.println("diagonal_free: " + s.diagonalFree);
    out.println();
    out.println("Statistics");
    out.println("----------");
    out.println("tested: " + r.stats.tested);
    out.println("rejected_rowcol: " + r.stats.rejectedRowCol);
    out.println("rejected_diagonal: " + r.stats.rejectedDiagonal);
    out.println("rejected_straight: " + r.stats.rejectedStraight);
    out.println("rejected_line: " + r.stats.rejectedLine);
    out.println("possible_next_basic: " + next[0]);
    out.println("possible_next_line_ok: " + next[1]);
    out.println("possible_next_final: " + next[2]);
    out.println();
    out.println("Coordinates");
    out.println("-----------");
    for ( int i=0; i<r.points.size(); i++ )
    {
      PointI p = r.points.get(i);
      PointI m = r.mapped.get(i);
      out.println(i + ": model=" + p + ", grid=" + m + ", graph=(" + format1(m.x*s.stepX) + ", " + format1(m.y*s.stepY) + ")");
    }
    out.close();
  }

  private static int[] possibleNextCount(Result r)
  {
    HashSet<Integer> usedX = new HashSet<Integer>();
    HashSet<Integer> usedY = new HashSet<Integer>();
    HashSet<Integer> usedSlash = new HashSet<Integer>();
    HashSet<Integer> usedBackslash = new HashSet<Integer>();
    for ( int i=0; i<r.mapped.size(); i++ )
    {
      PointI p = r.mapped.get(i);
      usedX.add(p.x); usedY.add(p.y); usedSlash.add(slash(p)); usedBackslash.add(backslash(p));
    }
    int basic = (r.cols - usedX.size()) * (r.rows - usedY.size());
    int lineOk = 0, finalOk = 0;
    if ( r.mapped.size() < 2 ) return new int[] { basic, 0, 0 };
    PointI prevDir = vec(r.mapped.get(r.mapped.size()-2), r.mapped.get(r.mapped.size()-1));
    for ( int x=0; x<r.cols; x++ ) if ( !usedX.contains(x) )
    {
      for ( int y=0; y<r.rows; y++ ) if ( !usedY.contains(y) )
      {
        PointI p = new PointI(x, y);
        if ( !diagonalFree(r.spec.diagonalFree, p, usedSlash, usedBackslash) ) continue;
        if ( !lineFree(r.mapped, p) ) continue;
        lineOk++;
        PointI nd = vec(r.mapped.get(r.mapped.size()-1), p);
        if ( !forbiddenByRule(r.spec.rule, prevDir, nd, r.spec.angleMin) ) finalOk++;
      }
    }
    return new int[] { basic, lineOk, finalOk };
  }

  private static void writeEffectiveSpec(File file, Result r) throws IOException
  {
    PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    out.println("# Effective spec written by OpenGraphEd internal Java Greedy engine");
    if ( r.spec.originalSpecText != null && r.spec.originalSpecText.trim().length() > 0 )
    {
      out.println(r.spec.originalSpecText);
    }
    else
    {
      out.println("project:");
      out.println("  name: " + r.spec.projectName);
      out.println("  title: " + r.spec.projectTitle);
      out.println("graph:");
      out.println("  count: " + r.spec.count);
      out.println("  max: " + r.spec.max);
      out.println("constraints:");
      out.println("  diagonal_free: " + r.spec.diagonalFree);
      out.println("greedy:");
      out.println("  style: " + r.spec.style);
      out.println("  rule: " + r.spec.rule);
      out.println("  angle_min: " + r.spec.angleMin);
    }
    out.close();
  }

  private static void writeLastGenerated(File file, Result r) throws IOException
  {
    PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    out.println("opn=" + r.opnFile.getAbsolutePath());
    File graph = new File(r.outputDir, r.stem + ".graph");
    File svg = new File(r.outputDir, r.stem + ".svg");
    File png = new File(r.outputDir, r.stem + ".png");
    File report = new File(r.outputDir, r.stem + "_report.txt");
    File spec = new File(r.outputDir, r.stem + "_effective_spec.yaml");
    if ( graph.exists() ) out.println("graph=" + graph.getAbsolutePath());
    if ( svg.exists() ) out.println("svg=" + svg.getAbsolutePath());
    if ( png.exists() ) out.println("png=" + png.getAbsolutePath());
    if ( report.exists() ) out.println("report=" + report.getAbsolutePath());
    if ( spec.exists() ) out.println("effective_spec=" + spec.getAbsolutePath());
    out.println("engine=java-internal");
    out.close();
  }
}
