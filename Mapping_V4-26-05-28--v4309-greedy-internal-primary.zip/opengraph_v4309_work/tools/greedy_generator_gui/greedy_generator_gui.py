#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Greedy Graph Generator GUI

Doel:
- alles instelbaar via een Windows GUI
- uitvoer: .graph, .svg, .png, rapport, effective spec
- zichtbaar volledig max-grid
- knoop 0 centraal
- knopen liggen exact op gridlijnen

Start:
    py greedy_generator_gui.py

Exe bouwen:
    build_gui_exe.bat
"""

from __future__ import annotations

import argparse
import math
import os
import re
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText

try:
    import yaml
except Exception:
    yaml = None

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = None
    ImageDraw = None
    ImageFont = None


Point = Tuple[int, int]
Vector = Tuple[int, int]

NODE_NORMAL = -13369549
NODE_ZERO = -205
EDGE_COLOR = -16776961

ALLOWED_STYLES = ["near0", "maxturn", "quadrant", "ring"]
ALLOWED_RULES = ["none", "extension", "collinear", "angle"]
ALLOWED_DIAGONAL = ["none", "slash", "backslash", "both"]
ALLOWED_LANGUAGES = ["nl", "en"]

DEFAULT_SPEC = {
    "project": {
        "name": "space3",
        "title": "Space3 Greedy Graph",
        "description": "Groeiende greedy graph op zichtbaar grid",
    },
    "grid": {
        "step_x": 20,
        "step_y": 20,
        "show_grid_in_svg_png": True,
        "show_axes_through_origin": True,
        "show_major_grid_every": 5,
        "margin": 2,
    },
    "graph": {
        "count": 31,
        "max": 20,
        "start": [0, 0],
    },
    "constraints": {
        # none | slash | backslash | both
        # slash     = diagonalen in /-richting vrij houden: x + y uniek
        # backslash = diagonalen in \\-richting vrij houden: x - y uniek
        # both      = beide diagonale richtingen vrij houden
        "diagonal_free": "none",
    },
    "greedy": {
        "style": "near0",
        "rule": "collinear",
        "angle_min": 30,
    },
    "output": {
        "dir": "output",
        "base_name": "space3",
        "formats": ["graph", "svg", "png", "opn"],
        "naming": "short",
        "write_report": True,
        "write_effective_spec": True,
        "language": "nl",
    },
}


def deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def sanitize_filename(name: str) -> str:
    name = (name or "").strip() or "graph"
    name = re.sub(r"\s+", "_", name)
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)


def dump_yaml(spec: dict) -> str:
    if yaml is None:
        import json
        return json.dumps(spec, indent=2, ensure_ascii=False)
    return yaml.safe_dump(spec, sort_keys=False, allow_unicode=True)


def load_yaml(path: Path) -> dict:
    if yaml is None:
        raise RuntimeError("PyYAML ontbreekt. Installeer met: py -m pip install pyyaml")
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError("Spec moet een YAML-object zijn.")
    return data


def escape_xml(s: str) -> str:
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def language_of(spec: dict) -> str:
    return spec.get("output", {}).get("language", "nl")


def help_text_for_language(language: str) -> str:
    if language == "en":
        return (
            "What this generator does\n"
            "------------------------\n"
            "The generator builds a growing path: 0 -> 1 -> 2 -> ... -> n. "
            "Each node is placed on a visible grid point. Every new node is connected to the previous node.\n\n"
            "Grid\n"
            "----\n"
            "The grid is the hidden basis of both OPN and GRAPH output. A model point such as (3,-2) is not a pixel position yet. "
            "It first becomes a grid position, and then the graph coordinate is grid position multiplied by the grid step. "
            "With grid step 20, one model step becomes 20 graph units.\n\n"
            "Free node\n"
            "---------\n"
            "A candidate node is free only when it does not reuse a used vertical grid line (x), does not reuse a used horizontal grid line (y), "
            "and, optionally, does not reuse one or both diagonal grid lines. For slash diagonals x+y must be unique. "
            "For backslash diagonals x-y must be unique. With both, x, y, x+y and x-y must all be unused.\n\n"
            "OPN\n"
            "---\n"
            "OPN stores a simple source-grid view: node id, label, x, y, and edges. In this generator OPN uses source-grid coordinates, "
            "so the grid remains the conceptual basis of the format.\n\n"
            "Greedy rule\n"
            "-----------\n"
            "Greedy means: sort candidates, test them, take the first valid candidate. The generator does not search for the globally best full path. "
            "Later nodes do not change earlier choices.\n\n"
            "Styles\n"
            "------\n"
            "near0 keeps the path close to node 0. maxturn prefers strong turns. quadrant balances placement over quadrants. ring grows ring by ring around 0.\n\n"
            "Straight-line rules\n"
            "-------------------\n"
            "extension forbids continuing in the same direction. collinear forbids the same straight carrier line. angle forbids near-straight moves: "
            "with angle_min 30, allowed angles are 30 to 150 degrees.\n"
        )
    return (
        "Waar gaat dit over?\n"
        "-------------------\n"
        "De generator bouwt een groeiend pad: 0 -> 1 -> 2 -> ... -> n. "
        "Elke knoop wordt op een zichtbaar gridpunt geplaatst. Elke nieuwe knoop wordt verbonden met de vorige knoop.\n\n"
        "Grid\n"
        "----\n"
        "Het grid is de verborgen basis van zowel OPN als GRAPH output. Een modelpunt zoals (3,-2) is nog geen pixelpositie. "
        "Het wordt eerst een gridpositie, en daarna wordt de graphcoördinaat gridpositie maal gridstap. "
        "Bij gridstap 20 wordt één modelstap dus 20 graph-eenheden.\n\n"
        "Vrije knoop\n"
        "------------\n"
        "Een kandidaatknoop is vrij als hij geen gebruikte verticale gridlijn (x) hergebruikt, geen gebruikte horizontale gridlijn (y) hergebruikt, "
        "en desgewenst ook geen gebruikte diagonale gridlijn hergebruikt. Voor slash-diagonalen moet x+y uniek zijn. "
        "Voor backslash-diagonalen moet x-y uniek zijn. Met both moeten x, y, x+y en x-y allemaal ongebruikt zijn.\n\n"
        "OPN\n"
        "---\n"
        "OPN bewaart een eenvoudige bron-gridweergave: node-id, label, x, y en edges. In deze generator gebruikt OPN bron-gridcoördinaten, "
        "waardoor het grid de conceptuele basis van het formaat blijft.\n\n"
        "Greedy-regel\n"
        "-------------\n"
        "Greedy betekent: sorteer kandidaten, test ze, neem de eerste geldige kandidaat. De generator zoekt niet naar het globaal beste volledige pad. "
        "Latere knopen veranderen eerdere keuzes niet.\n\n"
        "Styles\n"
        "------\n"
        "near0 houdt het pad dicht bij knoop 0. maxturn zoekt sterke bochten. quadrant balanceert de plaatsing over kwadranten. ring groeit ring voor ring rond 0.\n\n"
        "Rechte-lijn-regels\n"
        "-------------------\n"
        "extension verbiedt doorlopen in dezelfde richting. collinear verbiedt dezelfde rechte drager. angle verbiedt bijna-rechte stappen: "
        "bij angle_min 30 zijn hoeken van 30 tot 150 graden toegestaan.\n"
    )


# ---------------------------------------------------------------------------
# Meetkunde
# ---------------------------------------------------------------------------

def orient(a: Point, b: Point, c: Point) -> int:
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def on_segment(a: Point, b: Point, c: Point) -> bool:
    return (
        min(a[0], b[0]) <= c[0] <= max(a[0], b[0])
        and min(a[1], b[1]) <= c[1] <= max(a[1], b[1])
        and orient(a, b, c) == 0
    )


def segments_intersect(a: Point, b: Point, c: Point, d: Point) -> bool:
    o1 = orient(a, b, c)
    o2 = orient(a, b, d)
    o3 = orient(c, d, a)
    o4 = orient(c, d, b)

    if o1 == 0 and on_segment(a, b, c):
        return True
    if o2 == 0 and on_segment(a, b, d):
        return True
    if o3 == 0 and on_segment(c, d, a):
        return True
    if o4 == 0 and on_segment(c, d, b):
        return True

    return (o1 > 0) != (o2 > 0) and (o3 > 0) != (o4 > 0)


def cross(v1: Vector, v2: Vector) -> int:
    return v1[0] * v2[1] - v1[1] * v2[0]


def dot(v1: Vector, v2: Vector) -> int:
    return v1[0] * v2[0] + v1[1] * v2[1]


def collinear(v1: Vector, v2: Vector) -> bool:
    return cross(v1, v2) == 0


def same_direction(v1: Vector, v2: Vector) -> bool:
    return collinear(v1, v2) and dot(v1, v2) > 0


def angle_degrees(v1: Vector, v2: Vector) -> float:
    n1 = math.hypot(v1[0], v1[1])
    n2 = math.hypot(v2[0], v2[1])
    if n1 == 0 or n2 == 0:
        return 0.0
    c = max(-1.0, min(1.0, dot(v1, v2) / (n1 * n2)))
    return math.degrees(math.acos(c))


def line_free(points: List[Point], candidate: Point) -> bool:
    if not points:
        return True

    a = points[-1]
    b = candidate

    for p in points[:-1]:
        if on_segment(a, b, p):
            return False

    # Direct vorige lijn wordt overgeslagen, want die deelt het beginpunt.
    for c, d in list(zip(points, points[1:]))[:-1]:
        if segments_intersect(a, b, c, d):
            return False

    return True


# ---------------------------------------------------------------------------
# Greedy-regels
# ---------------------------------------------------------------------------

def rule_label(rule: str, angle_min: float) -> str:
    if rule == "angle":
        return f"angle{int(angle_min)}_{int(180-angle_min)}"
    return rule


def forbidden_by_rule(rule: str, prev_dir: Optional[Vector], new_dir: Vector, angle_min: float) -> bool:
    if prev_dir is None:
        return False

    if rule == "none":
        return False
    if rule == "extension":
        return same_direction(prev_dir, new_dir)
    if rule == "collinear":
        return collinear(prev_dir, new_dir)
    if rule == "angle":
        angle = angle_degrees(prev_dir, new_dir)
        return angle < angle_min or angle > (180.0 - angle_min)

    raise ValueError(f"Onbekende rule: {rule}")


def quadrant(p: Point) -> int:
    x, y = p
    if x >= 0 and y < 0:
        return 0
    if x < 0 and y < 0:
        return 1
    if x < 0 and y >= 0:
        return 2
    return 3


def candidate_pool(limit: int) -> List[Point]:
    return [
        (x, y)
        for x in range(-limit, limit + 1)
        for y in range(-limit, limit + 1)
        if (x, y) != (0, 0)
    ]


def candidate_key(style: str, p: Point, points: List[Point], prev_dir: Optional[Vector]) -> tuple:
    prev = points[-1]
    x, y = p
    new_dir = (x - prev[0], y - prev[1])

    d0 = x * x + y * y
    step_len = new_dir[0] * new_dir[0] + new_dir[1] * new_dir[1]
    q = quadrant(p)

    angle = 90.0 if prev_dir is None else angle_degrees(prev_dir, new_dir)
    angle_to_90 = abs(angle - 90.0)

    if style == "near0":
        return (d0, angle_to_90, step_len, q, y, x)

    if style == "maxturn":
        return (-angle, d0, step_len, q, y, x)

    if style == "quadrant":
        counts = [sum(1 for pt in points if quadrant(pt) == i) for i in range(4)]
        sequence = [0, 2, 1, 3, 0, 3, 1, 2]
        target = sequence[(len(points) - 1) % len(sequence)]
        return (0 if q == target else 1, counts[q], d0, angle_to_90, step_len, y, x)

    if style == "ring":
        radius = max(abs(x), abs(y))
        return (radius, step_len, angle_to_90, q, y, x)

    raise ValueError(f"Onbekende style: {style}")



def slash_diag(p: Point) -> int:
    """Visuele /-richting in scherm/gridcoördinaten: x + y constant."""
    return p[0] + p[1]


def backslash_diag(p: Point) -> int:
    """Visuele backslash-richting in scherm/gridcoördinaten: x - y constant."""
    return p[0] - p[1]


def diagonal_is_free(mode: str, p: Point, used_slash: set, used_backslash: set) -> bool:
    if mode == "none":
        return True
    if mode == "slash":
        return slash_diag(p) not in used_slash
    if mode == "backslash":
        return backslash_diag(p) not in used_backslash
    if mode == "both":
        return slash_diag(p) not in used_slash and backslash_diag(p) not in used_backslash
    raise ValueError(f"Onbekende diagonal_free instelling: {mode}")


def add_diagonal_usage(p: Point, used_slash: set, used_backslash: set) -> None:
    used_slash.add(slash_diag(p))
    used_backslash.add(backslash_diag(p))


def validate_spec(spec: dict) -> None:
    count = int(spec["graph"]["count"])
    limit = int(spec["graph"]["max"])
    step_x = int(spec["grid"]["step_x"])
    step_y = int(spec["grid"]["step_y"])
    style = spec["greedy"]["style"]
    rule = spec["greedy"]["rule"]
    angle_min = float(spec["greedy"]["angle_min"])
    formats = spec["output"]["formats"]
    diagonal_free = spec.get("constraints", {}).get("diagonal_free", "none")
    language = spec.get("output", {}).get("language", "nl")

    if count < 1:
        raise ValueError("COUNT moet minstens 1 zijn.")
    if limit < 0:
        raise ValueError("MAX moet minstens 0 zijn.")
    if count > 2 * limit + 1:
        raise ValueError(
            f"COUNT={count} past niet binnen MAX={limit} met unieke x/y-lijnen. "
            f"Minimaal nodig: MAX >= {(count - 1) // 2}."
        )
    if step_x <= 0 or step_y <= 0:
        raise ValueError("Gridstap X/Y moet groter zijn dan 0.")
    if style not in ALLOWED_STYLES:
        raise ValueError(f"STYLE moet een van {ALLOWED_STYLES} zijn.")
    if rule not in ALLOWED_RULES:
        raise ValueError(f"RULE moet een van {ALLOWED_RULES} zijn.")
    if diagonal_free not in ALLOWED_DIAGONAL:
        raise ValueError(f"DIAGONAL_FREE moet een van {ALLOWED_DIAGONAL} zijn.")
    if not (0 <= angle_min < 90):
        raise ValueError("ANGLE_MIN moet liggen in [0, 90).")
    if not formats:
        raise ValueError("Kies minstens één uitvoerformaat.")
    if language not in ALLOWED_LANGUAGES:
        raise ValueError(f"LANGUAGE moet een van {ALLOWED_LANGUAGES} zijn.")


def generate_points(spec: dict) -> Tuple[List[Point], Dict[str, int]]:
    validate_spec(spec)

    count = int(spec["graph"]["count"])
    limit = int(spec["graph"]["max"])
    style = spec["greedy"]["style"]
    rule = spec["greedy"]["rule"]
    angle_min = float(spec["greedy"]["angle_min"])

    points: List[Point] = [(0, 0)]
    used_x = {0}
    used_y = {0}
    used_slash = {slash_diag((0, 0))}
    used_backslash = {backslash_diag((0, 0))}
    diagonal_mode = spec.get("constraints", {}).get("diagonal_free", "none")
    pool = candidate_pool(limit)

    stats = {
        "tested": 0,
        "rejected_rowcol": 0,
        "rejected_diagonal": 0,
        "rejected_straight": 0,
        "rejected_line": 0,
    }

    while len(points) < count:
        prev = points[-1]
        prev_dir = None if len(points) < 2 else (
            points[-1][0] - points[-2][0],
            points[-1][1] - points[-2][1],
        )

        placed = False
        candidates = sorted(pool, key=lambda pp: candidate_key(style, pp, points, prev_dir))

        for p in candidates:
            stats["tested"] += 1
            x, y = p

            if x in used_x or y in used_y:
                stats["rejected_rowcol"] += 1
                continue

            if not diagonal_is_free(diagonal_mode, p, used_slash, used_backslash):
                stats["rejected_diagonal"] += 1
                continue

            new_dir = (x - prev[0], y - prev[1])

            if forbidden_by_rule(rule, prev_dir, new_dir, angle_min):
                stats["rejected_straight"] += 1
                continue

            if not line_free(points, p):
                stats["rejected_line"] += 1
                continue

            points.append(p)
            used_x.add(x)
            used_y.add(y)
            add_diagonal_usage(p, used_slash, used_backslash)
            placed = True
            break

        if not placed:
            raise RuntimeError(
                f"Geen geldige kandidaat na {len(points)} knopen. "
                "Probeer MAX groter, COUNT kleiner, of een minder strenge RULE/ANGLE_MIN."
            )

    validate_points(points, spec)
    return points, stats


def validate_points(points: List[Point], spec: dict) -> None:
    limit = int(spec["graph"]["max"])
    rule = spec["greedy"]["rule"]
    angle_min = float(spec["greedy"]["angle_min"])

    if len({x for x, _ in points}) != len(points):
        raise AssertionError("Dubbele x-kolom gevonden.")
    if len({y for _, y in points}) != len(points):
        raise AssertionError("Dubbele y-rij gevonden.")
    if max(max(abs(x), abs(y)) for x, y in points) > limit:
        raise AssertionError("Punt buiten MAX gevonden.")

    diagonal_mode = spec.get("constraints", {}).get("diagonal_free", "none")
    if diagonal_mode in ("slash", "both") and len({slash_diag(p) for p in points}) != len(points):
        raise AssertionError("Dubbele /-diagonaal gevonden.")
    if diagonal_mode in ("backslash", "both") and len({backslash_diag(p) for p in points}) != len(points):
        raise AssertionError("Dubbele \\-diagonaal gevonden.")

    edges = list(zip(points, points[1:]))
    for i, (a, b) in enumerate(edges):
        for j, (c, d) in enumerate(edges):
            if j <= i + 1:
                continue
            if segments_intersect(a, b, c, d):
                raise AssertionError(f"Lijn {i} kruist/raakt lijn {j}.")

    for i in range(1, len(points) - 1):
        v1 = (points[i][0] - points[i - 1][0], points[i][1] - points[i - 1][1])
        v2 = (points[i + 1][0] - points[i][0], points[i + 1][1] - points[i][1])
        if forbidden_by_rule(rule, v1, v2, angle_min):
            raise AssertionError(f"Rechte-lijn-regel geschonden bij knoop {i}.")


def map_to_grid(points: List[Point], spec: dict) -> Tuple[List[Point], int, int, Point]:
    limit = int(spec["graph"]["max"])
    margin = int(spec["grid"]["margin"])
    cols = 2 * limit + 1 + 2 * margin
    rows = 2 * limit + 1 + 2 * margin
    origin = (limit + margin, limit + margin)
    mapped = [(origin[0] + x, origin[1] + y) for x, y in points]
    return mapped, rows, cols, origin


def possible_next_count(mapped: List[Point], rows: int, cols: int, spec: dict) -> Tuple[int, int, int]:
    used_x = {x for x, _ in mapped}
    used_y = {y for _, y in mapped}
    diagonal_mode = spec.get("constraints", {}).get("diagonal_free", "none")
    used_slash = {slash_diag(p) for p in mapped}
    used_backslash = {backslash_diag(p) for p in mapped}
    basic = (cols - len(used_x)) * (rows - len(used_y))

    if len(mapped) < 2:
        return basic, 0, 0

    rule = spec["greedy"]["rule"]
    angle_min = float(spec["greedy"]["angle_min"])
    prev_dir = (mapped[-1][0] - mapped[-2][0], mapped[-1][1] - mapped[-2][1])

    line_ok = 0
    final_ok = 0
    for x in range(cols):
        if x in used_x:
            continue
        for y in range(rows):
            if y in used_y:
                continue
            p = (x, y)
            if not diagonal_is_free(diagonal_mode, p, used_slash, used_backslash):
                continue
            if not line_free(mapped, p):
                continue
            line_ok += 1
            new_dir = (x - mapped[-1][0], y - mapped[-1][1])
            if not forbidden_by_rule(rule, prev_dir, new_dir, angle_min):
                final_ok += 1

    return basic, line_ok, final_ok


# ---------------------------------------------------------------------------
# Uitvoer
# ---------------------------------------------------------------------------

def build_stem(spec: dict) -> str:
    base = sanitize_filename(spec["output"]["base_name"] or spec["project"]["name"])
    if spec["output"]["naming"] == "short":
        return base

    style = spec["greedy"]["style"]
    rule = rule_label(spec["greedy"]["rule"], float(spec["greedy"]["angle_min"]))
    limit = int(spec["graph"]["max"])
    highest = int(spec["graph"]["count"]) - 1
    sx = int(spec["grid"]["step_x"])
    sy = int(spec["grid"]["step_y"])
    return f"{base}_{style}_{rule}_max{limit}_n{highest}_grid{sx}x{sy}"



def pipe_safe(value: object) -> str:
    if value is None:
        return ""
    return str(value).replace("|", "/").replace("\r", " ").replace("\n", " ").strip()


def write_opn(path: Path, points: List[Point], spec: dict) -> None:
    """Schrijf pipe-safe OPN STRUCTURE_NODES / STRUCTURE_EDGES.

    OPN gebruikt bron-gridcoördinaten zonder marge:
      source_x = model_x + MAX
      source_y = model_y + MAX

    De OpenGraphEd OPN-loader voegt zelf OPN_PIPE_GRID_MARGIN=2 toe en gebruikt
    OPN_PIPE_GRID_CELL=20. Daardoor blijven alle knopen exact op gridlijnen.
    """
    limit = int(spec["graph"]["max"])
    style = spec["greedy"]["style"]
    rule = rule_label(spec["greedy"]["rule"], float(spec["greedy"]["angle_min"]))
    diag = spec.get("constraints", {}).get("diagonal_free", "none")
    title = spec["project"].get("title", spec["project"].get("name", "Greedy Graph"))

    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write("OPN_VERSION: 0.2\n")
        f.write("STRUCTURE_TYPE: GreedyGraph\n")
        f.write(f"TITLE: {pipe_safe(title)}\n")
        f.write("\n")
        f.write("# OPN pipe-safe drawable view generated by Greedy Graph Generator GUI\n")
        f.write("# De loader tekent STRUCTURE_NODES en STRUCTURE_EDGES.\n")
        f.write("# OPN source-grid gebruikt x=model_x+MAX, y=model_y+MAX.\n")
        f.write("# OpenGraphEd voegt bij laden zijn eigen OPN-marge toe; knopen blijven op gridlijnen.\n")
        f.write(f"# max={limit}; count={len(points)}; style={style}; rule={rule}; diagonal_free={diag}\n")
        f.write("\n")
        f.write("STRUCTURE_NODES:\n")
        f.write("# id | label | x | y | kind\n")
        for label, (x, y) in enumerate(points):
            node_id = f"n{label:03d}"
            source_x = x + limit
            source_y = y + limit
            kind = "start" if label == 0 else "greedy-node"
            f.write(f"{node_id} | {label} | {source_x} | {source_y} | {kind}\n")
        f.write("\n")
        f.write("STRUCTURE_EDGES:\n")
        f.write("# from | to\n")
        for label in range(len(points) - 1):
            f.write(f"n{label:03d} | n{label+1:03d}\n")
        f.write("\n")
        f.write("CONSTRAINTS:\n")
        f.write(f"style | {style}\n")
        f.write(f"rule | {rule}\n")
        f.write(f"diagonal_free | {diag}\n")
        f.write(f"max | {limit}\n")
        f.write(f"count | {len(points)}\n")
        f.write("END_STRUCTURE:\n")


def write_graph(path: Path, mapped: List[Point], rows: int, cols: int, spec: dict) -> None:
    step_x = int(spec["grid"]["step_x"])
    step_y = int(spec["grid"]["step_y"])
    edge_count = len(mapped) - 1
    incident = {i + 1: [] for i in range(len(mapped))}

    for edge_id in range(1, edge_count + 1):
        incident[edge_id].append(edge_id)
        incident[edge_id + 1].append(edge_id)

    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n")  # OpenGraphEd: verplichte lege eerste regel
        f.write(f"{rows}\n")
        f.write(f"{step_y}\n")
        f.write(f"{cols}\n")
        f.write(f"{step_x}\n")
        f.write(f"{len(mapped)}\n")

        for label, (gx, gy) in enumerate(mapped):
            node_id = label + 1
            color = NODE_ZERO if label == 0 else NODE_NORMAL
            f.write(f"{node_id}\n")
            f.write(f"{gx * step_x:.1f}\n")
            f.write(f"{gy * step_y:.1f}\n")
            f.write(f"{label}\n")
            f.write(f"{color}\n")
            f.write(",".join(str(e) for e in incident[node_id]) + "\n")

        f.write(f"{edge_count}\n")

        for edge_id in range(1, edge_count + 1):
            x1, y1 = mapped[edge_id - 1]
            x2, y2 = mapped[edge_id]
            f.write(f"{edge_id}\n")
            f.write(f"{edge_id}\n")
            f.write(f"{edge_id + 1}\n")
            f.write("-1\n")
            f.write(f"{((x1 + x2) / 2) * step_x:.1f}\n")
            f.write(f"{((y1 + y2) / 2) * step_y:.1f}\n")
            f.write("false\nfalse\nfalse\n")
            f.write(f"{EDGE_COLOR}\n")


def meta_lines(spec: dict) -> List[str]:
    lang = language_of(spec)
    highest = int(spec['graph']['count']) - 1
    maxv = spec['graph']['max']
    grid = f"{spec['grid']['step_x']} x {spec['grid']['step_y']}"
    rule = rule_label(spec['greedy']['rule'], float(spec['greedy']['angle_min']))
    diag = spec.get('constraints', {}).get('diagonal_free', 'none')
    if lang == "en":
        return [
            f"labels 0 to {highest}",
            f"max-grid x,y in [-{maxv}, +{maxv}]",
            f"grid step {grid}",
            f"style {spec['greedy']['style']}",
            f"rule {rule}",
            f"diagonal_free {diag}",
        ]
    return [
        f"labels 0 t/m {highest}",
        f"max-grid x,y in [-{maxv}, +{maxv}]",
        f"gridstap {grid}",
        f"style {spec['greedy']['style']}",
        f"rule {rule}",
        f"diagonal_free {diag}",
    ]



def node0_label(spec: dict) -> str:
    return "node 0" if language_of(spec) == "en" else "knoop 0"


def preview_subtitle(spec: dict) -> str:
    if language_of(spec) == "en":
        return "Preview: full max-grid, node 0 centered, all nodes on grid lines."
    return "Preview: volledig max-grid, knoop 0 centraal, alle knopen op gridlijnen."


def startup_message(spec: dict=None) -> str:
    lang = "nl" if spec is None else language_of(spec)
    if lang == "en":
        return "GUI started. Choose settings, then click Preview or Generate output."
    return "GUI gestart. Kies instellingen, klik Preview of Genereer output."

def write_svg(path: Path, mapped: List[Point], rows: int, cols: int, origin: Point, spec: dict, stem: str) -> None:
    cell = 24
    margin = 56
    title_h = 62
    meta_h = 84
    left = margin
    top = margin + title_h + meta_h
    right = left + (cols - 1) * cell
    bottom = top + (rows - 1) * cell
    width = right + margin
    height = bottom + margin

    def px(p: Point) -> Tuple[int, int]:
        return left + p[0] * cell, top + p[1] * cell

    major = int(spec["grid"]["show_major_grid_every"])
    show_grid = bool(spec["grid"]["show_grid_in_svg_png"])
    show_axes = bool(spec["grid"]["show_axes_through_origin"])

    out = []
    out.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">')
    out.append('<rect width="100%" height="100%" fill="white"/>')
    out.append(f'<text x="{margin}" y="30" font-family="Arial" font-size="20" fill="#111">{escape_xml(spec["project"]["title"])}</text>')
    out.append(f'<text x="{margin}" y="52" font-family="Arial" font-size="14" fill="#555">{escape_xml(stem)}</text>')

    for i, line in enumerate(meta_lines(spec)):
        out.append(f'<text x="{margin}" y="{82 + i*16}" font-family="Arial" font-size="12" fill="#333">{escape_xml(line)}</text>')

    if show_grid:
        for c in range(cols):
            x = left + c * cell
            is_major = ((c - origin[0]) % major == 0)
            out.append(f'<line x1="{x}" y1="{top}" x2="{x}" y2="{bottom}" stroke="{"#d7d7d7" if is_major else "#eeeeee"}" stroke-width="{"1.3" if is_major else "1"}"/>')
        for r in range(rows):
            y = top + r * cell
            is_major = ((r - origin[1]) % major == 0)
            out.append(f'<line x1="{left}" y1="{y}" x2="{right}" y2="{y}" stroke="{"#d7d7d7" if is_major else "#eeeeee"}" stroke-width="{"1.3" if is_major else "1"}"/>')

    if show_axes:
        ox = left + origin[0] * cell
        oy = top + origin[1] * cell
        out.append(f'<line x1="{ox}" y1="{top}" x2="{ox}" y2="{bottom}" stroke="#c06b00" stroke-width="2"/>')
        out.append(f'<line x1="{left}" y1="{oy}" x2="{right}" y2="{oy}" stroke="#c06b00" stroke-width="2"/>')
        out.append(f'<text x="{ox+8}" y="{top+16}" font-family="Arial" font-size="11" fill="#a35a00">x=0</text>')
        out.append(f'<text x="{left+8}" y="{oy-8}" font-family="Arial" font-size="11" fill="#a35a00">y=0</text>')

    for c in range(cols):
        mx = c - origin[0]
        if mx % major == 0:
            x = left + c * cell
            out.append(f'<text x="{x}" y="{bottom+18}" text-anchor="middle" font-family="Arial" font-size="10" fill="#666">{mx}</text>')
    for r in range(rows):
        my = r - origin[1]
        if my % major == 0:
            y = top + r * cell
            out.append(f'<text x="{left-10}" y="{y+4}" text-anchor="end" font-family="Arial" font-size="10" fill="#666">{my}</text>')

    out.append(f'<rect x="{left}" y="{top}" width="{right-left}" height="{bottom-top}" fill="none" stroke="#aaa" stroke-width="1.5"/>')

    for a, b in zip(mapped, mapped[1:]):
        x1, y1 = px(a)
        x2, y2 = px(b)
        out.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#1f5eff" stroke-width="2.4"/>')

    for label, p in enumerate(mapped):
        x, y = px(p)
        fill = "#ffd348" if label == 0 else "#44c36a"
        out.append(f'<circle cx="{x}" cy="{y}" r="8" fill="{fill}" stroke="#111" stroke-width="1.5"/>')
        out.append(f'<text x="{x+10}" y="{y+4}" font-family="Arial" font-size="11" fill="#111">{label}</text>')

    ox, oy = px(origin)
    out.append(f'<text x="{ox+12}" y="{oy-12}" font-family="Arial" font-size="11" fill="#a35a00">{escape_xml(node0_label(spec))}</text>')
    out.append("</svg>")
    path.write_text("\n".join(out), encoding="utf-8")


def write_png(path: Path, mapped: List[Point], rows: int, cols: int, origin: Point, spec: dict, stem: str) -> bool:
    if Image is None:
        return False

    cell = 24
    margin = 56
    title_h = 62
    meta_h = 84
    left = margin
    top = margin + title_h + meta_h
    right = left + (cols - 1) * cell
    bottom = top + (rows - 1) * cell
    width = right + margin
    height = bottom + margin

    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)

    try:
        font_title = ImageFont.truetype("arial.ttf", 20)
        font_small = ImageFont.truetype("arial.ttf", 12)
        font_label = ImageFont.truetype("arial.ttf", 11)
    except Exception:
        font_title = ImageFont.load_default()
        font_small = ImageFont.load_default()
        font_label = ImageFont.load_default()

    draw.text((margin, 12), spec["project"]["title"], fill=(17, 17, 17), font=font_title)
    draw.text((margin, 36), stem, fill=(80, 80, 80), font=font_small)
    for i, line in enumerate(meta_lines(spec)):
        draw.text((margin, 70 + i * 16), line, fill=(50, 50, 50), font=font_small)

    major = int(spec["grid"]["show_major_grid_every"])
    show_grid = bool(spec["grid"]["show_grid_in_svg_png"])
    show_axes = bool(spec["grid"]["show_axes_through_origin"])

    if show_grid:
        for c in range(cols):
            x = left + c * cell
            main = ((c - origin[0]) % major == 0)
            draw.line((x, top, x, bottom), fill=(215, 215, 215) if main else (238, 238, 238), width=1)
        for r in range(rows):
            y = top + r * cell
            main = ((r - origin[1]) % major == 0)
            draw.line((left, y, right, y), fill=(215, 215, 215) if main else (238, 238, 238), width=1)

    if show_axes:
        ox = left + origin[0] * cell
        oy = top + origin[1] * cell
        draw.line((ox, top, ox, bottom), fill=(192, 107, 0), width=2)
        draw.line((left, oy, right, oy), fill=(192, 107, 0), width=2)
        draw.text((ox + 8, top + 2), "x=0", fill=(163, 90, 0), font=font_small)
        draw.text((left + 8, oy - 16), "y=0", fill=(163, 90, 0), font=font_small)

    for c in range(cols):
        mx = c - origin[0]
        if mx % major == 0:
            x = left + c * cell
            draw.text((x - 7, bottom + 4), str(mx), fill=(102, 102, 102), font=font_small)
    for r in range(rows):
        my = r - origin[1]
        if my % major == 0:
            y = top + r * cell
            draw.text((left - 26, y - 6), str(my), fill=(102, 102, 102), font=font_small)

    draw.rectangle((left, top, right, bottom), outline=(170, 170, 170), width=1)

    def px(p: Point) -> Tuple[int, int]:
        return left + p[0] * cell, top + p[1] * cell

    for a, b in zip(mapped, mapped[1:]):
        draw.line((*px(a), *px(b)), fill=(31, 94, 255), width=2)

    for label, p in enumerate(mapped):
        x, y = px(p)
        fill = (255, 211, 72) if label == 0 else (68, 195, 106)
        draw.ellipse((x - 8, y - 8, x + 8, y + 8), fill=fill, outline=(17, 17, 17), width=1)
        draw.text((x + 10, y - 6), str(label), fill=(17, 17, 17), font=font_label)

    ox, oy = px(origin)
    draw.text((ox + 12, oy - 18), node0_label(spec), fill=(163, 90, 0), font=font_small)

    img.save(path)
    return True


def write_report(path: Path, spec: dict, points: List[Point], mapped: List[Point], rows: int, cols: int, origin: Point, stats: Dict[str, int]) -> None:
    basic, line_ok, final_ok = possible_next_count(mapped, rows, cols, spec)
    sx = int(spec["grid"]["step_x"])
    sy = int(spec["grid"]["step_y"])
    lang = language_of(spec)
    limit = int(spec["graph"]["max"])
    highest = int(spec['graph']['count']) - 1
    diag = spec.get('constraints', {}).get('diagonal_free', 'none')
    lines = []

    if lang == "en":
        lines += [
            "Greedy Graph GUI report",
            "=======================",
            "",
            "What is this about?",
            "-------------------",
            f"This graph grows from node 0 to node {highest}.",
            "Every node is exactly on a grid point.",
            "The graph uses the full max-grid as a visible model window.",
            "",
            "Grid",
            "----",
            f"model window: x,y in [-{limit}, +{limit}]",
            f"grid in .graph: {cols} columns x {rows} rows",
            f"grid step: {sx} x {sy}",
            f"model origin 0,0 in grid: {origin}",
            "",
            "Settings",
            "--------",
            f"COUNT: {spec['graph']['count']} labels 0 to {highest}",
            f"MAX: {spec['graph']['max']}",
            f"STYLE: {spec['greedy']['style']}",
            f"RULE: {rule_label(spec['greedy']['rule'], float(spec['greedy']['angle_min']))}",
            f"ANGLE_MIN: {spec['greedy']['angle_min']}",
            f"DIAGONAL_FREE: {diag}",
            "",
            "Statistics",
            "----------",
            f"candidates tested: {stats['tested']}",
            f"rejected by duplicate x/y: {stats['rejected_rowcol']}",
            f"rejected by diagonal freedom: {stats.get('rejected_diagonal', 0)}",
            f"rejected by straight-line rule: {stats['rejected_straight']}",
            f"rejected by line crossing/touching: {stats['rejected_line']}",
            f"possible next places, basic: {basic}",
            f"possible next places, line-free: {line_ok}",
            f"possible next places, final: {final_ok}",
            "",
            "Coordinates",
            "-----------",
            "OPN source-grid: x=model_x+MAX, y=model_y+MAX. OpenGraphEd adds its own margin when loading OPN.",
        ]
    else:
        lines += [
            "Greedy Graph GUI rapport",
            "=======================",
            "",
            "Waar gaat dit over?",
            "-------------------",
            f"Deze graph groeit van knoop 0 naar knoop {highest}.",
            "Elke knoop ligt exact op een gridpunt.",
            "De graph gebruikt het volledige max-grid als zichtbaar modelvenster.",
            "",
            "Grid",
            "----",
            f"modelvenster: x,y in [-{limit}, +{limit}]",
            f"grid in .graph: {cols} kolommen x {rows} rijen",
            f"gridstap: {sx} x {sy}",
            f"modeloorsprong 0,0 in grid: {origin}",
            "",
            "Instellingen",
            "------------",
            f"COUNT: {spec['graph']['count']} labels 0 t/m {highest}",
            f"MAX: {spec['graph']['max']}",
            f"STYLE: {spec['greedy']['style']}",
            f"RULE: {rule_label(spec['greedy']['rule'], float(spec['greedy']['angle_min']))}",
            f"ANGLE_MIN: {spec['greedy']['angle_min']}",
            f"DIAGONAL_FREE: {diag}",
            "",
            "Statistiek",
            "----------",
            f"kandidaten getest: {stats['tested']}",
            f"afgewezen door dubbele x/y: {stats['rejected_rowcol']}",
            f"afgewezen door diagonale vrijheid: {stats.get('rejected_diagonal', 0)}",
            f"afgewezen door rechte-lijn-regel: {stats['rejected_straight']}",
            f"afgewezen door lijnkruising/raking: {stats['rejected_line']}",
            f"mogelijke volgende plekken, basis: {basic}",
            f"mogelijke volgende plekken, na lijnvrij: {line_ok}",
            f"mogelijke volgende plekken, na alle regels: {final_ok}",
            "",
            "Coördinaten",
            "-----------",
            "OPN source-grid: x=model_x+MAX, y=model_y+MAX. OpenGraphEd voegt bij OPN-laden eigen marge toe.",
        ]

    for label, p in enumerate(points):
        gx, gy = mapped[label]
        opn_source = (p[0] + limit, p[1] + limit)
        lines.append(f"{label}: model={p}, grid={mapped[label]}, graph=({gx*sx:.1f}, {gy*sy:.1f}), opn_source={opn_source}")

    path.write_text("\n".join(lines), encoding="utf-8")


def generate_outputs(spec: dict) -> Dict[str, object]:
    points, stats = generate_points(spec)
    mapped, rows, cols, origin = map_to_grid(points, spec)
    outdir = Path(spec["output"]["dir"])
    outdir.mkdir(parents=True, exist_ok=True)
    stem = build_stem(spec)

    files = []
    opn_file = None
    formats = spec["output"]["formats"]

    if "graph" in formats:
        path = outdir / f"{stem}.graph"
        write_graph(path, mapped, rows, cols, spec)
        files.append(path)
    if "opn" in formats:
        path = outdir / f"{stem}.opn"
        write_opn(path, points, spec)
        files.append(path)
        opn_file = path
    if "svg" in formats:
        path = outdir / f"{stem}.svg"
        write_svg(path, mapped, rows, cols, origin, spec, stem)
        files.append(path)
    if "png" in formats:
        path = outdir / f"{stem}.png"
        if write_png(path, mapped, rows, cols, origin, spec, stem):
            files.append(path)

    if spec["output"]["write_report"]:
        path = outdir / f"{stem}_report.txt"
        write_report(path, spec, points, mapped, rows, cols, origin, stats)
        files.append(path)

    if spec["output"]["write_effective_spec"]:
        path = outdir / f"{stem}_effective_spec.yaml"
        path.write_text(dump_yaml(spec), encoding="utf-8")
        files.append(path)

    return {
        "points": points,
        "mapped": mapped,
        "rows": rows,
        "cols": cols,
        "origin": origin,
        "stats": stats,
        "files": files,
        "opn_file": opn_file,
        "stem": stem,
    }


def load_effective_spec(spec_path: Path) -> dict:
    spec_path = Path(spec_path)
    raw = load_yaml(spec_path)
    return deep_merge(DEFAULT_SPEC, raw)


def write_last_generated_info(outdir: Path, result: Dict[str, object]) -> None:
    files = result.get("files", [])
    opn_file = result.get("opn_file")
    lines = [
        f"stem={result.get('stem', '')}",
        f"opn={Path(opn_file).resolve() if opn_file else ''}",
        "files=" + ";".join(str(Path(f).resolve()) for f in files),
    ]
    Path(outdir).mkdir(parents=True, exist_ok=True)
    (Path(outdir) / "last_generated.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def generate_from_spec_path(spec_path: Path, force_opn: bool = False) -> Dict[str, object]:
    spec = load_effective_spec(Path(spec_path))
    if force_opn and "opn" not in spec["output"].get("formats", []):
        spec["output"]["formats"] = list(spec["output"].get("formats", [])) + ["opn"]
    result = generate_outputs(spec)
    write_last_generated_info(Path(spec["output"]["dir"]), result)
    return result


def cli_main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Greedy Graph Generator GUI/headless generator")
    parser.add_argument("--generate", action="store_true", help="run headless generation instead of opening the GUI")
    parser.add_argument("--force-opn", action="store_true", help="ensure .opn is written, even if omitted in the spec")
    parser.add_argument("spec", nargs="?", default="spec.yaml", help="spec YAML file; default: spec.yaml")
    args = parser.parse_args(argv)

    if args.generate:
        result = generate_from_spec_path(Path(args.spec), force_opn=args.force_opn)
        print("OK Greedy generation")
        print("stem=" + str(result.get("stem", "")))
        opn_file = result.get("opn_file")
        if opn_file:
            print("opn=" + str(Path(opn_file).resolve()))
        print("files=" + str(len(result.get("files", []))))
        return 0

    app = App()
    app.mainloop()
    return 0


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Greedy Graph Generator GUI")
        self.geometry("1280x820")
        self.minsize(1100, 700)
        self.spec_path: Optional[Path] = None

        self._vars()
        self._layout()
        self.load_spec(DEFAULT_SPEC)
        self.refresh_help()
        self.log(startup_message(DEFAULT_SPEC))

    def _vars(self):
        self.project_name = tk.StringVar()
        self.project_title = tk.StringVar()
        self.language = tk.StringVar()
        self.count = tk.IntVar()
        self.maxv = tk.IntVar()
        self.step_x = tk.IntVar()
        self.step_y = tk.IntVar()
        self.margin = tk.IntVar()
        self.major = tk.IntVar()
        self.show_grid = tk.BooleanVar()
        self.show_axes = tk.BooleanVar()
        self.style = tk.StringVar()
        self.rule = tk.StringVar()
        self.diagonal_free = tk.StringVar()
        self.angle = tk.DoubleVar()
        self.output_dir = tk.StringVar()
        self.base_name = tk.StringVar()
        self.naming = tk.StringVar()
        self.f_graph = tk.BooleanVar()
        self.f_svg = tk.BooleanVar()
        self.f_png = tk.BooleanVar()
        self.f_opn = tk.BooleanVar()
        self.write_report = tk.BooleanVar()
        self.write_effective = tk.BooleanVar()

    def _layout(self):
        self.columnconfigure(0, weight=0)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        left = ttk.Frame(self, padding=10)
        left.grid(row=0, column=0, sticky="ns")
        right = ttk.Frame(self, padding=(0, 10, 10, 10))
        right.grid(row=0, column=1, sticky="nsew")
        right.rowconfigure(0, weight=1)
        right.rowconfigure(1, weight=0)
        right.columnconfigure(0, weight=1)

        self._controls(left)
        self._preview(right)

    def _controls(self, parent):
        nb = ttk.Notebook(parent)
        nb.pack(fill="both", expand=True)

        tabs = {}
        for name in ["Basis", "Grid", "Greedy", "Output", "Spec", "Uitleg/Help"]:
            frame = ttk.Frame(nb, padding=10)
            nb.add(frame, text=name)
            tabs[name] = frame

        self._entry(tabs["Basis"], 0, "Projectnaam", self.project_name)
        self._entry(tabs["Basis"], 1, "Titel", self.project_title)
        self._combo(tabs["Basis"], 2, "Taal / Language", self.language, ALLOWED_LANGUAGES)
        try:
            self.language.trace_add("write", lambda *args: self.refresh_help())
        except Exception:
            pass
        self._spin(tabs["Basis"], 3, "COUNT", self.count, 1, 500)
        self._spin(tabs["Basis"], 4, "MAX", self.maxv, 0, 500)
        ttk.Label(tabs["Basis"], text="COUNT=31 geeft labels 0 t/m 30.\nMAX=20 geeft x,y in [-20,+20].\nTaal bepaalt rapport/SVG/PNG metadata en Help-tab.", foreground="#444").grid(row=5, column=0, columnspan=3, sticky="w", pady=10)

        self._spin(tabs["Grid"], 0, "Gridstap X", self.step_x, 1, 500)
        self._spin(tabs["Grid"], 1, "Gridstap Y", self.step_y, 1, 500)
        self._spin(tabs["Grid"], 2, "Marge", self.margin, 0, 100)
        self._spin(tabs["Grid"], 3, "Hoofdlijn elke", self.major, 1, 50)
        ttk.Checkbutton(tabs["Grid"], text="Toon grid in SVG/PNG", variable=self.show_grid).grid(row=4, column=1, sticky="w")
        ttk.Checkbutton(tabs["Grid"], text="Toon assen door knoop 0", variable=self.show_axes).grid(row=5, column=1, sticky="w")
        ttk.Label(tabs["Grid"], text="De GUI toont altijd het volledige max-grid.\nKnoop 0 staat centraal.", foreground="#444").grid(row=6, column=0, columnspan=3, sticky="w", pady=10)

        self._combo(tabs["Greedy"], 0, "STYLE", self.style, ALLOWED_STYLES)
        self._combo(tabs["Greedy"], 1, "RULE", self.rule, ALLOWED_RULES)
        self._combo(tabs["Greedy"], 2, "DIAGONAL_FREE", self.diagonal_free, ALLOWED_DIAGONAL)
        self._spin_float(tabs["Greedy"], 3, "ANGLE_MIN", self.angle, 0, 89)
        explain = (
            "STYLE\n"
            "near0: dicht bij 0\n"
            "maxturn: grootste draai\n"
            "quadrant: kwadrantbalans\n"
            "ring: ring rond 0\n\n"
            "RULE\n"
            "none: geen filter\n"
            "extension: alleen verlengde verboden\n"
            "collinear: rechte drager verboden\n"
            "angle: hoek tussen ANGLE_MIN en 180-ANGLE_MIN\n\n"
            "DIAGONAL_FREE\n"
            "none: geen diagonale vrijheid\n"
            "slash: /-diagonaal vrij houden, x+y uniek\n"
            "backslash: \\-diagonaal vrij houden, x-y uniek\n"
            "both: beide richtingen vrij houden"
        )
        ttk.Label(tabs["Greedy"], text=explain, foreground="#444").grid(row=4, column=0, columnspan=3, sticky="w", pady=10)

        self._entry(tabs["Output"], 0, "Outputmap", self.output_dir, browse=True)
        self._entry(tabs["Output"], 1, "Bestandsnaam", self.base_name)
        self._combo(tabs["Output"], 2, "Naamgeving", self.naming, ["short", "full"])
        ttk.Label(tabs["Output"], text="Formaten").grid(row=3, column=0, sticky="w", pady=4)
        fmt = ttk.Frame(tabs["Output"])
        fmt.grid(row=3, column=1, sticky="w")
        ttk.Checkbutton(fmt, text=".graph", variable=self.f_graph).pack(side="left")
        ttk.Checkbutton(fmt, text=".svg", variable=self.f_svg).pack(side="left")
        ttk.Checkbutton(fmt, text=".png", variable=self.f_png).pack(side="left")
        ttk.Checkbutton(fmt, text=".opn", variable=self.f_opn).pack(side="left")
        ttk.Checkbutton(tabs["Output"], text="Schrijf rapport", variable=self.write_report).grid(row=4, column=1, sticky="w")
        ttk.Checkbutton(tabs["Output"], text="Schrijf effective spec", variable=self.write_effective).grid(row=5, column=1, sticky="w")

        ttk.Button(tabs["Spec"], text="Laad spec.yaml", command=self.load_spec_file).pack(fill="x", pady=3)
        ttk.Button(tabs["Spec"], text="Sla spec op", command=self.save_spec_file).pack(fill="x", pady=3)
        ttk.Button(tabs["Spec"], text="Sla spec op als...", command=self.save_spec_file_as).pack(fill="x", pady=3)
        ttk.Button(tabs["Spec"], text="Toon huidige spec in log", command=self.show_spec).pack(fill="x", pady=3)
        ttk.Button(tabs["Spec"], text="Reset standaard", command=lambda: self.load_spec(DEFAULT_SPEC)).pack(fill="x", pady=3)
        ttk.Label(tabs["Spec"], text="GUI = makkelijke laag.\nSpec = reproduceerbare bron.", foreground="#444").pack(anchor="w", pady=10)

        self.help_box = ScrolledText(tabs["Uitleg/Help"], height=28, wrap="word")
        self.help_box.pack(fill="both", expand=True)
        ttk.Button(tabs["Uitleg/Help"], text="Ververs uitleg / Refresh help", command=self.refresh_help).pack(fill="x", pady=4)

        buttons = ttk.Frame(parent)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Preview", command=self.preview).pack(fill="x", pady=3)
        ttk.Button(buttons, text="Genereer output", command=self.generate).pack(fill="x", pady=3)
        ttk.Button(buttons, text="Open outputmap", command=self.open_output_dir).pack(fill="x", pady=3)

    def refresh_help(self):
        if hasattr(self, "help_box"):
            self.help_box.delete("1.0", "end")
            self.help_box.insert("end", help_text_for_language(self.language.get() or "nl"))
            self.help_box.see("1.0")

    def _entry(self, parent, row, label, var, browse=False):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        ent = ttk.Entry(parent, textvariable=var, width=32)
        ent.grid(row=row, column=1, sticky="ew", pady=4)
        parent.columnconfigure(1, weight=1)
        if browse:
            ttk.Button(parent, text="...", width=4, command=self.choose_output_dir).grid(row=row, column=2, sticky="w", padx=4)

    def _spin(self, parent, row, label, var, from_, to):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Spinbox(parent, from_=from_, to=to, textvariable=var, width=12).grid(row=row, column=1, sticky="w", pady=4)

    def _spin_float(self, parent, row, label, var, from_, to):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Spinbox(parent, from_=from_, to=to, increment=1.0, textvariable=var, width=12).grid(row=row, column=1, sticky="w", pady=4)

    def _combo(self, parent, row, label, var, values):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(parent, textvariable=var, values=values, state="readonly", width=18).grid(row=row, column=1, sticky="w", pady=4)

    def _preview(self, parent):
        self.canvas = tk.Canvas(parent, bg="white", highlightthickness=1, highlightbackground="#aaa")
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.log_text = ScrolledText(parent, height=10, wrap="word")
        self.log_text.grid(row=1, column=0, sticky="ew", pady=(8, 0))

    def current_spec(self) -> dict:
        formats = []
        if self.f_graph.get():
            formats.append("graph")
        if self.f_svg.get():
            formats.append("svg")
        if self.f_png.get():
            formats.append("png")
        if self.f_opn.get():
            formats.append("opn")

        spec = {
            "project": {
                "name": self.project_name.get(),
                "title": self.project_title.get(),
                "description": "Gemaakt met Greedy Graph GUI",
            },
            "grid": {
                "step_x": int(self.step_x.get()),
                "step_y": int(self.step_y.get()),
                "show_grid_in_svg_png": bool(self.show_grid.get()),
                "show_axes_through_origin": bool(self.show_axes.get()),
                "show_major_grid_every": int(self.major.get()),
                "margin": int(self.margin.get()),
            },
            "graph": {
                "count": int(self.count.get()),
                "max": int(self.maxv.get()),
                "start": [0, 0],
            },
            "constraints": {
                "diagonal_free": self.diagonal_free.get(),
            },
            "greedy": {
                "style": self.style.get(),
                "rule": self.rule.get(),
                "angle_min": float(self.angle.get()),
            },
            "output": {
                "dir": self.output_dir.get(),
                "base_name": self.base_name.get(),
                "formats": formats,
                "naming": self.naming.get(),
                "write_report": bool(self.write_report.get()),
                "language": self.language.get(),
                "write_effective_spec": bool(self.write_effective.get()),
            },
        }
        return deep_merge(DEFAULT_SPEC, spec)

    def load_spec(self, spec: dict):
        spec = deep_merge(DEFAULT_SPEC, spec)
        self.project_name.set(spec["project"]["name"])
        self.project_title.set(spec["project"]["title"])
        self.language.set(spec.get("output", {}).get("language", "nl"))
        self.count.set(int(spec["graph"]["count"]))
        self.maxv.set(int(spec["graph"]["max"]))
        self.step_x.set(int(spec["grid"]["step_x"]))
        self.step_y.set(int(spec["grid"]["step_y"]))
        self.margin.set(int(spec["grid"]["margin"]))
        self.major.set(int(spec["grid"]["show_major_grid_every"]))
        self.show_grid.set(bool(spec["grid"]["show_grid_in_svg_png"]))
        self.show_axes.set(bool(spec["grid"]["show_axes_through_origin"]))
        self.style.set(spec["greedy"]["style"])
        self.rule.set(spec["greedy"]["rule"])
        self.diagonal_free.set(spec.get("constraints", {}).get("diagonal_free", "none"))
        self.angle.set(float(spec["greedy"]["angle_min"]))
        self.output_dir.set(spec["output"]["dir"])
        self.base_name.set(spec["output"]["base_name"])
        self.naming.set(spec["output"]["naming"])
        self.f_graph.set("graph" in spec["output"]["formats"])
        self.f_svg.set("svg" in spec["output"]["formats"])
        self.f_png.set("png" in spec["output"]["formats"])
        self.f_opn.set("opn" in spec["output"].get("formats", []))
        self.write_report.set(bool(spec["output"]["write_report"]))
        self.write_effective.set(bool(spec["output"]["write_effective_spec"]))
        if hasattr(self, "help_box"):
            self.refresh_help()

    def log(self, msg: str):
        self.log_text.insert("end", msg.rstrip() + "\n")
        self.log_text.see("end")

    def error(self, title: str, exc: BaseException):
        self.log("FOUT: " + str(exc))
        self.log(traceback.format_exc())
        messagebox.showerror(title, str(exc))

    def choose_output_dir(self):
        d = filedialog.askdirectory(title="Kies outputmap")
        if d:
            self.output_dir.set(d)

    def load_spec_file(self):
        path = filedialog.askopenfilename(title="Laad spec", filetypes=[("YAML", "*.yaml *.yml"), ("Alle bestanden", "*.*")])
        if not path:
            return
        try:
            spec = deep_merge(DEFAULT_SPEC, load_yaml(Path(path)))
            validate_spec(spec)
            self.load_spec(spec)
            self.spec_path = Path(path)
            self.log(f"Spec geladen: {path}")
            self.preview()
        except Exception as exc:
            self.error("Spec laden mislukt", exc)

    def save_spec_file(self):
        if self.spec_path is None:
            self.save_spec_file_as()
            return
        try:
            spec = self.current_spec()
            validate_spec(spec)
            self.spec_path.write_text(dump_yaml(spec), encoding="utf-8")
            self.log(f"Spec opgeslagen: {self.spec_path}")
        except Exception as exc:
            self.error("Spec opslaan mislukt", exc)

    def save_spec_file_as(self):
        path = filedialog.asksaveasfilename(title="Sla spec op als", defaultextension=".yaml", filetypes=[("YAML", "*.yaml"), ("Alle bestanden", "*.*")])
        if not path:
            return
        self.spec_path = Path(path)
        self.save_spec_file()

    def show_spec(self):
        try:
            spec = self.current_spec()
            validate_spec(spec)
            self.log("Huidige spec:\n" + dump_yaml(spec))
        except Exception as exc:
            self.error("Spec ongeldig", exc)

    def preview(self):
        try:
            spec = self.current_spec()
            points, stats = generate_points(spec)
            mapped, rows, cols, origin = map_to_grid(points, spec)
            self.draw_preview(spec, points, mapped, rows, cols, origin, stats)
            self.log(f"Preview OK: {len(points)} knopen, grid {cols} x {rows}.")
        except Exception as exc:
            self.error("Preview mislukt", exc)

    def generate(self):
        try:
            spec = self.current_spec()
            result = generate_outputs(spec)
            self.draw_preview(spec, result["points"], result["mapped"], result["rows"], result["cols"], result["origin"], result["stats"])
            self.log("Output gemaakt:")
            for p in result["files"]:
                self.log(f"  {p}")
            messagebox.showinfo("Klaar", f"Output gemaakt in:\n{Path(spec['output']['dir']).resolve()}")
        except Exception as exc:
            self.error("Genereren mislukt", exc)

    def open_output_dir(self):
        d = Path(self.output_dir.get()).resolve()
        d.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(d))
        except Exception as exc:
            self.error("Openen mislukt", exc)

    def draw_preview(self, spec: dict, points: List[Point], mapped: List[Point], rows: int, cols: int, origin: Point, stats: Dict[str, int]):
        self.canvas.delete("all")
        cw = max(400, self.canvas.winfo_width())
        ch = max(300, self.canvas.winfo_height())

        pad = 42
        header = 54
        avail_w = cw - 2 * pad
        avail_h = ch - 2 * pad - header
        cell = max(3, min(22, avail_w / max(1, cols - 1), avail_h / max(1, rows - 1)))

        grid_w = (cols - 1) * cell
        grid_h = (rows - 1) * cell
        left = (cw - grid_w) / 2
        top = pad + header + max(0, (avail_h - grid_h) / 2)

        def px(p: Point) -> Tuple[float, float]:
            return left + p[0] * cell, top + p[1] * cell

        major = int(spec["grid"]["show_major_grid_every"])

        title = f"{spec['project']['title']} | grid {cols}x{rows} | MAX={spec['graph']['max']} | COUNT={spec['graph']['count']} | {spec['greedy']['style']} / {rule_label(spec['greedy']['rule'], float(spec['greedy']['angle_min']))} / diag={spec.get('constraints', {}).get('diagonal_free', 'none')} | lang={language_of(spec)}"
        self.canvas.create_text(12, 12, anchor="nw", text=title, fill="#111", font=("Arial", 11, "bold"))
        self.canvas.create_text(12, 34, anchor="nw", text=preview_subtitle(spec), fill="#555", font=("Arial", 10))

        if spec["grid"]["show_grid_in_svg_png"]:
            for c in range(cols):
                x = left + c * cell
                color = "#d7d7d7" if ((c - origin[0]) % major == 0) else "#eeeeee"
                self.canvas.create_line(x, top, x, top + grid_h, fill=color)
            for r in range(rows):
                y = top + r * cell
                color = "#d7d7d7" if ((r - origin[1]) % major == 0) else "#eeeeee"
                self.canvas.create_line(left, y, left + grid_w, y, fill=color)

        if spec["grid"]["show_axes_through_origin"]:
            ox, oy = px(origin)
            self.canvas.create_line(ox, top, ox, top + grid_h, fill="#c06b00", width=2)
            self.canvas.create_line(left, oy, left + grid_w, oy, fill="#c06b00", width=2)
            self.canvas.create_text(ox + 16, top + 12, text="x=0", fill="#a35a00", font=("Arial", 9))
            self.canvas.create_text(left + 20, oy - 10, text="y=0", fill="#a35a00", font=("Arial", 9))

        self.canvas.create_rectangle(left, top, left + grid_w, top + grid_h, outline="#999")

        for a, b in zip(mapped, mapped[1:]):
            x1, y1 = px(a)
            x2, y2 = px(b)
            self.canvas.create_line(x1, y1, x2, y2, fill="#1f5eff", width=2)

        for label, p in enumerate(mapped):
            x, y = px(p)
            fill = "#ffd348" if label == 0 else "#44c36a"
            r = max(4, min(8, cell * 0.34))
            self.canvas.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline="#111")
            self.canvas.create_text(x + 11, y, text=str(label), anchor="w", fill="#111", font=("Arial", 9))

        basic, line_ok, final_ok = possible_next_count(mapped, rows, cols, spec)
        summary = f"tested={stats['tested']} | reject x/y={stats['rejected_rowcol']} | reject diag={stats.get('rejected_diagonal',0)} | reject recht={stats['rejected_straight']} | reject lijn={stats['rejected_line']} | volgende={final_ok}"
        self.canvas.create_text(12, ch - 20, anchor="sw", text=summary, fill="#333", font=("Arial", 10))


def main():
    return cli_main()


if __name__ == "__main__":
    raise SystemExit(main())
