# Handleiding Greedy Graph Generator GUI

## Waar gaat dit over?

Deze GUI maakt een groeiende graph:

```text
0 → 1 → 2 → ... → 30
```

Elke knoop ligt exact op een gridpunt.  
Elke nieuwe knoop wordt geplaatst volgens een greedy-regel.

## Start

Dubbelklik:

```text
start_gui.bat
```

## Tab Basis

Hier stel je in:

| veld | betekenis |
|---|---|
| Projectnaam | interne naam |
| Titel | titel boven preview/svg/png |
| COUNT | aantal knopen |
| MAX | zoekvenster rond 0 |

`COUNT=31` betekent labels 0 t/m 30.  
`MAX=20` betekent x,y in [-20,+20].

## Tab Grid

Hier stel je in:

| veld | betekenis |
|---|---|
| Gridstap X/Y | stapgrootte in .graph |
| Marge | extra rand rond max-grid |
| Hoofdlijn elke | zwaardere gridlijn per N |
| Toon grid | grid zichtbaar in SVG/PNG/preview |
| Toon assen | assen x=0 en y=0 zichtbaar |

De GUI gebruikt standaard het volledige max-grid.  
Daardoor staat knoop 0 centraal.

## Tab Greedy

Hier stel je de plaatsingsregel in.

### STYLE

| style | betekenis |
|---|---|
| near0 | blijf dicht bij knoop 0 |
| maxturn | kies grootste draaihoek |
| quadrant | verdeel over kwadranten |
| ring | werk ring voor ring |

### RULE

| rule | betekenis |
|---|---|
| none | geen rechte-lijn-filter |
| extension | alleen verlengde verboden |
| collinear | zelfde rechte drager verboden |
| angle | hoek moet tussen ANGLE_MIN en 180-ANGLE_MIN liggen |

## Tab Output

Hier stel je in:

- outputmap;
- bestandsnaam;
- korte of volledige naamgeving;
- welke bestanden gemaakt worden: graph/svg/png;
- rapport;
- effective spec.

## Tab Spec

Hier kun je:

- een spec laden;
- een spec opslaan;
- de huidige spec in het log bekijken;
- resetten naar standaard.

## Preview

Klik op:

```text
Preview
```

De GUI toont de graph zonder bestanden te schrijven.

## Genereer output

Klik op:

```text
Genereer output
```

De GUI schrijft de gekozen bestanden.

## Waarom is het grid belangrijk?

Zonder grid lijkt de graph zomaar in een leeg vlak te staan.  
Maar het model groeit op een rooster:

- elke knoop kiest een vrij gridpunt;
- geen twee knopen delen een x-kolom;
- geen twee knopen delen een y-rij;
- lijnen mogen niet ongeoorloofd kruisen/raken;
- knoop 0 is de oorsprong.

## .graph

De eerste regel van het `.graph`-bestand is bewust leeg.  
Niet verwijderen. OpenGraphEd heeft die regel nodig voor correct inlezen.


## Extra instelling: diagonale vrijheid

Naast vrije horizontale en verticale gridlijnen kan de generator nu ook diagonale vrijheid eisen.

In de GUI staat dit op het tabblad **Greedy** als:

```text
DIAGONAL_FREE
```

In de spec staat dit als:

```yaml
constraints:
  diagonal_free: none
```

### Mogelijke waarden

| waarde | betekenis |
|---|---|
| `none` | alleen x/y-vrijheid; diagonalen tellen niet mee |
| `slash` | een nieuwe knoop mag geen gebruikte `/`-diagonaal delen |
| `backslash` | een nieuwe knoop mag geen gebruikte `\`-diagonaal delen |
| `both` | beide diagonale richtingen moeten vrij zijn |

### Wat is een `/`-diagonaal?

In het grid is een `/`-diagonaal gedefinieerd als:

```text
x + y = constant
```

Als `diagonal_free: slash` actief is, mogen geen twee knopen dezelfde waarde `x + y` hebben.

### Wat is een `\`-diagonaal?

In het grid is een `\`-diagonaal gedefinieerd als:

```text
x - y = constant
```

Als `diagonal_free: backslash` actief is, mogen geen twee knopen dezelfde waarde `x - y` hebben.

### Wat betekent `both`?

Bij:

```yaml
constraints:
  diagonal_free: both
```

moet een nieuwe knoop tegelijk vrij zijn in:

```text
x
y
/
\
```

Dus de knoop moet vrij zijn op:

- zijn verticale gridlijn;
- zijn horizontale gridlijn;
- zijn `/`-diagonaal;
- zijn `\`-diagonaal.

Dit is de strengste instelling en kan sneller tot vastlopen leiden. Verhoog dan `MAX`, verlaag `COUNT`, of gebruik een minder strenge rechte-lijn-regel.


## Nieuw in v2.2: OPN-output

De GUI kan nu ook `.opn` schrijven. Zet in de GUI bij **Output** het vakje `.opn` aan, of gebruik in de spec:

```yaml
output:
  formats: [graph, svg, png, opn]
```

### Wat staat er in de OPN?

De generator schrijft een pipe-safe OPN met:

```text
STRUCTURE_NODES:
node-id | label | x | y | kind

STRUCTURE_EDGES:
from | to
```

De OPN bevat ook metadata/commentaar over:

- `max`
- `count`
- `style`
- `rule`
- `diagonal_free`

### Belangrijk verschil tussen `.graph` en `.opn`

De `.graph` bevat de directe OpenGraphEd-coördinaten.

De `.opn` bevat bron-gridcoördinaten:

```text
opn_x = model_x + MAX
opn_y = model_y + MAX
```

Bij het laden van OPN voegt OpenGraphEd zelf zijn vaste OPN-marge toe en gebruikt een gridcel van 20. Daardoor blijven de knopen exact op gridlijnen.

### Diagonal in OPN

`diagonal_free` wordt in de OPN expliciet meegeschreven als metadata. De OPN-plaatsing zelf is al volgens die regel berekend. Het `.opn`-bestand bevat dus zowel het resultaat als een leesbare vermelding van de gebruikte diagonale vrijheidsregel.


## Taalinstelling en uitgebreide uitleg

Deze versie bevat een taalinstelling. In de GUI staat die op het tabblad **Basis** als:

```text
Taal / Language
```

Mogelijke waarden:

| waarde | betekenis |
|---|---|
| `nl` | Nederlandse help, rapport- en metadataregels |
| `en` | English help, report text and metadata |

In de spec staat dezelfde instelling onder output:

```yaml
output:
  language: nl
```

of:

```yaml
output:
  language: en
```

De GUI bevat ook een tabblad **Uitleg/Help**. Dat tabblad toont tekst in de gekozen taal en legt in gewone woorden uit wat grid, vrije knoop, OPN, greedy, styles, rules, diagonal freedom en angle betekenen.

Voor printbare uitleg zijn twee PDF's meegeleverd:

- `GREEDY_GENERATOR_UITLEG_NL.pdf`
- `GREEDY_GENERATOR_EXPLANATION_EN.pdf`

## Direct vanuit OpenGraphEd genereren en laden

Vanaf v4301 kan OpenGraphEd de generator ook zonder GUI starten.

Menu in OpenGraphEd:

```text
OpenGraph > Generate + Load Greedy OPN
```

Dit doet achtereenvolgens:

1. lees `tools/greedy_generator_gui/spec.yaml`;
2. genereer `.graph`, `.opn`, `.svg`, `.png`, rapport en effective spec;
3. schrijf `output/last_generated.txt`;
4. laad de laatst gegenereerde `.opn` direct in OpenGraphEd.

De GUI blijft beschikbaar via:

```text
OpenGraph > Greedy Generator
```

Gebruik de GUI wanneer je instellingen wilt aanpassen. Gebruik **Generate + Load Greedy OPN** wanneer de spec al goed staat en je snel een nieuwe OpenGraphEd-weergave wilt laden.
