# PACKAGING MANIFEST v4348

Package: `Mapping_V4-26-06-04--v4348-jan-carousel-viewer.zip`

## Kern

- PWA-viewer zonder ingebouwde voorbeeldkeuzelijst.
- Aparte JAN-carousel-webpagina met de bestaande OpenGraph-carrouselbeelden.
- Losse viewerzip bevat de volledige map `mobile/greedy-grow-viewer/` inclusief carousel.

## Start

```bat
START-GREEDY-GROW-VIEWER.bat
```

Open:

```text
http://localhost:8088
http://localhost:8088/carousel/index.html
```
