# CHANGELOG v4348 — JAN-carousel naast viewer

## Vraag

De gebruiker gaf aan dat voorbeelden binnen de viewer op deze wijze een slecht idee zijn en dat de carousel gebruikt moet worden.

## Wijzigingen

- Voorbeeldkeuzelijst uit de PWA-viewer verwijderd.
- Viewer gepositioneerd als JSON/grow-afspeler.
- JAN-carousel als aparte webpagina toegevoegd onder `mobile/greedy-grow-viewer/carousel/`.
- Bestaande `opengraph_carousel` afbeeldingen en teksten gebruikt als slides.
- Link `JAN-carousel openen` toegevoegd aan de viewer.
- Service-worker cache naar v4348 gezet.
- Testpoort naar 8088 gezet.

## Niet gewijzigd

- Java/OpenGraphEd desktopcode.
- Greedy Grow JSON-export.
