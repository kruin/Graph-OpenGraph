# PATCH MANIFEST v4347 — JAN Open Notation Viewer

Doel: de PWA-viewer presenteren als demo van JAN, de Open Notation voor taalbomen.

Toegevoegd aan de viewer:

- JAN-header en intro.
- Voorbeeldselector.
- Drie taalboomdemo's.
- Leesbare lange labels.

Geen Java-desktopwijzigingen.
