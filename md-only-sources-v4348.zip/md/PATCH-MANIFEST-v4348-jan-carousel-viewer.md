# PATCH MANIFEST v4348 — JAN-carousel naast viewer

- Viewer-voorbeelden verwijderd.
- Carousel-webpagina toegevoegd.
- Bestaande OpenGraph-carouselbestanden hergebruikt.
- Poort 8088.
