# v4348 — JAN-carousel naast viewer

Start:

```bat
START-GREEDY-GROW-VIEWER.bat
```

Viewer:

```text
http://localhost:8088
```

Carousel:

```text
http://localhost:8088/carousel/index.html
```

De viewer is geen lijst met voorbeelden meer. De carousel draagt de uitleg en voorbeelden.
