# 15 — v4348 JAN-carousel naast viewer

## Besluit

De grow-viewer toont geen lijst met inhoudelijke voorbeelden meer. Dat bleek didactisch verwarrend: de viewer is een afspeler/testscherm, geen lesmodule.

## Nieuwe scheiding

```text
viewer   = één JSON/grow-weergave testen
carousel = uitlegbeelden en voorbeelden tonen
```

## Locaties

```text
mobile/greedy-grow-viewer/index.html
mobile/greedy-grow-viewer/carousel/index.html
mobile/greedy-grow-viewer/carousel/slides/
opengraph_carousel/
```

De carousel gebruikt de bestaande OpenGraph-carrouselbeelden en teksten als webpresentatie.

## Viewerwijzigingen

- Voorbeeldkeuzelijst verwijderd.
- Knop/link naar JAN-carousel toegevoegd.
- Technische startdemo blijft beschikbaar als automatische viewerdata.
- JSON laden blijft de hoofdactie voor eigen exports.
- Poort: 8088.
