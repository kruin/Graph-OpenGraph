# v4347 — JAN Open Notation Viewer

De PWA-viewer communiceert nu expliciet dat hij een demonstrator is voor **JAN**, de Open Notation voor taalbomen.

## Toegevoegd

- Header: `JAN · OpenGraph` en `Open Notation voor taalbomen`.
- Introblok met korte uitleg over vrije taalboomknopen.
- Voorbeeldkiezer met drie JAN-taalboomvoorbeelden.
- Taalboomvoorbeelden als JSON:
  - `jan-open-notation-taalboom.json`
  - `jan-projecties-lex-syn-log.json`
  - `jan-topicalisatie-zonder-verplaatsingspijl.json`
- Lange labels worden naast de knoop gezet, zodat taalvoorbeelden leesbaar blijven.
- Service-worker cache en lokale poort naar v4347/8087.

## Kern

JAN gebruikt open notatie: de bronknopen hoeven niet onder één vaste klassieke boom-as te hangen. LEX, SYN en LOG kunnen als eigen projecties in eigen ruimte verschijnen.

De viewer blijft een demo-viewer, geen volledige OpenGraphEd-editor.
