package userInterface.menuAndToolBar;

import java.util.Vector;

public final class MenuAndToolBarControlCatalog
{
  private MenuAndToolBarControlCatalog() {}

  public static Vector loadControls()
  {
    Vector v = new Vector();

    v.add("M,File,F,Load & Save Graphs");
    v.add("S,File,New Graph,/images/New.gif,Create a New Graph,N,true,1,newGraph");
    v.add("S,File,Load Graph,/images/Open.gif,Load a Graph From a File,L,isApplication,1,loadGraph");
    v.add("S,File,Open OPN,/images/Open.gif,Open an OpenGraphEd .opn file,O,isApplication,1,openOPN");
    v.add("S,File,Save Graph,/images/Save.gif,Save the Current Graph To a File,S,false,1,saveGraph");
    v.add("S,File,Close Graph,/images/Delete.gif,Close the Current Graph Editor,C,false,1,closeGraph");
    v.add("S,File,Preferences,/images/Preferences.gif,OpenGraphEd Preferences,P,true,1,preferences");
    v.add("separator,space");

    v.add("M,General,G,General options");
    v.add("K,General,Test,null,Enable test features,T,true,1,toggleTestFeatures");

    v.add("M,Modes,M,Change Editor Mode");
    v.add("P,Modes,Choose an Operation Mode,/images/DefaultDisplay.gif,Choose an Operation Mode,Z,false,1,5,"
        + "C,Modes,Edit,/images/Edit.gif,Graph Edit Mode,E,false,1,editMode,"
        + "C,Modes,Grid,/images/Grid.gif,Graph Grid Mode,M,false,1,gridMode,"
        + "C,Modes,Move,/images/Move.gif,Graph Move Mode,M,false,1,moveMode,"
        + "C,Modes,Rotate,/images/Rotate.gif,Graph Rotate Mode,R,false,1,rotateMode,"
        + "C,Modes,Resize,/images/Resize.gif,Graph Resize Mode,Z,false,1,resizeMode");

    v.add("M,Show,S,Coordinate or Label Showing Options");
    v.add("P,Show,Show,/images/DefaultDisplay.gif,Choose to Show Coordinates or Labels,Z,false,1,3,"
        + "C,Show,Show Coordinates,/images/ShowCoords.gif,Show Coordinates,C,false,1,showCoords,"
        + "C,Show,Show Labels,/images/ShowLabels.gif,Show Labels,L,false,1,showLabels,"
        + "C,Show,Show Nothing,/images/ShowNothing.gif,Show Nothing,T,false,1,showNothing");

    v.add("M,Info,I,Info about the current graph");
    v.add("S,Info,Info,/images/Info.gif,Info about the current graph,I,false,1,info");
    v.add("S,Info,Log,/images/Log.gif,Log of Operations run on the current graph,L,false,1,log");

    v.add("M,Help,H,OpenGraphEd Help");
    v.add("S,Help,Help,/images/Help.gif,OpenGraphEd Help,H,true,1,help");
    v.add("separator,space");

    v.add("M,Undo,U,Undo or Redo Actions");
    v.add("S,Undo,Undo,/images/Undo.gif,Undo Last Command,U,false,1,undo");
    v.add("S,Undo,Redo,/images/Redo.gif,Redo Last Un-Done Command,R,false,1,redo");
    v.add("S,Undo,Toggle Undos,/images/ToggleUndos.gif,Disable Undos,D,true,1,toggleUndo");
    v.add("separator,space");

    v.add("M,Edit,E,Edit Options");
    v.add("S,Edit,Unselect All,/images/UnselectAll.gif,Unselect All Nodes and Edges,U,false,1,unselectAll");
    v.add("S,Edit,Remove Selected,/images/RemoveSelected.gif,Remove Selected Nodes and Edges,S,false,1,removeSelected");
    v.add("S,Edit,Remove All,/images/RemoveAll.gif,Remove All Nodes and Edges,R,false,1,removeAll");
    v.add("S,Edit,Remove Generated,/images/RemoveGenerated.gif,Remove Generated Edges,E,false,1,removeGenerated");
    v.add("S,Edit,Preserve Generated,/images/PreserveGenerated.gif,Preserve Generated Edges,P,false,1,preserveGenerated");
    v.add("separator,newline");

    v.add("M,Test,T,Test the Current Graph");
    v.add("S,Test,Connectivity Test,/images/TestConnectivity.gif,Is Current Graph Connected?,C,false,1,testConnectivity");
    v.add("S,Test,Biconnectivity Test,/images/TestBiconnectivity.gif,Is Current Graph Biconnected?,B,false,1,testBiconnectivity");
    v.add("S,Test,Planarity Test,/images/TestPlanarity.gif,Is Current Graph Planar?,P,false,1,testPlanarity");
    v.add("separator,space");

    v.add("M,Operation,O,Operate on Current Graph");
    v.add("S,Operation,Create Random,/images/CreateRandom.gif,Create X Random Nodes,R,false,1,createRandom");
    v.add("S,Operation,Embedding,/images/Embed.gif,Embed the Current Graph,E,false,1,embedding");
    v.add("S,Operation,Make Connected,/images/MakeConnected.gif,Connect the Current Graph,C,false,1,makeConnected");
    v.add("S,Operation,Make Biconnected,/images/MakeBiconnected.gif,Biconnect the Current Graph,B,false,1,makeBiconnected");
    v.add("S,Operation,Make Maximal,/images/MakeMaximal.gif,Triangulate the Current Graph,M,false,1,makeMaximal");
    v.add("S,Operation,Straight Line Embed,/images/StraightLineEmbed.gif,Straight Line Embed the Current Graph,S,false,1,straightLineEmbed");
    v.add("separator,space");

    v.add("M,OpenGraph,O,OpenGraph drawing grid and projection actions");
    v.add("S,OpenGraph,Grid Settings,/images/Grid.gif,Set or reapply the OpenGraph grid,G,false,1,openGraphGridMode");
    v.add("S,OpenGraph,FT Settings,/images/DefaultDisplay.gif,Functional Tree settings: core/frame roles and spacing,F,false,1,openFunctionalTreeSettings");
    v.add("S,OpenGraph,Toggle Projections,/images/DefaultDisplay.gif,Show or hide OpenGraph projections,P,false,1,toggleLexicalProjection");
    v.add("S,OpenGraph,Save OPN,/images/Save.gif,Save the current OpenGraph result as .opn,S,false,1,saveOPN");
    v.add("separator,space");

    v.add("M,Display,D,Graph Display Options");
    v.add("S,Display,Default,/images/DefaultDisplay.gif,Reset to Default Display,F,false,1,resetDisplay");
    v.add("S,Display,Depth First Search,/images/DFSDisplay.gif,Display Depth First Search,D,false,1,displayDFS");
    v.add("S,Display,Biconnected Components,/images/BiconnectedDisplay.gif,Display Biconnected Components,B,false,1,displayBiconnected");
    v.add("S,Display,ST Numbering,/images/STDisplay.gif,Display ST Numbering,S,false,1,displayST");
    v.add("S,Display,Canonical Ordering,/images/CanonicalDisplay.gif,Display Canonical Ordering,O,false,1,displayCanonical");
    v.add("S,Display,Normal Labeling,/images/NormalDisplay.gif,Display Normal Labeling,N,false,1,displayNormal");
    v.add("S,Display,Chan Tree Drawing,/images/ChanTreeDisplay.gif,Display Chan Tree Drawing,C,false,1,displayChanTree");
    v.add("S,Display,Minimum Spanning Tree,/images/MSTDisplay.gif,Display Minimum Spanning Tree,M,false,1,displayMST");
    v.add("S,Display,Dijkstra Shortest Path,/images/SPDisplay.gif,Display Shortest Path For Two Nodes,P,false,1,displayDijkstra");
    v.add("separator,space");

    v.add("M,Windows,W,List of Open Windows");
    v.add("S,Windows,None,null,No Windows Are Open, ,true,1, ");

    v.add("cursorLocationLabel");

    return v;
  }
}
