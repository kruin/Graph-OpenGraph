package userInterface;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Properties;
import graphStructure.*;
import operation.OpenGraphTreeDrawOperation;

public class GraphEditorWindow extends OpenGraphEdInternalFrame
{
  private static final int STRUCTURE_ORIGINAL_GRAPH = 0;

  public static int WIDTH = 1150;//400;//SET MAX, see below:setSize
  public static int HEIGHT = 750;//400;

  private GraphController graphController;
  private GraphEditor graphEditor;
  private static int newCount = 0;
  private GraphEditorDialog ged;
  private GraphEditorInfoWindow infoWindow;
  private GraphEditorLogWindow logWindow;
  private ButtonGroup zinstypeButtonGroup;
  private JToggleButton basisZinstypeButton;
  private JToggleButton bijzinZinstypeButton;
  private JToggleButton stellendZinstypeButton;
  private JToggleButton jaNeeZinstypeButton;
  private JToggleButton whZinstypeButton;
  private JToggleButton topicalisatieZinstypeButton;
  private JComboBox structureTypeCombo;
  private JButton openGraphDrawButton;
  private JButton openGraphExplainButton;
  private JLabel zinstypeLabel;
  private JPanel zinstypePanel;
  private JPanel verbClusterPanel;
  private JButton languageTreeSettingsButton;
  private JButton functionalTreeSettingsButton;
  private ButtonGroup verbClusterButtonGroup;
  private JToggleButton pvVdVerbClusterButton;
  private JToggleButton vdPvVerbClusterButton;
  private JPanel projectionProfilePanel;
  private JCheckBox projectionShowCheckBox;
  private JCheckBox projectionLeftCheckBox;
  private JCheckBox projectionRightCheckBox;
  private JCheckBox projectionTopCheckBox;
  private JCheckBox projectionBottomCheckBox;
  private JTextField projectionLeftCaptionField;
  private JTextField projectionRightCaptionField;
  private JTextField projectionTopCaptionField;
  private JTextField projectionBottomCaptionField;
  private JButton projectionSaveProfileButton;
  private boolean updatingStructureTypeCombo = false;
  private boolean updatingProjectionProfileControls = false;
  private int lastExplicitTreeTypeSelection = STRUCTURE_ORIGINAL_GRAPH;

  public GraphEditorWindow(GraphController graphController, Graph graph)
  {
    super(graphController, graph.getFileName(),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    if ( graph.getLabel().length() == 0 )
    {
      setTitle(graph.getFileName());
    }
    init(graphController);
    graphEditor.setGraph(graph);
    OpenGraphProjectionSettings initialSettings = initialProjectionSettingsForGraph(graph);
    if ( initialSettings != null )
    {
      graphEditor.setOpenGraphProjectionSettings(initialSettings);
      graphEditor.rememberLanguageProjectionSettings(initialSettings);
      graphEditor.setOpenGraphProjectionContextActive(true);
      lastExplicitTreeTypeSelection = initialSettings.getStructureType();
    }
    updateOpenGraphHeaderControls();
  }


  private OpenGraphProjectionSettings initialProjectionSettingsForGraph(Graph graph)
  {
    int structureType = preferredStructureTypeForGraph(graph);
    if ( structureType == 0 )
    {
      return null;
    }

    OpenGraphProjectionSettings settings = OpenGraphProjectionSupport.loadBestAvailableForStructureType(structureType);
    settings.setStructureType(structureType);
    settings.setShowProjections(true);
    return settings;
  }

  private int preferredStructureTypeForGraph(Graph graph)
  {
    String topLabel = detectTopNodeLabel(graph);
    if ( topLabel.equals("CLAUSE") || topLabel.equals("V") || topLabel.equals("S") || topLabel.equals("S") )
    {
      return OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE;
    }
    if ( graph != null && graph.isOPNLanguageTreePreferred() )
    {
      return OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    }
    return 0;
  }

  private String detectTopNodeLabel(Graph graph)
  {
    if ( graph == null ) return "";

    java.util.Vector nodes = graph.getNodes();
    if ( nodes == null || nodes.size() == 0 ) return "";

    java.util.HashSet targets = new java.util.HashSet();
    java.util.Vector edges = graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge == null ) continue;
      NodeInterface end = edge.getEndNode();
      if ( end != null ) targets.add(end);
    }

    Node best = null;
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node == null ) continue;
      if ( !targets.contains(node) )
      {
        best = node;
        break;
      }
      if ( best == null || node.getLocation().intY() < best.getLocation().intY() ||
           (node.getLocation().intY() == best.getLocation().intY() &&
            node.getLocation().intX() < best.getLocation().intX()) )
      {
        best = node;
      }
    }

    if ( best == null ) return "";
    String label = best.getLabel();
    return label == null ? "" : label.trim().toUpperCase();
  }

  public GraphEditorWindow(GraphController graphController)
  {
    super(graphController, "Untitled " + ++newCount,
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
    init(graphController);
  }

  private void init(GraphController graphController)
  {
    this.graphController = graphController;
    infoWindow = new GraphEditorInfoWindow(graphController, this);
    logWindow = new GraphEditorLogWindow(graphController, this);
    graphEditor = new GraphEditor(graphController, infoWindow, logWindow);
    ged = null;
    installImmediateZinstypeToolTips();

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    getContentPane().setLayout(layout);

    JPanel openGraphActionBar = createOpenGraphActionBar();
    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = 1;
    layoutCons.fill = GridBagConstraints.HORIZONTAL;
    layoutCons.insets = new Insets(3,3,0,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 0.0;
    layout.setConstraints(openGraphActionBar, layoutCons);
    getContentPane().add(openGraphActionBar);

    JScrollPane scrollPane = new JScrollPane(graphEditor,
                                             JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = GridBagConstraints.REMAINDER;
    layoutCons.fill = GridBagConstraints.BOTH;
    layoutCons.insets = new Insets(3,3,3,3);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 1.0;
    layoutCons.weighty = 1.0;
    layout.setConstraints(scrollPane, layoutCons);
    getContentPane().add(scrollPane);

    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    addInternalFrameListener(graphController);

  //  setSize(WIDTH, HEIGHT);
    
    setSize(graphController.getGraphWindow().getWidth(), graphController.getGraphWindow().getHeight());
    setVisible(true);
  }

  private void installImmediateZinstypeToolTips()
  {
    ToolTipManager manager = ToolTipManager.sharedInstance();
    manager.setInitialDelay(0);
    manager.setReshowDelay(0);
    manager.setDismissDelay(15000);
  }

  private JPanel createOpenGraphActionBar()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 2));
    panel.setBorder(BorderFactory.createEtchedBorder());

    JLabel structureTypeLabel = new JLabel("Tree:");
    structureTypeLabel.setToolTipText("OpenGraph tree. Language = DS-boom, LEX-as, zinstypeprofielen en V-cluster.");
    panel.add(structureTypeLabel);
    structureTypeCombo = createStructureTypeCombo();
    panel.add(structureTypeCombo);

    openGraphExplainButton = createOpenGraphButton("Uitleg", "Leg het huidige Tree-type uit: origineel, Simple, Language, Functional, Frame of Anaphor.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        showCurrentTreeTypeExplanation();
      }
    });
    panel.add(openGraphExplainButton);

    languageTreeSettingsButton = createOpenGraphButton("Settings...", "Language Tree settings: V-cluster en projectieprofiel voor de gebruiker. Alleen zichtbaar bij Tree = Language.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        openLanguageTreeSettingsDialog();
      }
    });
    /* Keep the settings button directly next to Tree. It must be
     * findable before the wide Zinstype/V-cluster/projection groups on
     * narrow screens. */
    panel.add(languageTreeSettingsButton);

    functionalTreeSettingsButton = createOpenGraphButton("FT Settings...", "Functional Tree settings: core/frame roles, vertical spacing and role table. Alleen zichtbaar bij Tree = Functional.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        openFunctionalTreeSettingsDialog();
      }
    });
    panel.add(functionalTreeSettingsButton);

    /* Keep Zinstype close to Tree, but after LT Settings. */
    zinstypePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    zinstypePanel.setOpaque(false);
    zinstypeLabel = new JLabel("Zin:");
    zinstypeLabel.setToolTipText("Zinstype voor Language Tree / Phrase. De knoppen voeren direct Draw/Redraw uit; de DS-boom blijft ongewijzigd.");
    zinstypePanel.add(zinstypeLabel);
    zinstypeButtonGroup = new ButtonGroup();
    basisZinstypeButton = createZinstypeButton("Basis", OpenGraphProjectionSettings.ZINSTYPE_BASIS);
    bijzinZinstypeButton = createZinstypeButton("Bijzin", OpenGraphProjectionSettings.ZINSTYPE_BIJZIN);
    stellendZinstypeButton = createZinstypeButton("Stell.", OpenGraphProjectionSettings.ZINSTYPE_STELLEND);
    jaNeeZinstypeButton = createZinstypeButton("Ja/nee", OpenGraphProjectionSettings.ZINSTYPE_JA_NEE);
    whZinstypeButton = createZinstypeButton("WH", OpenGraphProjectionSettings.ZINSTYPE_WH);
    topicalisatieZinstypeButton = createZinstypeButton("Topic", OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE);
    zinstypePanel.add(basisZinstypeButton);
    zinstypePanel.add(bijzinZinstypeButton);
    zinstypePanel.add(stellendZinstypeButton);
    zinstypePanel.add(jaNeeZinstypeButton);
    zinstypePanel.add(whZinstypeButton);
    zinstypePanel.add(topicalisatieZinstypeButton);
    panel.add(zinstypePanel);

    verbClusterPanel = createVerbClusterPanel();
    panel.add(verbClusterPanel);

    projectionProfilePanel = createProjectionProfilePanel();
    panel.add(projectionProfilePanel);

    openGraphDrawButton = createOpenGraphButton("Draw", "Draw/Redraw using the selected Tree. Tree selection alone does not draw.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.drawSelectedOpenGraphStructure(GraphEditorWindow.this);
      }
    });
    panel.add(openGraphDrawButton);

    panel.add(createOpenGraphButton("Grid", "Set or reapply the OpenGraph grid without clearing the current OPN result", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.openGraphGridMode(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Toggle Proj.", "Show or hide OpenGraph projections without moving the structure grid", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.toggleLexicalProjection(GraphEditorWindow.this);
      }
    }));
    panel.add(createOpenGraphButton("Save OPN", "Save the current OpenGraph result as .opn", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        graphController.saveOPN(GraphEditorWindow.this);
      }
    }));

    updateZinstypeButtonSelection();
    updateVerbClusterButtonSelection();
    updateStructureTypeComboSelection();
    updateOpenGraphHeaderControlsVisibility();
    return panel;
  }


  private void openLanguageTreeSettingsDialog()
  {
    if ( graphEditor == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    if ( settings.getStructureType() != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      settings = OpenGraphProjectionSupport.loadBestAvailableForStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    }
    settings.setStructureType(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);

    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

    JTextArea intro = new JTextArea(
      "Language Tree settings\n" +
      "Deze instellingen gelden specifiek voor Language Tree / Phrase.\n" +
      "Zinstypeknoppen tekenen direct; deze settings worden opgeslagen en gebruikt bij de volgende Language Tree draw."
    );
    intro.setEditable(false);
    intro.setOpaque(false);
    intro.setLineWrap(true);
    intro.setWrapStyleWord(true);
    root.add(intro, BorderLayout.NORTH);

    JPanel form = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(3, 3, 3, 3);
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 1.0;

    int row = 0;
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 1;
    form.add(new JLabel("V-cluster:"), c);

    JPanel verbPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    final JRadioButton pvVd = new JRadioButton("pv-VD  heeft gebeten");
    final JRadioButton vdPv = new JRadioButton("VD-pv  gebeten heeft");
    ButtonGroup group = new ButtonGroup();
    group.add(pvVd);
    group.add(vdPv);
    if ( OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV.equals(settings.getLanguageTreeVerbClusterOrder()) )
    {
      vdPv.setSelected(true);
    }
    else
    {
      pvVd.setSelected(true);
    }
    verbPanel.add(pvVd);
    verbPanel.add(vdPv);
    c.gridx = 1;
    c.gridy = row++;
    form.add(verbPanel, c);

    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("Projecties:"), c);
    final JCheckBox show = new JCheckBox("toon projecties", settings.getShowProjections());
    c.gridx = 1;
    c.gridy = row++;
    form.add(show, c);

    final JCheckBox leftEnabled = new JCheckBox("links", settings.getLeftProjectionEnabled());
    final JTextField leftCaption = new JTextField(settings.getLeftProjectionCaption(), 8);
    JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    leftPanel.add(leftEnabled);
    leftPanel.add(new JLabel("caption:"));
    leftPanel.add(leftCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("LEX-as:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(leftPanel, c);

    final JCheckBox rightEnabled = new JCheckBox("rechts", settings.getRightProjectionEnabled());
    final JTextField rightCaption = new JTextField(settings.getRightProjectionCaption(), 8);
    JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    rightPanel.add(rightEnabled);
    rightPanel.add(new JLabel("caption:"));
    rightPanel.add(rightCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("SYNT-as:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(rightPanel, c);

    final JCheckBox topEnabled = new JCheckBox("boven", settings.getTopProjectionEnabled());
    final JTextField topCaption = new JTextField(settings.getTopProjectionCaption(), 8);
    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    topPanel.add(topEnabled);
    topPanel.add(new JLabel("caption:"));
    topPanel.add(topCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("boven:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(topPanel, c);

    final JCheckBox bottomEnabled = new JCheckBox("onder", settings.getBottomProjectionEnabled());
    final JTextField bottomCaption = new JTextField(settings.getBottomProjectionCaption(), 8);
    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    bottomPanel.add(bottomEnabled);
    bottomPanel.add(new JLabel("caption:"));
    bottomPanel.add(bottomCaption);
    c.gridx = 0;
    c.gridy = row;
    form.add(new JLabel("onder:"), c);
    c.gridx = 1;
    c.gridy = row++;
    form.add(bottomPanel, c);

    root.add(form, BorderLayout.CENTER);

    int answer = JOptionPane.showConfirmDialog(this, root, "Language Tree settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if ( answer != JOptionPane.OK_OPTION )
    {
      return;
    }

    settings.setLanguageTreeVerbClusterOrder(vdPv.isSelected() ? OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV : OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD);
    settings.setShowProjections(show.isSelected());
    settings.setLeftProjectionEnabled(leftEnabled.isSelected());
    settings.setRightProjectionEnabled(rightEnabled.isSelected());
    settings.setTopProjectionEnabled(topEnabled.isSelected());
    settings.setBottomProjectionEnabled(bottomEnabled.isSelected());
    settings.setLeftProjectionCaption(leftCaption.getText());
    settings.setRightProjectionCaption(rightCaption.getText());
    settings.setTopProjectionCaption(topCaption.getText());
    settings.setBottomProjectionCaption(bottomCaption.getText());
    settings.normalize();

    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(true);
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.update();
    updateOpenGraphHeaderControls();
    saveProjectionProfile(settings);
  }



  public void openFunctionalTreeSettingsDialog()
  {
    final Properties props = loadFunctionalTreeProperties();

    final JCheckBox autoDetect = new JCheckBox("Auto-detect FT by top label", boolProp(props, "functional.layout.autoDetect.enabled", true));
    final JCheckBox syntaxProposal = new JCheckBox("Maak thematisch voorstel uit syntaxis (S/NP/VP)", boolProp(props, "functional.layout.syntaxProposal.enabled", true));
    final JTextField autoLabels = new JTextField(strProp(props, "functional.layout.autoDetectTopLabels", "S,CLAUSE,V"), 22);
    final java.util.LinkedHashMap coreRoleChecks = createFunctionalRoleChecklist(props, "functional.layout.coreRoles", true);
    final java.util.LinkedHashMap frameRoleChecks = createFunctionalRoleChecklist(props, "functional.layout.frameRoles", false);
    connectFunctionalRoleChecklistExclusion(coreRoleChecks, frameRoleChecks);
    final JCheckBox frameEnabled = new JCheckBox("Put frame roles in FRAME", boolProp(props, "functional.layout.frame.enabled", true));
    final JCheckBox frameVisible = new JCheckBox("Show frame roles in main FT tree", boolProp(props, "functional.layout.frameRolesVisibleInMainTree", false));
    final JTextField frameCaption = new JTextField(strProp(props, "functional.layout.frame.caption", "FRAME"), 12);
    final JSpinner verticalStep = new JSpinner(new SpinnerNumberModel(intProp(props, "functional.layout.verticalStep", 1), 1, 20, 1));
    final JSpinner verticalStart = new JSpinner(new SpinnerNumberModel(intProp(props, "functional.layout.verticalStart", 2), 0, 50, 1));
    final JComboBox horizontalSpread = new JComboBox(new String[] { "compact", "medium", "wide" });
    horizontalSpread.setSelectedItem(strProp(props, "functional.layout.horizontalSpread", "compact"));

    final JPanel coreRolesPanel = createFunctionalRoleHierarchyPanel(coreRoleChecks);
    final JPanel frameRolesPanel = createFunctionalRoleHierarchyPanel(frameRoleChecks);
    final JTable ftNodesTable = createFunctionalTreeNodesTable();

    JTabbedPane tabs = new JTabbedPane();
    JPanel basis = new JPanel(new GridBagLayout());
    basis.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(3, 3, 3, 3);
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 1.0;
    int row = 0;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(autoDetect, c); row++;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(syntaxProposal, c); row++;
    addFTDialogRow(basis, c, row++, "Auto labels", autoLabels);
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(new JLabel("Voorstel: S/CLAUSE/V=action; eerste NP/DP=agens; NP/DP onder VP/V=patiens; PP=Frame."), c); row++;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(frameEnabled, c); row++;
    c.gridx = 0; c.gridy = row; c.gridwidth = 2; basis.add(frameVisible, c); row++;
    addFTDialogRow(basis, c, row++, "Frame caption", frameCaption);
    addFTDialogRow(basis, c, row++, "Vertical step", verticalStep);
    addFTDialogRow(basis, c, row++, "Vertical start", verticalStart);
    addFTDialogRow(basis, c, row++, "Horizontal spread", horizontalSpread);

    JPanel roles = new JPanel(new BorderLayout(6, 6));
    roles.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JTextArea roleInfo = new JTextArea("Rollen worden gekozen met vinklijsten in FT Basis.\nCore = hoofdrollen in compacte FT-boom.\nFrame = omstandigheden/adjuncten voor FRAME.");
    roleInfo.setEditable(false);
    roleInfo.setOpaque(false);
    roleInfo.setLineWrap(true);
    roleInfo.setWrapStyleWord(true);
    roles.add(roleInfo, BorderLayout.NORTH);
    roles.add(new JScrollPane(createFunctionalRoleOverviewPanel(coreRoleChecks, frameRoleChecks)), BorderLayout.CENTER);

    JPanel nodePanel = new JPanel(new BorderLayout(6, 6));
    nodePanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    nodePanel.add(new JLabel("Niet-eindknopen: Default FT is voorstel; Override FT past de knoop aan."), BorderLayout.NORTH);
    nodePanel.add(new JScrollPane(ftNodesTable), BorderLayout.CENTER);

    tabs.addTab("FT Basis", basis);
    tabs.addTab("FT Rollen", roles);
    tabs.addTab("FT Nodes", nodePanel);

    JPanel root = new JPanel(new BorderLayout(8, 8));
    root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JLabel intro = new JLabel("Functional Tree settings - vink rollen aan per hiërarchie; Save activeert de volgende Draw.");
    root.add(intro, BorderLayout.NORTH);
    root.add(tabs, BorderLayout.CENTER);
    root.setPreferredSize(new Dimension(780, 540));

    int answer = JOptionPane.showConfirmDialog(this, root, "FT Settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if ( answer != JOptionPane.OK_OPTION )
    {
      return;
    }

    props.setProperty("functional.layout.autoDetect.enabled", Boolean.toString(autoDetect.isSelected()));
    props.setProperty("functional.layout.syntaxProposal.enabled", Boolean.toString(syntaxProposal.isSelected()));
    props.setProperty("functional.layout.autoDetectTopLabels", autoLabels.getText().trim());
    String selectedCoreRoles = selectedFunctionalRolesCsv(coreRoleChecks);
    String selectedFrameRoles = selectedFunctionalRolesCsv(frameRoleChecks);
    props.setProperty("functional.layout.coreRoles", selectedCoreRoles);
    props.setProperty("functional.layout.frameRoles", selectedFrameRoles);
    props.setProperty("functional.layout.frame.enabled", Boolean.toString(frameEnabled.isSelected()));
    props.setProperty("functional.layout.frameRolesVisibleInMainTree", Boolean.toString(frameVisible.isSelected()));
    props.setProperty("functional.layout.frame.caption", frameCaption.getText().trim());
    props.setProperty("functional.layout.verticalStep", String.valueOf(((Integer)verticalStep.getValue()).intValue()));
    props.setProperty("functional.layout.verticalStart", String.valueOf(((Integer)verticalStart.getValue()).intValue()));
    props.setProperty("functional.layout.horizontalSpread", String.valueOf(horizontalSpread.getSelectedItem()));
    applyFunctionalTreeNodeTableOverrides(ftNodesTable);
    rememberCurrentGraphAsFunctionalTreeInputTest();
    String generatedRoleTable = functionalRoleTableFromChecklist(coreRoleChecks, frameRoleChecks);
    props.setProperty("functional.layout.roleTable", generatedRoleTable);
    applyFunctionalRoleTableToProperties(props, generatedRoleTable);

    try
    {
      OpenGraphDialogSettingsSupport.saveProperties("config/opengraph_user.properties", props, "OpenGraph user settings");
      OpenGraphTreeDrawOperation.resetFunctionalTreeConfigCache();
      JOptionPane.showMessageDialog(this, "FT config saved en actief. Gebruik Draw om opnieuw te tekenen.", "FT Settings", JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( IOException ioe )
    {
      JOptionPane.showMessageDialog(this, "FT config kon niet worden opgeslagen.", "FT Settings", JOptionPane.ERROR_MESSAGE);
    }
  }


  private JTable createFunctionalTreeNodesTable()
  {
    String[] columns = new String[] { "#", "Label", "Projectie-text", "Default FT", "Override FT", "Result FT" };
    javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel(columns, 0)
    {
      public boolean isCellEditable(int row, int column)
      {
        return column == 4;
      }
    };

    Graph graph = graphEditor == null ? null : graphEditor.getGraph();
    java.util.Vector nodes = graph == null ? null : graph.getNodes();
    for ( int i=0; nodes != null && i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node == null || !isFunctionalTreeNonTerminal(graph, node) ) continue;
      String projectionText = functionalTreeProjectionTextForNode(graph, node);
      String def = defaultFunctionalTreeProposalForNode(graph, node);
      String defDisplay = functionalTreeDefaultDisplay(def, projectionText);
      String override = node.hasFunctionalTreeMetadata() ? functionalTreeResultForNode(node) : "";
      String result = override.length() == 0 ? defDisplay : override;
      model.addRow(new Object[] { new Integer(node.getIndex()), node.getLabel(), projectionText, defDisplay, override, result });
    }

    JTable table = new JTable(model);
    table.setFillsViewportHeight(true);
    table.getColumnModel().getColumn(0).setMaxWidth(46);
    table.getColumnModel().getColumn(1).setPreferredWidth(70);
    table.getColumnModel().getColumn(2).setPreferredWidth(180);
    table.getColumnModel().getColumn(3).setPreferredWidth(145);
    table.getColumnModel().getColumn(4).setPreferredWidth(190);
    table.getColumnModel().getColumn(5).setPreferredWidth(145);

    table.getColumnModel().getColumn(4).setCellEditor(new FunctionalTreeNodeOverrideEditor(table));
    return table;
  }



  private String functionalTreeDefaultDisplay(String defaultValue, String projectionText)
  {
    if ( defaultValue == null ) defaultValue = "";
    if ( projectionText == null ) projectionText = "";
    projectionText = projectionText.trim();
    if ( projectionText.length() == 0 ) return defaultValue;
    if ( defaultValue.length() == 0 ) return "LEX(stellend): " + projectionText;
    return defaultValue + " | LEX(stellend): " + projectionText;
  }

  private String functionalTreeDefaultRoleValue(String displayValue)
  {
    if ( displayValue == null ) return "";
    String value = displayValue.trim();
    int bar = value.indexOf("|");
    if ( bar >= 0 ) value = value.substring(0, bar).trim();
    if ( value.startsWith("LEX")) return "";
    return value;
  }

  private String functionalTreeProjectionTextForNode(Graph graph, Node node)
  {
    java.util.Vector labels = new java.util.Vector();
    collectFunctionalTreeLeafLabels(graph, node, labels, new java.util.HashSet());
    if ( labels.size() == 0 )
    {
      String label = node == null ? "" : node.getLabel();
      return label == null ? "" : label;
    }
    StringBuffer buffer = new StringBuffer();
    for ( int i=0; i<labels.size(); i++ )
    {
      if ( i > 0 ) buffer.append(" ");
      buffer.append((String)labels.elementAt(i));
    }
    return buffer.toString();
  }

  private void collectFunctionalTreeLeafLabels(Graph graph, Node node, java.util.Vector labels, java.util.HashSet seen)
  {
    if ( graph == null || node == null || seen.contains(node) ) return;
    seen.add(node);
    java.util.Vector children = functionalTreeChildren(graph, node);
    if ( children.size() == 0 )
    {
      String label = node.getLabel();
      if ( label != null && label.trim().length() > 0 ) labels.addElement(label.trim());
      return;
    }
    for ( int i=0; i<children.size(); i++ )
    {
      collectFunctionalTreeLeafLabels(graph, (Node)children.elementAt(i), labels, seen);
    }
  }

  private java.util.Vector functionalTreeChildren(Graph graph, Node node)
  {
    java.util.Vector result = new java.util.Vector();
    java.util.Vector edges = graph == null ? null : graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge != null && edge.getStartNode() == node && edge.getEndNode() instanceof Node )
      {
        result.addElement((Node)edge.getEndNode());
      }
    }
    sortFunctionalTreeNodesByPosition(result);
    return result;
  }

  private void sortFunctionalTreeNodesByPosition(java.util.Vector nodes)
  {
    for ( int i=0; nodes != null && i<nodes.size(); i++ )
    {
      for ( int j=i+1; j<nodes.size(); j++ )
      {
        Node a = (Node)nodes.elementAt(i);
        Node b = (Node)nodes.elementAt(j);
        if ( functionalTreeNodeComesAfter(a, b) )
        {
          nodes.setElementAt(b, i);
          nodes.setElementAt(a, j);
        }
      }
    }
  }

  private boolean functionalTreeNodeComesAfter(Node a, Node b)
  {
    if ( a == null || b == null ) return false;
    int ay = a.getLocation().intY();
    int by = b.getLocation().intY();
    if ( ay != by ) return ay > by;
    return a.getLocation().intX() > b.getLocation().intX();
  }

  private class FunctionalTreeNodeOverrideEditor extends DefaultCellEditor
  {
    private JTable table;

    FunctionalTreeNodeOverrideEditor(JTable table)
    {
      super(new JComboBox(new String[] { "" }));
      this.table = table;
    }

    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
    {
      JComboBox combo = new JComboBox(functionalTreeOverrideValuesForRow(row));
      combo.setSelectedItem(value == null ? "" : String.valueOf(value));
      delegate = new EditorDelegate()
      {
        public void setValue(Object value)
        {
          ((JComboBox)editorComponent).setSelectedItem(value == null ? "" : String.valueOf(value));
        }

        public Object getCellEditorValue()
        {
          return ((JComboBox)editorComponent).getSelectedItem();
        }
      };
      editorComponent = combo;
      return combo;
    }

    private String[] functionalTreeOverrideValuesForRow(int row)
    {
      String def = "";
      if ( table != null && row >= 0 && row < table.getRowCount() )
      {
        Object defObj = table.getValueAt(row, 3);
        def = defObj == null ? "" : functionalTreeDefaultRoleValue(String.valueOf(defObj));
      }

      if ( def.startsWith("frame/") )
      {
        return functionalTreeFrameOverrideValues();
      }
      return functionalTreeCentralOverrideValues();
    }
  }

  private String[] functionalTreeCentralOverrideValues()
  {
    return new String[] {
      "",
      "top/action", "top/event",
      "pred/process",
      "participant/agens", "participant/patiens", "participant/recipiens",
      "participant/actor/animate", "participant/actor/bezield",
      "participant/actor/inanimate", "participant/actor/onbezield",
      "participant/ervaarder", "participant/fenomeen", "participant/zegger", "participant/bewoording",
      "participant/drager", "participant/eigenschap", "participant/bestaande"
    };
  }

  private String[] functionalTreeFrameOverrideValues()
  {
    return new String[] {
      "",
      "frame/instrument", "frame/locatief", "frame/plaats", "frame/tijd", "frame/richting",
      "frame/bron", "frame/doel", "frame/manier", "frame/oorzaak", "frame/reden", "frame/motief", "frame/duur"
    };
  }

  private boolean isFunctionalTreeNonTerminal(Graph graph, Node node)
  {
    if ( graph == null || node == null ) return false;
    java.util.Vector edges = graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge != null && edge.getStartNode() == node ) return true;
    }
    return false;
  }

  private String defaultFunctionalTreeProposalForNode(Graph graph, Node node)
  {
    if ( node == null ) return "";
    String label = node.getLabel();
    if ( label == null ) label = "";
    String l = label.trim().toUpperCase();
    if ( l.equals("S") || l.equals("CLAUSE") ) return "top/action";
    if ( l.equals("V") || l.equals("VP") ) return "pred/process";
    if ( l.equals("NP") || l.equals("DP") )
    {
      return isUnderFunctionalVerb(graph, node) ? "participant/patiens" : "participant/agens";
    }
    if ( l.equals("PP") || l.equals("P") ) return "frame/locatief";
    if ( l.equals("ADV") || l.equals("ADVP") ) return "frame/tijd";
    if ( l.equals("AP") || l.equals("ADJP") ) return "participant/eigenschap";
    return "";
  }

  private boolean isUnderFunctionalVerb(Graph graph, Node node)
  {
    if ( graph == null || node == null ) return false;
    Node parent = findFunctionalTreeParent(graph, node);
    while ( parent != null )
    {
      String label = parent.getLabel();
      if ( label != null )
      {
        label = label.trim().toUpperCase();
        if ( label.equals("VP") || label.equals("V") ) return true;
        if ( label.equals("S") || label.equals("CLAUSE") ) return false;
      }
      parent = findFunctionalTreeParent(graph, parent);
    }
    return false;
  }

  private Node findFunctionalTreeParent(Graph graph, Node node)
  {
    java.util.Vector edges = graph == null ? null : graph.getEdges();
    for ( int i=0; edges != null && i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      if ( edge != null && edge.getEndNode() == node && edge.getStartNode() instanceof Node )
      {
        return (Node)edge.getStartNode();
      }
    }
    return null;
  }

  private String functionalTreeResultForNode(Node node)
  {
    if ( node == null ) return "";
    String type = node.getFunctionalTreeNodeType();
    String process = node.getFunctionalTreeProcessType();
    String role = node.getFunctionalTreeRolePath();
    if ( role != null && role.length() > 0 ) return role;
    if ( type != null && type.length() > 0 && process != null && process.length() > 0 ) return type + "/" + process;
    if ( type != null && type.length() > 0 ) return type;
    return "";
  }

  private void applyFunctionalTreeNodeTableOverrides(JTable table)
  {
    if ( table == null || graphEditor == null || graphEditor.getGraph() == null ) return;
    if ( table.isEditing() ) table.getCellEditor().stopCellEditing();
    Graph graph = graphEditor.getGraph();
    for ( int r=0; r<table.getRowCount(); r++ )
    {
      Object idObj = table.getValueAt(r, 0);
      Object overrideObj = table.getValueAt(r, 4);
      int index = Integer.parseInt(String.valueOf(idObj));
      String override = overrideObj == null ? "" : String.valueOf(overrideObj).trim();
      Node node = findFunctionalTreeNodeByIndex(graph, index);
      if ( node == null ) continue;
      if ( override.length() == 0 )
      {
        node.clearFunctionalTreeMetadata();
      }
      else
      {
        applyFunctionalTreeOverrideToNode(node, override);
      }
    }
  }

  private Node findFunctionalTreeNodeByIndex(Graph graph, int index)
  {
    java.util.Vector nodes = graph == null ? null : graph.getNodes();
    for ( int i=0; nodes != null && i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      if ( node != null && node.getIndex() == index ) return node;
    }
    return null;
  }

  private void applyFunctionalTreeOverrideToNode(Node node, String override)
  {
    if ( override.startsWith("top/"))
    {
      node.setFunctionalTreeMetadata("top", override.substring(4), override);
    }
    else if ( override.startsWith("participant/"))
    {
      node.setFunctionalTreeMetadata("participant", "", override);
    }
    else if ( override.startsWith("frame/"))
    {
      node.setFunctionalTreeMetadata("frame", "", override);
    }
    else if ( override.startsWith("pred/"))
    {
      node.setFunctionalTreeMetadata("pred", "", override);
    }
    else
    {
      node.setFunctionalTreeMetadata("", "", override);
    }
  }

  private void rememberCurrentGraphAsFunctionalTreeInputTest()
  {
    try
    {
      Graph graph = graphEditor == null ? null : graphEditor.getGraph();
      if ( graph == null ) return;
      java.io.File dir = new java.io.File("examples/ft-input-testset/runtime");
      dir.mkdirs();
      String name = graph.getFileName();
      if ( name == null || name.length() == 0 ) name = "graph";
      name = name.replace('\\', '_').replace('/', '_').replace(':', '_');
      java.io.File marker = new java.io.File(dir, "README-runtime-inputs.txt");
      java.io.FileWriter out = new java.io.FileWriter(marker, true);
      out.write(name + "\n");
      out.close();
    }
    catch ( Exception ignored )
    {
    }
  }

  private void addFTDialogRow(JPanel panel, GridBagConstraints c, int row, String label, Component field)
  {
    c.gridx = 0;
    c.gridy = row;
    c.gridwidth = 1;
    c.weightx = 0.0;
    panel.add(new JLabel(label), c);
    c.gridx = 1;
    c.weightx = 1.0;
    panel.add(field, c);
  }


  private String[] defaultFunctionalRoleNames()
  {
    return new String[] {
      "pred", "proces", "action", "event", "materieel", "mentaal", "relationeel", "verbaal", "attributief", "identificerend", "gedragsmatig", "existentieel", "existentiëel",
      "participant", "animate", "inanimate", "bezield", "onbezield",
      "actor", "agens", "gever", "nemer", "voeler", "ervaarder", "ontvanger", "recipiënt", "recipiens", "beneficient", "beneficiënt", "zegger", "gedrager",
      "patiens", "thema", "fenomeen", "bewoording", "bestaande", "doel", "object", "natuurlijke oorzaak",
      "frame", "richting", "bron", "plaats", "locatief", "locatie", "tijd", "tijdsduur", "manier", "instrument", "oorzaak", "reden", "motief", "eigenschap"
    };
  }

  private java.util.LinkedHashMap createFunctionalRoleChecklist(Properties props, String propertyKey, boolean coreDefault)
  {
    java.util.LinkedHashMap map = new java.util.LinkedHashMap();
    String defaults = coreDefault
      ? "pred,proces,action,event,actor,agens,patiens,thema,recipiens,ontvanger,ervaarder,voeler,fenomeen,zegger,bewoording,gedrager,bestaande,beneficient,beneficiënt,doel,gever,nemer"
      : "frame,richting,bron,plaats,locatief,locatie,tijd,tijdsduur,manier,instrument,oorzaak,reden,motief,eigenschap,natuurlijke oorzaak";
    java.util.HashSet selected = csvToLowerSet(strProp(props, propertyKey, defaults));
    String[] names = defaultFunctionalRoleNames();
    for ( int i=0; i<names.length; i++ )
    {
      JCheckBox cb = new JCheckBox(names[i]);
      cb.setSelected(selected.contains(names[i].toLowerCase()));
      map.put(names[i], cb);
    }
    return map;
  }

  private java.util.HashSet csvToLowerSet(String csv)
  {
    java.util.HashSet set = new java.util.HashSet();
    if ( csv == null ) return set;
    String[] parts = csv.split(",");
    for ( int i=0; i<parts.length; i++ )
    {
      String v = parts[i].trim().toLowerCase();
      if ( v.length() > 0 ) set.add(v);
    }
    return set;
  }

  private JPanel createFunctionalRoleHierarchyPanel(java.util.LinkedHashMap checks)
  {
    JPanel body = new JPanel(new GridLayout(0, 2, 8, 8));
    body.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

    addFunctionalRoleGroup(body, checks, "PROCES", new String[] {
      "pred", "proces", "action", "event", "materieel", "mentaal", "relationeel", "verbaal", "attributief", "identificerend", "gedragsmatig", "existentieel", "existentiëel"
    });
    addFunctionalRoleGroup(body, checks, "PARTICIPANT", new String[] {
      "participant", "animate", "inanimate", "bezield", "onbezield"
    });
    addFunctionalRoleGroup(body, checks, "ANIMATE / BEZIELD", new String[] {
      "actor", "agens", "gever", "nemer", "voeler", "ervaarder", "ontvanger", "recipiënt", "recipiens", "beneficient", "beneficiënt", "zegger", "gedrager"
    });
    addFunctionalRoleGroup(body, checks, "INANIMATE / ONBEZIELD", new String[] {
      "patiens", "thema", "fenomeen", "bewoording", "bestaande", "doel", "object", "natuurlijke oorzaak"
    });
    addFunctionalRoleGroup(body, checks, "FRAME - RICHTING / STATISCH", new String[] {
      "frame", "richting", "bron", "plaats", "locatief", "locatie", "tijd", "tijdsduur"
    });
    addFunctionalRoleGroup(body, checks, "FRAME - HOE / DYNAMISCH", new String[] {
      "manier", "instrument", "oorzaak", "reden", "motief", "eigenschap"
    });

    return body;
  }

  private void addFunctionalRoleGroup(JPanel body, java.util.LinkedHashMap checks, String title, String[] roles)
  {
    JPanel group = new JPanel(new GridLayout(0, 2, 4, 1));
    group.setBorder(BorderFactory.createTitledBorder(title));
    for ( int i=0; i<roles.length; i++ )
    {
      JCheckBox box = (JCheckBox)checks.get(roles[i]);
      if ( box != null )
      {
        group.add(box);
      }
    }
    body.add(group);
  }

  private void connectFunctionalRoleChecklistExclusion(final java.util.LinkedHashMap coreChecks,
                                                       final java.util.LinkedHashMap frameChecks)
  {
    for ( java.util.Iterator it = coreChecks.keySet().iterator(); it.hasNext(); )
    {
      final String role = (String)it.next();
      final JCheckBox core = (JCheckBox)coreChecks.get(role);
      final JCheckBox frame = (JCheckBox)frameChecks.get(role);
      if ( core == null || frame == null ) continue;
      core.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( core.isSelected() ) frame.setSelected(false);
        }
      });
      frame.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          if ( frame.isSelected() ) core.setSelected(false);
        }
      });
      if ( core.isSelected() && frame.isSelected() )
      {
        frame.setSelected(false);
      }
    }
  }

  private JPanel createFunctionalRoleChecklistPanel(java.util.LinkedHashMap checks, int columns)
  {
    JPanel panel = new JPanel(new GridLayout(0, columns, 4, 1));
    for ( java.util.Iterator it = checks.values().iterator(); it.hasNext(); )
    {
      panel.add((JCheckBox)it.next());
    }
    return panel;
  }

  private JPanel createFunctionalRoleOverviewPanel(java.util.LinkedHashMap coreChecks, java.util.LinkedHashMap frameChecks)
  {
    JPanel panel = new JPanel(new GridLayout(0, 3, 6, 1));
    panel.add(new JLabel("Role"));
    panel.add(new JLabel("Core"));
    panel.add(new JLabel("Frame"));
    for ( java.util.Iterator it = coreChecks.keySet().iterator(); it.hasNext(); )
    {
      String role = (String)it.next();
      panel.add(new JLabel(role));
      panel.add((JCheckBox)coreChecks.get(role));
      panel.add((JCheckBox)frameChecks.get(role));
    }
    return panel;
  }

  private String selectedFunctionalRolesCsv(java.util.LinkedHashMap checks)
  {
    StringBuffer sb = new StringBuffer();
    for ( java.util.Iterator it = checks.keySet().iterator(); it.hasNext(); )
    {
      String role = (String)it.next();
      JCheckBox cb = (JCheckBox)checks.get(role);
      if ( cb.isSelected() )
      {
        if ( sb.length() > 0 ) sb.append(',');
        sb.append(role);
      }
    }
    return sb.toString();
  }

  private String functionalRoleTableFromChecklist(java.util.LinkedHashMap coreChecks, java.util.LinkedHashMap frameChecks)
  {
    StringBuffer sb = new StringBuffer();
    int rank = 0;
    for ( java.util.Iterator it = coreChecks.keySet().iterator(); it.hasNext(); )
    {
      String role = (String)it.next();
      JCheckBox core = (JCheckBox)coreChecks.get(role);
      JCheckBox frame = (JCheckBox)frameChecks.get(role);
      if ( core.isSelected() )
      {
        sb.append(role).append(",core,true,").append(rank).append(",center\n");
        rank += 10;
      }
      else if ( frame.isSelected() )
      {
        sb.append(role).append(",frame,false,").append(rank).append(",frame\n");
        rank += 10;
      }
    }
    return sb.toString().trim();
  }

  private Properties loadFunctionalTreeProperties()
  {
    Properties merged = new Properties();
    mergePropertiesFromPath(merged, "config/opengraph_defaults.properties");
    mergePropertiesFromPath(merged, "config/opengraph_user.properties");
    mergePropertiesFromPath(merged, "config/opengraphed_user.properties");
    return merged;
  }

  private void mergePropertiesFromPath(Properties target, String path)
  {
    try
    {
      Properties loaded = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(path);
      if ( loaded != null )
      {
        for ( java.util.Enumeration e = loaded.propertyNames(); e.hasMoreElements(); )
        {
          String key = (String)e.nextElement();
          target.setProperty(key, loaded.getProperty(key));
        }
      }
    }
    catch ( IOException ioe )
    {
      // Ignore unreadable optional config files; defaults stay active.
    }
  }

  private String strProp(Properties props, String key, String def)
  {
    String value = props == null ? null : props.getProperty(key);
    if ( value == null || value.trim().length() == 0 ) return def;
    return value.trim();
  }

  private boolean boolProp(Properties props, String key, boolean def)
  {
    String value = props == null ? null : props.getProperty(key);
    if ( value == null ) return def;
    return Boolean.valueOf(value.trim()).booleanValue();
  }

  private int intProp(Properties props, String key, int def)
  {
    try
    {
      String value = props == null ? null : props.getProperty(key);
      if ( value == null ) return def;
      return Integer.parseInt(value.trim());
    }
    catch ( Exception ex )
    {
      return def;
    }
  }

  private String defaultFunctionalRoleTable()
  {
    return "pred,core,true,0,center\n" +
           "agens,core,true,10,left\n" +
           "patiens,core,true,20,right\n" +
           "recipiens,core,true,30,right\n" +
           "instrument,frame,false,40,frame\n" +
           "locatief,frame,false,50,frame\n" +
           "plaats,frame,false,50,frame\n" +
           "tijd,frame,false,60,frame";
  }

  private void applyFunctionalRoleTableToProperties(Properties props, String table)
  {
    if ( props == null || table == null ) return;
    String[] lines = table.split("\\n");
    for ( int i=0; i<lines.length; i++ )
    {
      String line = lines[i].trim();
      if ( line.length() == 0 || line.startsWith("#") ) continue;
      String[] parts = line.split(",");
      if ( parts.length < 5 ) continue;
      String role = parts[0].trim().toLowerCase();
      if ( role.length() == 0 ) continue;
      props.setProperty("functional.layout.role." + role + ".scope", parts[1].trim());
      props.setProperty("functional.layout.role." + role + ".visible", parts[2].trim());
      props.setProperty("functional.layout.role." + role + ".rank", parts[3].trim());
      props.setProperty("functional.layout.role." + role + ".side", parts[4].trim());
    }
  }

  private JPanel createProjectionProfilePanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
    panel.setOpaque(false);
    panel.add(new JLabel("Projecties:"));

    projectionShowCheckBox = createProjectionCheckBox("aan", "Toon/verberg projecties voor het gekozen Tree.");
    panel.add(projectionShowCheckBox);

    projectionLeftCheckBox = createProjectionCheckBox("L", "Linkerprojectie aan/uit.");
    projectionLeftCaptionField = createProjectionCaptionField("LEX", "Caption voor de linkerprojectie.");
    panel.add(projectionLeftCheckBox);
    panel.add(projectionLeftCaptionField);

    projectionRightCheckBox = createProjectionCheckBox("R", "Rechterprojectie aan/uit.");
    projectionRightCaptionField = createProjectionCaptionField("SYNT", "Caption voor de rechterprojectie.");
    panel.add(projectionRightCheckBox);
    panel.add(projectionRightCaptionField);

    projectionTopCheckBox = createProjectionCheckBox("Boven", "Bovenprojectie aan/uit.");
    projectionTopCaptionField = createProjectionCaptionField("pm", "Caption voor de bovenprojectie.");
    panel.add(projectionTopCheckBox);
    panel.add(projectionTopCaptionField);

    projectionBottomCheckBox = createProjectionCheckBox("Onder", "Onderprojectie aan/uit.");
    projectionBottomCaptionField = createProjectionCaptionField("LF", "Caption voor de onderprojectie.");
    panel.add(projectionBottomCheckBox);
    panel.add(projectionBottomCaptionField);

    projectionSaveProfileButton = createOpenGraphButton("Save profile", "Sla deze projectieconfig op voor het gekozen Tree in config/opengraph_user.properties.", new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        saveProjectionProfileFromHeader();
      }
    });
    panel.add(projectionSaveProfileButton);

    updateProjectionProfileControlsFromEditor();
    return panel;
  }

  private JCheckBox createProjectionCheckBox(String text, String toolTip)
  {
    JCheckBox box = new JCheckBox(text);
    box.setFocusable(false);
    box.setOpaque(false);
    box.setToolTipText(toolTip);
    box.setMargin(new Insets(0, 0, 0, 0));
    box.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    return box;
  }

  private JTextField createProjectionCaptionField(String text, String toolTip)
  {
    final JTextField field = new JTextField(text, 4);
    field.setToolTipText(toolTip);
    field.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    field.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        applyProjectionProfileControlsToEditor(false);
      }
    });
    return field;
  }

  private void updateProjectionProfileControlsFromEditor()
  {
    if ( graphEditor == null || projectionShowCheckBox == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    updatingProjectionProfileControls = true;
    try
    {
      projectionShowCheckBox.setSelected(settings.getShowProjections());
      projectionLeftCheckBox.setSelected(settings.getLeftProjectionEnabled());
      projectionRightCheckBox.setSelected(settings.getRightProjectionEnabled());
      projectionTopCheckBox.setSelected(settings.getTopProjectionEnabled());
      projectionBottomCheckBox.setSelected(settings.getBottomProjectionEnabled());

      projectionLeftCaptionField.setText(settings.getLeftProjectionCaption());
      projectionRightCaptionField.setText(settings.getRightProjectionCaption());
      projectionTopCaptionField.setText(settings.getTopProjectionCaption());
      projectionBottomCaptionField.setText(settings.getBottomProjectionCaption());

      boolean enabled = OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType());
      projectionShowCheckBox.setEnabled(enabled);
      projectionLeftCheckBox.setEnabled(enabled);
      projectionRightCheckBox.setEnabled(enabled);
      projectionTopCheckBox.setEnabled(enabled);
      projectionBottomCheckBox.setEnabled(enabled);
      projectionLeftCaptionField.setEnabled(enabled);
      projectionRightCaptionField.setEnabled(enabled);
      projectionTopCaptionField.setEnabled(enabled);
      projectionBottomCaptionField.setEnabled(enabled);
      projectionSaveProfileButton.setEnabled(enabled);
    }
    finally
    {
      updatingProjectionProfileControls = false;
    }
  }

  private void applyProjectionProfileControlsToEditor(boolean persist)
  {
    if ( updatingProjectionProfileControls || graphEditor == null || projectionShowCheckBox == null )
    {
      return;
    }

    OpenGraphProjectionSettings settings = graphEditor.getOpenGraphProjectionSettings();
    if ( !OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) )
    {
      updateProjectionProfileControlsFromEditor();
      return;
    }

    settings.setShowProjections(projectionShowCheckBox.isSelected());
    settings.setLeftProjectionEnabled(projectionLeftCheckBox.isSelected());
    settings.setRightProjectionEnabled(projectionRightCheckBox.isSelected());
    settings.setTopProjectionEnabled(projectionTopCheckBox.isSelected());
    settings.setBottomProjectionEnabled(projectionBottomCheckBox.isSelected());

    settings.setLeftProjectionCaption(projectionLeftCaptionField.getText());
    settings.setRightProjectionCaption(projectionRightCaptionField.getText());
    settings.setTopProjectionCaption(projectionTopCaptionField.getText());
    settings.setBottomProjectionCaption(projectionBottomCaptionField.getText());
    settings.normalize();

    graphEditor.setOpenGraphProjectionSettings(settings);
    graphEditor.setOpenGraphProjectionContextActive(OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()));
    graphEditor.rememberLanguageProjectionSettings(settings);
    graphEditor.update();

    if ( persist )
    {
      saveProjectionProfile(settings);
    }
  }

  private void saveProjectionProfileFromHeader()
  {
    applyProjectionProfileControlsToEditor(false);
    if ( graphEditor == null )
    {
      return;
    }
    saveProjectionProfile(graphEditor.getOpenGraphProjectionSettings());
  }

  private void saveProjectionProfile(OpenGraphProjectionSettings settings)
  {
    if ( settings == null || !OpenGraphProjectionSettings.isProjectionCapableStructureType(settings.getStructureType()) )
    {
      return;
    }

    try
    {
      Properties props = OpenGraphDialogSettingsSupport.loadPropertiesIfExists(OpenGraphGridSettingsIO.USER_SETTINGS_PATH);
      if ( props == null )
      {
        props = new Properties();
      }

      String prefix = "projection.profile." + OpenGraphDialogSettingsSupport.projectionProfileName(settings.getStructureType()) + ".";
      props.setProperty("structure.type", String.valueOf(settings.getStructureType()));
      props.setProperty(prefix + "show", String.valueOf(settings.getShowProjections()));
      props.setProperty(prefix + "left.enabled", String.valueOf(settings.getLeftProjectionEnabled()));
      props.setProperty(prefix + "right.enabled", String.valueOf(settings.getRightProjectionEnabled()));
      props.setProperty(prefix + "top.enabled", String.valueOf(settings.getTopProjectionEnabled()));
      props.setProperty(prefix + "bottom.enabled", String.valueOf(settings.getBottomProjectionEnabled()));
      props.setProperty(prefix + "left.caption", settings.getLeftProjectionCaption());
      props.setProperty(prefix + "right.caption", settings.getRightProjectionCaption());
      props.setProperty(prefix + "top.caption", settings.getTopProjectionCaption());
      props.setProperty(prefix + "bottom.caption", settings.getBottomProjectionCaption());
      props.setProperty(prefix + "left.position", String.valueOf(settings.getLeftProjectionPosition()));
      props.setProperty(prefix + "right.position", String.valueOf(settings.getRightProjectionPosition()));
      props.setProperty(prefix + "top.position", String.valueOf(settings.getTopProjectionPosition()));
      props.setProperty(prefix + "bottom.position", String.valueOf(settings.getBottomProjectionPosition()));
      if ( settings.getStructureType() == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
      {
        props.setProperty(prefix + "verbcluster.order", settings.getLanguageTreeVerbClusterOrder());
        props.setProperty("language.verbcluster.order", settings.getLanguageTreeVerbClusterOrder());
      }

      OpenGraphDialogSettingsSupport.saveProperties(OpenGraphGridSettingsIO.USER_SETTINGS_PATH, props,
        "OpenGraphEd user settings - projection profile updated from header UI");
      JOptionPane.showMessageDialog(this,
        "Projectieprofiel opgeslagen voor " + currentStructureTypeLabel(settings.getStructureType()) + ".",
        "Projection profile", JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( IOException ex )
    {
      System.err.println("[OpenGraph] Could not save projection profile: " + ex);
      ex.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this,
        "Projectieprofiel kon niet worden opgeslagen:\n" + ex.getMessage(),
        "Projection profile", JOptionPane.ERROR_MESSAGE);
    }
  }

  private String currentStructureTypeLabel(int structureType)
  {
    if ( structureTypeCombo != null )
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          return item.toString();
        }
      }
    }
    return "tree " + structureType;
  }

  private void showCurrentTreeTypeExplanation()
  {
    int structureType = currentDisplayedTreeTypeValue();
    String title = "Tree-type: " + currentTreeTypeName(structureType);

    JTextArea area = new JTextArea(currentTreeTypeExplanation(structureType), 24, 74);
    area.setEditable(false);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setCaretPosition(0);

    JScrollPane scrollPane = new JScrollPane(area,
      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
      JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    JOptionPane.showMessageDialog(this,
      scrollPane,
      title,
      JOptionPane.INFORMATION_MESSAGE);
  }

  private int currentDisplayedTreeTypeValue()
  {
    if ( structureTypeCombo != null )
    {
      Object selected = structureTypeCombo.getSelectedItem();
      if ( selected instanceof StructureTypeItem )
      {
        int selectedValue = ((StructureTypeItem)selected).getValue();
        if ( selectedValue != STRUCTURE_ORIGINAL_GRAPH )
        {
          return selectedValue;
        }
      }
    }

    /*
     * Simple has no external projection layer.  Several header refresh paths
     * therefore treat it like a non-projection state and may visually fall
     * back to "origineel".  For the Uitleg button that is wrong: after an
     * explicit user choice of Simple, the explanation must be Simple.
     */
    if ( lastExplicitTreeTypeSelection != STRUCTURE_ORIGINAL_GRAPH )
    {
      return lastExplicitTreeTypeSelection;
    }

    if ( graphEditor == null || !graphEditor.isOpenGraphProjectionContextActive() )
    {
      return STRUCTURE_ORIGINAL_GRAPH;
    }
    return graphEditor.getOpenGraphProjectionSettings().getStructureType();
  }

  private String currentTreeTypeName(int structureType)
  {
    if ( structureType == STRUCTURE_ORIGINAL_GRAPH ) return "origineel";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "Simple";
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ) return "Language";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "Functional";
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "Frame";
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ) return "Anaphor";
    return "onbekend";
  }

  private String currentTreeTypeExplanation(int structureType)
  {
    String newline = System.getProperty("line.separator");
    StringBuffer text = new StringBuffer();

    if ( structureType == STRUCTURE_ORIGINAL_GRAPH )
    {
      text.append("origineel").append(newline).append(newline);
      text.append("Dit toont de huidige OpenGraph-bronnotatie in de editor: de vrije graph met knopen, labels en takken zoals die nu in het venster staat.").append(newline);
      text.append("Het is dus niet automatisch de laatst opgeslagen .graph op schijf. Editorwijzigingen blijven staan.").append(newline);
      text.append("Als er een Draw-resultaat zichtbaar is, verwijdert origineel alleen die renderstap en keert terug naar de actuele bronboom.").append(newline);
      text.append("Voor een echte oudere toestand gebruik je de gewone Back/Undo-toets.").append(newline).append(newline);
      text.append("OpenGraph-notatie:").append(newline);
      text.append("De editorboom is bewust vrijer dan één klassieke boomtekening. Knopen hoeven nog niet in één definitieve projectierichting vast te liggen.").append(newline);
      text.append("Die vrije knopen vormen de werkruimte waaruit OpenGraphEd verschillende projecties kan maken: een compacte Simple-boom, een Language Tree met LEX/SYN/LF, later Functional/Frame/Anaphor.").append(newline);
      text.append("Dezelfde bronnotatie kan dus meerdere lezingen krijgen zonder de graph telkens structureel te herschrijven.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      appendSimpleTreeExplanation(text, newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      text.append("Language").append(newline).append(newline);
      text.append("Language gebruikt dezelfde OpenGraph-bronnotatie als Simple. Lees daarom eerst Simple: daar staat de basisuitleg over vrije knopen, takken, recursieve boxen en projectieruimte.").append(newline).append(newline);

      text.append("Taalboom van het Nederlands:").append(newline);
      text.append("De centrale boom geeft categoriale relaties weer, bijvoorbeeld S/CP, NP/DP, VP, V, N en Det. De woorden zelf staan traditioneel onderaan als eindknopen.").append(newline);
      text.append("De vraag voor een student is: wat doen die woorden daar onder aan de boom? Er is natuurlijk geen zwaartekracht. Die positie is een notatiekeuze.").append(newline);
      text.append("De klassieke boom gebruikt vertakkingen om achteraf de uiting/woordvolgorde te reconstrueren. Bij varianten worden daar vaak transformaties of verplaatsingen aan toegevoegd.").append(newline).append(newline);

      text.append("OpenGraph en LEX:").append(newline);
      text.append("OpenGraph splitst die twee zaken: de centrale graph bewaart de structurele relaties; de LEX-projectie toont de lexicale volgorde van de uiting.").append(newline);
      text.append("Daardoor hoeft de boom niet telkens descriptief te worden verbouwd om een woordvolgorde te verklaren.").append(newline);
      text.append("Als de taklengtes en projectieslots goed verdeeld zijn, levert de LEX-projectie dezelfde leesvolgorde op als de klassieke boom, maar zonder dat de woorden door 'zwaartekracht' onderaan hoeven te hangen.").append(newline).append(newline);

      text.append("Oude notatie tegenover OpenGraph-notatie:").append(newline);
      text.append("In de oude boomnotatie is S-NP,VP een andere lokale structuur dan S-VP,NP. De volgorde zit daar direct in de vertakking ingebakken.").append(newline);
      text.append("In OpenGraph kan dezelfde bronstructuur ruimte houden voor meerdere projecties. LEX bepaalt dan de uitingsvolgorde; SYN kan de categoriale structuur tonen; LF kan de logische projectie tonen.").append(newline).append(newline);

      text.append("LEX-regels als alternatief voor transformaties:").append(newline);
      text.append("Zinstypeknoppen zoals Basis, Bijzin, Stellend, Ja/Nee, WH en Topicalisatie sturen LEX-regels.").append(newline);
      text.append("De V-cluster-keuze, bijvoorbeeld pv-VD of VD-pv, werkt eveneens op de LEX-weergave.").append(newline);
      text.append("Een object, bijvoorbeeld 'man (OBJ)' wanneer zo'n label in de huidige boom staat, kan dus in de LEX-projectie op zijn uitingsplaats verschijnen zonder dat de onderliggende knoop uit de syntactische structuur wordt gesleept.").append(newline).append(newline);

      text.append("SYN en LF:").append(newline);
      text.append("SYN gebruikt de categoriale knopen. LF/logische vorm wordt als aparte projectie beneden getoond wanneer het profiel dat aanzet.").append(newline);
      text.append("De vrije OpenGraph-knopen zijn precies bedoeld om zulke projecties rond dezelfde bronboom te kunnen tonen.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      text.append("Functional").append(newline).append(newline);
      text.append("Komt later inhoudelijker.").append(newline);
      text.append("Voor de basisnotatie: zie Simple. Functional gebruikt dezelfde vrije OpenGraph-bronboom, maar leest knopen functioneel: proces, participant, rol, core/frame.").append(newline);
      text.append("De vrije knopen geven ruimte om naast de centrale boom functionele projecties te plaatsen zonder de bronboom te herschrijven.").append(newline);
      text.append("FT Settings beheert rollen, frame/core-indeling en node-overrides.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      text.append("Frame").append(newline).append(newline);
      text.append("Komt later inhoudelijker.").append(newline);
      text.append("Voor de basisnotatie: zie Simple. Frame gebruikt dezelfde vrije OpenGraph-bronboom, maar reserveert projectieruimte voor frame- en rolstructuur.").append(newline);
      text.append("Het bovenlabel, bijvoorbeeld FRAME, staat horizontaal. De vrije knopen maken het mogelijk frame-informatie buiten de centrale boom te tonen.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      text.append("Anaphor").append(newline).append(newline);
      text.append("Komt later inhoudelijker.").append(newline);
      text.append("Voor de basisnotatie: zie Simple. Anaphor gebruikt dezelfde vrije OpenGraph-bronboom, maar zal anaforische relaties en verwijzingen als aparte projectie tonen.").append(newline);
      text.append("De centrale boom blijft intact; anaforische lijnen of labels worden als projectieve laag toegevoegd.").append(newline);
      appendCurrentTreeElements(text, newline);
      return text.toString();
    }

    return "Onbekend Tree-type.";
  }

  private void appendSimpleTreeExplanation(StringBuffer text, String newline)
  {
    text.append("Simple").append(newline).append(newline);
    text.append("Simple is de basisuitleg voor de OpenGraph-tree-notatie. De uitleg is bedoeld vanuit de vraag van een taalkundige of student: wat stelt zo'n boom eigenlijk voor?").append(newline);
    text.append("De invoer is de actuele editorboom: de vrije graph die nu in het venster staat, inclusief niet-opgeslagen wijzigingen.").append(newline);
    text.append("Simple maakt daar een compacte boomtekening van, zonder LEX-, SYN-, LF-, Functional-, Frame- of Anaphor-projecties.").append(newline).append(newline);

    text.append("1. De traditionele boom als uitgangspunt").append(newline);
    text.append("In een klassieke syntactische boom staan woorden vaak onderaan, als eindknopen. Dat roept een praktische vraag op: wat doen die woorden daar onderaan? Zwaartekracht?").append(newline);
    text.append("Natuurlijk niet. 'Onder' is geen taalkundige eigenschap, maar een conventie van de tekening.").append(newline);
    text.append("De klassieke boom bouwt vertakkingen om de uiting, dus de woordvolgorde, weer te reconstrueren. De boom is daarmee vaak descriptief: hij laat zien hoe de zin achteraf in categorieën en posities kan worden verdeeld.").append(newline);
    text.append("Bij woordvolgordevarianten worden in traditionele analyses vaak extra middelen gebruikt, zoals transformaties, verplaatsingen of lege posities.").append(newline).append(newline);

    text.append("2. Volgorde in de oude notatie").append(newline);
    text.append("In de oude boomnotatie maakt de lokale volgorde direct verschil:").append(newline);
    text.append("- S-NP,VP betekent: onder S staat eerst NP, daarna VP.").append(newline);
    text.append("- S-VP,NP betekent: onder S staat eerst VP, daarna NP.").append(newline);
    text.append("Dat zijn in die notatie twee verschillende boomvormen. De woordvolgorde is dus ingebakken in de vertakking zelf.").append(newline).append(newline);

    text.append("3. OpenGraph-notatie: vrije knopen").append(newline);
    text.append("OpenGraphEd begint niet met één gesloten eindboom. De editor bevat vrije knopen met labels en takken.").append(newline);
    text.append("Die vrije knopen zijn geen gebrek aan structuur. Ze maken juist ruimte: dezelfde bronstructuur kan later verschillende projecties dragen.").append(newline);
    text.append("Denk aan een centrale boom, een LEX-projectie voor woordvolgorde, een SYN-projectie voor categorieën, een LF-projectie voor logische vorm, en later functionele, frame- of anaforische projecties.").append(newline);
    text.append("Simple laat alleen de centrale boom zien. De andere Tree-types gebruiken dezelfde vrije bronnotatie en plaatsen daar projecties omheen.").append(newline).append(newline);

    text.append("4. LEX-projectie in plaats van alles in de boom te stoppen").append(newline);
    text.append("De woorden hoeven in OpenGraph niet door de centrale boom 'naar beneden' te vallen. De lexicale volgorde hoort bij LEX.").append(newline);
    text.append("Als de taklengte en de projectieruimte goed verdeeld zijn, kan de LEX-projectie dezelfde volgorde tonen als de klassieke boomtekening.").append(newline);
    text.append("Het verschil is principieel: de syntactische structuur blijft staan, terwijl de uitingsvolgorde op de LEX-lijn wordt getoond.").append(newline);
    text.append("Daarmee worden LEX-regels een alternatief voor transformaties: niet de boom wordt herschreven, maar de lexicale projectie wordt bepaald.").append(newline).append(newline);

    text.append("5. Minimum kindtakken").append(newline);
    text.append("Een knoop heeft 0 kindtakken of minimaal 2 kindtakken.").append(newline);
    text.append("0 kindtakken betekent: eindknoop/terminaal element.").append(newline);
    text.append("1 kindtak is fout: een tak onder een tak is geen geldige boomvertakking in deze OpenGraph-tree-weergave.").append(newline);
    text.append("Richting is hierbij irrelevant. Alleen het aantal kindtakken telt.").append(newline).append(newline);

    text.append("6. Binair en n-air").append(newline);
    text.append("2 kindtakken geeft een binaire vertakking.").append(newline);
    text.append("3, 4 of meer kindtakken geeft een n-air vertakking.").append(newline);
    text.append("De boom hoeft dus niet kunstmatig naar alleen binaire vertakkingen te worden teruggebracht.").append(newline);
    text.append("Waar je wel binair wilt testen, stel je Branches = 2 in op de relevante categoriale knoop.").append(newline).append(newline);

    text.append("7. Branches-config per categoriale knoop").append(newline);
    text.append("In de editor kun je via Branches kiezen: auto, 2, 3, 4 of many.").append(newline);
    text.append("auto volgt de feitelijke kindtakken in de graph.").append(newline);
    text.append("2 forceert een binaire lokale weergave; 3 en 4 geven vaste n-air slots; many laat bredere n-air vertakkingen toe.").append(newline);
    text.append("Deze config hoort bij de bronknopen en geldt voor alle Tree-types, niet alleen voor Simple.").append(newline).append(newline);

    text.append("8. Recursieve box-aanpak").append(newline);
    text.append("Simple tekent van onder naar boven. Elke subboom krijgt eerst een denkbeeldige box met breedte, hoogte, wortelpunt en kindposities.").append(newline);
    text.append("Daarna combineert de ouder de boxen van zijn kinderen compact naast elkaar en plaatst zichzelf erboven.").append(newline);
    text.append("De box is geen zichtbare rechthoek. Het is een layout-hulpmiddel dat subbomen tegen overlap beschermt en lege horizontale of verticale gridlijnen beperkt.").append(newline);
    text.append("Voor n-air knopen wordt dezelfde box-logica gebruikt: meerdere kindboxen worden als één compacte groep onder de ouder geplaatst.").append(newline).append(newline);

    text.append("9. Waarom Simple belangrijk is").append(newline);
    text.append("Simple is de controlelaag voor de vrije OpenGraph-bron: klopt de graph als boom, zijn er geen 1-kindknoopfouten, en kan de structuur compact worden getekend?").append(newline);
    text.append("Als Simple klopt, is er een stabiele basis waarop Language, Functional, Frame en Anaphor hun projecties kunnen plaatsen.").append(newline);
  }

  private void appendCurrentTreeElements(StringBuffer text, String newline)
  {
    Graph graph = graphEditor == null ? null : graphEditor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 )
    {
      return;
    }

    java.util.Vector terminals = new java.util.Vector();
    java.util.Vector categories = new java.util.Vector();
    java.util.Vector marked = new java.util.Vector();

    for ( int i=0; i<graph.getNumNodes(); i++ )
    {
      Node node = graph.getNodeAt(i);
      if ( node == null ) continue;
      String label = cleanTreeExplanationLabel(node.getLabel());
      if ( label.length() == 0 ) continue;

      if ( label.indexOf('(') >= 0 || label.indexOf('[') >= 0 || label.indexOf(':') >= 0 )
      {
        addUniqueLimited(marked, label, 16);
      }

      if ( isLikelyTreeCategoryLabel(label) )
      {
        addUniqueLimited(categories, label, 16);
      }
      else
      {
        addUniqueLimited(terminals, label, 16);
      }
    }

    text.append(newline).append("Huidige boom:").append(newline);
    text.append("- knopen: ").append(graph.getNumNodes()).append("; takken: ").append(graph.getNumEdges()).append(newline);
    if ( categories.size() > 0 )
    {
      text.append("- categoriale knopen: ").append(joinVector(categories)).append(newline);
    }
    if ( terminals.size() > 0 )
    {
      text.append("- elementen/eindlabels: ").append(joinVector(terminals)).append(newline);
    }
    if ( marked.size() > 0 )
    {
      text.append("- elementen met rol/markering: ").append(joinVector(marked)).append(newline);
    }
  }

  private String cleanTreeExplanationLabel(String label)
  {
    return label == null ? "" : label.trim();
  }

  private void addUniqueLimited(java.util.Vector vector, String value, int limit)
  {
    if ( value == null || value.length() == 0 ) return;
    if ( vector.contains(value) ) return;
    if ( vector.size() < limit )
    {
      vector.addElement(value);
    }
    else if ( vector.size() == limit )
    {
      vector.addElement("...");
    }
  }

  private String joinVector(java.util.Vector vector)
  {
    StringBuffer result = new StringBuffer();
    for ( int i=0; vector != null && i<vector.size(); i++ )
    {
      if ( i > 0 ) result.append(", ");
      result.append(vector.elementAt(i));
    }
    return result.toString();
  }

  private boolean isLikelyTreeCategoryLabel(String label)
  {
    if ( label == null ) return false;
    String v = label.trim();
    if ( v.length() == 0 ) return false;
    if ( v.equals("S") || v.equals("CP") || v.equals("VP") || v.equals("DP") ||
         v.equals("NP") || v.equals("PP") || v.equals("AP") || v.equals("V") ||
         v.equals("N") || v.equals("A") || v.equals("P") || v.equals("Det") ||
         v.equals("Comp") || v.equals("PV") || v.equals("VD") )
    {
      return true;
    }
    return v.toUpperCase().equals(v) && v.length() <= 6;
  }

  private JComboBox createStructureTypeCombo()
  {
    final StructureTypeItem[] items = new StructureTypeItem[]
    {
      new StructureTypeItem(STRUCTURE_ORIGINAL_GRAPH, "origineel", "Huidige editorboom zonder Draw-resultaat. Herlaadt niet van schijf; aangepaste editorboom blijft behouden."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_SIMPLE_TREE, "Simple", "Simple tree: compact; binair en n-air via branch-config per categoriale knoop."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE, "Language", "Taalboom Nederlands: LEX-projectie, zinstypeprofielen, V-cluster en projectieprofiel."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE, "Functional", "Functional Tree: functionele rollen, role_box layout, projectiegestuurd."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_FRAME, "Frame", "Frame: rol-/functiestructuur met eigen projectieprofiel."),
      new StructureTypeItem(OpenGraphDialog.STRUCTURE_ANAPHOR_TREE, "Anaphor", "Anaphor: anaforische/projectieve structuur.")
    };
    final JComboBox combo = new JComboBox(items);
    combo.setFocusable(false);
    combo.setToolTipText("Tree. Volgorde: origineel, Simple, Language, Functional, Frame, Anaphor. Origineel toont de huidige editorboom zonder Draw-resultaat; geen reload van schijf.");
    combo.setRenderer(new DefaultListCellRenderer()
    {
      public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
      {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if ( value instanceof StructureTypeItem )
        {
          StructureTypeItem item = (StructureTypeItem)value;
          setText(item.toString());
          list.setToolTipText(item.getToolTip());
        }
        return this;
      }
    });
    combo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if ( updatingStructureTypeCombo )
        {
          return;
        }
        Object selected = combo.getSelectedItem();
        if ( selected instanceof StructureTypeItem )
        {
          int value = ((StructureTypeItem)selected).getValue();
          lastExplicitTreeTypeSelection = value;
          if ( value == STRUCTURE_ORIGINAL_GRAPH )
          {
            graphController.restoreOriginalOpenGraphTree(GraphEditorWindow.this);
          }
          else
          {
            graphController.applyOpenGraphStructureType(GraphEditorWindow.this, value);
          }
        }
      }
    });
    return combo;
  }

  private static class StructureTypeItem
  {
    private final int value;
    private final String label;
    private final String toolTip;

    StructureTypeItem(int value, String label, String toolTip)
    {
      this.value = value;
      this.label = label;
      this.toolTip = toolTip;
    }

    int getValue()
    {
      return value;
    }

    String getToolTip()
    {
      return toolTip;
    }

    public String toString()
    {
      return label;
    }
  }

  private JToggleButton createZinstypeButton(String text, final String zinstype)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 6, 2, 6));
    button.setFocusable(false);
    button.setToolTipText(buildZinstypeToolTip(zinstype));
    if ( zinstypeButtonGroup != null )
    {
      zinstypeButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeZinstype(GraphEditorWindow.this, zinstype);
          updateZinstypeButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  private String buildZinstypeToolTip(String zinstype)
  {
    OpenGraphProjectionSettings settings = graphEditor == null ? new OpenGraphProjectionSettings() : new OpenGraphProjectionSettings(graphEditor.getOpenGraphProjectionSettings());
    settings.setLanguageTreeZinstype(zinstype);
    String[] lines = settings.getLanguageTreeZinstypeRulePreviewLines();
    StringBuffer html = new StringBuffer("<html><b>Zinstype: ");
    html.append(settings.getLanguageTreeZinstypeDisplayName());
    html.append("</b><br>");
    html.append("Language Tree / Phrase; geen Frame. DS blijft staan, regels werken op de LEX-as.<br><br>");
    for ( int i=0; i<lines.length; i++ )
    {
      if ( lines[i] != null && lines[i].trim().length() > 0 )
      {
        html.append("&#8226; ").append(lines[i]).append("<br>");
      }
    }
    if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(settings.getLanguageTreeZinstype()) )
    {
      html.append("<br>Klik eerst een categoriale knoop, bijvoorbeeld NP of DP.<br>");
      html.append("De lexicale vorm wordt als frase getoond, bijvoorbeeld NP(de man).");
    }
    html.append("</html>");
    return html.toString();
  }

  private JPanel createVerbClusterPanel()
  {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    panel.setOpaque(false);
    JLabel label = new JLabel("V:");
    label.setToolTipText("V-cluster voor Language Tree: lokale vertakking/volgorde binnen V. Projectie blijft terminale knoop -> LEX-as.");
    panel.add(label);

    verbClusterButtonGroup = new ButtonGroup();
    pvVdVerbClusterButton = createVerbClusterButton("pv-VD", OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD,
      "heeft gebeten: pv kort/eerst, VD lang/tweede");
    vdPvVerbClusterButton = createVerbClusterButton("VD-pv", OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV,
      "gebeten heeft: VD kort/eerst, pv lang/tweede");
    panel.add(pvVdVerbClusterButton);
    panel.add(vdPvVerbClusterButton);
    return panel;
  }

  private JToggleButton createVerbClusterButton(String text, final String order, String toolTip)
  {
    JToggleButton button = new JToggleButton(text);
    button.setMargin(new Insets(2, 6, 2, 6));
    button.setFocusable(false);
    button.setToolTipText("<html><b>V-cluster " + text + "</b><br>" + toolTip + "<br>Alleen Language Tree / Phrase. De DS-projecties blijven onveranderd.</html>");
    if ( verbClusterButtonGroup != null )
    {
      verbClusterButtonGroup.add(button);
    }
    button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          graphController.applyLanguageTreeVerbClusterOrder(GraphEditorWindow.this, order);
          updateVerbClusterButtonSelection();
          updateStructureTypeComboSelection();
        }
      });
    return button;
  }

  public void updateVerbClusterButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String order = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeVerbClusterOrder();
    if ( OpenGraphProjectionSettings.VERB_CLUSTER_VD_PV.equals(order) && vdPvVerbClusterButton != null )
    {
      vdPvVerbClusterButton.setSelected(true);
    }
    else if ( pvVdVerbClusterButton != null )
    {
      pvVdVerbClusterButton.setSelected(true);
    }
  }

  public void updateZinstypeButtonSelection()
  {
    if ( graphEditor == null )
    {
      return;
    }
    String zinstype = graphEditor.getOpenGraphProjectionSettings().getLanguageTreeZinstype();
    if ( OpenGraphProjectionSettings.ZINSTYPE_BIJZIN.equals(zinstype) && bijzinZinstypeButton != null )
    {
      bijzinZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_STELLEND.equals(zinstype) && stellendZinstypeButton != null )
    {
      stellendZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_JA_NEE.equals(zinstype) && jaNeeZinstypeButton != null )
    {
      jaNeeZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_WH.equals(zinstype) && whZinstypeButton != null )
    {
      whZinstypeButton.setSelected(true);
    }
    else if ( OpenGraphProjectionSettings.ZINSTYPE_TOPICALISATIE.equals(zinstype) && topicalisatieZinstypeButton != null )
    {
      topicalisatieZinstypeButton.setSelected(true);
    }
    else if ( basisZinstypeButton != null )
    {
      basisZinstypeButton.setSelected(true);
    }
  }

  public void updateStructureTypeComboSelection()
  {
    if ( graphEditor == null || structureTypeCombo == null )
    {
      return;
    }
    int structureType = graphEditor.isOpenGraphProjectionContextActive() ?
      graphEditor.getOpenGraphProjectionSettings().getStructureType() :
      (lastExplicitTreeTypeSelection != STRUCTURE_ORIGINAL_GRAPH ? lastExplicitTreeTypeSelection : STRUCTURE_ORIGINAL_GRAPH);
    updatingStructureTypeCombo = true;
    try
    {
      for ( int i=0; i<structureTypeCombo.getItemCount(); i++ )
      {
        Object item = structureTypeCombo.getItemAt(i);
        if ( item instanceof StructureTypeItem && ((StructureTypeItem)item).getValue() == structureType )
        {
          structureTypeCombo.setSelectedIndex(i);
          return;
        }
      }
    }
    finally
    {
      updatingStructureTypeCombo = false;
    }
  }

  public void updateOpenGraphHeaderControls()
  {
    updateZinstypeButtonSelection();
    updateVerbClusterButtonSelection();
    updateStructureTypeComboSelection();
    updateProjectionProfileControlsFromEditor();
    updateOpenGraphHeaderControlsVisibility();
  }

  private void updateOpenGraphHeaderControlsVisibility()
  {
    if ( graphEditor == null )
    {
      return;
    }
    int structureType = graphEditor.isOpenGraphProjectionContextActive() ?
      graphEditor.getOpenGraphProjectionSettings().getStructureType() : STRUCTURE_ORIGINAL_GRAPH;
    boolean isOriginalTree = structureType == STRUCTURE_ORIGINAL_GRAPH;
    boolean isLanguageTree = structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    if ( zinstypePanel != null )
    {
      zinstypePanel.setVisible(isLanguageTree);
    }
    if ( verbClusterPanel != null )
    {
      verbClusterPanel.setVisible(isLanguageTree);
    }
    if ( languageTreeSettingsButton != null )
    {
      languageTreeSettingsButton.setVisible(isLanguageTree);
    }
    boolean isFunctionalTree = structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE;
    if ( functionalTreeSettingsButton != null )
    {
      functionalTreeSettingsButton.setVisible(isFunctionalTree);
    }
    if ( projectionProfilePanel != null )
    {
      projectionProfilePanel.setVisible(OpenGraphProjectionSettings.isProjectionCapableStructureType(structureType));
    }
    if ( openGraphDrawButton != null )
    {
      openGraphDrawButton.setVisible(!isOriginalTree && !isLanguageTree);
    }
    revalidate();
    repaint();
  }


  private JButton createOpenGraphButton(String text, String toolTip, ActionListener listener)
  {
    JButton button = new JButton(text);
    button.setMargin(new Insets(2, 8, 2, 8));
    button.setFocusable(false);
    button.setToolTipText(toolTip);
    button.addActionListener(listener);
    return button;
  }

  public void dispose()
  {
    graphEditor.prepareForClose();
    super.dispose();
  }

  public GraphEditor getGraphEditor()
  {
    return graphEditor;
  }

  public GraphEditorDialog getDialog() { return ged; }

  public void setDialog(GraphEditorDialog d) { ged = d; }

  public GraphEditorInfoWindow getInfoWindow()
  {
    return infoWindow;
  }
  
  public GraphEditorLogWindow getLogWindow()
  {
    return logWindow;
  }  
}