# OpenGraphEd

Legacy Java graph editor (2004) restored and refactored to run on modern Java.

## Status

This repository is currently based on the stable refactor baseline:

**OpenGraphEd_refactor_phase33_pq_lifecycle_support_2026-04-02**

This version has been verified as the current stable baseline after a long refactor series.

## What this baseline includes

The codebase has been substantially refactored in the following areas:

- application naming migrated to **OpenGraphEd**
- controller layer reduced and split into focused helpers
- window and dialog handling cleaned up
- file actions isolated
- editor support split into:
  - layout/grid support
  - render/transform support
  - mode/listener support
  - overlay support
- menu and toolbar logic reduced and split into helpers
- `Graph`, `Node`, and `Edge` significantly decomposed into focused support classes
- several operation classes refactored into orchestration + support structures
- partial non-critical cleanup of `PQNode` and `PQTree`

## Important note about scope

The deep PQ reduction core was **intentionally not fully refactored further**.

This was a deliberate decision to preserve stability in the most sensitive algorithmic part of the application.

## Regression note

During the refactor process, a display regression was found in the biconnectivity flow.

That issue was traced to the extracted support logic for biconnected component construction and was corrected. The stable baseline in this repository includes that fix.

## Run

You can run the application either from the built jar or by using the batch scripts.

### Run existing build

```bat
OpenGraphEd.bat
```

or

```bat
run.bat
```

or

```bat
java -jar OpenGraphEd.jar
```

### Open a specific `.graph` file directly

These now work:

```bat
OpenGraphEd.bat "C:\pad\naar\bestand.graph"
```

or

```bat
run.bat "C:\pad\naar\bestand.graph"
```

or

```bat
java -jar OpenGraphEd.jar "C:\pad\naar\bestand.graph"
```

At startup, OpenGraphEd opens the supplied `.graph` file directly in an editor window.
If OpenGraphEd is already running from the same folder, later launches forward the file to the existing app window instead of opening a second app instance.

### Windows double-click association for `.graph`

A one-time Windows association script is included:

```bat
register_graph_file_association.bat
```

This registers `.graph` files for the current Windows user so a double-click opens OpenGraphEd and loads that graph.

Files included for this flow:

- `OpenGraphEd.bat`
- `open_graph_file.bat`
- `register_graph_file_association.bat`
- `unregister_graph_file_association.bat`
- `create_desktop_shortcut.bat`

The Windows launcher/display name is set to:

```text
OpenGraphEd (Java, via DOS .batfile)
```

## Build

On Windows:

```bat
build.bat
```

After building, the compiled output is available in:

```text
out\
```

The repository also includes the packaged runtime jar:

```text
OpenGraphEd.jar
```

## Basic structure

```text
dataStructure/                core data structures
graphStructure/               graph model
operation/                    graph algorithms and operations
userInterface/                Swing UI
userInterface/menuAndToolBar/ menus and toolbar helpers
userInterface/modes/          editor interaction modes
images/                       toolbar and UI images
help/                         HTML help pages
config/                       configuration and persisted dialog settings
docs/                         historical PDF material
out/                          compiled classes and copied runtime resources
```

## Notes

The original code used several legacy patterns and obsolete APIs.
The refactor baseline includes many internal cleanups while preserving behavior as much as possible.

Examples of preserved behavior that were explicitly checked during the refactor process:

- undo / redo
- render state after undo
- display flows
- dialog/window interaction
- save/load
- graph editing operations

## Recommended maintenance approach

For future work, prefer:

- small refactor steps
- build after every step
- functional checks after every step
- extra care in PQ-tree and embedding-related code

Recommended areas for safe future cleanup:

- documentation
- changelog / release notes
- small UI helpers
- isolated utility methods

Areas to treat as high risk:

- PQ reduction logic
- PQ templates
- deep embedding core behavior

## License / origin

This repository contains a restored legacy Java graph editor codebase with targeted modernization and refactoring for current Java environments.


## Build note on Windows

If `OpenGraphEd.jar` is currently running, Windows may lock that file. In that case `build.bat` now still refreshes `out\` and writes a fallback jar as `OpenGraphEd.new.jar` instead of failing the whole build.

Build note for Windows:
- Local launching uses freshly compiled classes from `out\` when available.
- Packaging jars are written first to `dist\OpenGraphEd.jar`.
- If Windows blocks copying a jar into the project root, local app use still works.

## Mapping V3 core stable checkpoint

Mapping V3 core is marked as `MAPPING_V3_CORE_STABLE` in `md/sources/mapping-v3/current-state.md`.

The stable core covers:

- Agens
- Patiens
- RECIPIENT
- THEME
- V
- V-AUX
- V-PART
- split VP: `V-AUX ... V-PART`

Current regression status:

```text
Mapping V3 regression: 13 pass, 0 fail
MD folder check: PASS
```

WH, NEG, TIME/PLACE, DET, FRAME.graph, lexicon and UI/rendering are later phases.

## Mapping V4.0 scope freeze

Mapping V4 has started as a documentation-only scope-freeze phase:

```text
MAPPING_V4_SCOPE_FREEZE
```

V4.0 preserves the Mapping V3 core stable checkpoint and adds V4 planning/source documentation only.

No Java code, class files, jar files, generator, validator, parser, UI, rendering, or example semantics are changed in V4.0.

The package now also includes an md-only sources zip under:

```text
md/sources-md-zip/
```

This zip is intended for manual upload to Project Sources and for source-state verification.
