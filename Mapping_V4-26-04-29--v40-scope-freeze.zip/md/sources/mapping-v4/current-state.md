# Current State (Mapping V4)

Status:

```text
MAPPING_V4_SCOPE_FREEZE
```

## Phase

V4.0 is documentation-only.

## In scope for V4.0

- Start Mapping V4 from the stable Mapping V3 core checkpoint.
- Preserve the Mapping V3 core as the regression baseline.
- Add V4 source documentation under `md/sources/mapping-v4/`.
- Add a V4 phase manifest under `md/meta-inf/`.
- Record the packaging rule for the md-only sources zip.
- Keep all `.md` files under `md/`.

## Not in scope for V4.0

- Java code changes
- `.class` rebuilds
- generator changes
- validator changes
- OPN parser changes
- UI changes
- rendering changes
- graph mutation behavior
- new mapping examples
- new expected-output manifests
- new checker behavior

## Preserved V3 core

The V3 stable core remains:

- Agens
- Patiens
- RECIPIENT
- THEME
- V
- V-AUX
- V-PART
- split VP: `V-AUX ... V-PART`

## Still outside the stable core

These remain later V4 phases, not part of V4.0:

- NEG
- TIME / PLACE
- WH / vraagzinnen
- DET / lidwoorden
- FRAME.graph
- lexicon
- UI/rendering/view-options

## Architecture rule

The V3 architecture remains binding in V4.0:

```text
STRUCTURE = view
MAPPING_V3 = logica
MAPPING_V4 = planned extension layer
geen graph-mutatie
output via generator
validatie en generatie via de lexicale as
```

## Test baseline

The expected V4.0 validation result is unchanged from V3.10:

```text
Mapping V3 regression: 13 pass, 0 fail
MD folder check: PASS
```
