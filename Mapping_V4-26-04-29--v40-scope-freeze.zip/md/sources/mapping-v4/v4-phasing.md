# Mapping V4 Phasing

## Phase rule

V4 must advance in small, separately testable phases.

Each phase should end with:

```text
Mapping V3 regression: pass
MD folder check: PASS
phase examples present when behavior changes
phase expected-output / expected-fail manifests present when behavior changes
```

## V4.0 — Scope freeze and test basis

Status: current phase.

Purpose:

- establish V4 documentation
- freeze the V3 core baseline
- define phase order
- add packaging rule for the md-only sources zip

No code changes.

## V4.1 — NEG / TIME / PLACE

Purpose:

- promote selected non-core adverbial and negation behavior into a controlled V4 layer
- define exact placement rules and diagnostics

Candidate scope:

- NEG
- TIME
- PLACE
- bijwoordplaatsing
- valid examples
- invalid examples
- expected-output and expected-fail manifests

Explicitly not combined with:

- WH
- DET
- FRAME.graph

## V4.2 — DET / simple NP expansion

Purpose:

- add controlled handling of determiners and simple nominal groups

Candidate scope:

- DET
- simple NP-internal placement
- relation between DET and nominal argument role
- output with lidwoorden

Explicitly not combined with:

- complex NP
- adjectives
- relative clauses
- WH

## V4.3 — WH / vraagzinnen

Purpose:

- add question mode after core declarative and simple NP/adverbial extensions are stable

Candidate scope:

- WH role(s)
- question-mode flag or relation
- simple WH-positioning
- diagnostics for incomplete WH structures

Explicitly not combined with:

- FRAME.graph
- broad UI redesign

## V4.4 — FRAME.graph

Purpose:

- define FRAME.graph as a separate architectural layer before implementation

Candidate scope:

- formal definition of FRAME.graph
- relation to `STRUCTURE`
- relation to `MAPPING_V3` / future `MAPPING_V4`
- examples
- checker expansion

## V4.5 — Lexicon layer

Purpose:

- separate lexical data from individual examples after roles and placement are stable

Candidate scope:

- lexical items
- lemma / form / role coupling
- minimal feature fields

Explicitly not in first lexicon phase:

- broad morphology
- inflection engine
- language-wide lexicon

## V4.6 — UI / rendering / view options

Purpose:

- expose mapping diagnostics and view options after semantics are stable

Candidate scope:

- visible mapping diagnostics
- view toggle for mapping layer
- vertical lexical axis option

Preserved rule:

```text
No graph mutation as a consequence of mapping logic.
```
