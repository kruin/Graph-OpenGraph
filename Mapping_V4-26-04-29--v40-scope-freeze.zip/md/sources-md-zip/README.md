# MD-only sources zip

This directory contains an md-only sources zip for manual upload to Project Sources.

Rule:

```text
Every project zip must include an md-only sources zip containing all Markdown files included in the package, preserving their relative paths.
```

The zip is not used by the Java runtime.

It is a packaging and project-source recovery artifact.
