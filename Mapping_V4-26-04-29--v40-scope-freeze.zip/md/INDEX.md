# MD index

Alle markdown-documentatie in deze zip staat onder deze map.

## Hoofdmap

- `README.md` — oorspronkelijke project-README
- `CHANGELOG.md` — wijziglog

## Mapping-bronnen

- `sources/mapping-v3/` — actuele project-/mappingbronnen

## Meta-notities

- `meta-inf/` — fase-notities en tijdelijke placeholders
- `meta-inf/frame_md.tmp` — placeholder voor latere Frame/WH/DET/NEG/uitingstype-fasen

## Voorbeelden

- `examples/opn/mapping-v3-expected-output-manifest.md` — expected-output manifest

## Afspraak

Deze map is documentatie/config-context. De runtime-code gebruikt de `.opn`, `.java`, `.class`, `.bat` en voorbeeldbestanden buiten deze map.

## Mapping V40

- `md/meta-inf/2026-04-27-mapping-v40-md-folder-check.md`
- `run-md-folder-check.bat`
- `tools/check-md-folder.sh`
- `tools/CheckMdFolder.java`

## Mapping v3.10 stable checkpoint

- `md/meta-inf/2026-04-27-mapping-v310-core-stable-checkpoint.md`
- `md/sources/mapping-v3/current-state.md` — bijgewerkt naar `MAPPING_V3_CORE_STABLE`

## Mapping V4.0 scope freeze

- `md/sources/mapping-v4/README.md` — V4 startnotitie en basisafspraken
- `md/sources/mapping-v4/current-state.md` — actuele V4.0-status
- `md/sources/mapping-v4/v4-phasing.md` — voorgestelde V4-fasering
- `md/sources/mapping-v4/scope-freeze.md` — V4.0 scope-freeze regels
- `md/meta-inf/2026-04-29-mapping-v40-start.md` — V4.0 fase-manifest
- `md/sources-md-zip/README.md` — afspraak over md-only sources zip
- `md/sources-md-zip/Mapping_V4-26-04-29--v40-all-md-sources.zip` — md-only sources zip voor handmatige Project Sources upload
