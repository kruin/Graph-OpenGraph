## 2026-04-29 — Mapping V4.0 scope freeze

### Added
- Added `md/sources/mapping-v4/` as the V4 documentation source area.
- Added V4.0 current-state, phasing and scope-freeze documents.
- Added `md/meta-inf/2026-04-29-mapping-v40-start.md`.
- Added `md/sources-md-zip/` for the embedded md-only sources zip.

### Packaging
- Project zips now include an md-only sources zip containing all Markdown files in the package, preserving relative paths.
- The md-only zip is intended for manual upload to Project Sources and source-state verification.

### Scope
- Documentation/package-only phase.
- No Java code changes.
- No `.class` rebuilds.
- No jar rebuilds.
- No generator, validator, parser, UI, rendering or example-semantics changes.
- Mapping V3 core remains the regression baseline.

### Expected checks
- Mapping V3 regression: `13 pass, 0 fail`.
- MD folder check: `PASS`.

## 2026-04-27 — Mapping V3.7 future phases placeholder

### Added
- extended `meta-inf/frame_md.tmp` with later phases for utterance type / clause mode
- added placeholders for declarative, interrogative, imperative and exclamative utterances
- added placeholders for full vs elliptic utterances
- clarified that WH, negation, DET, TIME/PLACE and FRAME.graph remain outside the current core checker scope

### Scope
- documentation only
- no Java changes
- no mapping-rule changes
- no checker changes

## 2026-04-18 — Move-mode edge midpoint cleanup

### Fixed
- ordinary undirected edge midpoint markers are now hidden while the editor is in **Move** mode
- the suppression applies both to the buffered graph image and to temporary redraw overlays during transforms

### Scope
- directed edge arrows are unchanged
- projection rendering is unchanged
- midpoint markers still remain available outside Move mode

## 2026-04-18 — First projection slice follow-up

### Included
- Sources-led markdown files restored into the package root
- first projection slice refined for phrase trees
- rebuilt `OpenGraphEd.jar` and `dist/OpenGraphEd.jar`

### Changed
- default phrase-tree projections now enable **LEX left** and **SYN right**
- right-side projection labels are now computed from ordered child labels
- simple JAN convention for this slice: first child uppercase, following children lowercase, joined with `, `
- bottom logical projection rendering is limited to source nodes that already carry explicit logical labels
- phrase-tree UI copy updated to describe the current first slice

### Layout
- fitted OpenGraph grid no longer expands the structure grid for projection bands or projection labels
- projection visibility is handled through render/visible bounds rather than structure-grid growth

- 2026-04-17: Moved `Set Default Graph Dir` into the Load Graph dialog accessory and removed the now-redundant File menu item.
- 2026-04-17: Removed the duplicate File menu checkbox for starting Load Graph in the Graph directory. The option remains available in the Load Graph dialog; the separate File menu item was redundant.
# Changelog

## 2026-04-02 — Stable refactor baseline

Stable baseline:

**OpenGraphEd_refactor_phase33_pq_lifecycle_support_2026-04-02**

### Included

#### Naming and packaging
- project naming standardized to **OpenGraphEd**
- runtime jar standardized as `OpenGraphEd.jar`

#### Controller and UI refactor
- controller responsibilities reduced and split into focused helpers
- file actions isolated
- window/dialog coordination isolated
- menu and toolbar heavily reduced and decomposed
- help/info/log/preferences windows simplified

#### Graph editor refactor
- layout/grid support extracted
- render/transform support extracted
- mode/listener support extracted
- overlay support extracted

#### Graph model refactor
- `Graph` decomposed into focused support classes for:
  - median helpers
  - selection helpers
  - copy helpers
  - bounds helpers
  - grid helpers
  - stats helpers
  - lookup helpers
  - transform helpers
  - persistence helpers
  - extender helpers
  - edge mutation helpers
  - appearance helpers
  - undo helpers
  - log helpers
  - property mutation helpers
  - topology helpers
  - structure mutation helpers

#### Node / Edge refactor
- `Node` split into:
  - incident support
  - geometry support
  - persistence support
- `Edge` split into:
  - cycle support
  - geometry support
  - persistence support

#### Operation refactor
- biconnectivity support extracted
- Chan tree draw support extracted
- embed support extracted
- Schnyder embedding support extracted

#### PQ and file utility partial cleanup
- debug support extracted from `PQNode`
- debug support extracted from `PQTree`
- lifecycle/state support extracted from PQ structures
- GIF palette/color conversion support extracted

### Fixed

#### Biconnectivity display regression
- fixed a regression introduced during refactoring of biconnected component support
- cause: temporary `newEdges` collection was not cleared per component
- result: component display/state corruption
- fix applied and included in stable baseline

### Deliberately not continued
- deep PQ reduction core not further refactored
- PQ template logic not further split
- high-risk algorithmic core intentionally left in place for stability

### Validation
The stable baseline was kept only after repeated successful checks of:

- compile
- jar build
- out folder generation
- undo / redo sanity
- render-after-undo behavior
- display flows
- editor interaction flows

## 2026-04-13

### Menu / file loading
- added `File -> Set Default Graph Dir` to choose the default folder for loading `.graph` files
- `File -> Graph Dir` now uses the chosen default graph directory instead of only the built-in `GRAPH` folder
- default graph directory is persisted in `config/opengraphed_user.properties`
- `Load Graph` accessory now shows the active default graph directory

## 2026-04-16

### Graph file click / direct open
- OpenGraphEd can now start with one or more `.graph` file paths as command-line arguments
- added shared path-based graph loading so startup and file chooser use the same open logic
- updated `run.bat` so `run.bat "bestand.graph"` opens that graph directly
- added `open_graph_file.bat` as a dedicated launcher for a specific `.graph` file
- added `register_graph_file_association.bat` and `unregister_graph_file_association.bat` for Windows double-click association of `.graph` files

### Internal OpenGraph rename
- renamed the internal `Kruin*` module/class/config layer to `OpenGraph*`
- kept the GitHub owner/account name `kruin` unchanged
- renamed OpenGraph settings/config files to `config/opengraph_defaults.properties` and `config/opengraph_user.properties`
- updated source lists, tests, UI labels, dialog titles, grid/projection helpers, and draw operations to the OpenGraph naming line
- rebuilt the project so `out/` and `OpenGraphEd.jar` match the renamed sources

## 2026-04-16 — graph click single-instance fix

- added single-instance forwarding for launches from the same app folder
- later `.graph` double-clicks now open in the existing OpenGraphEd window instead of starting a second app instance
- added `OpenGraphEd.bat` as the named launcher
- updated Windows `.graph` association to use the launcher name `OpenGraphEd (Java, via DOS .batfile)`
- added `create_desktop_shortcut.bat` to create a desktop shortcut with that display name


- 2026-04-17: build.bat made resilient on Windows when OpenGraphEd.jar is locked by a running app; build now keeps refreshed classes in out\ and writes OpenGraphEd.new.jar as fallback instead of failing the whole build.

- 2026-04-17: Move mode in OpenGraph projection context now shifts the visible grid display window together with the graph so projection bands and markers stay attached during drag.

- 2026-04-17: OpenGraph projection labels phase 1 added visible side captions (LEX/SYN/LF/PM) and copied source labels on projection targets; bottom labels now render downward.

- 2026-04-18: projection caption orientation updated: LEX vertical on the left; LF horizontal below projected labels.

## 2026-04-26 — OPN structure loader fix

- Fixed `Open OPN` so metadata is not drawn as graph nodes.
- Current supported demo/test OPN formats:
  - YAML-like `structure.nodes` / `structure.edges`
  - older pipe-delimited `STRUCTURE_NODES` / `STRUCTURE_EDGES`
- `meta`, `notes`, `OPN_VERSION`, and `STRUCTURE_TYPE` are not graph content.
- Included example OPN files for ONBEZIELD bovenboom and the V-centered example sentence.

## 2026-04-26 - OPN mapping v1 visibility
- Added non-drawing support for `MAPPING_V1` sections in pipe-safe OPN files.
- `Open OPN` still draws only `STRUCTURE_NODES` / `STRUCTURE_EDGES`.
- Mapping sections are counted and reported in the Info window as OPN Mapping v1 metadata.
- Added mapping-v1 example OPN files under `examples/opn/mapping-v1/`.

## 2026-04-26 — OPN placement rules v2
- Generalized generator: generated utterance is now derived from `PLACEMENT_RULES` ordering constraints instead of hardcoded role sequence.
- Supported `MAPPING_V2:` / `END_MAPPING_V2:` markers while preserving `MAPPING_V1:` compatibility.
- Current v2 rule relations: `left_of V`, `right_of V`, `realizes_before`, `realizes_after`, plus aliases `before` and `after`.
- Added `examples/opn/mapping-v2/` with the same three views using the v2 markers.

## 2026-04-26 - adverbs-v2 example
- Added mapping-v2 adverb example with TIME, NEG and PLACE lexical items.
- Existing data-driven placement-rule engine is used; graph nodes are not mutated.

2026-04-26: mapping v3 NEG constraint upgraded to after_aux_before_object (V-AUX < NEG < Patiens).

## 2026-04-27 — Mapping V3.1 ranking en alternatieven

- V3-generator bouwt nu expliciete alternatieve kandidaten op basis van ranked placement rules.
- Alternatieven worden stabiel gerangschikt, gededupliceerd en begrensd tot maximaal 3 in Info.
- Niet-oplosbare ordering-constraints worden niet meer als fallback-volgorde gegenereerd; zulke kandidaten vallen weg.
- Toegevoegd: beperkte combinatie van ranked opties voor meerdere argumenten.
- Toegevoegd: ondersteuning voor `before_clause` en `after_clause` als placement-relaties.
- Scope: geen UI- of graph-renderingwijzigingen.


## 2026-04-27 — Mapping V3.2 argumenten en placement-resolutie

- V3-placementregels ondersteunen nu compacte spec-spelling:
  - `left_of_V` / `right_of_V`
  - `before_Theme` / `before_V_PART`
  - `before_clause` / `after_clause`
  - `anchor` / `clause_end`
- Generator/validator normaliseren role-targets robuuster, onder meer `Theme` ↔ `THEME` en `V_PART` ↔ `V-PART`.
- `after_aux_before_object` heeft nu een veilige default naar `Patiens` wanneer geen target is opgegeven, maar kan ook expliciet op `THEME` worden toegepast.
- `clause_end` wordt generatorisch behandeld zonder conflict met `after_clause`-rollen zoals PLACE.
- Toegevoegd: compact V3.2 voorbeeld met TIME, NEG, RECIPIENT, THEME, V-PART en PLACE.
- Scope: geen UI- of graph-renderingwijzigingen.

## 2026-04-27 — Mapping V3.3 core regressie

- Toegevoegd: kern-regressieset onder `examples/opn/mapping-v3-core/`.
- V3.3-scope aangescherpt tot declaratieve kernmapping: Agens, Patiens, RECIPIENT, THEME, V, V-AUX en V-PART.
- Gesplitste VP blijft in scope: `heeft ... gebreid/gegeven`.
- Vraagzinnen/WH, negatie, TIME/PLACE-bijwoorden, DET-splitsing en FRAME.graph zijn expliciet on hold gezet.
- Toegevoegd: `meta-inf/frame_md.tmp` als placeholder voor latere fasen.
- Scope: geen Java-, UI- of graph-renderingwijzigingen.

## 2026-04-27 — Mapping v3.4 core invalid diagnostics

- Added invalid Mapping V3 regression examples under `examples/opn/mapping-v3-core-invalid/`.
- Open OPN now reports Mapping V3 validation diagnostics in the Info window.
- Invalid Mapping V3 summaries include the loaded file name in the validation details.
- Generation is suppressed for invalid mappings: `generated: none (invalid mapping)`.
- Diagnostics added for missing role, unknown role, missing targets, ordering cycles, broken verb-domain references, duplicate lexical ids, and missing V anchors.

## 2026-04-27 - Mapping v3.4 invalid dialog

- Invalid `MAPPING_V3` bij open `.opn` toont nu direct een modal melding met OK-knop.
- De melding noemt de loadfile en verwijst naar het Info-scherm.
- Het Info-scherm wordt automatisch geopend/bijgewerkt voor de volledige diagnose.
- Geen wijziging aan mappingregels of rendering.

## 2026-04-27 - Mapping v3.4 invalid info-only

- Removed modal warning dialog for invalid OPN MAPPING_V3 on load.
- Invalid mapping now opens the Info window directly.
- Validation fail summary is ordered first in the OPN Mapping info text.
- Loadfile name remains included in validation details.

## 2026-04-27 - Mapping v3.5 expected output manifest

- Added expected-output manifest for valid core Mapping V3 examples.
- Added expected-fail manifest for invalid core Mapping V3 examples.
- Added central `examples/opn/mapping-v3-expected-output-manifest.md` with pass criteria.
- No Java, UI, rendering or mapping-rule changes.

## 2026-04-27 - Mapping v3.6 expected-output checker

- Added `tools/MappingV3RegressionChecker.java` and compiled class files.
- Added `run-mapping-v3-checker.bat` for Windows use.
- Checker compares valid examples against `EXPECTED.txt` and invalid examples against `EXPECTED-FAIL.txt`.
- Checker verifies generated best output, validation counts, invalid diagnostics, filename presence and suppressed invalid generation.
- Last container run: `summary: 13 pass, 0 fail`.
- Scope remains Mapping V3 core only; WH, NEG, DET, FRAME.graph, lexicon and rendering remain out of scope.

## 2026-04-27 - Mapping v3.8 source MD bundle

- Added `sources/mapping-v3/` with the current project-source `.md` set.
- Added source bundle README and meta note.
- No Java code changes.
- Mapping V3 checker remains unchanged; core checker status remains `13 pass, 0 fail`.

## 2026-04-27 — Mapping v3.9 MD folder cleanup

- Verzamelt alle `.md`-bestanden in één `md/`-map.
- Behoudt de oorspronkelijke subpaden onder `md/`, zoals `md/meta-inf/`, `md/sources/mapping-v3/` en `md/examples/`.
- Verplaatst ook `frame_md.tmp` naar `md/meta-inf/` omdat dit een markdown-achtige placeholder is.
- Geen Java-codewijzigingen.
- Geen wijziging aan mapping, checker, examples, generator of validator.

## 2026-04-27 — Mapping V40: MD Folder Check

- Toegevoegd: `run-md-folder-check.bat` voor Windows.
- Toegevoegd: `tools/check-md-folder.sh` voor POSIX/containercontrole.
- Toegevoegd: `tools/CheckMdFolder.java` als Java-bron voor een latere cross-platform checker.
- Regel technisch afdwingbaar gemaakt: alle `.md`-bestanden moeten onder `md/` staan.
- Geen wijzigingen aan Mapping V3, generator, validator, regression checker of UI.

## 2026-04-27 — Mapping v3.10 core stable checkpoint

- Markeert de core Mapping V3-laag als `MAPPING_V3_CORE_STABLE`.
- Werkt `md/sources/mapping-v3/current-state.md` bij met stable-status.
- Legt vast dat core in scope is: Agens, Patiens, RECIPIENT, THEME, V, V-AUX, V-PART en gesplitste VP.
- Legt vast dat WH, NEG, TIME/PLACE, DET, FRAME.graph, lexicon en UI/rendering buiten dit checkpoint blijven.
- Geen Java-codewijzigingen.
- Mapping checker blijft: `13 pass, 0 fail`.
- MD folder check blijft: `PASS`.
