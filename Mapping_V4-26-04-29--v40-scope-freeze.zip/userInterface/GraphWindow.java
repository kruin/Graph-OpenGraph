package userInterface;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;
import graphStructure.*;

public class GraphWindow extends JPanel
{
  private final JDesktopPane desktopPane;
  private final GraphDesktopFrames desktopFrames;

  public GraphWindow()
  {
    desktopPane = new JDesktopPane();
    desktopFrames = new GraphDesktopFrames(desktopPane);

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints layoutCons = new GridBagConstraints();
    setLayout(layout);

    layoutCons.gridx = GridBagConstraints.RELATIVE;
    layoutCons.gridy = GridBagConstraints.RELATIVE;
    layoutCons.gridwidth = GridBagConstraints.REMAINDER;
    layoutCons.gridheight = GridBagConstraints.REMAINDER;
    layoutCons.fill = GridBagConstraints.BOTH;
    layoutCons.insets = new Insets(1,1,1,1);
    layoutCons.anchor = GridBagConstraints.NORTH;
    layoutCons.weightx = 120.0;
    layoutCons.weighty = 120.0;
    layout.setConstraints(desktopPane, layoutCons);
    add(desktopPane);
  }

  public GraphEditorWindow addGraphEditorWindow(GraphController graphController)
  {
    return addGraphEditorWindow(new GraphEditorWindow(graphController));
  }

  public GraphEditorWindow addGraphEditorWindow(GraphController graphController, Graph graph)
  {
    return addGraphEditorWindow(new GraphEditorWindow(graphController, graph));
  }

  private GraphEditorWindow addGraphEditorWindow(GraphEditorWindow graphEditorWindow)
  {
    desktopFrames.addAndActivate(graphEditorWindow);
    return graphEditorWindow;
  }

  public void close(OpenGraphEdInternalFrame intFrame)
  {
    desktopFrames.close(intFrame);
  }

  public void activate(OpenGraphEdInternalFrame intFrame)
  {
    desktopFrames.activate(intFrame);
  }

  public void show(OpenGraphEdInternalFrame intFrame)
  {
    desktopFrames.show(intFrame);
  }

  public void showInfo(GraphEditorWindow window)
  {
    if ( window == null )
    {
      return;
    }
    GraphEditorInfoWindow infoWindow = window.getInfoWindow();
    if ( !desktopFrames.contains(infoWindow) )
    {
      infoWindow.setVisible(true);
      desktopPane.add(infoWindow);
    }
    infoWindow.update();
    desktopFrames.reopenAndActivate(infoWindow);
  }

  public void closeInfo(GraphEditorInfoWindow window)
  {
    desktopFrames.closeIfPossible(window);
  }

  public void showLog(GraphEditorWindow window)
  {
    if ( window == null )
    {
      return;
    }
    GraphEditorLogWindow logWindow = window.getLogWindow();
    if ( !desktopFrames.contains(logWindow) )
    {
      logWindow.setVisible(true);
      desktopPane.add(logWindow);
    }
    logWindow.update();
    desktopFrames.reopenAndActivate(logWindow);
  }

  public void closeLog(GraphEditorLogWindow window)
  {
    desktopFrames.closeIfPossible(window);
  }

  public void showDialog(GraphEditorDialog dialog)
  {
    showOwnedFrame(dialog);
  }

  public void activateDialog(GraphEditorDialog dialog)
  {
    if ( dialog.getOwner().isSelected() )
    {
      try
      {
        dialog.getOwner().setSelected(false);
      }
      catch (java.beans.PropertyVetoException pve)
      {
        pve.printStackTrace();
      }
    }
    desktopFrames.reopenAndActivate(dialog);
  }

  private void showOwnedFrame(OpenGraphEdInternalFrame frame)
  {
    if ( !desktopFrames.contains(frame) )
    {
      frame.setVisible(true);
      desktopPane.add(frame);
    }
    desktopFrames.reopenAndActivate(frame);
  }

  public void forceGraphRepaints()
  {
    JInternalFrame frames[] = desktopFrames.allFrames();
    for ( int i=0; i<frames.length; i++ )
    {
      if ( frames[i] instanceof GraphEditorWindow )
      {
        ((GraphEditorWindow)frames[i]).getGraphEditor().getGraph().markForRepaint();
      }
    }
    repaint();
  }
  
  public Vector<GraphEditorWindow> getAllGraphEditorWindows()
  {
    Vector<GraphEditorWindow> toReturn = new Vector<GraphEditorWindow>();
    JInternalFrame frames[] = desktopPane.getAllFrames();
    for ( int i=0; i<frames.length; i++ )
    {
      if ( frames[i] instanceof GraphEditorWindow )
      {
        toReturn.add((GraphEditorWindow)frames[i]);
      }
    }
    return toReturn;
  }
}