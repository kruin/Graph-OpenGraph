package userInterface;

import javax.swing.*;
import java.awt.*;
import graphStructure.Graph;
import operation.*;

public class GraphEditorInfoSupport
{
  private final JLabel totalNodesLabel;
  private final JLabel totalEdgesLabel;
  private final JLabel generatedEdgesLabel;
  private final JLabel curvedEdgesLabel;
  private final JLabel planarLabel;
  private final JLabel maximalPlanarLabel;
  private final JLabel connectedCountLabel;
  private final JLabel biconnectedCountLabel;
  private final JTextArea opnMappingTextArea;

  public GraphEditorInfoSupport(Container container)
  {
    GridBagLayout layout = GraphEditorWindowUiSupport.installVerticalLayout(container);
    totalNodesLabel = addInfoLabel(container, layout);
    totalEdgesLabel = addInfoLabel(container, layout);
    generatedEdgesLabel = addInfoLabel(container, layout);
    curvedEdgesLabel = addInfoLabel(container, layout);
    planarLabel = addInfoLabel(container, layout);
    maximalPlanarLabel = addInfoLabel(container, layout);
    connectedCountLabel = addInfoLabel(container, layout);
    biconnectedCountLabel = addInfoLabel(container, layout);
    opnMappingTextArea = addInfoTextArea(container, layout);
  }

  private JLabel addInfoLabel(Container container, GridBagLayout layout)
  {
    JLabel label = new JLabel();
    GraphEditorWindowUiSupport.addFullWidth(container, layout, label,
                                            GridBagConstraints.BOTH, 1.0);
    return label;
  }

  private JTextArea addInfoTextArea(Container container, GridBagLayout layout)
  {
    JTextArea textArea = new JTextArea();
    textArea.setEditable(false);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    textArea.setOpaque(false);
    textArea.setFont(UIManager.getFont("Label.font"));
    textArea.setBorder(null);
    GraphEditorWindowUiSupport.addFullWidth(container, layout, textArea,
                                            GridBagConstraints.BOTH, 1.0);
    return textArea;
  }

  private String formatOPNMappingSummary(String summary)
  {
    if ( summary == null || summary.length() == 0 )
    {
      return "OPN Mapping: none";
    }

    String text = "OPN " + summary;
    text = text.replace("; validation:", "\n  validation:");
    text = text.replace("; Mapping", "\n  Mapping");
    text = text.replace("; generated:", "\n  generated:");
    text = text.replace("; alternatives:", "\n  alternatives:");

    int alt = text.indexOf("\n  alternatives:");
    if ( alt >= 0 )
    {
      int start = alt + "\n  alternatives:".length();
      String before = text.substring(0, start);
      String rest = text.substring(start).trim();
      if ( rest.length() > 0 )
      {
        String[] alternatives = rest.split("\\s*\\|\\s*");
        StringBuffer buf = new StringBuffer(before);
        int max = Math.min(alternatives.length, 3);
        for ( int i=0; i<max; i++ )
        {
          String alternative = alternatives[i].trim();
          if ( alternative.length() > 0 )
          {
            buf.append("\n    ").append(i + 1).append(". ").append(alternative);
          }
        }
        if ( alternatives.length > max )
        {
          buf.append("\n    ...");
        }
        text = buf.toString();
      }
    }

    return text;
  }

  public void update(Graph graph)
  {
    totalNodesLabel.setText("Total Nodes: " + graph.getNumNodes());
    totalEdgesLabel.setText("Total Edges: " + graph.getNumEdges());
    generatedEdgesLabel.setText("Generated Edges: " + graph.getNumGeneratedEdges());
    curvedEdgesLabel.setText("Curved Edges: " + graph.getNumCurvedEdges());

    boolean planar = PlanarityOperation.isPlanar(graph);
    planarLabel.setText("Planar?: " + planar);
    maximalPlanarLabel.setText("Maximal Planar?: " + (planar &&
      graph.getNumEdges() == graph.getNumNodes() * 3 - 6));
    connectedCountLabel.setText("Num Connected Components: " +
      ConnectivityOperation.getConnectedComponents(graph).size());
    biconnectedCountLabel.setText("Num Biconnected Components: " +
      BiconnectivityOperation.getBiconnectedComponents(graph).size());
    if ( graph.hasOPNMappingV1Info() )
    {
      opnMappingTextArea.setText(formatOPNMappingSummary(graph.getOPNMappingV1Summary()));
    }
    else
    {
      opnMappingTextArea.setText("OPN Mapping: none");
    }
  }
}
