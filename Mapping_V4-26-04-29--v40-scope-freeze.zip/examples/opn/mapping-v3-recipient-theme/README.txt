Mapping V3.2 recipient/theme voorbeeld.

Doel:
- test meerdere argumentrollen in een uiting
- test compacte placementregels zoals left_of_V, before_Theme en before_V_PART
- test combineerbaarheid met TIME, NEG en PLACE

Verwachte best-output:
gisteren vrouw heeft niet man boek gegeven daar
