Mapping V3.3 core regression examples

Scope:
- declarative clauses only
- core roles: Agens, Patiens, RECIPIENT, THEME, V, V-AUX, V-PART
- split VP with auxiliary + participle is included

Out of scope for these examples:
- WH/question clauses
- negation
- adverbs / TIME / PLACE
- DET splitting
- FRAME.graph integration

Note:
- multiword groups such as "een boek" are represented as one lexical/mapping item in v3.3.
