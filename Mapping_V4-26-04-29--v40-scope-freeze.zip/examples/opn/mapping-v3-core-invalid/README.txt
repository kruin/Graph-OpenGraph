Mapping V3.4 core invalid regression set.

Open each .opn and inspect the Info window.
Expected behaviour:
- validation must have at least one fail
- the diagnostic text must include the loaded file name
- generated output must say: none (invalid mapping)

Cases:
01 missing role
02 unknown role
03 missing THEME target
04 missing V-PART target
05 RECIPIENT/THEME ordering cycle
06 verb-domain reference to unknown lexical item
07 duplicate lexical id
08 missing verb anchor
