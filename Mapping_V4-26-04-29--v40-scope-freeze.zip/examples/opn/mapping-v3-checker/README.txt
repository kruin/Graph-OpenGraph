Mapping V3.6 checker

Scope:
- Valid core Mapping V3 examples in examples/opn/mapping-v3-core/EXPECTED.txt
- Invalid Mapping V3 examples in examples/opn/mapping-v3-core-invalid/EXPECTED-FAIL.txt

Run from the OpenGraphEd directory:

  java tools.MappingV3RegressionChecker .

Or on Windows:

  run-mapping-v3-checker.bat

Expected result:

  summary: 13 pass, 0 fail

Out of scope:
- WH / vraagzinnen
- NEG
- TIME / PLACE / bijwoorden
- DET splitting
- FRAME.graph
- lexicon
- UI rendering / rotate / layout
