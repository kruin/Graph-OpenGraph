package tools;

import java.io.*;
import java.util.*;

/** Mapping V3 regression checker for the OpenGraphEd example manifests. */
public class MappingV3RegressionChecker
{
  private static final int MAX_MESSAGES = 4;

  public static void main(String[] args)
  {
    File root = new File(args.length > 0 ? args[0] : ".");
    File validDir = new File(root, "examples/opn/mapping-v3-core");
    File invalidDir = new File(root, "examples/opn/mapping-v3-core-invalid");
    int pass = 0;
    int fail = 0;
    System.out.println("Mapping V3.6 regression checker");
    System.out.println("Root: " + root.getAbsolutePath());
    System.out.println();
    try
    {
      List validExpected = readValidExpected(new File(validDir, "EXPECTED.txt"));
      System.out.println("Valid core examples:");
      for ( int i=0; i<validExpected.size(); i++ )
      {
        ExpectedValid expected = (ExpectedValid)validExpected.get(i);
        CheckResult result = checkValid(new File(validDir, expected.fileName), expected);
        if ( result.passed ) pass++; else fail++;
        printResult(result);
      }
      System.out.println();
      List invalidExpected = readInvalidExpected(new File(invalidDir, "EXPECTED-FAIL.txt"));
      System.out.println("Invalid core examples:");
      for ( int i=0; i<invalidExpected.size(); i++ )
      {
        ExpectedInvalid expected = (ExpectedInvalid)invalidExpected.get(i);
        CheckResult result = checkInvalid(new File(invalidDir, expected.fileName), expected);
        if ( result.passed ) pass++; else fail++;
        printResult(result);
      }
      System.out.println();
      System.out.println("summary: " + pass + " pass, " + fail + " fail");
      if ( fail > 0 ) System.exit(1);
    }
    catch ( Exception ex )
    {
      System.out.println("FAIL checker error: " + ex.getClass().getName() +
                         (ex.getMessage() == null ? "" : ": " + ex.getMessage()));
      ex.printStackTrace(System.out);
      System.exit(2);
    }
  }

  private static void printResult(CheckResult result)
  {
    System.out.println((result.passed ? "  PASS " : "  FAIL ") + result.fileName);
    if ( !result.passed )
    {
      for ( int i=0; i<result.messages.size(); i++ ) System.out.println("       " + result.messages.get(i));
      if ( result.actualMapping != null ) System.out.println("       actual mapping: " + result.actualMapping);
      if ( result.actualValidation != null ) System.out.println("       actual validation: " + result.actualValidation);
      if ( result.actualGenerated != null ) System.out.println("       actual generated: " + result.actualGenerated);
    }
  }

  private static CheckResult checkValid(File opnFile, ExpectedValid expected) throws IOException
  {
    MappingSummary actual = analyzeOPN(opnFile);
    CheckResult result = new CheckResult(expected.fileName);
    result.actualMapping = actual.mappingLine;
    result.actualValidation = actual.validationLine;
    result.actualGenerated = actual.generatedLine;
    expectEquals(result, "mapping", expected.mappingLine, actual.mappingLine);
    expectEquals(result, "validation", expected.validationLine, actual.validationLine);
    expectEquals(result, "generated", expected.generatedLine, actual.generatedLine);
    result.finish();
    return result;
  }

  private static CheckResult checkInvalid(File opnFile, ExpectedInvalid expected) throws IOException
  {
    MappingSummary actual = analyzeOPN(opnFile);
    CheckResult result = new CheckResult(expected.fileName);
    result.actualMapping = actual.mappingLine;
    result.actualValidation = actual.validationLine;
    result.actualGenerated = actual.generatedLine;
    if ( !actual.validationLine.startsWith(expected.validationStartsWith) ) result.messages.add("validation does not start with expected prefix: " + expected.validationStartsWith);
    for ( int i=0; i<expected.detailContains.size(); i++ )
    {
      String needle = (String)expected.detailContains.get(i);
      if ( !containsNormalized(actual.validationLine, needle) ) result.messages.add("validation details missing: " + needle);
    }
    expectEquals(result, "generated", expected.generatedLine, actual.generatedLine);
    result.finish();
    return result;
  }

  private static boolean containsNormalized(String haystack, String needle)
  {
    return normalizeForContains(haystack).indexOf(normalizeForContains(needle)) >= 0;
  }

  private static String normalizeForContains(String value)
  {
    if ( value == null ) return "";
    return value.toLowerCase().replace('-', '_');
  }

  private static void expectEquals(CheckResult result, String label, String expected, String actual)
  {
    if ( expected == null ) expected = "";
    if ( actual == null ) actual = "";
    if ( !expected.equals(actual) ) result.messages.add(label + " mismatch; expected: " + expected);
  }

  private static MappingSummary analyzeOPN(File opnFile) throws IOException
  {
    List lines = readAllLines(opnFile);
    int lexicalItems = countPipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    int verbDomains = countPipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    int placementRules = countPipeSectionRows(lines, "PLACEMENT_RULES:", getMappingEndMarker(lines));
    Validation validation = validateMappingV3(lines, opnFile.getName());
    String generated = validation.failed == 0 ? generateBest(lines) : "none (invalid mapping)";
    MappingSummary summary = new MappingSummary();
    summary.mappingLine = "Mapping v3: " + lexicalItems + " lexical items, " + verbDomains + " verb domains, " + placementRules + " placement rules";
    summary.validationLine = "validation: " + validation.passed + " ok, " + validation.failed + " fail";
    String details = validation.details();
    if ( details.length() > 0 ) summary.validationLine += " (" + details + ")";
    summary.generatedLine = "generated: " + generated;
    return summary;
  }

  private static Validation validateMappingV3(List lines, String fileName)
  {
    Validation result = new Validation(fileName);
    Map roleToX = new HashMap();
    Map roleToWord = new HashMap();
    Map xToWord = new HashMap();
    Map xIds = new HashMap();
    readLexicalItems(lines, roleToX, roleToWord, xToWord, xIds, result);
    Map verbDomain = new HashMap();
    readVerbDomain(lines, verbDomain, xIds, result);
    List rules = new ArrayList();
    readPlacementRules(lines, rules);
    List validationRules = bestPlacementRules(rules);
    Map before = new HashMap();
    List roles = sortedRolesByX(roleToX);
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new ArrayList());
    List afterClauseRoles = rolesWithRelation(validationRules, roleToWord, "after_clause");
    for ( int i=0; i<validationRules.size(); i++ ) validateRule((String[])validationRules.get(i), roleToX, verbDomain, before, roles, afterClauseRoles, result);
    if ( result.failed == 0 && roles.size() > 0 )
    {
      List ordered = topologicalRoleOrder(roles, before);
      if ( ordered.size() == 0 ) result.fail("ordering cycle in best placement rules");
    }
    return result;
  }

  private static String generateBest(List lines)
  {
    Map roleToWord = new HashMap();
    Map roleToX = new HashMap();
    Map xToWord = new HashMap();
    readLexicalItemsLenient(lines, roleToX, roleToWord, xToWord);
    Map verbDomain = new HashMap();
    readVerbDomainLenient(lines, verbDomain);
    List rules = new ArrayList();
    readPlacementRules(lines, rules);
    List words = generateUtterance(roleToWord, roleToX, verbDomain, bestPlacementRules(rules));
    if ( words.size() == 0 ) return "";
    return "best: " + joinWords(words);
  }

  private static void readLexicalItems(List lines, Map roleToX, Map roleToWord, Map xToWord, Map xIds, Validation result)
  {
    List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 ) { result.fail("invalid lexical item row"); continue; }
      String xId = parts[0];
      String word = parts[1];
      if ( xIds.get(xId) != null ) result.fail("duplicate lexical id " + xId);
      xIds.put(xId, Boolean.TRUE);
      xToWord.put(xId, word);
      String role = null;
      for ( int j=2; j<parts.length; j++ ) if ( parts[j].startsWith("role:") ) role = canonicalRoleToken(parts[j].substring("role:".length()));
      if ( role == null || role.length() == 0 ) { result.fail(xId + " missing role"); continue; }
      if ( !isKnownRole(role) ) { result.fail("unknown role " + role + " at " + xId); continue; }
      roleToX.put(role, new Integer(parseXIndex(xId)));
      roleToWord.put(role, word);
    }
  }

  private static void readLexicalItemsLenient(List lines, Map roleToX, Map roleToWord, Map xToWord)
  {
    List rows = pipeSectionRows(lines, "LEXICAL_ITEMS:", "VERB_DOMAIN:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 2 ) continue;
      String xId = parts[0];
      String word = parts[1];
      xToWord.put(xId, word);
      for ( int j=2; j<parts.length; j++ )
      {
        if ( parts[j].startsWith("role:") )
        {
          String role = canonicalRoleToken(parts[j].substring("role:".length()));
          roleToX.put(role, new Integer(parseXIndex(xId)));
          roleToWord.put(role, word);
        }
      }
    }
  }

  private static void readVerbDomain(List lines, Map verbDomain, Map xIds, Validation result)
  {
    List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length < 3 ) { result.fail("invalid verb-domain row"); continue; }
      verbDomain.put(parts[0], parts[2]);
      String[] refs = parts[2].split(",");
      for ( int j=0; j<refs.length; j++ )
      {
        String ref = refs[j].trim();
        if ( ref.length() > 0 && xIds.get(ref) == null ) result.fail("verb-domain " + parts[0] + " references unknown lexical item " + ref);
      }
    }
  }

  private static void readVerbDomainLenient(List lines, Map verbDomain)
  {
    List rows = pipeSectionRows(lines, "VERB_DOMAIN:", "PLACEMENT_RULES:");
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] parts = splitPipe((String)rows.get(i));
      if ( parts.length >= 3 ) verbDomain.put(parts[0], parts[2]);
    }
  }

  private static void readPlacementRules(List lines, List rules)
  {
    List rows = pipeSectionRows(lines, "PLACEMENT_RULES:", getMappingEndMarker(lines));
    for ( int i=0; i<rows.size(); i++ )
    {
      String[] rule = normalizePlacementRule(splitPipe((String)rows.get(i)));
      if ( rule != null ) rules.add(rule);
    }
  }

  private static void validateRule(String[] rule, Map roleToX, Map verbDomain, Map before, List roles, List afterClauseRoles, Validation result)
  {
    if ( rule == null || rule.length < 2 ) { result.fail("invalid placement rule"); return; }
    String role = resolveRoleKey(roleToX, rule[0]);
    String relation = rule[1];
    String target = rule.length > 2 ? rule[2] : "";
    String label = rule[0] + " " + relation + (target != null && target.length() > 0 ? " " + target : "");
    if ( role == null ) { result.fail("missing role for rule " + label); return; }
    if ( relation.equals("left_of") && target.equals("V") )
    {
      String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
      if ( vAnchorRole == null ) result.fail("missing V-anchor for rule " + label);
      else { addOrderingConstraint(before, role, vAnchorRole); result.pass(); }
      return;
    }
    if ( relation.equals("right_of") && target.equals("V") )
    {
      String vAnchorRole = findVerbAnchorRole(roleToX, verbDomain);
      if ( vAnchorRole == null ) result.fail("missing V-anchor for rule " + label);
      else { addOrderingConstraint(before, vAnchorRole, role); result.pass(); }
      return;
    }
    if ( relation.equals("realizes_before") || relation.equals("before") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      if ( resolvedTarget == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, role, resolvedTarget); result.pass(); }
      return;
    }
    if ( relation.equals("realizes_after") || relation.equals("after") )
    {
      String resolvedTarget = resolveRoleKey(roleToX, target);
      if ( resolvedTarget == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, resolvedTarget, role); result.pass(); }
      return;
    }
    if ( relation.equals("after_aux_before_object") )
    {
      String auxRole = resolveRoleKey(roleToX, "V-AUX");
      String objectRole = resolveRoleKey(roleToX, target == null || target.length() == 0 ? "Patiens" : target);
      if ( auxRole == null ) result.fail("missing V-AUX for rule " + label);
      else if ( objectRole == null ) result.fail("missing target " + target + " for rule " + label);
      else { addOrderingConstraint(before, auxRole, role); addOrderingConstraint(before, role, objectRole); result.pass(); }
      return;
    }
    if ( relation.equals("before_clause") ) { addClauseBoundaryConstraints(before, roles, role, true); result.pass(); return; }
    if ( relation.equals("after_clause") ) { addClauseBoundaryConstraints(before, roles, role, false); result.pass(); return; }
    if ( relation.equals("clause_end") ) { addClauseEndConstraints(before, roles, role, afterClauseRoles); result.pass(); return; }
    if ( relation.equals("anchor") ) { result.pass(); return; }
    result.fail("unknown placement relation " + relation + " for rule " + label);
  }

  private static List generateUtterance(Map roleToWord, Map roleToX, Map verbDomain, List rules)
  {
    List roles = sortedRolesByX(roleToX);
    Map before = new HashMap();
    for ( int i=0; i<roles.size(); i++ ) before.put((String)roles.get(i), new ArrayList());
    List afterClauseRoles = rolesWithRelation(rules, roleToWord, "after_clause");
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      String role = resolveRoleKey(roleToWord, rule[0]);
      String relation = rule[1];
      String target = rule.length > 2 ? rule[2] : "";
      if ( role == null ) continue;
      if ( relation.equals("left_of") && target.equals("V") ) addOrderingConstraint(before, role, findVerbAnchorRole(roleToX, verbDomain));
      else if ( relation.equals("right_of") && target.equals("V") ) addOrderingConstraint(before, findVerbAnchorRole(roleToX, verbDomain), role);
      else if ( relation.equals("realizes_before") || relation.equals("before") ) addOrderingConstraint(before, role, resolveRoleKey(roleToWord, target));
      else if ( relation.equals("realizes_after") || relation.equals("after") ) addOrderingConstraint(before, resolveRoleKey(roleToWord, target), role);
      else if ( relation.equals("after_aux_before_object") ) { String objectRole = resolveRoleKey(roleToWord, target.length() == 0 ? "Patiens" : target); addOrderingConstraint(before, resolveRoleKey(roleToWord, "V-AUX"), role); addOrderingConstraint(before, role, objectRole); }
      else if ( relation.equals("before_clause") ) addClauseBoundaryConstraints(before, roles, role, true);
      else if ( relation.equals("after_clause") ) addClauseBoundaryConstraints(before, roles, role, false);
      else if ( relation.equals("clause_end") ) addClauseEndConstraints(before, roles, role, afterClauseRoles);
    }
    List orderedRoles = topologicalRoleOrder(roles, before);
    List words = new ArrayList();
    for ( int i=0; i<orderedRoles.size(); i++ )
    {
      Object word = roleToWord.get((String)orderedRoles.get(i));
      if ( word != null && word.toString().length() > 0 ) words.add(word.toString());
    }
    return words;
  }

  private static List bestPlacementRules(List rules)
  {
    List filtered = new ArrayList();
    for ( int i=0; i<rules.size(); i++ )
    {
      String[] rule = (String[])rules.get(i);
      if ( isCoreRule(rule) || getRuleRank(rule) == 1 ) filtered.add(rule);
    }
    return filtered;
  }
  private static boolean isCoreRule(String[] rule) { if ( rule == null || rule.length < 4 ) return true; String marker = rule[3] == null ? "" : rule[3].trim(); return marker.length() == 0 || marker.equalsIgnoreCase("core") || marker.equals("-"); }
  private static int getRuleRank(String[] rule) { if ( rule == null || rule.length < 4 ) return 0; String marker = rule[3] == null ? "" : rule[3].trim(); if ( marker.startsWith("rank:")) marker = marker.substring("rank:".length()); if ( marker.startsWith("pref:")) marker = marker.substring("pref:".length()); try { return Integer.parseInt(marker); } catch ( Exception e ) { return 0; } }

  private static String[] normalizePlacementRule(String[] parts)
  {
    if ( parts == null || parts.length < 2 ) return null;
    String role = safeTrim(parts[0]); String relation = safeTrim(parts[1]); String target = ""; String marker = "";
    if ( parts.length >= 4 ) { target = safeTrim(parts[2]); marker = safeTrim(parts[3]); }
    else if ( parts.length == 3 ) { String third = safeTrim(parts[2]); if ( isRuleMarker(third) || relationImpliesTarget(relation) || isUnaryPlacementRelation(relation) ) marker = third; else target = third; }
    String[] expanded = expandPlacementRelation(relation, target); relation = expanded[0]; target = expanded[1];
    if ( role.length() == 0 || relation.length() == 0 ) return null;
    return new String[] { canonicalRoleToken(role), relation, canonicalRoleToken(target), marker };
  }
  private static String[] expandPlacementRelation(String relation, String target)
  {
    String original = safeTrim(relation); String compact = original.toLowerCase().replace('-', '_'); String resolvedTarget = safeTrim(target);
    if ( compact.equals("left_of_v") ) return new String[] { "left_of", "V" };
    if ( compact.equals("right_of_v") ) return new String[] { "right_of", "V" };
    if ( compact.startsWith("before_") && !compact.equals("before_clause") ) { String s = original.replace('-', '_'); return new String[] { "before", s.substring(s.indexOf('_') + 1) }; }
    if ( compact.startsWith("after_") && !compact.equals("after_clause") && !compact.equals("after_aux_before_object") ) { String s = original.replace('-', '_'); return new String[] { "after", s.substring(s.indexOf('_') + 1) }; }
    if ( compact.equals("before_clause") ) return new String[] { "before_clause", "" };
    if ( compact.equals("after_clause") ) return new String[] { "after_clause", "" };
    if ( compact.equals("after_aux_before_object") ) return new String[] { "after_aux_before_object", resolvedTarget.length() == 0 ? "Patiens" : resolvedTarget };
    if ( compact.equals("anchor") ) return new String[] { "anchor", "" };
    if ( compact.equals("clause_end") ) return new String[] { "clause_end", "" };
    if ( compact.equals("realizes_before") ) return new String[] { "realizes_before", resolvedTarget };
    if ( compact.equals("realizes_after") ) return new String[] { "realizes_after", resolvedTarget };
    return new String[] { original, resolvedTarget };
  }
  private static boolean relationImpliesTarget(String relation) { String compact = safeTrim(relation).toLowerCase().replace('-', '_'); return compact.equals("left_of_v") || compact.equals("right_of_v") || (compact.startsWith("before_") && !compact.equals("before_clause")) || (compact.startsWith("after_") && !compact.equals("after_clause") && !compact.equals("after_aux_before_object")); }
  private static boolean isUnaryPlacementRelation(String relation) { String compact = safeTrim(relation).toLowerCase().replace('-', '_'); return compact.equals("before_clause") || compact.equals("after_clause") || compact.equals("anchor") || compact.equals("clause_end"); }
  private static boolean isRuleMarker(String value) { String marker = safeTrim(value).toLowerCase(); return marker.length() == 0 || marker.equals("-") || marker.equals("core") || marker.startsWith("rank:") || marker.startsWith("pref:"); }
  private static boolean isKnownRole(String role) { String r = canonicalRoleToken(role); return r.equals("Agens") || r.equals("Patiens") || r.equals("RECIPIENT") || r.equals("THEME") || r.equals("TIME") || r.equals("PLACE") || r.equals("NEG") || r.equals("V") || r.equals("V-AUX") || r.equals("V-PART"); }
  private static String canonicalRoleToken(String value) { String token = safeTrim(value); if ( token.length() == 0 ) return token; token = token.replace('_', '-'); if ( token.equalsIgnoreCase("v") ) return "V"; if ( token.equalsIgnoreCase("v-aux") ) return "V-AUX"; if ( token.equalsIgnoreCase("v-part") ) return "V-PART"; if ( token.equalsIgnoreCase("recipient") ) return "RECIPIENT"; if ( token.equalsIgnoreCase("theme") ) return "THEME"; if ( token.equalsIgnoreCase("time") ) return "TIME"; if ( token.equalsIgnoreCase("place") ) return "PLACE"; if ( token.equalsIgnoreCase("neg") ) return "NEG"; if ( token.equalsIgnoreCase("agens") ) return "Agens"; if ( token.equalsIgnoreCase("patiens") ) return "Patiens"; return token; }
  private static List rolesWithRelation(List rules, Map roleMap, String relation) { List result = new ArrayList(); for ( int i=0; i<rules.size(); i++ ) { String[] rule = (String[])rules.get(i); if ( rule.length < 2 || !relation.equals(rule[1]) ) continue; String role = resolveRoleKey(roleMap, rule[0]); if ( role != null && !result.contains(role) ) result.add(role); } return result; }
  private static String resolveRoleKey(Map roleMap, String requested) { if ( requested == null ) return null; String wanted = canonicalRoleToken(requested); if ( wanted.length() == 0 ) return null; if ( roleMap.get(wanted) != null ) return wanted; Iterator it = roleMap.keySet().iterator(); while ( it.hasNext() ) { String candidate = (String)it.next(); if ( sameRoleToken(candidate, wanted) ) return candidate; } return null; }
  private static boolean sameRoleToken(String a, String b) { return canonicalRoleToken(a).replace('-', '_').equalsIgnoreCase(canonicalRoleToken(b).replace('-', '_')); }
  private static List sortedRolesByX(final Map roleToX) { List roles = new ArrayList(roleToX.keySet()); Collections.sort(roles, new Comparator() { public int compare(Object a, Object b) { Integer xa = (Integer)roleToX.get(a); Integer xb = (Integer)roleToX.get(b); int av = xa == null ? Integer.MAX_VALUE : xa.intValue(); int bv = xb == null ? Integer.MAX_VALUE : xb.intValue(); if ( av != bv ) return av - bv; return a.toString().compareTo(b.toString()); } }); return roles; }
  private static String findVerbAnchorRole(Map roleToX, Map verbDomain) { Object value = verbDomain.get("V"); if ( value == null ) return null; String[] xs = value.toString().split(","); int bestX = Integer.MAX_VALUE; String bestRole = null; for ( int i=0; i<xs.length; i++ ) { int x = parseXIndex(xs[i].trim()); if ( x < 0 ) continue; Iterator it = roleToX.keySet().iterator(); while ( it.hasNext() ) { String role = (String)it.next(); Integer rx = (Integer)roleToX.get(role); if ( rx != null && rx.intValue() == x && x < bestX ) { bestX = x; bestRole = role; } } } return bestRole; }
  private static void addOrderingConstraint(Map before, String first, String second) { if ( first == null || second == null || first.equals(second) ) return; List list = (List)before.get(first); if ( list == null ) { list = new ArrayList(); before.put(first, list); } if ( !list.contains(second) ) list.add(second); if ( before.get(second) == null ) before.put(second, new ArrayList()); }
  private static void addClauseBoundaryConstraints(Map before, List roles, String role, boolean beforeClause) { if ( role == null ) return; for ( int i=0; i<roles.size(); i++ ) { String other = (String)roles.get(i); if ( other == null || other.equals(role) ) continue; if ( beforeClause ) addOrderingConstraint(before, role, other); else addOrderingConstraint(before, other, role); } }
  private static void addClauseEndConstraints(Map before, List roles, String role, List afterClauseRoles) { if ( role == null ) return; for ( int i=0; i<roles.size(); i++ ) { String other = (String)roles.get(i); if ( other == null || other.equals(role) ) continue; if ( afterClauseRoles != null && afterClauseRoles.contains(other) ) continue; addOrderingConstraint(before, other, role); } }
  private static List topologicalRoleOrder(List initialRoles, Map before) { List remaining = new ArrayList(initialRoles); List ordered = new ArrayList(); while ( remaining.size() > 0 ) { String candidate = null; for ( int i=0; i<remaining.size(); i++ ) { String role = (String)remaining.get(i); if ( hasNoIncomingConstraints(role, remaining, before) ) { candidate = role; break; } } if ( candidate == null ) return new ArrayList(); ordered.add(candidate); remaining.remove(candidate); } return ordered; }
  private static boolean hasNoIncomingConstraints(String role, List remaining, Map before) { for ( int i=0; i<remaining.size(); i++ ) { String other = (String)remaining.get(i); List list = (List)before.get(other); if ( list != null && list.contains(role) ) return false; } return true; }
  private static String joinWords(List words) { StringBuffer b = new StringBuffer(); for ( int i=0; i<words.size(); i++ ) { if ( i > 0 ) b.append(" "); b.append(words.get(i).toString()); } return b.toString(); }
  private static List readValidExpected(File file) throws IOException { List lines = readAllLines(file); List result = new ArrayList(); ExpectedValid current = null; for ( int i=0; i<lines.size(); i++ ) { String line = ((String)lines.get(i)).trim(); if ( isExpectedFileHeader(line) ) { if ( current != null ) result.add(current); current = new ExpectedValid(line); } else if ( current != null && line.startsWith("expected mapping:")) current.mappingLine = line.substring("expected mapping:".length()).trim(); else if ( current != null && line.startsWith("expected validation:")) current.validationLine = line.substring("expected validation:".length()).trim(); else if ( current != null && line.startsWith("expected generated:")) current.generatedLine = line.substring("expected generated:".length()).trim(); } if ( current != null ) result.add(current); return result; }
  private static List readInvalidExpected(File file) throws IOException { List lines = readAllLines(file); List result = new ArrayList(); ExpectedInvalid current = null; for ( int i=0; i<lines.size(); i++ ) { String line = ((String)lines.get(i)).trim(); if ( isExpectedFileHeader(line) ) { if ( current != null ) result.add(current); current = new ExpectedInvalid(line); } else if ( current != null && line.startsWith("expected validation starts with:")) current.validationStartsWith = line.substring("expected validation starts with:".length()).trim(); else if ( current != null && line.startsWith("expected details contain:")) current.detailContains.add(line.substring("expected details contain:".length()).trim()); else if ( current != null && line.startsWith("expected generated:")) current.generatedLine = line.substring("expected generated:".length()).trim(); } if ( current != null ) result.add(current); return result; }
  private static boolean isExpectedFileHeader(String line) { return line != null && line.endsWith(".opn") && !line.startsWith("expected ") && line.indexOf(":") < 0; }
  private static int countPipeSectionRows(List lines, String startMarker, String endMarker) { return pipeSectionRows(lines, startMarker, endMarker).size(); }
  private static List pipeSectionRows(List lines, String startMarker, String endMarker) { List rows = new ArrayList(); boolean inSection = false; for ( int i=0; i<lines.size(); i++ ) { String raw = (String)lines.get(i); String line = raw == null ? "" : raw.trim(); if ( line.equals(startMarker) ) { inSection = true; continue; } if ( inSection && line.equals(endMarker) ) break; if ( inSection ) { if ( line.length() == 0 || line.startsWith("#") ) continue; if ( line.endsWith(":")) break; if ( line.indexOf("|") >= 0 ) rows.add(line); } } return rows; }
  private static String getMappingEndMarker(List lines) { if ( containsTrimmedLine(lines, "END_MAPPING_V3:") ) return "END_MAPPING_V3:"; if ( containsTrimmedLine(lines, "END_MAPPING_V2:") ) return "END_MAPPING_V2:"; return "END_MAPPING_V1:"; }
  private static boolean containsTrimmedLine(List lines, String text) { for ( int i=0; i<lines.size(); i++ ) { String line = (String)lines.get(i); if ( line != null && line.trim().equals(text) ) return true; } return false; }
  private static String[] splitPipe(String line) { List parts = new ArrayList(); String[] rawParts = line.split("\\|"); for ( int i=0; i<rawParts.length; i++ ) parts.add(rawParts[i].trim()); return (String[])parts.toArray(new String[parts.size()]); }
  private static int parseXIndex(String xId) { if ( xId == null ) return -1; String s = xId.trim(); if ( s.length() > 0 && (s.charAt(0) == 'x' || s.charAt(0) == 'X') ) s = s.substring(1); try { return Integer.parseInt(s); } catch ( Exception e ) { return -1; } }
  private static String safeTrim(String value) { return value == null ? "" : value.trim(); }
  private static List readAllLines(File file) throws IOException { List lines = new ArrayList(); BufferedReader reader = new BufferedReader(new FileReader(file)); try { String line; while ( (line = reader.readLine()) != null ) lines.add(line); } finally { reader.close(); } return lines; }
  private static class ExpectedValid { String fileName; String mappingLine = ""; String validationLine = ""; String generatedLine = ""; ExpectedValid(String fileName) { this.fileName = fileName; } }
  private static class ExpectedInvalid { String fileName; String validationStartsWith = ""; List detailContains = new ArrayList(); String generatedLine = ""; ExpectedInvalid(String fileName) { this.fileName = fileName; } }
  private static class CheckResult { String fileName; boolean passed = false; List messages = new ArrayList(); String actualMapping; String actualValidation; String actualGenerated; CheckResult(String fileName) { this.fileName = fileName; } void finish() { passed = messages.size() == 0; } }
  private static class MappingSummary { String mappingLine; String validationLine; String generatedLine; }
  private static class Validation { int passed = 0; int failed = 0; List messages = new ArrayList(); String fileName; Validation(String fileName) { this.fileName = fileName; } void pass() { passed++; } void fail(String message) { failed++; if ( message != null && message.length() > 0 ) messages.add(message); } String details() { if ( failed == 0 ) return "best placement rules satisfied"; StringBuffer b = new StringBuffer(); if ( fileName != null && fileName.length() > 0 ) b.append("file: ").append(fileName); for ( int i=0; i<messages.size(); i++ ) { if ( b.length() > 0 ) b.append("; "); b.append(messages.get(i).toString()); if ( i >= MAX_MESSAGES - 1 && messages.size() > MAX_MESSAGES ) { b.append("; ..."); break; } } return b.toString(); } }
}
