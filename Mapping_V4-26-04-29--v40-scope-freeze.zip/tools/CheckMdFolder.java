package tools;

import java.io.*;
import java.util.*;

/**
 * Verifies the OpenGraphEd packaging rule: all Markdown files must live under md/.
 */
public class CheckMdFolder
{
  public static void main(String[] args)
  {
    File root = new File(args.length > 0 ? args[0] : ".");
    List violations = new ArrayList();
    List allMarkdown = new ArrayList();
    try
    {
      File canonicalRoot = root.getCanonicalFile();
      scan(canonicalRoot, canonicalRoot, violations, allMarkdown);
      Collections.sort(violations);
      Collections.sort(allMarkdown);
      System.out.println("Markdown folder check");
      System.out.println("Root: " + canonicalRoot.getAbsolutePath());
      System.out.println("Markdown files: " + allMarkdown.size());
      if ( violations.isEmpty() )
      {
        System.out.println("PASS: all .md files are under md/");
        return;
      }
      System.out.println("FAIL: .md files outside md/:");
      for ( int i=0; i<violations.size(); i++ ) System.out.println("  " + violations.get(i));
      System.exit(1);
    }
    catch ( Exception ex )
    {
      System.out.println("FAIL checker error: " + ex.getClass().getName() +
                         (ex.getMessage() == null ? "" : ": " + ex.getMessage()));
      ex.printStackTrace(System.out);
      System.exit(2);
    }
  }

  private static void scan(File root, File file, List violations, List allMarkdown) throws IOException
  {
    String name = file.getName();
    if ( file.isDirectory() )
    {
      if ( ".git".equals(name) || ".svn".equals(name) || "__MACOSX".equals(name) ) return;
      File[] children = file.listFiles();
      if ( children == null ) return;
      for ( int i=0; i<children.length; i++ ) scan(root, children[i], violations, allMarkdown);
      return;
    }
    if ( !name.toLowerCase().endsWith(".md") ) return;
    String rel = relativePath(root, file.getCanonicalFile());
    allMarkdown.add(rel);
    if ( !(rel.equals("md") || rel.startsWith("md/")) ) violations.add(rel);
  }

  private static String relativePath(File root, File file) throws IOException
  {
    String rootPath = root.getCanonicalPath();
    String filePath = file.getCanonicalPath();
    if ( filePath.startsWith(rootPath) )
    {
      String rel = filePath.substring(rootPath.length());
      while ( rel.startsWith(File.separator) ) rel = rel.substring(1);
      return rel.replace(File.separatorChar, '/');
    }
    return filePath.replace(File.separatorChar, '/');
  }
}
