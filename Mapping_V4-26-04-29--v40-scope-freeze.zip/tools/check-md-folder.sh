#!/usr/bin/env sh
set -eu
ROOT="${1:-.}"
cd "$ROOT"
violations=$(find . -type f -name '*.md' ! -path './md/*' | sort)
count=$(find . -type f -name '*.md' | wc -l | tr -d ' ')
echo "Markdown folder check"
echo "Root: $(pwd)"
echo "Markdown files: $count"
if [ -n "$violations" ]; then
  echo "FAIL: .md files outside md/:"
  echo "$violations" | sed 's#^./#  #'
  exit 1
fi
echo "PASS: all .md files are under md/"
