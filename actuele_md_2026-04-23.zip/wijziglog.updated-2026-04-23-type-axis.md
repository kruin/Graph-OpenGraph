# wijziglog-2026-04-23-type-axis-update

## Overzicht
Deze set actualiseert de markdownbestanden na het besluit om de TYPE-as te herstructureren.

Kernpunten:
- de oude D/L/R-oriëntatie wordt niet langer als hoofdindeling gebruikt
- de hoofdtypes zijn nu:
  - `Simple`
  - `Phrase`
  - `Anaphor`
  - `Frame`
- `Frame` staat **naast** de andere types
- `Other` vervalt volledig
- **L2** blijft een **groeimodus** en is geen type

## Bestanden

### 1. `projectie-master-spec.updated-2026-04-23-type-axis.md`
Wijzigingen:
- sectie **Structuurtype** volledig herschreven
- nieuwe TYPE-as vastgelegd: `Simple / Phrase / Anaphor / Frame`
- `Other` verwijderd
- `L2` expliciet losgekoppeld van TYPE
- verwijzingen naar oude `type D / L1`-terminologie aangepast

### 2. `projection-layout-implementation-plan.updated-2026-04-23-type-axis.md`
Wijzigingen:
- terminologische basis toegevoegd
- verwijzingen naar `type D / L1` vervangen door formuleringen die aansluiten op de nieuwe TYPE-as
- expliciet gemaakt dat `L2` een groeimodus is en geen type

### 3. `projectielayout-en-gridgedrag.updated-2026-04-23-type-axis.md`
Wijzigingen:
- inhoudelijk ongewijzigd
- korte terminologische noot toegevoegd over de nieuwe TYPE-as

### 4. `l2-growth-spec-v0.updated-2026-04-23-type-note.md`
Wijzigingen:
- inhoudelijk ongewijzigd
- terminologische noot toegevoegd dat **L2 geen type** is
- verduidelijkt dat TYPE `Frame` buiten deze L2-specificatie valt

### 5. `l2-growth-spec-v0.2.updated-2026-04-23-type-note.md`
Wijzigingen:
- inhoudelijk ongewijzigd
- terminologische noot toegevoegd dat **L2 geen type** is
- verduidelijkt dat TYPE `Frame` buiten deze L2-specificatie valt

## Uitvoer
Doel van deze set is om de documentatie weer in lijn te brengen met:
- de nieuwe TYPE-as
- het schrappen van `Other`
- het besluit dat **Frame** een zelfstandig type is
- het besluit dat **L2** een groeimodus blijft
