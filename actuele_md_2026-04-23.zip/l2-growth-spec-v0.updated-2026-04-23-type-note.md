# L2 Growth Specification v0

## Terminologische noot 2026-04-23

Deze specificatie gaat over **L2 als groeimodus**.

Belangrijk:
- **L2 is geen type**
- het zelfstandige TYPE **`Frame`** staat in de hoofdindeling **naast** `Simple`, `Phrase` en `Anaphor`
- deze L2-specificatie definieert dus **geen TYPE `Frame`**

---

## 1. Doel

Deze specificatie definieert het minimale model voor **L2 (groeiende taalboom)**.

L2 verschilt principieel van L1:

- **L1**: boom bestaat vooraf; wordt recursief opgebouwd of getekend  
- **L2**: boom bestaat niet vooraf; ontstaat stap voor stap tijdens invoer  

De invoer (LEX-volgorde) stuurt de groei van de structuur.

---

## 2. Kernidee

De boom groeit via iteratieve plaatsing van tokens:

1. neem volgend token uit lineaire invoer  
2. zoek de **eerste open plek**  
3. plaats token op die plek  
4. update structuur en open plekken  

Formeel:

```
for token in input:
    slot = first_open_slot(token)
    place(token, slot)
    update_state()
```

---

## 3. Basisbegrippen

### 3.1 GrowthState

Bevat de huidige partiële structuur.

Velden:
- root (knoop)
- openSlots (geordende lijst)
- history (optioneel)

---

### 3.2 OpenSlot

Een open plek waar een element geplaatst kan worden.

Velden:
- hostNode  
- slotType  
- priority (lage waarde = eerder)  
- occupied (boolean)

---

### 3.3 SlotType (v0)

Minimale set voor eerste prototype:

- LEX_LEFT_EDGE  
- VERB_FINITE  
- DET_SLOT  
- NOUN_SLOT  
- VERB_PARTICIPLE  

---

## 4. Selectieregel

Een token wordt geplaatst op:

> de eerste open slot waarvoor de constraints gelden

In v0 zijn constraints impliciet (hardcoded per slotType).

---

## 5. Voorbeeld: "wie heeft de hond gebeten"

### 5.1 Input

```
wie → heeft → de → hond → gebeten
```

---

### 5.2 Initiële open slots (in volgorde)

1. LEX_LEFT_EDGE  
2. VERB_FINITE  
3. DET_SLOT  
4. NOUN_SLOT  
5. VERB_PARTICIPLE  

---

### 5.3 Groeistappen

| stap | token     | slot               |
|------|-----------|--------------------|
| 1    | wie       | LEX_LEFT_EDGE      |
| 2    | heeft     | VERB_FINITE        |
| 3    | de        | DET_SLOT           |
| 4    | hond      | NOUN_SLOT          |
| 5    | gebeten   | VERB_PARTICIPLE    |

---

### 5.4 Resultaat

- alle slots gevuld  
- structuur is volledig  
- eindknopen beschikbaar voor LEX-projectie  
- vertakkende knopen beschikbaar voor LOG-projectie  

---

## 6. Belangrijk onderscheid

L2 is geen afgeleide van een bestaande boom.

- geen recursieve tekenprocedure  
- geen volledige structuur vooraf  
- geen top-down expander van een vast schema  

Maar:

- incrementele groei  
- gestuurd door invoer  
- gestuurd door open slots  

---

## 7. Relatie met projecties

Na groei:

- **LEX** werkt op eindknopen  
- **LOG** werkt op vertakkende knopen  

Projecties:
- beïnvloeden de structuur niet  
- worden achteraf toegevoegd  
- volgen bestaande layoutregels  

---

## 8. Scope van v0

Deze versie is beperkt tot:

- één voorbeeldzin  
- vaste slottypes  
- vaste volgorde  
- geen algemene grammatica  
- geen backtracking  
- geen ambiguïteit  

---

## 9. Volgende uitbreidingen

- formele constraints per slot  
- dynamische slotcreatie  
- meerdere zinstypen  
- integratie met Graph-model  
- koppeling aan projectie-engine  


---

## Notitie 2026-04-21

Deze L2-v0-specificatie blijft inhoudelijk ongewijzigd. De opslaglaag erboven heet voortaan `.opn` in plaats van `.ots`, maar dat verandert niets aan het groeimodel zelf.
