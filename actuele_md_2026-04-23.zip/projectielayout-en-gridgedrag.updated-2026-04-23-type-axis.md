# Projectielayout en gridgedrag

## Doel
Deze sectie legt vast hoe projectieknopen en projectielabels worden geplaatst ten opzichte van de bronstructuur en het grid.

## Hoofdregel
Het **grid blijft onveranderd** wanneer projecties worden toegevoegd.

Dat betekent:
- projectieknopen vergroten het grid niet
- projectielabels vergroten het grid niet
- de bronstructuur bepaalt de gridgrenzen
- extra ruimte voor projectieknopen en projectielabels komt uit **render-/margeruimte**, niet uit gridvergroting

## Scheiding tussen grid en rendering
Er wordt onderscheid gemaakt tussen:

### 1. Structuurgrid
- bedoeld voor de bronstructuur
- bepaalt de vaste gridafmetingen

### 2. Renderruimte
- extra tekenruimte buiten het grid
- bedoeld voor projectieknopen en projectielabels
- mag automatisch meegroeien zonder wijziging van het grid zelf

## Huidige projecties

### LEX
- standaardrichting: **links**
- grijpt aan op: **eindknopen**
- labelbron: label van de bronknoop
- huidige transfermodus: **copy**

### LOG
- standaardrichting: **onder**
- grijpt aan op: **vertakkende knopen / P-knooppunten**
- labelbron: label van de bronknoop
- huidige transfermodus: **copy**
- in de eerste implementatieslice alleen bedoeld voor expliciet aanwezige logische labels

### SYN
- standaardrichting: **rechts**
- grijpt aan op: **vertakkende categorieknooppunten**
- labelinhoud wordt **berekend**
- labelbron: **geordende dochtercategorieën van de bronknoop**
- huidige transfermodus: **computed**
- notatie volgt de **JAN-hoofd-/kleinschriftconventie**

## Richtingen
Voor alle projecties moet configuratie mogelijk zijn voor vier richtingen:
- links
- rechts
- boven
- onder

## Labelregels per richting

### Links
- label staat **outwards**
- het label sluit aan op de **linker gridrand**
- tekst blijft voorlopig horizontaal

### Rechts
- label staat **outwards**
- het label sluit aan op de **rechter gridrand**
- tekst blijft voorlopig horizontaal

### Boven
- label staat **outwards**
- het label sluit aan op de **bovenste gridrand**
- tekstoriëntatie is later configureerbaar

### Onder
- label staat **outwards**
- het label sluit aan op de **onderste gridrand**
- labeltekst loopt **naar beneden**, dus niet horizontaal

## Projectieknooppunten
- projectieknooppunten zijn zichtbaar
- projectieknooppunten mogen buiten het bron-grid liggen
- projectieknooppunten worden via een projectielijn verbonden met hun bronknoop
- projectieknooppunten veranderen de gridgrootte niet

## Labeltransfer
Per projectie moet configureerbaar zijn:
- **copy**
- **move**
- later eventueel: **computed**

Huidige default:
- LEX: `copy`
- LOG: `copy`
- SYN: `computed`

## Reserve voor latere uitbreiding
Later moet ondersteuning mogelijk zijn voor:
- berekende SYN-projectie met JAN-notatie voor meer dan twee dochters
- labelmaat-gevoelige render margins
- verschillende offsets per projectie
- verschillende offsets per richting
- eventuele grid-aanpassing als afzonderlijke, expliciet instelbare modus


## Eerste implementatieslice

De eerste werkende implementatie richt zich op een **bestaande getekende boom** en gebruikt deze prioriteit:

1. **LEX links**
2. **SYN rechts**
3. **LOG onder** alleen wanneer logische labels al expliciet aanwezig zijn

Voor deze slice geldt ook:
- projecties moeten zichtbaar zijn zonder vergroting van het structuurgrid
- `sourceBounds` en `renderBounds` moeten technisch gescheiden worden
- **L2-groei** valt buiten deze eerste slice


---

## Bestandsnotitie 2026-04-21

Deze layoutregels blijven inhoudelijk ongewijzigd. Voor opslag geldt voortaan:
- `.graph` = kale snapshot
- `.opn` = rijke OpenSpec-laag

De vroegere aanduiding `.ots` wordt niet meer gebruikt.


---

## Terminologische noot 2026-04-23

De nieuwe TYPE-as luidt:
- `Simple`
- `Phrase`
- `Anaphor`
- `Frame`

Deze layoutregels veranderen daardoor inhoudelijk niet.
