# projection-layout-implementation-plan

## Doel

Dit document zet de vastgelegde projectiespecificatie om in een concreet technisch implementatieplan voor OpenGraphEd.

Het plan dekt:

- classlijst
- Java-skeletten
- opslagvoorstel voor `.graph` / `.opn`
- implementatiefases 1 t/m 6

Dit document sluit aan op:
- `projectie-master-spec.md`
- `l2-growth-spec-v0.md`
- de secties over **Projectielayout en gridgedrag**
- de sectie **Concrete app-config keys voor projectielayout**

Terminologische basis van deze versie:
- hoofdtypes: **Simple**, **Phrase**, **Anaphor**, **Frame**
- **Frame** staat naast de andere types
- **Other** is vervallen
- **L2** is een groeimodus en geen type

---

## 1. Ontwerpdoelen

### 1.1 Functionele doelen
- LEX-projecties kunnen genereren
- LOG-projecties kunnen genereren
- later SYN-projecties rechts kunnen genereren
- projectieknooppunten zichtbaar tonen
- projectielabels richting-specifiek tonen
- projecties kunnen opslaan en opnieuw laden
- de **eerste werkende versie** laten draaien op een **bestaande getekende structuur** binnen de nieuwe TYPE-as (in de praktijk vooral **Simple** en **Phrase**)

### 1.2 Layoutdoelen
- het structuurgrid blijft vast
- projectieknopen vergroten het structuurgrid niet
- projectielabels vergroten het structuurgrid niet
- projecties gebruiken aparte render-/margeruimte
- per richting moet labelplaatsing configureerbaar zijn

### 1.3 Technische doelen
- projecties moeten undo/redo ondersteunen
- projecties moeten export/import ondersteunen
- projecties moeten later uitbreidbaar zijn naar SYN
- model, layout en rendering moeten gescheiden blijven

### 1.4 Eerste verticale doorsnede

De eerste werkende doorsnede wordt expliciet beperkt tot:

- een **statische, bestaande boom**
- **LEX links**
- **SYN rechts** als berekende JAN-notatie
- **LOG onder** alleen wanneer de logische labels al expliciet in de bronstructuur aanwezig zijn
- scheiding tussen **`sourceBounds`** en **`renderBounds`**

Niet in deze eerste doorsnede (historische afbakening van de eerste verticale start):
- L2-groei
- automatische inferentie van logische rollen
- volledige, robuuste opslag en undo/redo van projecties
- uitgebreide UI-bediening

Deze prioriteit volgt uit de gekozen volgorde:
- eerst **model**
- dan **layout**
- dan **rendering**
- pas daarna **opslag** en verdere UI


---

## Statusupdate 2026-04-21

De oorspronkelijke fasering in dit document blijft bruikbaar, maar de actuele codebasis staat inmiddels iets verder op enkele punten:

- de eerste projectieslice voor **LEX links** en **SYN rechts** is begonnen
- `sourceBounds` en `renderBounds` zijn technisch gescheiden
- er bestaat nu een eerste **Save OPN / Load OPN v0**-lijn
- die OPN-lijn is nog **onvolledig**:
  - projection entries zijn nog niet volledig robuust
  - reconstructie vanuit `.opn` is nog niet volledig af
  - undo/redo en persistente projecties zijn nog niet editor-volwassen

Belangrijk:
- de vroegere naam **`.ots`** is vervangen door **`.opn`**
- `opn` staat voor **open**, juist omdat het formaat later niet beperkt mag blijven tot bomen

---

## 2. Architectuur in drie lagen

### 2.1 Structuurlaag
Bevat de feitelijke projectie-entiteiten in het graphmodel:
- projectieknoop
- projectielink
- projectietype
- bronknoop

### 2.2 Layoutlaag
Berekeningslaag:
- selecteert projectiebronnen
- bepaalt richting en offset
- bepaalt positie van projectieknooppunten
- bepaalt positie van projectielabels
- berekent render bounds zonder structuurgrid te wijzigen

### 2.3 Weergavelaag
Tekenlaag:
- tekent projectielijnen
- tekent projectieknooppunten
- tekent projectielabels
- respecteert tekstoriëntatie en labelanker

---

## 3. Classlijst

### 3.1 Enumtypes

```java
public enum ProjectionType {
    LEX, LOG, SYN, PM
}

public enum ProjectionDirection {
    LEFT, RIGHT, UP, DOWN
}

public enum LabelTransferMode {
    COPY, MOVE, COMPUTED
}

public enum ProjectionAttachRule {
    TERMINAL_NODE,
    BRANCHING_NODE,
    COMPUTED
}

public enum LabelAnchor {
    GRID_OUTWARD
}

public enum TextOrientation {
    HORIZONTAL,
    UPWARD,
    DOWNWARD
}

public enum GridResizeMode {
    FIXED,
    EXPAND_FOR_PROJECTIONS
}
```

### 3.2 Config- en specsclasses
- `ProjectionLayoutConfig`
- `ProjectionSpec`
- `DirectionSpec`

### 3.3 Modelclasses
- `ProjectionLink`
- `ProjectionNodeData`
- `ProjectedLabel`
- `ProjectionLayoutResult`

### 3.4 Selectie- en layoutclasses
- `ProjectionSourceSelector`
- `LexSourceSelector`
- `LogSourceSelector`
- `SynSourceSelector`
- `SynLabelFormatter`
- `ProjectionLayoutEngine`

### 3.5 Opslagclasses
- `ProjectionFileCodec`
- of uitbreiding van bestaande graph file read/write classes

### 3.6 Undo/redo
- `AddProjectionMemento`
- `RemoveProjectionMemento`
- `RebuildProjectionMemento`
- `UpdateProjectionConfigMemento`

---

## 4. Java-skeletten

### 4.1 ProjectionLayoutConfig

```java
public final class ProjectionLayoutConfig {
    public GridResizeMode gridResizeMode = GridResizeMode.FIXED;

    public boolean includeSourceStructureInBounds = true;
    public boolean includeProjectionNodesInBounds = false;
    public boolean includeProjectionLabelsInBounds = false;

    public boolean renderMarginEnabled = true;
    public boolean renderMarginIncludeProjectionNodes = true;
    public boolean renderMarginIncludeProjectionLabels = true;

    public ProjectionSpec lex = new ProjectionSpec();
    public ProjectionSpec log = new ProjectionSpec();
    public ProjectionSpec syn = new ProjectionSpec();

    public DirectionSpec left = new DirectionSpec();
    public DirectionSpec right = new DirectionSpec();
    public DirectionSpec up = new DirectionSpec();
    public DirectionSpec down = new DirectionSpec();

    public int projectionOffsetInGridUnits = 1;
    public int labelGapFromProjectionNodeInGridUnits = 0;
}
```

### 4.2 ProjectionSpec

```java
public final class ProjectionSpec {
    public boolean enabled;
    public ProjectionDirection direction;
    public ProjectionAttachRule attachTo;
    public LabelTransferMode labelTransfer;
    public String labelSource;
}
```

### 4.3 DirectionSpec

```java
public final class DirectionSpec {
    public LabelAnchor labelAnchor = LabelAnchor.GRID_OUTWARD;
    public TextOrientation textOrientation = TextOrientation.HORIZONTAL;
    public boolean nodeOutsideGrid = true;
}
```

### 4.4 ProjectionLink

```java
public final class ProjectionLink {
    public Node sourceNode;
    public Node projectionNode;
    public ProjectionType projectionType;
}
```

### 4.5 ProjectionNodeData

```java
public final class ProjectionNodeData {
    public ProjectionType projectionType;
    public Node sourceNode;
    public ProjectionDirection direction;
    public String projectedLabel;
    public boolean generated = true;
}
```

### 4.6 ProjectedLabel

```java
public final class ProjectedLabel {
    public String text;
    public LabelTransferMode mode;
    public String sourceKind;
}
```

### 4.7 ProjectionLayoutResult

```java
public final class ProjectionLayoutResult {
    public Rectangle sourceBounds;
    public Rectangle renderBounds;
}
```

### 4.8 ProjectionSourceSelector

```java
public interface ProjectionSourceSelector {
    boolean matches(Node node, Graph graph);
}
```

### 4.9 LexSourceSelector

```java
public final class LexSourceSelector implements ProjectionSourceSelector {
    @Override
    public boolean matches(Node node, Graph graph) {
        return node != null && node.getDegree() <= 1;
    }
}
```

### 4.10 LogSourceSelector

```java
public final class LogSourceSelector implements ProjectionSourceSelector {
    @Override
    public boolean matches(Node node, Graph graph) {
        return node != null && node.getDegree() >= 2;
    }
}
```

### 4.11 SynSourceSelector

```java
public final class SynSourceSelector implements ProjectionSourceSelector {
    @Override
    public boolean matches(Node node, Graph graph) {
        return node != null && node.getDegree() >= 2;
    }
}
```

### 4.12 SynLabelFormatter

```java
public interface SynLabelFormatter {
    String format(List<String> orderedChildCategories);
}
```

### 4.13 ProjectionLayoutEngine

```java
public final class ProjectionLayoutEngine {

    public ProjectionLayoutResult computeLayout(Graph graph, ProjectionLayoutConfig config) {
        ProjectionLayoutResult result = new ProjectionLayoutResult();
        result.sourceBounds = computeSourceBounds(graph, config);
        result.renderBounds = computeRenderBounds(graph, config, result.sourceBounds);
        return result;
    }

    protected Rectangle computeSourceBounds(Graph graph, ProjectionLayoutConfig config) {
        return new Rectangle();
    }

    protected Rectangle computeRenderBounds(
            Graph graph,
            ProjectionLayoutConfig config,
            Rectangle sourceBounds) {
        return new Rectangle(sourceBounds);
    }
}
```

---

## 5. Uitbreidingen aan Graph

### 5.1 Nieuwe velden in Graph
Voorstel:

```java
private ProjectionLayoutConfig projectionLayoutConfig;
private List<ProjectionLink> projectionLinks;
```

### 5.2 Nieuwe methods in Graph

```java
public ProjectionLayoutConfig getProjectionLayoutConfig();
public void setProjectionLayoutConfig(ProjectionLayoutConfig config);

public List<ProjectionLink> getProjectionLinks();

public void clearProjections();
public void rebuildProjections();
public void buildProjection(ProjectionType type);

public List<Node> getProjectionSources(ProjectionType type);
```

### 5.3 Doel van echte modelobjecten
Projecties moeten niet alleen visueel bestaan, maar ook:
- selecteerbaar zijn
- opslaan/laadbaar zijn
- undo/redo ondersteunen
- herberekend kunnen worden
- later per projectietype beheerd kunnen worden

---

## 6. Selectieregels per projectie

### 6.1 LEX
Huidige regel:
- aangrijpen op eindknopen

Voorlopige technische interpretatie:
- knoop met graad `<= 1`

Opmerking:
- later verfijnen als de formele definitie van `eindknoop` preciezer wordt

### 6.2 LOG
Huidige regel:
- aangrijpen op vertakkende knopen / P-knooppunten

Voorlopige technische interpretatie:
- knoop met graad `>= 2`

Opmerking:
- in de **eerste implementatieslice** alleen gebruiken wanneer logische labelinhoud al expliciet op de bronstructuur aanwezig is
- automatische inferentie van Subject/Object/Verb valt buiten deze slice
- later verfijnen als phrase-/vertakkingsknoop semantisch anders wordt gedefinieerd

### 6.3 SYN
Huidige regel:
- aangrijpen op vertakkende categorieknooppunten
- label wordt berekend uit geordende dochtercategorieën

Voorlopige technische interpretatie:
- knoop met graad `>= 2`
- lees de dochterlabels in vaste links-naar-rechtsvolgorde
- formatteer de output volgens JAN-notatie

Opmerking:
- in de **eerste implementatieslice** beperken tot de eenvoudige JAN-gevallen op bestaande bomen
- eerst uitgaan van expliciete links-naar-rechts boomorde en eenvoudige formattering
- later verfijnen voor gevallen met meer dan twee dochters

---

## 7. Labeltransfer

### 7.1 COPY
- bronlabel blijft zichtbaar op de bronknoop
- projectieknoop krijgt een kopie van de labeltekst

### 7.2 MOVE
- bronlabel wordt niet meer bij de bron getoond
- label wordt getoond bij de projectieknoop

### 7.3 COMPUTED
- label ontstaat uit berekeningslogica
- voor SYN: uit geordende dochtercategorieën van een vertakkende knoop
- formattering volgt de JAN-hoofd-/kleinschriftconventie

### 7.4 Reden om dit expliciet te modelleren
`copy` en `move` zijn geen puur visuele varianten, maar semantische modi die effect hebben op:
- rendering
- opslag
- undo/redo
- toekomstig UI-gedrag

---

## 8. Layoutregels

### 8.1 Structuurbounds versus renderbounds
De layoutlaag moet twee grenzen onderscheiden:

#### sourceBounds
Bevat alleen:
- bronstructuur
- bestaande structurele bounds

#### renderBounds
Bevat:
- bronstructuur
- projectieknopen
- projectielabels
- extra render margins

### 8.2 Hoofdregel
Niet:
```java
graphBounds = everythingVisible;
```

Wel:
```java
sourceBounds = computeSourceBounds();
renderBounds = expandForProjectionRendering(sourceBounds);
```

### 8.3 Richtingsregels

#### LEFT
- projectieknoop links van bronknoop
- label sluit outwards aan op linker gridrand
- tekst voorlopig horizontaal

#### RIGHT
- projectieknoop rechts van bronknoop
- label sluit outwards aan op rechter gridrand
- tekst voorlopig horizontaal
- hier komt de huidige SYN-notatieprojectie te staan

#### UP
- projectieknoop boven bronknoop
- label sluit outwards aan op bovenste gridrand
- tekstoriëntatie later verfijnbaar

#### DOWN
- projectieknoop onder bronknoop
- label sluit outwards aan op onderste gridrand
- labeltekst loopt naar beneden

---

## 9. Rendering

### 9.1 Nieuwe renderfasen
Voorstel binnen graph draw pipeline:

1. bronstructuur tekenen
2. projectielijnen tekenen
3. projectieknopen tekenen
4. projectielabels tekenen

### 9.2 Waarom aparte labelfase
Omdat projectielabels:
- een andere tekstoriëntatie kunnen hebben
- buiten het structuurgrid kunnen vallen
- niet mogen terugwerken op de gridberekening

---

## 10. Opslagvoorstel voor `.graph` / `.opn`

### 10.1 Ontwerpeis
Projecties mogen niet alleen impliciet bestaan via:
- gewone labels
- generated edges
- toevallige extra knopen

Projectie-informatie moet expliciet opslaan:
- type
- bronknoop
- projectieknoop
- richting
- transfermodus
- labeltekst

### 10.2 Graph-level configsectie
Voorstel:

```text
<- Projection Layout Config Present ->
<- Grid Resize Mode ->
<- Include Source Structure In Bounds ->
<- Include Projection Nodes In Bounds ->
<- Include Projection Labels In Bounds ->
<- Render Margin Enabled ->
<- Render Margin Include Projection Nodes ->
<- Render Margin Include Projection Labels ->
<- Projection Offset In Grid Units ->
<- Label Gap From Projection Node In Grid Units ->
```

### 10.3 Projection entries
Voorstel:

```text
<- Number Of Projections ->
<- Projection Index ->
<- Projection Type ->
<- Source Node Index ->
<- Projection Node Index ->
<- Direction ->
<- Label Transfer Mode ->
<- Attach Rule ->
<- Projected Label Text ->
```

### 10.4 Waarom expliciete projectiesectie
Voordelen:
- helder formaat
- geen misbruik van gewone edge/node-semantiek
- export/import blijft stabiel
- latere SYN-uitbreiding blijft schoon

---

## 11. Undo/redo

### 11.1 Nieuwe mementos
Voorstel:
- `AddProjectionMemento`
- `RemoveProjectionMemento`
- `RebuildProjectionMemento`
- `UpdateProjectionConfigMemento`

### 11.2 Minimale verantwoordelijkheden
- projectieknoop toevoegen/verwijderen
- projectielink toevoegen/verwijderen
- configwijziging herstelbaar maken
- rebuild als één logische operatie kunnen terugdraaien

### 11.3 Reden
Projecties zijn geen tijdelijk tekeneffect, maar modelwijzigingen. Daarom moeten ze op hetzelfde niveau behandeld worden als andere graphbewerkingen.

---

## 12. Implementatiefases 1 t/m 6

### Fase 1 — Config en enums
Doel:
- de basisstructuur compilabel maken

Taken:
- enumtypes toevoegen
- `ProjectionLayoutConfig`
- `ProjectionSpec`
- `DirectionSpec`

Resultaat:
- vaste representatie van projectie-instellingen

### Fase 2 — Selectie van bronknopen
Doel:
- LEX-, LOG- en SYN-bronnen automatisch kunnen bepalen

Taken:
- `ProjectionSourceSelector`
- `LexSourceSelector`
- `LogSourceSelector`
- `SynSourceSelector`

Resultaat:
- lijst van bronknopen per projectietype

### Fase 3 — Modelobjecten en rebuild
Doel:
- projecties als echte objecten in het graphmodel opnemen

Taken:
- `ProjectionLink`
- `ProjectionNodeData`
- `ProjectedLabel`
- graphvelden en graphmethods
- `clearProjections()`
- `rebuildProjections()`
- `buildProjection(ProjectionType type)`

Resultaat:
- projecties bestaan echt in het model

### Fase 4 — Layout en rendering
Doel:
- projecties zichtbaar maken zonder gridvergroting

Taken:
- `ProjectionLayoutEngine`
- `sourceBounds` / `renderBounds`
- projectielijnen tekenen
- projectieknopen tekenen
- labelplaatsing links, rechts en onder
- outwards anchor
- downward text
- eerste `SynLabelFormatter` koppelen aan rechter projectielabels
- eerste slice richten op **LEX links** en **SYN rechts** op een bestaande getekende boom

Resultaat:
- eerste bruikbare visuele projecties op een statische boom zonder gridvergroting

### Fase 5 — Opslag en undo/redo
Doel:
- projecties persistent en herstelbaar maken

Taken:
- fileformaat uitbreiden
- lezen en schrijven van config + projecties
- mementos toevoegen
- rebuild als undo/redo-eenheid modelleren

Resultaat:
- projecties blijven bestaan na opslaan/laden
- projecties zijn editorwaardig

### Fase 6 — SYN-voorbereiding en verfijning
Doel:
- architectuur klaarzetten voor berekende syntactische notatieprojecties

Taken:
- `SynLabelFormatter` verfijnen
- JAN-hoofd-/kleinschriftconventie expliciet modelleren
- gedrag voor meer dan twee dochters vastleggen
- richting-specifieke verfijning boven/rechts
- latere UI-koppeling

Resultaat:
- architectuur klaar voor SYN-notatie rechts

---

## 13. Aanbevolen bouwvolgorde

1. Fase 1
2. Fase 2
3. Fase 3
4. Fase 4
5. Fase 5
6. Fase 6

Belangrijk:
- niet eerst UI
- niet eerst losse labelrendering
- eerst model en opslag stabiel maken

---

## 14. Eerste concrete ontwikkeltaak

De eerstvolgende praktische ontwikkelstap is:

### Stap A
Voeg de enumtypes en configclasses toe.

### Stap B
Voeg aan `Graph` de velden en methods toe voor:
- `ProjectionLayoutConfig`
- `List<ProjectionLink>`
- `clearProjections()`
- `rebuildProjections()`

### Stap C
Implementeer voorlopig:
- `LexSourceSelector`
- `SynSourceSelector`

### Stap D
Laat `rebuildProjections()` in de eerste slice:
- bestaande projecties wissen
- **LEX-projecties links** opbouwen
- **SYN-projecties rechts** opbouwen
- SYN-labels berekenen uit geordende dochtercategorieën
- projectieknopen op vaste grid-offset plaatsen

### Stap E
Implementeer direct de scheiding tussen:
- `sourceBounds`
- `renderBounds`

zodat projecties zichtbaar zijn zonder vergroting van het structuurgrid.

### Stap F
Behandel **LOG** in deze slice alleen wanneer logische labelinhoud al expliciet beschikbaar is op de bronstructuur.

Dat geeft snel een eerste testbare verticale doorsnede die overeenkomt met de JAN-use-case.

---

## 15. Besluit

De technisch juiste route is nu:

- **eerst model**
- dan **layout**
- dan **rendering**
- dan **opslag**
- pas daarna verdere UI-verfijning

Zo blijft de implementatie in lijn met:
- de bestaande JGraphEd/OpenGraphEd-architectuur
- de nieuwe master-spec
- de eis dat projecties niet het structuurgrid vergroten

---

## 16. L2-integratie

### 16.1 Doel
De projectie-architectuur moet expliciet kunnen aansluiten op het L2-groeimodel uit `l2-growth-spec-v0.md`.

Belangrijke volgorderegel:
- **L2 maakt geen deel uit van de eerste implementatieslice**
- eerst wordt de projectie-architectuur getest op **statische bomen**
- daarna wordt L2-groei aangesloten

Hoofdregel:
- eerst groeit de L2-structuur
- daarna worden projecties afgeleid van de voltooide structuur

Daarmee blijft het onderscheid helder tussen:
- **groeilogica**
- **projectielogica**
- **renderlogica**

### 16.2 Extra classes voor L2
Aanvullend op de bestaande projectieclasses zijn voor L2 minimaal nodig:
- `GrowthState`
- `OpenSlot`
- `SlotType`
- `L2GrowthEngine`

### 16.3 Java-skeletten voor L2

#### 16.3.1 SlotType

```java
public enum SlotType {
    LEX_LEFT_EDGE,
    VERB_FINITE,
    DET_SLOT,
    NOUN_SLOT,
    VERB_PARTICIPLE
}
```

#### 16.3.2 OpenSlot

```java
public final class OpenSlot {
    public Node hostNode;
    public SlotType slotType;
    public int priority;
    public boolean occupied;
}
```

#### 16.3.3 GrowthState

```java
public final class GrowthState {
    public Node root;
    public List<OpenSlot> openSlots = new ArrayList<>();
    public List<String> history = new ArrayList<>();
}
```

#### 16.3.4 L2GrowthEngine

```java
public final class L2GrowthEngine {

    public GrowthState initialize();

    public OpenSlot firstOpenSlot(String token, GrowthState state);

    public void place(String token, OpenSlot slot, GrowthState state);

    public void updateState(GrowthState state);
}
```

### 16.4 Uitbreidingen aan Graph voor L2
Voorstel:

```java
private GrowthState growthState;
```

Extra methods:

```java
public GrowthState getGrowthState();
public void setGrowthState(GrowthState growthState);
public void resetGrowthState();
public void buildL2FromTokens(List<String> tokens);
```

### 16.5 Relatie tussen L2 en projecties
Belangrijk onderscheid:

- tijdens L2-groei is een knoop nog niet noodzakelijk stabiel als eindknoop of vertakkende knoop
- de huidige voorlopige selectors op basis van graad (`<= 1`, `>= 2`) zijn bruikbaar voor bestaande statische bomen
- voor L2 moeten projecties idealiter worden afgeleid **na voltooiing van de groeifase**

Dus voorlopig:
- voor bestaande getekende bomen mogen `LexSourceSelector` en `LogSourceSelector` op graad werken
- voor L2 moet later een explicietere bronselectie mogelijk worden op basis van het voltooide L2-model

### 16.6 Extra implementatiestap
Na de huidige eerste verticale doorsnede is de logisch volgende stap:

1. `SlotType` toevoegen
2. `OpenSlot` toevoegen
3. `GrowthState` toevoegen
4. `L2GrowthEngine` toevoegen
5. `buildL2FromTokens(...)` als aparte instappunt in `Graph` of controller toevoegen
6. pas daarna projecties automatisch afleiden uit de voltooide L2-boom

---

## 17. Wijziglog

- **2026-04-23**: terminologie aangepast aan de nieuwe TYPE-as: **Simple / Phrase / Anaphor / Frame**. `Other` vervalt; `Frame` staat naast de andere types; **L2** blijft een groeimodus.


- **2026-04-21**: `.ots` hernoemd naar `.opn`; Save/Load OPN v0 als eerste OpenSpec-lijn toegevoegd, nog zonder volledige reconstructie van alle projection entries.
- **2026-04-18**: implementatievolgorde aangescherpt: eerste werkende doorsnede op statische, getekende structuren — in de praktijk vooral **Simple** en **Phrase** — met **LEX links**, **SYN rechts** en directe scheiding tussen `sourceBounds` en `renderBounds`; **L2** en automatische LOG-inferentie later.
- **2026-04-18**: SYN aangescherpt als rechter notatieprojectie op vertakkende categorieknooppunten; `SynSourceSelector` en `SynLabelFormatter` toegevoegd aan het plan.
- **2026-04-18**: labelbron voor SYN verduidelijkt als geordende dochtercategorieën in links-naar-rechtsvolgorde, met JAN-hoofd-/kleinschriftconventie.
- **2026-04-18**: document uitgebreid met expliciete L2-integratie, inclusief `GrowthState`, `OpenSlot`, `SlotType` en een voorstel voor `L2GrowthEngine`.
- **2026-04-18**: verduidelijkt dat projecties bij L2 pas idealiter na voltooiing van de groeifase uit de structuur worden afgeleid.
