# wijziglog-2026-04-21-opn-doc-update

## Overzicht
Deze set actualiseert de markdownbestanden na de overgang van **`.ots`** naar **`.opn`** en na de eerste beginstappen van **Save/Load OPN v0**.

Kernpunten:
- `.ots` wordt verlaten ten gunste van **`.opn`**
- `opn` staat voor **open**, zodat het formaat later niet beperkt blijft tot bomen
- `.graph` blijft het **kale, JGraphEd-compatibele snapshotformaat**
- `.opn` wordt het **rijkere OpenSpec-formaat**
- de documentatie noteert nu expliciet dat **Save/Load OPN v0** al begonnen is, maar nog niet volledig af is

## Bestanden

### 1. `projectie-master-spec.updated-2026-04-21-opn.md`
Wijzigingen:
- nieuwe sectie toegevoegd over **bestandsformaten**
- onderscheid vastgelegd tussen `.graph` en `.opn`
- expliciet gemaakt dat `.opn` neutraler is dan `.ots` omdat het project niet bij bomen blijft
- wijziglog aangevuld met de formaatwijziging

### 2. `projection-layout-implementation-plan.updated-2026-04-21-opn.md`
Wijzigingen:
- alle verwijzingen naar `.ots` vervangen door `.opn`
- statusupdate toegevoegd over de actuele codebasis
- verduidelijkt dat Save/Load OPN v0 begonnen is maar nog onvolledig is
- wording aangescherpt zodat de oorspronkelijke fases als historisch plan leesbaar blijven

### 3. `projectielayout-en-gridgedrag.updated-2026-04-21-opn.md`
Wijzigingen:
- inhoudelijk ongewijzigd
- korte bestandsnotitie toegevoegd voor `.graph` versus `.opn`

### 4. `l2-growth-spec-v0.updated-2026-04-21-opn.md`
Wijzigingen:
- inhoudelijk ongewijzigd
- korte notitie toegevoegd dat de opslaglaag voortaan `.opn` heet

## Uitvoer
Doel van deze set is om de documentatie weer in lijn te brengen met:
- de recente codewijzigingen rond **OPN**
- het bredere projectdoel waarin niet alleen bomen maar ook andere structuren moeten passen
