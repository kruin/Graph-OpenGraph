Mapping V4 v4.28.9 source strip

Patch: Tree menu origineel + Uitleg.

Added:
- Tree-keuzelijst begint met: origineel.
- Origineel herlaadt de oorspronkelijke .graph van schijf.
- Nieuwe knop: Uitleg.
- Uitleg verklaart het huidige Tree-type: origineel, Simple, Language, Functional, Frame, Anaphor.

Build:
- Run build.bat from the project directory.
- Paths with spaces are supported.
