OpenGraphEd Mapping V4 v4.28.7 source strip

Wijzigingen v4.28.7:
- v4286 teruggedraaid: Simple is niet meer hardcoded Branches=2.
- Alle Tree-types gebruiken dezelfde per-node Branches-config uit de editor:
  auto, 2, 3, 4, many.
- Branches=2 werkt nu als lokale node-config, ook in Simple.
- Tree-layout compacter gemaakt:
  - geen extra lege horizontale gridrij na terminale subtrees;
  - eerste n-ary corridors gebruiken geen lege verticale tussenkolom;
  - Branches=2 gebruikt compacte slots -1 / +1 in plaats van -2 / +2.
- Projectienaam boven, bijvoorbeeld FRAME, wordt horizontaal getekend.
- Eventuele boven-projectielabels worden ook horizontaal geplaatst.

Build:
- Gebruik build.bat vanuit de uitgepakte projectmap.
- Deze strip bevat geen out/, dist/, .class of .jar-bestanden.
