OpenGraphEd v4.28.4 source strip

Purpose:
- Source-only package for rebuilding OpenGraphEd.
- Fixes build.bat generation of the javac @argfile on Windows.

Build fix in v4.28.4:
- build.bat now uses delayed expansion inside :append_source.
- Source paths are written as relative paths with forward slashes.
- Prevents cmd.exe/javac argfile issues that produced errors such as:
  error: file not found: C:...dataStructureDoublyLinkedList.java
  error: Class names, 'CD', are only accepted if annotation processing is explicitly requested

Expected usage:
1. Unzip into any folder, including paths with spaces.
2. Run build.bat.
3. Run OpenGraphEd.bat or OpenGraphEd-console.bat.

Strip policy:
- Excludes .class files, out/, dist/, jars, and local build temp output.
- Includes Java sources, config, help/images, examples, md, tools, and batch scripts.
