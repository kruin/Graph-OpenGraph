OpenGraphEd source strip v4295
==============================

Doel: bronpakket zonder build-output.

Belangrijkste wijziging:
- Tree > OpenGraph carrousel uitgebreid met verwijderen, volgorde verschuiven, verplaatsen, wisselen en standaardnavigatie.

Niet meegeleverd in deze strip:
- .class
- out/
- dist/
- .build-tmp/
- .jar

Build:
  build.bat

Compile-check uitgevoerd met javac: OK, alleen bestaande waarschuwingen.
