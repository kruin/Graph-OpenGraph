# CHANGELOG v4307 — Greedy resultaat als echte OpenGraphEd-importworkflow

## Doel

Deze versie maakt van het Greedy-resultaat niet alleen een directe laadactie, maar een expliciete importworkflow binnen OpenGraphEd.

## Nieuw

Onder menu **OpenGraph** zijn toegevoegd:

```text
Settings + Generate + Import Greedy OPN
Generate + Import Greedy OPN
```

Deze route doet:

1. Greedy-generator headless uitvoeren vanuit `tools/greedy_generator_gui/spec.yaml`.
2. Het laatst gegenereerde `.opn`-bestand vinden via `last_generated.txt` of de outputmap.
3. Een importdialoog tonen met het gegenereerde resultaat.
4. De gebruiker laten kiezen:
   - `Import OPN`
   - `Preview PNG`
   - `Report`
   - `Effective Spec`
   - `Output Folder`
   - `Cancel`
5. Alleen bij `Import OPN` wordt de `.opn` daadwerkelijk geladen in OpenGraphEd.

## Behouden

De directe route blijft bestaan:

```text
Generate + Load Greedy OPN
Settings + Generate + Load Greedy OPN
```

Die laadt de `.opn` direct, zonder importdialoog.

## Technisch

Aangepast:

- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
- `userInterface/GraphController.java`
- `userInterface/OpenGraphActions.java`

Toegevoegd in `OpenGraphActions`:

- importworkflow-actieconstanten;
- `showGreedyImportWorkflow(File opnFile)`.

Toegevoegd in `GraphController`:

- `configureGenerateAndImportGreedyOPN()`;
- `generateAndImportGreedyOPN()`;
- `runGreedyImportWorkflow(File opnFile)`.

## Test

Uitgevoerd in deze buildomgeving:

```text
javac compile: OK
jar build: OK
headless greedy generation: OK
.opn-output: OK
.png-output: OK
```

Niet in deze omgeving getest: klikken in Windows/OpenGraphEd.
