# Changelog v4.28.5

## Verzoek
- Editorwijzigingen moeten zichtbaar zijn na Draw.
- UI-label Type veranderen naar Tree.
- Tree-volgorde: Simple - Language - Functional - Frame - Anaphor.
- Simple tree binair/recursief.
- Overige trees per categoriale knoop configureerbaar: branches 2, 3, 4 of many.

## Aangepast
- `userInterface/OpenGraphActions.java`: Draw, zinstype en V-cluster redraw laden niet meer standaard de oorspronkelijke graph opnieuw.
- `userInterface/GraphEditorWindow.java`: headerlabel en combovolgorde aangepast.
- `userInterface/OpenGraphDialog.java`: tree-keuze en volgorde aangepast.
- `graphStructure/Node.java`: per-node `treeBranchMode` toegevoegd.
- `graphStructure/GraphPersistenceSupport.java`: branch-metadata opslaan/laden toegevoegd.
- `userInterface/modes/EditListener.java` en `EditListenerPopupSupport.java`: editor-popup `Branches...` toegevoegd.
- `operation/OpenGraphTreeDrawOperation.java`: branch-limit layout voor 2/3/4 toegevoegd; Simple gebruikt 2 als default.

## Compile-test
- `javac -d out @sources.txt`: geslaagd.
- Resultaat: 1 bestaande deprecation-waarschuwing, geen compile-errors.
