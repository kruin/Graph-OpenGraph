# CHANGELOG v4308 — Greedy internal Java engine

## Doel

Start van fase 3: de Greedy-generator kan nu ook binnen Java/OpenGraphEd draaien zonder Python-headless route.

## Nieuw in menu OpenGraph

```text
Settings + Generate Internal + Import Greedy OPN
Generate Internal + Import Greedy OPN
```

## Werking

- Leest `tools/greedy_generator_gui/spec.yaml`.
- Genereert intern in Java dezelfde soort Greedy-punten.
- Schrijft `.opn`, `.graph`, `.svg`, `.png`, rapport, effective spec en `last_generated.txt`.
- Opent daarna dezelfde importworkflow als v4307.

## Externe generator blijft aanwezig

De bestaande Python/Tkinter-generator en de externe headless route blijven bestaan. v4308 voegt een interne route toe, zodat resultaten vergeleken kunnen worden voordat de Python-afhankelijkheid eventueel wordt verminderd.

## Test

- Java compile: OK.
- JAR build: OK.
- Interne Java-generatie met `spec.yaml`: OK.
