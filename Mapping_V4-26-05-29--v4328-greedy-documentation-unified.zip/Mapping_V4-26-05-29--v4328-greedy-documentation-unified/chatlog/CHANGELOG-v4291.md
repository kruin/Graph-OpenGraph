# CHANGELOG v4.29.1 — Uitleg OpenGraph-notatie en vrije knopen

## Vraag
- In de uitleg meer nadruk op de OpenGraph-notatie.
- Benoem dat middels vrije knopen ruimte ontstaat voor de diverse projecties.
- Gedetailleerde uitleg bij Simple; bij de rest daarnaar verwijzen.
- Als er iets is aangepast, altijd de aangepaste versie leveren.

## Wijzigingen
- `userInterface/GraphEditorWindow.java`
  - Knop `Uitleg` gebruikt nu een scrollbaar tekstvenster, zodat langere inhoudelijke uitleg leesbaar blijft.
  - `origineel` legt nu uit dat dit de actuele OpenGraph-bronnotatie toont: vrije graph met knopen, labels en takken.
  - `Simple` is uitgebreid tot basisuitleg voor de OpenGraph-tree-notatie:
    - vrije knopen;
    - projectieruimte;
    - minimum kindtakken: 0 of 2+;
    - richting irrelevant;
    - binair en n-air;
    - Branches-config: auto, 2, 3, 4, many;
    - recursieve box-aanpak;
    - compact tekenen zonder lege horizontale of verticale gridlijnen;
    - Simple als controlelaag voor boomgeldigheid.
  - `Language` verwijst naar Simple voor de basisnotatie en legt daarna LEX, LEX-regels, SYN en LF inhoudelijk uit.
  - `Functional`, `Frame` en `Anaphor` verwijzen naar Simple en benoemen voorlopig alleen hun projectieve doelrichting.
- `build.bat`
  - Manifestversie bijgewerkt naar v4.29.1.

## Test
- Java compile-check uitgevoerd.
- Resultaat: build OK, alleen de bestaande Java-waarschuwing over `new Integer(...)`.
