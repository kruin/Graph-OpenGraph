# CHANGELOG v4310 — OPN vrije knoop bronnotatie

## Doel

v4310 werkt de vrije knoop en de OPN-bronnotatie verder uit.

## Gewijzigd

- Greedy internal Java engine schrijft OPN v0.3.
- Externe Python Greedy-generator schrijft OPN v0.3.
- `Save OPN` schrijft nu ook OPN_SOURCE_NOTATION en FREE_NODES.
- Nieuwe OPN-secties:
  - `OPN_SOURCE_NOTATION`
  - `FREE_NODES`
  - `GROWTH_ORDER`
- `STRUCTURE_NODES` blijft compatibel met de bestaande loader.
- OpenGraphEd herkent vrije-bronnotatie en toont dit in het Info-venster.
- Greedy Settings helptekst uitgebreid met uitleg over vrije knopen en OPN-source-grid.
- Nieuwe documentatie: `md/OPN-BRONNOTATIE-VRIJE-KNOOP-v4310.md`.

## Niet gewijzigd

- Interne Java-engine blijft de standaard Greedy-route.
- Externe Python-generator blijft fallback/reference.
- OPN-import blijft de bestaande pipe-safe tekenlaag gebruiken voor zichtbare nodes/edges.

## Test

- Java compile: OK.
- JAR build: OK.
- Interne Greedy generatie: OK.
- OPN v0.3 bevat STRUCTURE_NODES, FREE_NODES en GROWTH_ORDER.
