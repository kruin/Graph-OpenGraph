# CHANGELOG v4320 — Greedy display first, save later

## Aanleiding

De OpenGraph-menustructuur werd te druk. Ook was de Greedy-route te veel gericht op eerst outputbestanden maken en daarna importeren/laden. Gewenst is: eerst direct tonen, daarna finetunen, pas daarna expliciet opslaan.

## Gewijzigd

- OpenGraph-menu versimpeld tot hoofdacties.
- Nieuwe normale route: `Generate Greedy Graph`.
- Interne Java Greedy-engine kan nu direct een `Graph` in geheugen maken.
- Geen verplichte save/load-cyclus meer voor de normale route.
- Nieuwe `Save As...`-actie met keuze voor `.graph`, `.opn` of image.
- Geavanceerde Greedy-acties verplaatst naar `Greedy Tools...`.

## Behouden

- Externe Python/Tkinter-generator blijft beschikbaar als fallback/reference.
- Oude importfuncties blijven in code aanwezig voor fallback en test, maar staan niet meer als losse hoofdmenu-items in OpenGraph.
- Gridnaam- en legacy-renamegedrag uit v4311-v4319 blijft behouden.

## Teststatus

- `javac`: OK, alleen bestaande deprecation/unchecked warnings.
- JAR: OK.
- Headless preview-generator: OK.
