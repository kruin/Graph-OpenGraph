# CHANGELOG v4327 — Greedy package PNG/SVG + menu cleanup

## Context

Gebruiker meldde dat de Greedy package voor grid `19,21` nog geen `.svg` en `.png` bevatte. Daarnaast moest het menu-item `Greedy Settings` hernoemd worden naar `Greedy Generator`, en `Grid Settings` leek overbodig in het hoofdmenu.

## Wijzigingen

1. `Greedy -> Greedy Settings` hernoemd naar:

```text
Greedy -> Greedy Generator
```

2. `Grid Settings` is verwijderd uit het hoofdmenu `Greedy`.

3. De gridinstelling blijft beschikbaar via:

```text
Greedy -> Greedy Tools... -> Grid Settings / Reapply Grid
```

Daarmee is grid-correctie nog mogelijk, maar niet langer prominent in de hoofdworkflow.

4. `Greedy package (.zip)` bevat nu ook:

```text
<base>.svg
<base>.png
```

naast:

```text
<base>.opn
<base>.graph
spec.yaml
effective_spec.yaml
<base>_report.txt
README-GREEDY-PACKAGE.txt
<base>_preview.gif   # legacy preview, indien beschikbaar
```

5. De package-README is aangepast zodat `.svg` en `.png` expliciet genoemd worden.

## Test

- Java compile: OK.
- JAR build: OK.
- Menu descriptor check: OK.
