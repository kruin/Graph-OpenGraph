# CHANGELOG v4325 — gridtag save uses active grid

## Fix

- Greedy Save As now derives `gridH...W...` from the active grid at save time.
- A stale prefilled filename such as `space3_gridH20W20.zip` no longer resets the graph or package back to `20,20`.
- If the user chooses grid cell `18,22`, Save As proposes and writes `gridH18W22`.
- Manual Set Grid Size now also updates the OpenGraphGrid settings cache, so later Greedy saves use the same cell size.

## Rule

The filename grid tag follows the active graph/editor grid. The filename is not allowed to override the active grid silently.
