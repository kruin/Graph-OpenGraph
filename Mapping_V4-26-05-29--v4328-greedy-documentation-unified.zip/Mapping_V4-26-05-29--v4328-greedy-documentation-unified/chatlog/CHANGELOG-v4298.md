# CHANGELOG v4.29.8 - OpenGraph carousel upload reminder

## Vraag

Voeg aan de carrousel-reminder toe:

> Upload die zip hier mee bij je volgende verzoek.

## Aanpassing

- `Tree > OpenGraph > Reminder` bevat nu expliciet dat de exportzip hier moet worden meegeüpload bij het volgende verzoek.
- De permanente korte reminderregel onder de carrouseltekst bevat dit ook.
- De melding na `Export carousel` bevat dit ook.
- `opengraph_carousel/README.txt` en `examples/opengraph-carousel/README.txt` zijn bijgewerkt.

## Git

De app voert geen git-commando's uit. Git blijft handwerk:

```text
git add opengraph_carousel
git commit -m "update opengraph carousel"
git push
```
