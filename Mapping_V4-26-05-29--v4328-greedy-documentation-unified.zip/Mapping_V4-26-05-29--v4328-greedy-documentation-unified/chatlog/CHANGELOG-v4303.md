# CHANGELOG v4303 - Greedy menu descriptor fix

## Fix

- Fixed startup crash in v4302:
  `NullPointerException` in `MenuAndToolBarBuildSupport.addActionControls`.
- Cause: the menu descriptor for `Settings + Generate + Load Greedy OPN` contained commas inside the description field.
  The existing menu parser uses comma-separated descriptors, so the descriptor was split into too many tokens and produced a null action.
- Removed commas from that menu descriptor.
- Added a defensive check in `MenuAndToolBarBuildSupport` so future malformed action descriptors fail with a clear message instead of a NullPointerException.
- Added an explicit error if a menu action references a missing `GraphController` method.

## Functional change

No intended functional change. This is a startup/menu-build fix for v4302.

## Test advice

1. Run `run.bat`.
2. Confirm OpenGraphEd starts.
3. Test `OpenGraph -> Greedy Settings`.
4. Test `OpenGraph -> Settings + Generate + Load Greedy OPN`.
