# CHANGELOG v4.28.9 — Tree origineel en Uitleg

## Aanleiding

In de Tree-keuzelijst ontbrak een directe terugkeer naar de bronboom. Daarnaast was er geen korte uitlegknop voor het actuele Tree-type.

## Wijziging

- Tree-keuzelijst begint nu met `origineel`.
- `origineel` herlaadt de oorspronkelijke `.graph` van schijf en verwijdert het huidige OpenGraph-drawresultaat uit het venster.
- Nieuwe knop `Uitleg` naast de Tree-keuze.
- `Uitleg` toont uitleg voor het actuele Tree-type:
  - origineel
  - Simple
  - Language
  - Functional
  - Frame
  - Anaphor

## Gedrag

- `origineel` tekent niet; het keert terug naar de bronboom.
- `Simple`, `Functional`, `Frame` en `Anaphor` blijven via `Draw` tekenen.
- `Language` blijft via de zinstypeknoppen tekenen; `Draw` blijft daar verborgen.
- Na terugkeer naar `origineel` worden OPN-status en tijdelijke OpenGraph-renderartefacten opgeruimd.

## Aangepaste bestanden

- `userInterface/GraphEditorWindow.java`
- `userInterface/GraphController.java`
- `userInterface/OpenGraphActions.java`
- `build.bat`
