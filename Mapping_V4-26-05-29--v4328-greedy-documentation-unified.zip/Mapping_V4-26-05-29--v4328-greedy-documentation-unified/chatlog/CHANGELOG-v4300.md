# CHANGELOG v4300 — Greedy Generator integration

## Doel

Fase-1 integratie van de Greedy Graph Generator in OpenGraphEd.

## Gewijzigd

- Nieuw menu-item onder `OpenGraph`:
  - `Greedy Generator`
  - `Open Greedy OPN`
- `Greedy Generator` start de meegeleverde generator via:

```text
tools/greedy_generator_gui/start_gui.bat
```

- `Open Greedy OPN` opent een OPN-bestandskiezer in:

```text
tools/greedy_generator_gui/output
```

- De Greedy Generator v2.3 is meegeleverd in `tools/greedy_generator_gui/`.
- De generator schrijft `.graph`, `.opn`, `.svg`, `.png`, rapport en effective spec.
- De generator bevat Nederlandse en Engelse uitleg/PDF.
- Projectzip bevat beschikbare PDF-bronnen in `sources/pdf/`.

## Java

Aangepast:

- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
- `userInterface/GraphController.java`
- `userInterface/GraphFileActions.java`
- `userInterface/OpenGraphActions.java`
- `userInterface/OpenGraphEdAppInfo.java`

## Test

- Java compile uitgevoerd met `javac -encoding UTF-8`.
- Resultaat: compile OK, alleen bestaande waarschuwingen.

## Opmerking

Dit is nog geen volledige Java-port van de greedy-kern. De integratie gebruikt `.opn` als brugformaat.
