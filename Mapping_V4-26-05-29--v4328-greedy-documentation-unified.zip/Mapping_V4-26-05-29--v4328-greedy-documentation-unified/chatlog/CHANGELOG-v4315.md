# CHANGELOG v4315 — Gridtag = gridcelgrootte, niet rijen/kolommen

Datum: 2026-05-28

## Aanleiding

In v4314 werd `gridH18W32` voorgesteld voor `lextest.graph`. Dat was fout: `18,32` zijn rijen en kolommen, niet de gridcelgrootte. De bestandsnaam moet de ingestelde gridcelgrootte vermelden, zodat oude en nieuwe bestanden direct op gridknooppunten kunnen worden geplaatst.

## Wijzigingen

- Bestandsnaamtag `gridH...W...` betekent nu: `gridH<celhoogte>W<celbreedte>`.
- Oude `.graph`-bestanden zonder gridtag krijgen normaliter voorstel `gridH20W20`, omdat de meeste oude bestanden gridcel `20,20` gebruiken.
- Bij laden van een bestand met gridtag wordt de tag toegepast als celhoogte/celbreedte, niet als rijen/kolommen.
- Rijen/kolommen blijven bewaard uit het bestand of worden alleen vergroot wanneer knopen dat nodig maken.
- `Set Grid Size` gebruikt in het tweede venster nu expliciet `grid cell height,width`.
- Save Graph / Save OPN / beeldoutput gebruiken de actieve ingestelde gridcelgrootte in de outputnaam.
- Greedy interne en externe generator gebruiken nu `gridH<step_y>W<step_x>` in outputnamen.
- OPN `GRID:` schrijft nu expliciet zowel `rows/cols` als `cell_height/cell_width`; `height/width` blijven legacy-alias voor rijen/kolommen.

## Voorbeeld

Input zonder gridtag:

```text
examples\graph\lextest.graph
```

met file-header:

```text
rows=18
rowHeight=20
cols=32
colWidth=20
```

leidt nu tot voorstel:

```text
examples\graph\lextest_gridH20W20.graph
```

Niet meer:

```text
lextest_gridH18W32.graph
```

## Teststatus

- Java compile: OK.
- Python Greedy headless generatie: OK.
- Externe Greedy-outputnaam: `space3_gridH20W20.*`: OK.
