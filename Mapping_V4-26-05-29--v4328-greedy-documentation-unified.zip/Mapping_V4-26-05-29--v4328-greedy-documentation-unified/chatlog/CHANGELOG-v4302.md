# CHANGELOG v4302 — Greedy Settings inside OpenGraphEd

## Doel

Derde integratiestap voor de Greedy Graph Generator: niet alleen extern starten of headless genereren, maar de belangrijkste `spec.yaml`-instellingen direct vanuit OpenGraphEd kunnen wijzigen.

## Nieuw in het OpenGraph-menu

```text
OpenGraph
  Greedy Settings
  Settings + Generate + Load Greedy OPN
  Greedy Generator
  Generate + Load Greedy OPN
  Open Greedy OPN
```

## Nieuwe Java-functionaliteit

- Nieuw dialoogvenster: `userInterface/GreedyGeneratorSettingsDialog.java`.
- Nieuw controllerpad:
  - `configureGreedyGenerator()`
  - `configureGenerateAndOpenGreedyOPN()`
- `Greedy Settings` opent een Java/Swing-dialoog en schrijft `tools/greedy_generator_gui/spec.yaml`.
- `Settings + Generate + Load Greedy OPN` opent dezelfde dialoog, schrijft de spec, genereert headless, en laadt de `.opn` direct.

## Instelbaar in de dialoog

- projectnaam, titel, bestandsnaam;
- `COUNT`, `MAX`, taal;
- gridstap X/Y, marge, hoofdlijnen, grid/assen tonen;
- `STYLE`, `RULE`, `DIAGONAL_FREE`, `ANGLE_MIN`;
- outputmap, naamgeving, `.graph`, `.opn`, `.svg`, `.png`, rapport en effective spec.

## Test

- Java compile OK.
- Jar gebouwd OK.
- Headless generator met bestaande `spec.yaml` OK.
- `.opn`, `.graph`, `.svg`, `.png`, rapport en effective spec gegenereerd.

## Niet volledig automatisch getest in container

- Kliktest van de Java/Swing-dialoog in Windows.
- Automatisch laden van `.opn` na `Settings + Generate + Load Greedy OPN` blijft Windows/OpenGraphEd-test.
