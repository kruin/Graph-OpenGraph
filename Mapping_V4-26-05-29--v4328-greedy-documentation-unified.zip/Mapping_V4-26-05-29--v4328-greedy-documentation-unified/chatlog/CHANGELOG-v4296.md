# CHANGELOG v4296 - OpenGraph carousel reorder fix

## Doel

Correctie van de carrouselvolgorde in `Tree > OpenGraph`.

Gemelde fout:

- `afb7` verplaatsen naar plaats `2`;
- daarna vanaf `2` doorbladeren naar `7`;
- de oude afbeelding `7` bleef zichtbaar / bleef als residu in de reeks.

## Oorzaak

De vorige volgorde-opslag hernoemde bestanden in-place via tijdelijke bestandsnamen. Dat is kwetsbaar bij carouselbestanden die al geladen zijn in de UI of waarbij oude genummerde bestanden blijven liggen.

## Wijziging

`persistOpenGraphCarouselOrder(...)` is vervangen door een veiliger volledige herschrijfactie:

1. alle gewenste slides worden eerst naar een tijdelijke map gekopieerd;
2. alle bestaande carousel-afbeeldingen en bijbehorende `.txt`-bestanden worden uit de carouselmap verwijderd;
3. de tijdelijke bestanden worden met nieuwe `001-`, `002-`, `003-`-namen teruggezet;
4. daarna wordt de carousel opnieuw ingelezen.

Daarnaast laadt de viewer afbeeldingen nu via `ImageIO.read(...)` in plaats van direct met een padgebonden `ImageIcon`, zodat Windows minder snel oude image-files vasthoudt.

## Test

- Java compile-check: geslaagd.
- Resultaat: verplaatsen is nu een echte move, geen kopie/residu.
