# CHANGELOG v4293 — Simple Uitleg selectie-fix

## Aanleiding

De knop **Uitleg** toonde bij **Tree = Simple** nog de tekst voor **origineel**.

## Oorzaak

Simple heeft geen aparte projectielaag zoals Language/Frame/Functional/Anaphor. Daardoor konden header-refreshpaden Simple behandelen als niet-projectieve toestand en de Tree-keuze visueel/logisch terug laten vallen naar **origineel**.

## Wijziging

- `GraphEditorWindow` onthoudt nu de laatst expliciet gekozen Tree-optie.
- Na keuze **Simple** blijft de Uitleg-context **Simple**, ook als er geen projectielaag actief is.
- `origineel` blijft expliciet mogelijk en zet de Uitleg-context terug naar origineel.
- De inhoudelijke Simple-uitleg zelf blijft de studentgerichte versie over:
  - traditionele boomnotatie;
  - woorden onderaan / geen zwaartekracht;
  - S-NP,VP versus S-VP,NP;
  - OpenGraph-notatie met vrije knopen;
  - LEX-projectie als uitingsvolgorde;
  - LEX-regels als alternatief voor transformaties;
  - minimum kindtakken, binair/n-air, Branches-config en recursieve box-aanpak.

## Bestand

- `userInterface/GraphEditorWindow.java`
