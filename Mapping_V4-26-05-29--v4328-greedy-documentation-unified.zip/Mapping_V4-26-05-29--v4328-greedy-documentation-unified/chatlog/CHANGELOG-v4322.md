# CHANGELOG v4322 — Greedy generate zonder YAML

## Aanleiding

Gebruiker gaf aan dat `Greedy Settings → Genereren` niet eerst `spec.yaml` moet schrijven. Er kan immers nog fine-tuning volgen. YAML/instellingen horen pas bij expliciet opslaan of exporteren, en vooral in de opgeslagen OPN.

## Wijzigingen

1. `Spec opslaan` verwijderd uit het hoofdvenster van Greedy Settings.
2. `Genereren` is nu display-only:
   - leest instellingen uit het venster;
   - genereert intern;
   - toont de graph direct;
   - schrijft geen YAML of andere outputfiles.
3. Generated Greedy graphs dragen de gebruikte spectekst intern mee.
4. Save OPN schrijft die instellingen in een `GREEDY_SETTINGS_YAML`-sectie.
5. Open OPN leest `GREEDY_SETTINGS_YAML` terug en koppelt die aan het actieve document.
6. `Greedy Settings` opent, indien aanwezig, met de embedded documentinstellingen.

## Teststatus

- `javac`: OK, alleen bestaande deprecation warnings.
- `jar`: OK.
- Interne generatie vanuit in-memory spectekst: OK.
