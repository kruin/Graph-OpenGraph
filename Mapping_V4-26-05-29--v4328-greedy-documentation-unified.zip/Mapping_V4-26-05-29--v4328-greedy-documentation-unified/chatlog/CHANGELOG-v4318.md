# CHANGELOG v4318 — legacy rename to .oldgraph/.oldopn

Date: 2026-05-28
Project: Mapping V4 / OpenGraphEd

## Request

When an old input file has no grid name and the user saves the graph under the new grid-tagged filename, offer a safe cleanup option for the old legacy file.

Preferred behavior: rename the old file to `.oldgraph` or `.oldopn`, not delete it.

## Changes

- Added `userInterface/OpenGraphLegacyFileSupport.java`.
- After successful **Save Graph**:
  - if the input file had no `gridH...W...` tag,
  - and the new saved `.graph` file does have a grid tag,
  - and the old and new paths differ,
  - OpenGraphEd asks whether to rename the old file to `.oldgraph`.
- After successful **Save OPN** from a legacy `.opn` source:
  - the same check offers rename to `.oldopn`.
- The old file is not deleted.
- The action is optional and user-confirmed.
- If the target legacy name already exists, OpenGraphEd uses a numbered name:
  - `name_1.oldgraph`
  - `name_2.oldgraph`
  - etc.

## Examples

```text
lextest.graph
→ save as lextest_gridH20W20.graph
→ optional rename: lextest.oldgraph
```

```text
example.opn
→ save as example_gridH20W20.opn
→ optional rename: example.oldopn
```

## Notes

- Save Graph replacement flow is the main target.
- Save OPN only offers old-opn rename when the source was also `.opn`; saving an OPN derived from a `.graph` file does not rename the `.graph` source.

## Test status

- Java compile: OK.
- JAR build: OK.
