# CHANGELOG v4295 - OpenGraph carousel management

Datum: 2026-05-23

## Aanleiding
De OpenGraph-carrousel had alleen basisnavigatie, toevoegen, tekst opslaan en verversen. Gevraagd:
- screenshots kunnen verwijderen;
- screenshots van plaats kunnen verschuiven;
- screenshots van plaats kunnen wisselen;
- zo veel mogelijk standaardcarrouselfunctionaliteit toevoegen.

## Wijzigingen

### Navigatie
Toegevoegd:
- Eerste
- Vorige
- Volgende
- Laatste
- Naar...

### Beheer
Toegevoegd:
- Verwijder

Bestaand behouden:
- Screenshot toevoegen
- Tekst opslaan
- Ververs

### Volgorde beheren
Toegevoegd:
- Plaats < : huidige screenshot één plaats naar voren
- Plaats > : huidige screenshot één plaats naar achteren
- Verplaats... : huidige screenshot naar opgegeven positie
- Wissel... : huidige screenshot wisselt met opgegeven positie

### Persistente volgorde
De carrouselvolgorde wordt opgeslagen door de bestanden te hernummeren:
- 001-...
- 002-...
- 003-...

Het bijbehorende .txt-bestand wordt mee hernoemd.

### Veiligheid
- Vóór herordenen wordt de huidige toelichtende tekst opgeslagen.
- Bij verwijderen wordt ook het gelijknamige .txt-bestand verwijderd.
- De zichtbare afbeelding wordt eerst vrijgegeven voordat het bestand wordt verwijderd of hernoemd.

## Aangeraakt
- userInterface/GraphEditorWindow.java
- opengraph_carousel/README.txt
- examples/opengraph-carousel/README.txt
- build.bat version label
