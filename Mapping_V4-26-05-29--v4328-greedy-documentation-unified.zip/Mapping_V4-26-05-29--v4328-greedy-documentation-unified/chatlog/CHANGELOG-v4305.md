# CHANGELOG v4305 — Greedy NL/EN language consistency fix

## Doel

v4304 testte goed, maar de NL/EN-taalinstelling werkte nog niet consequent genoeg.

## Aangepast

- `GreedyGeneratorSettingsDialog.java` herschreven naar een taalbewuste dialoog.
- Taalkeuze `nl/en` werkt nu in de OpenGraphEd-instellingen zelf.
- Bij openen gebruikt de dialoog de taal uit `tools/greedy_generator_gui/spec.yaml`.
- Bij wijzigen van de taal in de dialoog worden tabs, labels, knoppen, notities en helptekst direct bijgewerkt.
- Generator-GUI werkt de helptekst direct bij als de taalkeuze verandert.
- SVG/PNG gebruiken nu in Engels `node 0` in plaats van `knoop 0`.
- Headless generatie met `spec_english.yaml` schrijft Engels rapport en Engelse SVG-metadata.

## Test

- Java compile: OK.
- Jar gebouwd: OK.
- Headless generator met `spec_english.yaml`: OK.
- Controle Engelse output: `space3_en_report.txt` Engels en `space3_en.svg` bevat `node 0`.

## Nog niet in deze omgeving getest

- Kliktest in Windows/OpenGraphEd van de taalwissel in de dialoog.
