# CHANGELOG v4326 — Greedy grid workflow streamlined

## User request

After Greedy generation, OpenGraphEd still showed a second OpenGraphGrid dialog with stale 20,20 values. Even after choosing and saving another grid size, the suggested output name could remain `gridH20W20`.

## Changes

- `Greedy Settings -> Genereren` now displays the generated graph directly.
- No automatic OpenGraphGrid dialog is shown after generation.
- The active OpenGraphGrid cell size is initialized from the generated Greedy graph:
  - `grid.step_x` -> column width / filename W value
  - `grid.step_y` -> row height / filename H value
- `Greedy -> Grid Settings -> Save + Apply` now saves the grid settings and applies them to the current drawing.
- Save/export proposals now follow the active drawing grid after generation or after Grid Settings changes.

## Files changed

- `userInterface/GraphController.java`
- `userInterface/OpenGraphGridModeDialog.java`
- `build.bat`

## Test status

- Java compile: OK
- JAR build: OK
