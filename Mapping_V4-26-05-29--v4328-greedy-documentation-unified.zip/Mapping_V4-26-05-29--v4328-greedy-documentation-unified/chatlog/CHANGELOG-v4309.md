# CHANGELOG v4309 — Greedy internal route promoted

## Samenvatting

v4309 maakt de interne Java Greedy-engine de normale OpenGraphEd-route.

De externe Python/Tkinter-generator blijft aanwezig als GUI/fallback, maar de standaardmenu-items gebruiken nu de interne Java-engine.

## Gewijzigd menu OpenGraph

Nieuwe, opgeschoonde Greedy-volgorde:

```text
Greedy Settings
Settings + Generate + Import Greedy OPN
Generate + Import Greedy OPN
Greedy Generator GUI
Generate External + Import Greedy OPN
Open Greedy OPN
Open Greedy Preview PNG
Open Greedy Report
Open Greedy Effective Spec
Open Greedy Output Folder
Open Greedy Manual PDF
```

## Betekenis

- `Generate + Import Greedy OPN` gebruikt nu de interne Java-engine.
- `Settings + Generate + Import Greedy OPN` gebruikt ook de interne Java-engine.
- De expliciete `Internal`-menu-items zijn verwijderd uit het menu, omdat de interne route nu de standaard is.
- De externe route blijft beschikbaar als `Generate External + Import Greedy OPN`.
- `Greedy Generator GUI` opent nog steeds de externe Python/Tkinter-GUI.

## Technisch

- `GraphController.generateAndImportGreedyOPN()` routeert nu naar `generateInternalGreedyGeneratorDefaultOPN()`.
- `GraphController.generateExternalAndImportGreedyOPN()` is toegevoegd voor de externe Python-route.
- Oude interne methodes blijven bestaan als compatibiliteitsaliases.
- Direct-load fallback gebruikt nu ook de interne engine.

## Teststatus

- Java compile: OK.
- JAR build: OK.
- Interne Java-generatie uit `spec.yaml`: OK.
- Externe Python-generator blijft meegeleverd als fallback.
