# CHANGELOG v4306 - Greedy output viewer

Datum: 2026-05-28

## Doel

Na bevestigde test van v4305 is de volgende stap gezet: de Greedy-output is nu direct vanuit OpenGraphEd inspecteerbaar.

## Toegevoegd onder OpenGraph

- Open Greedy Preview PNG
- Open Greedy Report
- Open Greedy Effective Spec
- Open Greedy Output Folder
- Open Greedy Manual PDF

## Gedrag

- De opties openen de laatst gegenereerde bestanden in `tools/greedy_generator_gui/output`.
- Ontbreekt een bestand nog, dan geeft OpenGraphEd een duidelijke melding.
- De PDF-handleiding kan direct vanuit OpenGraphEd worden geopend.

## Test

- Java compile: OK
- JAR build: OK
- Headless Greedy generation: OK
