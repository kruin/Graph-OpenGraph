# CHANGELOG v4314 — input gridnaam + save-voorstel

Datum: 2026-05-28

## Doel

Een bestaand inputbestand zonder gridnaam mag nog geopend worden, maar OpenGraphEd moet direct duidelijk maken welke nieuwe naam bij dit bestand hoort. Bij opnieuw opslaan mag de gebruiker niet meer terugvallen op `untitled.graph` in de projectroot.

## Wijzigingen

- Bij input zonder `gridH<hoogte>W<breedte>` toont de waarschuwing nu ook:
  - het volledige inputpad;
  - de gedetecteerde gridhoogte en gridbreedte;
  - de gedetecteerde gridtag;
  - de gridcelhoogte en gridcelbreedte;
  - expliciet dat veel oude `.graph`-bestanden gridcel `20,20` gebruiken;
  - een voorgestelde nieuwe bestandsnaam in dezelfde map als het inputbestand.
- `File → Save Graph` gebruikt nu het geladen bronbestand als basis voor het save-voorstel.
- Voorbeeld: `examples/graph/lextest.graph` wordt voorgesteld als:

```text
examples/graph/lextest_gridH18W32.graph
```

- Als het bestand al een gridtag had, wordt die vervangen of behouden volgens de actuele griddimensies.
- Bij laden worden knopen altijd naar het actieve grid gesnapt:
  - met gridtag: eerst grid uit bestandsnaam toepassen;
  - zonder gridtag: bestandsgrid gebruiken, waarschuwing tonen, daarna snappen.
- Na opslaan wordt het graph-filepad intern bijgewerkt naar de nieuwe gridnaam.

## Technisch

Aangepast:

- `userInterface/GraphFileActions.java`
- `build.bat`

## Test

- Java compile: OK
- JAR build: OK
- Waarschuwingstekst bevat voorgesteld pad: OK
- Save chooser gebruikt bronmap + gridnaamvoorstel: OK
