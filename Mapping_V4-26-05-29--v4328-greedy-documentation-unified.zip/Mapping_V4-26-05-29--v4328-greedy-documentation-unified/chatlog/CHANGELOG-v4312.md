# CHANGELOG v4312 — general grid filenames and input

Datum: 2026-05-28

## Samenvatting

v4311 beperkte de gridnaam/gridinput praktisch tot Greedy. v4312 trekt deze afspraak algemeen door naar OpenGraphEd.

## Functioneel

- Alle relevante outputnamen krijgen nu een `gridH<hoogte>W<breedte>`-tag.
- Bij input wordt die tag teruggelezen.
- Als een inputbestand een gridtag in de naam heeft, wordt de editorgrid daarop gezet.
- Bij OPN-input worden knopen daarna op het dichtstbijzijnde gridknooppunt geplaatst.
- Gewone `Save OPN` schrijft nu een `GRID:`-sectie.

## Technisch

Nieuw:

- `userInterface/OpenGraphGridFileNameSupport.java`

Aangepast:

- `GraphFileActions`:
  - leest gridtag uit inputnaam;
  - voegt gridtag toe aan `.graph` en image-output;
  - OPN-loader leest `opn_loader_margin`.
- `OpenTreeStructureSupport`:
  - voegt gridtag toe aan OPN-output;
  - schrijft `GRID:` bij gewone Save OPN;
  - gebruikt echte graph-gridcoördinaten in plaats van hardcoded `40/25`.

## Test

- Compile OK.
- JAR OK.
