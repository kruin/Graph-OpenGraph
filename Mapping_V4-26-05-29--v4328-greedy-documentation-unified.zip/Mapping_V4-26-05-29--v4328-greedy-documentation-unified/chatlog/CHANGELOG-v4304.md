# CHANGELOG v4304 — Greedy menu blank-method fix

## Fix

v4303 added a stricter menu-method check. That exposed an existing placeholder menu item:

```text
S,Windows,None,null,No Windows Are Open, ,true,1, 
```

This entry intentionally has no GraphController method. The stricter check treated the blank method as an error and stopped OpenGraphEd at startup.

## Change

`MenuAndToolBarBuildSupport` now trims the method field and accepts an empty method as `null`. Real non-empty method names are still checked and still produce a clear error if missing.

## Test

- Java compile: OK
- JAR build: OK
- Menu descriptor scan: OK
