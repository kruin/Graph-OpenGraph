# CHANGELOG v4294 — OpenGraph carousel

## User request
- Add Tree option **OpenGraph** between **origineel** and **Simple**.
- In OpenGraph, show an editor-screen carousel to which screenshots can be added.
- Each screenshot must have its own explanatory text.
- Initial plan:
  1. simple one-level branching with variants;
  2. projection to the left, first without a name: a bare line with copied nodes;
  3. further screenshots will be supplied later.

## Changes
- Added Tree option order:
  **origineel — OpenGraph — Simple — Language — Functional — Frame — Anaphor**.
- Removed the accidental duplicate **origineel** entry from the Tree combo.
- Added an OpenGraph explanation carousel inside the editor area.
- Carousel reads from root folder `opengraph_carousel/`.
- Fallback folder also included: `examples/opengraph-carousel/`.
- Added buttons:
  - `<` previous screenshot
  - `>` next screenshot
  - `Screenshot toevoegen`
  - `Tekst opslaan`
  - `Ververs`
- Each image can have a same-basename `.txt` caption file.
- Seeded the carousel with the screenshots supplied in the chat and first explanatory texts.
- Updated **Uitleg** for the new OpenGraph option.
- Updated Branches popup text so it no longer says Simple is always binary.

## Compile check
- `javac -encoding UTF-8` completed successfully.
- Existing warning only: deprecated `Integer(int)` constructor in `GraphEditorWindow.java`.
