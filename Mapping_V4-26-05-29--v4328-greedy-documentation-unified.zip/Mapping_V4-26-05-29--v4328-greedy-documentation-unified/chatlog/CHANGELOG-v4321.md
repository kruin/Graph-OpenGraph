# CHANGELOG v4321 — Greedy menu rename + workflow labels

## Doel

De instructie uit v4320 geldt alleen voor het voormalige `OpenGraph`-menu. Daarom is dat menu in de UI hernoemd naar `Greedy`, zodat duidelijk is dat de document-first workflow de Greedy-generatorworkflow betreft en niet de volledige OpenGraphEd-app.

## Wijzigingen

- Menu `OpenGraph` hernoemd naar `Greedy`.
- Greedy-menu vereenvoudigd tot hoofdacties:
  - `Greedy Settings`
  - `Generate Greedy Graph`
  - `Open Greedy OPN`
  - `Grid Settings`
  - `Save As...`
  - `Greedy Tools...`
- `FT Settings` en `Toggle Projections` zijn uit het Greedy-hoofdmenu gehaald.
- In `Greedy Generator-instellingen` is de knop `Opslaan + genereren + laden` vervangen door `Genereren`.
- Engelse knoptekst: `Generate`.
- Meldingen verwijzen nu naar `Greedy > ...` in plaats van `OpenGraph > ...`.

## Build/test

- Java compile: OK.
- JAR build: OK.
- Headless run bereikt alleen de normale Swing `HeadlessException`; geen menuparserfout.
