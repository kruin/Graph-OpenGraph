# CHANGELOG v4317 — grid legacy option toggle

Datum: 2026-05-28

## Aanleiding

In v4316 kreeg het tweede venster van Set Grid Size een dropdown met 20,20 als legacy-first optie. De gebruiker wil die legacy-keuze kunnen verwijderen uit de keuzelijst.

## Wijzigingen

- `Set Grid Size` tweede stap gebruikt nu een eigen dialoogvenster met:
  - dropdown `Grid cell height,width`;
  - checkbox `Toon legacy 20,20 optie`.
- De legacy-optie `20,20 - oude standaard / legacy default` kan worden uitgezet.
- De keuze wordt bewaard via Java Preferences, zodat de legacy-optie bij latere dialogs verborgen blijft.
- De checkbox blijft beschikbaar om de legacy-optie later weer aan te zetten.

## Gedrag

- Als de checkbox aan staat, verschijnt `20,20` als eerste vaste legacy-keuze.
- Als de checkbox uit staat, wordt die vaste legacy-keuze uit de dropdown verwijderd.
- Actuele of venster-afgeleide gridcellen blijven beschikbaar.
- Outputbestanden blijven de gekozen gridcelgrootte in de naam opnemen: `gridH<cell_height>W<cell_width>`.

## Test

- Java compile: OK.
- JAR build: OK.
