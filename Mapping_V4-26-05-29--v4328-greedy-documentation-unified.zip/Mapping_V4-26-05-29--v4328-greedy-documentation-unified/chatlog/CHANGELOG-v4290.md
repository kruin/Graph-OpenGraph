# CHANGELOG v4.29.0

Datum: 2026-05-22

## Wijzigingen

- Tree = origineel herlaadt niet meer de opgeslagen `.graph` van schijf.
- Tree = origineel toont de huidige editorboom; niet-opgeslagen editorwijzigingen blijven behouden.
- Als er een OpenGraph Draw-resultaat zichtbaar is, draait Tree = origineel alleen die laatste Draw-stap terug.
- Fix: kiezen van Tree = Simple blijft nu Simple tonen; de keuzelijst springt niet meer terug naar origineel.
- Uitleg uitgebreid:
  - origineel: actuele editorboom versus echte undo/back-historie;
  - Simple: binair/n-air, minimum 2 kindtakken, branch-config, recursieve box-aanpak, compact tekenen;
  - Language: taalboom Nederlands, LEX-projectie, LEX-regels als alternatief voor transformaties, SYN/LF-projecties;
  - Functional, Frame en Anaphor blijven voorlopig aangeduid als later inhoudelijker uit te werken.
- Uitleg toont, waar mogelijk, een korte samenvatting van de huidige boom: aantal knopen/takken, categoriale knopen, eindlabels en labels met rol/markering zoals `man (OBJ)`.

## Build

- Compile-check uitgevoerd met `javac`.
- Resultaat: geslaagd; alleen de bestaande Java-waarschuwing over `Integer(int)`.
