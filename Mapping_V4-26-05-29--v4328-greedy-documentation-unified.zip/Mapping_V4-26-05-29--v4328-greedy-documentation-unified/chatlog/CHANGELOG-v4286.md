# CHANGELOG v4286 — Simple binary tree / Branches=2 herstel

## Vraag
- Simple: herstel de binary tree test.
- Branches: 2.

## Wijziging
- `operation/OpenGraphTreeDrawOperation.java`
  - Simple Tree gebruikt opnieuw altijd binaire recursieve n-ary afhandeling.
  - Voor Simple wordt per-node Branches-config genegeerd en effectief `2` gebruikt.
  - Language / Functional / Frame / Anaphor gebruiken wel de editorconfig per categoriale knoop: `2`, `3`, `4`, `many`.

## Technische kern
- De renderer bepaalt nu expliciet:
  - Simple: `useProjectionCapableBranchConfig = false` → `effectiveBranchLimitForNode(...)` geeft `2` terug.
  - overige Tree-types: `useProjectionCapableBranchConfig = true` → lees `node.getTreeBranchMode()`.

## Test
- Compile-check met `javac -encoding UTF-8`: geslaagd.
- Alleen bestaande waarschuwing in `GraphEditorWindow.java` over deprecated `Integer(int)`.
