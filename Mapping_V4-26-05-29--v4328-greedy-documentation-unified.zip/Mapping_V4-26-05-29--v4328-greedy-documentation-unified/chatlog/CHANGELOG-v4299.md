# CHANGELOG v4299 — projectie-master-spec restored

## Aanleiding

De gebruiker meldde terecht dat `projectie-master-spec.md` niet in de projectzip zat.

## Correctie

Toegevoegd:

- `projectie-master-spec.md`
- `md/projectie-master-spec.md`
- `md-only-sources-v4299.zip`

## Java

Geen Java-wijzigingen.

## Packaging-regel

Vanaf deze versie moet elke volgende projectzip in deze reeks de master-spec meenemen.
