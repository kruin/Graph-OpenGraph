# CHANGELOG v4292 — Tree Uitleg: studentversie, LEX-projectie en traditionele boom

Datum: 2026-05-22

## Aanleiding

De knop **Uitleg** was nog te technisch en te weinig gericht op de taalkundige/student.
De uitleg moest vertrekken vanuit de traditionele boomvraag: waarom staan woorden onderaan de boom, en hoe verhoudt die notatie zich tot OpenGraph en LEX-projecties?

## Wijzigingen

- **Simple** is inhoudelijk herschreven als basisuitleg:
  - traditionele boom als uitgangspunt;
  - vraag: wat doen de woorden onderaan de boom? "Zwaartekracht?";
  - klassieke boom als descriptieve reconstructie van woordvolgorde;
  - verschil tussen `S-NP,VP` en `S-VP,NP` in oude boomnotatie;
  - OpenGraph-notatie met vrije knopen als ruimte voor projecties;
  - LEX-projectie als plaats voor de lexicale/uitingsvolgorde;
  - LEX-regels als alternatief voor transformaties;
  - minimum kindtakken, binair/n-air, Branches-config en recursieve box-aanpak blijven uitgelegd.
- **Language** verwijst explicieter naar Simple en legt daarna uit:
  - centrale taalboom Nederlands;
  - LEX-projectie;
  - LEX-regels en V-cluster als alternatief voor transformaties;
  - SYN en LF als aparte projecties rond dezelfde bronboom.
- **Functional**, **Frame** en **Anaphor** blijven voorlopig kort en verwijzen inhoudelijk naar Simple.

## Test

- Compile-check uitgevoerd met `javac -encoding UTF-8`.
- Resultaat: geslaagd, alleen de bestaande Java-waarschuwing over `Integer(int)`.
