# CHANGELOG v4323 — Greedy package + restorable OPN save

Date: 2026-05-29
Project: Mapping V4 / OpenGraphEd / Greedy

## User request

- `Save As → OPN` must preserve the Greedy YAML/settings.
- Add a Greedy save option that creates a package containing all available Greedy information.
- Make clear that plain `.graph` and image exports do not restore Greedy settings.

## Changes

### Greedy Save As menu

The Greedy Save As dialog now offers:

1. `Greedy package (.zip)`
2. `OPN document (.opn)`
3. `Graph only (.graph)`
4. `Image only (.gif/.jpg/.jpeg)`
5. `Cancel`

### Greedy package

`Greedy package (.zip)` writes a restorable archive with:

- `.opn` with embedded `GREEDY_SETTINGS_YAML`
- `.graph` with the visible graph structure
- `spec.yaml`
- `effective_spec.yaml`
- report text
- README
- preview `.gif` when available

### OPN document

`OPN document (.opn)` writes the current displayed graph and embeds the Greedy settings in:

```text
GREEDY_SETTINGS_YAML:
...
END_GREEDY_SETTINGS_YAML:
```

### Graph/image warnings

`Graph only` and `Image only` now warn the user that these formats do not preserve Greedy restore data.

## Technical notes

- Added `userInterface/GreedySaveExportSupport.java`.
- Updated `GraphController.saveOpenGraphAs()`.
- Updated `OpenTreeStructureSupport.saveCurrentGraph()` so existing `.opn` files are not blindly copied when the active graph contains Greedy settings; a fresh OPN is written instead.
- Old mini-OPN writer now includes embedded Greedy settings when available.

## Test status

- Java compile: OK.
- JAR build: OK.
- Direct OPN writer test: `GREEDY_SETTINGS_YAML` present in generated OPN.
