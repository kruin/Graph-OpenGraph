# CHANGELOG v4324 — gridtag bij Save As volgt gekozen grid

## Probleem

Bij Greedy Save As kon de uitvoernaam terugvallen op een oudere gridtag, bijvoorbeeld `gridH20W20`, terwijl de gebruiker een andere gridcelgrootte had gekozen, bijvoorbeeld `14,20`.

## Fix

- Save As respecteert nu een expliciet gekozen of getypte `gridH...W...`-tag in de bestandsnaam.
- Als de gebruiker een gridtag in de save-naam kiest, wordt die niet meer stil overschreven door een oudere tag.
- OPN en Greedy package synchroniseren embedded `GREEDY_SETTINGS_YAML` met de actuele graph-gridcel:
  - `grid.step_x` = actuele celbreedte;
  - `grid.step_y` = actuele celhoogte;
  - `grid.height` = actuele rijen;
  - `grid.width` = actuele kolommen.
- Graph only en Image only gebruiken dezelfde save-selectie-logica.

## Gedrag

Voor een gekozen gridcel:

```text
hoogte,breedte = 14,20
```

wordt de outputnaam:

```text
..._gridH14W20.opn
..._gridH14W20.graph
..._gridH14W20.zip
```

Niet meer:

```text
..._gridH20W20.*
```

## Test

- Java compile: OK.
- JAR build: OK.
