# CHANGELOG v4287 — Tree config, compact layout, top caption horizontal

## Vraag
- Test binair werkt niet.
- Draai terug: alle tree-types config.
- Maak de tree compact, zodat er geen lege Hor en Ver lijnen zijn.
- Projectienaam boven, bijvoorbeeld FRAME, moet horizontaal staan zoals LF in Language Tree.

## Wijziging
- `operation/OpenGraphTreeDrawOperation.java`
  - De v4286-hardcoding voor Simple is teruggedraaid.
  - `Branches` is nu een editorconfig voor alle Tree-types: Simple, Language, Functional, Frame, Anaphor.
  - `auto` en `many` betekenen: geen kunstmatige branch-limiet.
  - `2`, `3`, `4` beperken de lokale n-ary fan-out van de ingestelde knoop.
  - Compactere boomplaatsing:
    - geen extra terminal-gap meer in `stackedBelowShiftY(...)`;
    - `Branches=2`: slots `-1/+1` in plaats van `-2/+2`;
    - n-ary compact LR gebruikt geen extra terminal-diagonaalkolom meer.

- `userInterface/OpenGraphProjectionSupport.java`
  - De bovenste projectienaam/caption wordt horizontaal getekend.
  - Top-projectielabels zijn voorbereid als horizontaal, niet verticaal.

## Test
- Compile-check met `javac -encoding UTF-8`: geslaagd.
- Alleen bestaande waarschuwing in `GraphEditorWindow.java` over deprecated `Integer(int)`.
