# CHANGELOG v4297 - OpenGraph carousel export/import + reminders

## Vraag
- Voeg reminder toe voor de carrouselworkflow.
- Voeg ook reminder toe voor de git-update, omdat die handwerk blijft.
- Dit sluit aan bij de eerder genoemde knoppen: Export carousel en Import carousel.

## Wijzigingen

### Carrouselknoppen
Toegevoegd aan Tree > OpenGraph:
- Export carousel
- Import carousel
- Reminder

### Export carousel
- Slaat de actuele map `opengraph_carousel/` op als zip.
- Neemt afbeeldingen, bijbehorende `.txt`-toelichtingen en `README.txt` mee.
- Vraagt een opslaglocatie via bestandsdialoog.
- Toont na export een herinnering dat de exportzip moet worden meegenomen bij de volgende zipversie.

### Import carousel
- Laadt een eerder geëxporteerde carrouselzip.
- Vervangt de actuele carrouselbestanden.
- Beperkt import tot veilige carrouselbestanden: afbeeldingen, `.txt`, `README.txt`.
- Leest daarna de carrousel opnieuw in.

### Reminder
- Permanente statusregel onder de toelichting:
  `Reminder: na carrouselwijzigingen: Export carousel. Git-update blijft handwerk: git add / commit / push.`
- Reminder-knop toont de volledige workflow:
  1. carrousel wijzigen;
  2. Export carousel maken;
  3. exportzip uploaden/meenemen voor volgende versie;
  4. git handmatig bijwerken.

### Schrijfmap
- Bij schrijven/aanpassen wordt voortaan expliciet de hoofdmap `opengraph_carousel/` gebruikt.
- De fallback `examples/opengraph-carousel/` blijft leesbaar wanneer de hoofdmap nog niet bestaat.

## Aangeraakt
- `userInterface/GraphEditorWindow.java`
- `opengraph_carousel/README.txt`
- `examples/opengraph-carousel/README.txt`
- `build.bat`

## Compile-check
- `javac -encoding UTF-8` geslaagd.
- Alleen bestaande Java-waarschuwingen over deprecated `Integer(int)`.
