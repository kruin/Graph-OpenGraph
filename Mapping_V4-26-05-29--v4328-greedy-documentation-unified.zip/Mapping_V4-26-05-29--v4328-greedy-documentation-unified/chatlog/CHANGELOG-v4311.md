# CHANGELOG v4311 — grid height/width in output names and OPN input

## Doel

De gebruiker wil dat elke outputnaam direct de gebruikte grid-dimensies vermeldt:

```text
gridH<hoogte>W<breedte>
```

Daarnaast moet OPN-input deze grid-dimensies kunnen lezen, zodat gegenereerde knopen meteen op de bedoelde gridknooppunten vallen.

## Wijzigingen

- Alle Greedy-outputbestanden krijgen nu een gridtag in de naam, ook bij korte naamgeving:
  - `space3_gridH45W45.opn`
  - `space3_gridH45W45.graph`
  - `space3_gridH45W45.svg`
  - `space3_gridH45W45.png`
  - `space3_gridH45W45_report.txt`
  - `space3_gridH45W45_effective_spec.yaml`
- In `spec.yaml` zijn grid-dimensies toegevoegd:

```yaml
grid:
  height: 0   # 0 = afleiden uit max en margin
  width: 0    # 0 = afleiden uit max en margin
```

- De Java-internal Greedy-engine leest `grid.height` en `grid.width`.
- De externe Python-generator leest `grid.height` en `grid.width`.
- De OpenGraphEd Greedy Settings-dialoog bevat nu velden voor gridhoogte en gridbreedte.
- OPN-output bevat nu een `GRID:`-sectie:

```text
GRID:
height | 45
width | 45
step_x | 20
step_y | 20
origin_x | 22
origin_y | 22
opn_loader_margin | 2
```

- De OPN-loader leest deze `GRID:`-sectie terug en zet de OpenGraphEd-grid overeenkomstig.
- Doel: import van OPN levert direct knopen op gridknooppunten, zonder handmatig gridherstel.

## Test

- Java compile: OK.
- JAR build: OK.
- Python-generator: OK.
- Java internal generator zonder PNG in headless container: OK.
- OPN-output bevat `GRID:`-sectie: OK.
