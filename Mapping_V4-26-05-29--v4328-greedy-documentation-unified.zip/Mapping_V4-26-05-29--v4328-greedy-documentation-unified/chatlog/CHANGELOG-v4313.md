# CHANGELOG v4313 — gridnaam-alert bij input

Datum: 2026-05-28

## Samenvatting

v4313 voegt een waarschuwing toe bij het openen van bestaande `.graph`- en `.opn`-bestanden zonder gridnaam in de bestandsnaam.

## Functioneel

Als een inputbestand geen tag volgens deze conventie bevat:

```text
gridH<hoogte>W<breedte>
```

krijgt de gebruiker een alert met:

- de verwachte vorm;
- de naam van het bestand;
- de huidige/afgeleide gridtag;
- de melding dat het bestand nog steeds wordt geladen;
- de aanwijzing dat opnieuw opslaan een gridnaam aanmaakt.

Voorbeeld verwachte inputnaam:

```text
voorbeeld_gridH45W45.graph
voorbeeld_gridH45W45.opn
```

## Technisch

Aangepast:

- `userInterface/GraphFileActions.java`
  - controleert bij input of de bestandsnaam een gridtag bevat;
  - toont `JOptionPane.WARNING_MESSAGE` als de tag ontbreekt;
  - laadt het bestand daarna door.

## Test

- Java compile OK.
- JAR build OK.
