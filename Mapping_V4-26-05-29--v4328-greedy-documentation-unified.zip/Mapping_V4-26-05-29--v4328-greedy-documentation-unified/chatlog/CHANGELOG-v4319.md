# CHANGELOG v4319 — grid preview before accepting cell size

## Doel

Bij het kiezen van een gridcelgrootte, vooral de legacy-keuze `20,20`, moet de gebruiker eerst het gekozen grid kunnen zien voordat de keuze definitief wordt.

## Wijzigingen

- `Set Grid Size` toont na de dropdown-keuze tijdelijk het gekozen grid in het editorvenster.
- Daarna verschijnt een bevestiging:
  - gekozen gridcel hoogte,breedte;
  - gekozen rijen,kolommen;
  - `OK?`.
- Bij `OK` wordt de keuze definitief opgeslagen met normale undo-memento.
- Bij `Cancel` wordt de vorige gridstatus hersteld.
- Dit geldt ook voor de legacy-keuze `20,20`.

## Aangepast bestand

- `userInterface/GraphEditorLayoutSupport.java`

## Test

- Java compile: OK.
- JAR build: OK.
