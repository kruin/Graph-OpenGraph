# CHANGELOG v4.28.8 — tree minimum child branches fix

## Aanleiding

Een boom mocht nog een lokale unary-vertakking tekenen: één kindtak onder een bestaande tak. Dat is in de gewenste Tree-notatie verboden.

## Beslissing

De validatieregel is nu structureel, niet directioneel:

- `0` kindtakken = toegestaan als eindknoop.
- `1` kindtak = fout.
- `2` of meer kindtakken = toegestaan, met verdere Branches-config volgens editorinstelling.
- Richting links/rechts/onder is irrelevant voor deze fout.

## Technische wijziging

`operation/OpenGraphTreeDrawOperation.java`:

- na `buildTree(rootEx)` wordt `minimumChildBranchesError(rootEx)` uitgevoerd;
- bij een node met precies één kindtak stopt Draw met een `GraphException`;
- foutmelding vermeldt node-label en node-index.

## Verwachte foutmelding

Voorbeeld:

```text
Tree-fout: knoop 'hond' (#4) heeft 1 kindtak. Minimum kindtakken = 2; een knoop mag alleen 0 kindtakken hebben als eindknoop. Richting is irrelevant.
```
