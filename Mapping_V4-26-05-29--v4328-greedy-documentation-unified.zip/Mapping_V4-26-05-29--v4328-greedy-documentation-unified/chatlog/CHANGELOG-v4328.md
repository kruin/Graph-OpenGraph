# CHANGELOG v4328 — Greedy documentation unified

## Vraag

Gebruiker vroeg om de uitleg bij **Greedy Generator** te herschrijven en dezelfde aanpak door te voeren in documentatie, PDF's, menu's en verwante teksten.

## Uitgevoerd

- Greedy-menu help/descriptions gestroomlijnd rond document-first workflow.
- Greedy Generator-dialoog herschreven:
  - `Genereren` = tonen, geen opslag;
  - `Opslaan/Export` = latere exportcontext;
  - helptekst NL/EN herschreven.
- README en GUI-handleiding herschreven.
- Nederlandse en Engelse PDF-handleiding opnieuw gemaakt.
- PDF-kopieën in `sources/pdf` bijgewerkt.
- Externe Python-GUI-help aangepast om onderscheid te maken tussen normale OpenGraphEd-route en standalone/fallback-GUI.
- Master-spec bijgewerkt met v4328 Greedy-regels.

## Test

- Java compile: OK.
- JAR build: OK.
- PDF-rendercontrole: OK.
