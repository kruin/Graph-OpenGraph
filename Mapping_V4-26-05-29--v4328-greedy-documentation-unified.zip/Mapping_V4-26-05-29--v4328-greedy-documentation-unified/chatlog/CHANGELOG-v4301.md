# CHANGELOG v4301 — Greedy Generate + Load OPN

## Doel

Tweede integratiestap voor de Greedy Graph Generator: niet alleen de externe GUI starten, maar ook direct een `.opn` laten genereren en die meteen in OpenGraphEd laden.

## Java / OpenGraphEd

- Nieuw OpenGraph-menu-item toegevoegd:

```text
Generate + Load Greedy OPN
```

- Het menu-item voert uit:
  1. start headless generatie via `tools/greedy_generator_gui/generate_default_opn.bat`;
  2. leest `tools/greedy_generator_gui/output/last_generated.txt`;
  3. vindt de gegenereerde `.opn`;
  4. laadt die direct in OpenGraphEd.

- Bestaande items blijven bestaan:

```text
Greedy Generator
Open Greedy OPN
```

## Greedy Generator

- `greedy_generator_gui.py` ondersteunt nu ook headless CLI:

```bat
py greedy_generator_gui.py --generate --force-opn spec.yaml
```

- Nieuwe batchscripts:

```text
generate_default_opn.bat
generate_from_spec.bat
```

- Na generatie wordt geschreven:

```text
output/last_generated.txt
```

## Build

- Java compile: OK.
- Nieuwe jar gebouwd in `dist/OpenGraphEd.jar` en projectroot `OpenGraphEd.jar`.
