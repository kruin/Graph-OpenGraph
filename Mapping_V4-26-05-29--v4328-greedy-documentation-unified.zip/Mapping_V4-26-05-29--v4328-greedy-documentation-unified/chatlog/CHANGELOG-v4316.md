# CHANGELOG v4316 — grid cell size dropdown

Datum: 2026-05-28
Project: Mapping V4 / OpenGraphEd

## Aanleiding

Bij `Set Grid Size` stelde OpenGraphEd de tweede waarde automatisch voor op basis van de vensterafmetingen, bijvoorbeeld `32,30`.
Dat is niet per se de juiste gridcelgrootte voor oude `.graph`-bestanden. Voor de meeste oude bestanden is `20,20` de waarschijnlijk correcte standaard.

## Wijziging

- Het tweede `Set Grid Size`-venster is vervangen door een dropdown.
- Eerste optie is altijd `20,20`.
- Daarna volgen, indien verschillend:
  - de huidige gridcelgrootte;
  - de uit het venster afgeleide waarde, bijvoorbeeld `32,30`.
- De bestandsnaamtag blijft de ingestelde gridcelgrootte gebruiken:
  - `gridH20W20`
  - `gridH32W30`
  - enz.

## Doel

De gebruiker kiest expliciet de gridcelgrootte. Daardoor worden `.graph`, `.opn` en image-output opgeslagen met een gridtag die overeenkomt met de ingestelde gridcelgrootte.

## Technisch

Aangepast:

- `userInterface/GraphEditorLayoutSupport.java`

Toegevoegd:

- `chooseGridCellSizeString(...)`
- `addGridCellSizeOption(...)`
- `parseGridCellSize(...)`

## Teststatus

- Java compile: OK
- JAR build: OK
