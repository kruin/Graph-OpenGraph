package userInterface;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.geom.Rectangle2D;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.prefs.Preferences;
import graphStructure.Graph;
import graphStructure.Node;

/**
 * Shared layout, grid and viewport calculations for {@link GraphEditor}.
 * This keeps the editor focused on interaction and painting while preserving
 * existing behaviour.
 */
public class GraphEditorLayoutSupport
{
  private final GraphEditor editor;

  public GraphEditorLayoutSupport(GraphEditor editor)
  {
    this.editor = editor;
  }

  public void changeToOpenGraphGridMode(int rows, int rowHeight, int cols, int colWidth)
  {
    rowHeight = Math.max(2, rowHeight);
    colWidth = Math.max(2, colWidth);
    rows = Math.max(2, rows);
    cols = Math.max(2, cols);

    editor.getGraph().setGrid(rows, rowHeight, cols, colWidth, true);

    if ( !editor.isInGridMode() )
    {
      editor.ensureGridListener();
      editor.updateShapes();
      editor.repaint();
    }
    refreshPreferredSize();
  }

  public void changeToOpenGraphGridMode(OpenGraphGridSettings settings)
  {
    OpenGraphGridSettings normalized = settings == null ? new OpenGraphGridSettings() : settings.copy();
    normalized.normalize();
    editor.setOpenGraphGridSettings(normalized);

    int rowHeight = normalized.getCellHeight();
    int colWidth = normalized.getCellWidth();

    if ( normalized.getGridMode() == OpenGraphGridSettings.MODE_FULL_WINDOW )
    {
      int editorWidth = Math.max(1, getDrawWidth());
      int editorHeight = Math.max(1, getDrawHeight());
      int cols = Math.max(2, (int)Math.ceil((double)editorWidth / (double)colWidth) + 1);
      int rows = Math.max(2, (int)Math.ceil((double)editorHeight / (double)rowHeight) + 1);
      changeToOpenGraphGridMode(rows, rowHeight, cols, colWidth);
      editor.getGraph().resetGridDisplayWindow();
    }
    else
    {
      Rectangle2D.Double fitBounds = getOpenGraphFitBounds(normalized);
      int minX = floorToGrid((int)Math.floor(fitBounds.getMinX()), colWidth)
                 - normalized.getMarginLeftLines()*colWidth;
      int minY = floorToGrid((int)Math.floor(fitBounds.getMinY()), rowHeight)
                 - normalized.getMarginTopLines()*rowHeight;
      int maxX = ceilToGrid((int)Math.ceil(fitBounds.getMaxX()), colWidth)
                 + normalized.getMarginRightLines()*colWidth;
      int maxY = ceilToGrid((int)Math.ceil(fitBounds.getMaxY()), rowHeight)
                 + normalized.getMarginBottomLines()*rowHeight;

      if ( maxX <= minX )
      {
        maxX = minX + colWidth;
      }
      if ( maxY <= minY )
      {
        maxY = minY + rowHeight;
      }

      int cols = Math.max(2, ((maxX - minX) / colWidth) + 1);
      int rows = Math.max(2, ((maxY - minY) / rowHeight) + 1);

      changeToOpenGraphGridMode(rows, rowHeight, cols, colWidth);
      editor.getGraph().setGridDisplayWindow(minX, minY, rows, cols);
    }

    if ( !editor.isInGridMode() )
    {
      editor.ensureGridListener();
    }
    editor.updateShapes();
    refreshPreferredSize();
    editor.repaint();
  }

  public void changeToDynamicOpenGraphGridMode(int rowHeight, int colWidth)
  {
    OpenGraphGridSettings settings = editor.getOpenGraphGridSettings();
    settings.setGridMode(OpenGraphGridSettings.MODE_FIT_CONTENT);
    settings.setCellHeight(rowHeight);
    settings.setCellWidth(colWidth);
    changeToOpenGraphGridMode(settings);
  }

  public void changeToGridMode()
  {
    String gridString = null;
    if ( editor.getGraph().getGridRows() > 0 )
    {
      gridString = (String)JOptionPane.showInputDialog(
                             editor.getGraphController().getGraphWindow(),
                             "Use commas to separate the number of rows and columns",
                             "Set Grid Size",
                             JOptionPane.PLAIN_MESSAGE,
                             null, null,
                             String.valueOf(editor.getGraph().getGridRows() +
                                            "," + editor.getGraph().getGridCols()));
    }
    else
    {
      gridString = (String)JOptionPane.showInputDialog(
                             editor.getGraphController().getGraphWindow(),
                             "Use commas to separate the number of rows and columns",
                             "Set Grid Size",
                             JOptionPane.PLAIN_MESSAGE,
                             null, null,
                             String.valueOf((editor.getGraph().getNumNodes()-1) +
                                            "," + (editor.getGraph().getNumNodes()-1)));
    }
    int rows = 0;
    int cols = 0;
    if ( gridString != null )
    {
      try
      {
        StringTokenizer tok = new StringTokenizer(gridString, ",");
        if ( tok.countTokens() != 2 )
        {
          throw new NumberFormatException("Rows and Columns must be separated by a comma");
        }
        rows = Integer.parseInt(tok.nextToken());
        cols = Integer.parseInt(tok.nextToken());
        if ( rows < 2 || cols < 2 )
        {
          throw new NumberFormatException("Rows and Columns must both be greater than 1");
        }
        String sizeString = chooseGridCellSizeString(rows, cols);
        int rowHeight = 0;
        int colWidth = 0;
        if ( sizeString != null )
        {
          try
          {
            int[] gridCellSize = parseGridCellSize(sizeString);
            rowHeight = gridCellSize[0];
            colWidth = gridCellSize[1];
            if ( rowHeight < 2 || colWidth < 2 )
            {
              throw new NumberFormatException("Grid cell height and width must both be greater than 1");
            }
            if ( previewGridCellSizeAndConfirm(rows, rowHeight, cols, colWidth, sizeString) )
            {
              editor.getGraph().setGrid(rows, rowHeight, cols, colWidth, true);
              syncOpenGraphGridSettingsAfterManualGrid(rowHeight, colWidth);
              if ( !editor.isInGridMode() )
              {
                editor.ensureGridListener();
              }
              editor.updateShapes();
              refreshPreferredSize();
              editor.revalidate();
              editor.repaint();
            }
          }
          catch ( NumberFormatException nfe )
          {
            JOptionPane.showMessageDialog(editor.getGraphController().getGraphWindow(),
                                          "The grid cell height and width must be integers greater than 1 separated by a comma",
                                          "Unable to switch to grid mode", JOptionPane.ERROR_MESSAGE);
          }
        }

      }
      catch ( NumberFormatException nfe )
      {
        JOptionPane.showMessageDialog(editor.getGraphController().getGraphWindow(),
                                      "The number of rows and columns for the grid must be integers greater than 1 separated by a comma",
                                      "Unable to switch to grid mode", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  private static final String GRID_PREF_NODE = "OpenGraphEd/Grid";
  private static final String PREF_SHOW_LEGACY_20X20 = "showLegacy20x20GridCellOption";

  private void syncOpenGraphGridSettingsAfterManualGrid(int rowHeight, int colWidth)
  {
    OpenGraphGridSettings settings = editor.getOpenGraphGridSettings();
    if ( settings == null ) settings = new OpenGraphGridSettings();
    else settings = settings.copy();
    settings.setCellHeight(rowHeight);
    settings.setCellWidth(colWidth);
    editor.setOpenGraphGridSettings(settings);
  }

  private String chooseGridCellSizeString(int rows, int cols)
  {
    final Preferences prefs = Preferences.userRoot().node(GRID_PREF_NODE);
    boolean showLegacy = prefs.getBoolean(PREF_SHOW_LEGACY_20X20, true);

    final JComboBox combo = new JComboBox();
    final JCheckBox legacyCheck = new JCheckBox("Toon legacy 20,20 optie", showLegacy);

    refillGridCellSizeOptions(combo, rows, cols, showLegacy);

    legacyCheck.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(java.awt.event.ActionEvent event)
      {
        Object previous = combo.getSelectedItem();
        refillGridCellSizeOptions(combo, rows, cols, legacyCheck.isSelected());
        if ( previous != null )
        {
          combo.setSelectedItem(previous);
        }
        if ( combo.getSelectedIndex() < 0 && combo.getItemCount() > 0 )
        {
          combo.setSelectedIndex(0);
        }
      }
    });

    JTextArea note = new JTextArea(
      "Kies de gridcelhoogte en -breedte.\n" +
      "Voor oude .graph-bestanden is 20,20 meestal correct.\n" +
      "Schakel de legacy-optie uit om 20,20 niet meer als vaste eerste keuze te tonen.");
    note.setEditable(false);
    note.setOpaque(false);
    note.setLineWrap(true);
    note.setWrapStyleWord(true);

    JPanel panel = new JPanel(new BorderLayout(6, 6));
    JPanel top = new JPanel(new GridLayout(0, 1, 4, 4));
    top.add(new JLabel("Grid cell height,width:"));
    top.add(combo);
    top.add(legacyCheck);
    panel.add(top, BorderLayout.NORTH);
    panel.add(note, BorderLayout.CENTER);

    int result = JOptionPane.showConfirmDialog(
                   editor.getGraphController().getGraphWindow(),
                   panel,
                   "Set Grid Size",
                   JOptionPane.OK_CANCEL_OPTION,
                   JOptionPane.PLAIN_MESSAGE);

    if ( result != JOptionPane.OK_OPTION )
    {
      return null;
    }

    prefs.putBoolean(PREF_SHOW_LEGACY_20X20, legacyCheck.isSelected());
    Object chosen = combo.getSelectedItem();
    return chosen == null ? null : chosen.toString();
  }


  private boolean previewGridCellSizeAndConfirm(int rows, int rowHeight, int cols, int colWidth, String chosenLabel)
  {
    GridPreviewState previous = GridPreviewState.capture(editor);

    applyGridPreview(rows, rowHeight, cols, colWidth);

    String label = chosenLabel == null ? (rowHeight + "," + colWidth) : chosenLabel.trim();
    int dash = label.indexOf(" - " );
    if ( dash >= 0 )
    {
      label = label.substring(0, dash).trim();
    }

    JTextArea message = new JTextArea(
      "Het gekozen grid wordt nu getoond.\n\n" +
      "Gridcel hoogte,breedte: " + rowHeight + "," + colWidth + "\n" +
      "Rijen,kolommen: " + rows + "," + cols + "\n\n" +
      "OK?");
    message.setEditable(false);
    message.setOpaque(false);
    message.setLineWrap(true);
    message.setWrapStyleWord(true);

    int result = JOptionPane.showConfirmDialog(
                   editor.getGraphController().getGraphWindow(),
                   message,
                   "Grid tonen en bevestigen",
                   JOptionPane.OK_CANCEL_OPTION,
                   JOptionPane.QUESTION_MESSAGE);

    // Restore the pre-preview state in both cases.  If the user confirms, the
    // caller applies the selected grid once more with addMemento=true, so undo
    // still restores the original grid rather than the temporary preview grid.
    previous.restore(editor);

    return result == JOptionPane.OK_OPTION;
  }

  private void applyGridPreview(int rows, int rowHeight, int cols, int colWidth)
  {
    editor.getGraph().setGrid(rows, rowHeight, cols, colWidth, false);
    if ( !editor.isInGridMode() )
    {
      editor.ensureGridListener();
    }
    editor.updateShapes();
    refreshPreferredSize();
    editor.revalidate();
    editor.repaint();
  }

  private static class GridPreviewState
  {
    private int rows;
    private int rowHeight;
    private int cols;
    private int colWidth;
    private int originX;
    private int originY;
    private int displayRows;
    private int displayCols;
    private boolean wasInGridMode;
    private boolean drawGrid;

    static GridPreviewState capture(GraphEditor editor)
    {
      GridPreviewState state = new GridPreviewState();
      state.rows = editor.getGraph().getGridRows();
      state.rowHeight = editor.getGraph().getGridRowHeight();
      state.cols = editor.getGraph().getGridCols();
      state.colWidth = editor.getGraph().getGridColWidth();
      state.originX = editor.getGraph().getGridOriginX();
      state.originY = editor.getGraph().getGridOriginY();
      state.displayRows = editor.getGraph().getGridDisplayRows();
      state.displayCols = editor.getGraph().getGridDisplayCols();
      state.wasInGridMode = editor.isInGridMode();
      state.drawGrid = editor.getGraph().getDrawGrid();
      return state;
    }

    void restore(GraphEditor editor)
    {
      if ( rows > 0 && rowHeight > 0 && cols > 0 && colWidth > 0 )
      {
        editor.getGraph().setGrid(rows, rowHeight, cols, colWidth, false);
        editor.getGraph().setGridDisplayWindow(originX, originY, displayRows, displayCols);
      }
      editor.getGraph().setDrawGrid(drawGrid);
      if ( wasInGridMode )
      {
        editor.ensureGridListener();
      }
      else
      {
        editor.changeToEditMode();
      }
      editor.updateShapes();
      editor.revalidate();
      editor.repaint();
    }
  }

  private void refillGridCellSizeOptions(JComboBox combo, int rows, int cols, boolean showLegacy)
  {
    Object previous = combo.getSelectedItem();
    combo.removeAllItems();

    Vector options = new Vector();

    // Legacy .graph files were normally made on a 20,20 grid.
    // It is still available, but it can now be hidden by the user.
    if ( showLegacy )
    {
      addGridCellSizeOption(options, 20, 20, "oude standaard / legacy default");
    }

    int currentHeight = editor.getGraph().getGridRowHeight();
    int currentWidth = editor.getGraph().getGridColWidth();
    if ( currentHeight > 0 && currentWidth > 0 )
    {
      addGridCellSizeOption(options, currentHeight, currentWidth, "huidige gridcel / current grid cell");
    }

    int fittedHeight = rows > 1 ? getDrawHeight()/(rows-1) : 20;
    int fittedWidth = cols > 1 ? getDrawWidth()/(cols-1) : 20;
    addGridCellSizeOption(options, fittedHeight, fittedWidth, "afgeleid uit venster / fitted from window");

    if ( options.size() == 0 )
    {
      addGridCellSizeOption(options, 20, 20, "fallback");
    }

    for ( int i=0; i<options.size(); i++ )
    {
      combo.addItem(options.elementAt(i));
    }

    if ( previous != null )
    {
      combo.setSelectedItem(previous);
    }
    if ( combo.getSelectedIndex() < 0 && combo.getItemCount() > 0 )
    {
      combo.setSelectedIndex(0);
    }
  }

  private void addGridCellSizeOption(Vector options, int height, int width, String note)
  {
    if ( height < 2 || width < 2 ) return;
    String value = height + "," + width;
    for ( int i=0; i<options.size(); i++ )
    {
      String existing = options.elementAt(i).toString();
      if ( existing.equals(value) || existing.startsWith(value + " ") )
      {
        return;
      }
    }
    if ( note != null && note.trim().length() > 0 )
    {
      options.add(value + "  - " + note);
    }
    else
    {
      options.add(value);
    }
  }

  private int[] parseGridCellSize(String value)
  {
    if ( value == null ) throw new NumberFormatException("Grid cell height and width must be separated by a comma");
    String clean = value.trim();
    int dash = clean.indexOf(" - " );
    if ( dash >= 0 ) clean = clean.substring(0, dash).trim();
    int space = clean.indexOf(' ');
    if ( space >= 0 ) clean = clean.substring(0, space).trim();

    StringTokenizer tok = new StringTokenizer(clean, ",");
    if ( tok.countTokens() != 2 )
    {
      throw new NumberFormatException("Grid cell height and width must be separated by a comma");
    }
    int rowHeight = Integer.parseInt(tok.nextToken().trim());
    int colWidth = Integer.parseInt(tok.nextToken().trim());
    return new int[] { rowHeight, colWidth };
  }


  public void refreshPreferredSize()
  {
    Rectangle2D.Double visibleBounds = getVisibleContentBounds();
    int contentWidth = (int)Math.ceil(visibleBounds.getMaxX() + 2*GraphEditor.DRAW_BUFFER);
    int contentHeight = (int)Math.ceil(visibleBounds.getMaxY() + 2*GraphEditor.DRAW_BUFFER);
    int gridWidth = editor.getGraph().getGridDisplayMaxX() + 2*GraphEditor.DRAW_BUFFER;
    int gridHeight = editor.getGraph().getGridDisplayMaxY() + 2*GraphEditor.DRAW_BUFFER;
    int preferredWidth = Math.max(contentWidth, gridWidth);
    int preferredHeight = Math.max(contentHeight, gridHeight);
    preferredWidth = Math.max(preferredWidth, editor.getWidth());
    preferredHeight = Math.max(preferredHeight, editor.getHeight());
    preferredWidth = Math.max(preferredWidth, 2*GraphEditor.DRAW_BUFFER + 1);
    preferredHeight = Math.max(preferredHeight, 2*GraphEditor.DRAW_BUFFER + 1);

    Dimension dim = editor.getPreferredSize();
    if ( preferredWidth != dim.width || preferredHeight != dim.height )
    {
      editor.setPreferredSize(new Dimension(preferredWidth, preferredHeight));
    }
  }

  public Rectangle2D.Double getVisibleContentBounds()
  {
    Rectangle2D.Double bounds = editor.getGraph().getBounds();
    if ( OpenGraphProjectionSupport.syncProjectionModel(editor) )
    {
      graphStructure.ProjectionLayoutResult projectionLayout = editor.getGraph().getProjectionLayoutResult();
      if ( projectionLayout != null && projectionLayout.renderBounds != null )
      {
        bounds = new Rectangle2D.Double(projectionLayout.renderBounds.getX(),
                                        projectionLayout.renderBounds.getY(),
                                        projectionLayout.renderBounds.getWidth(),
                                        projectionLayout.renderBounds.getHeight());
      }
    }
    if ( editor.getGraph().getShowLabels() || editor.getGraph().getShowCoords() )
    {
      bounds = expandBoundsForNodeLabels(bounds);
    }
    return OpenGraphProjectionSupport.expandBoundsForReservedProjectionLabels(editor, bounds);
  }

  public void centerVisibleContentInWindow()
  {
    Graph graph = editor.getGraph();
    if ( graph == null || graph.getNumNodes() == 0 || !editor.isInGridMode() )
    {
      return;
    }

    OpenGraphGridSettings gridSettings = editor.getOpenGraphGridSettings();
    int cellWidth = Math.max(2, gridSettings.getCellWidth());
    int cellHeight = Math.max(2, gridSettings.getCellHeight());
    int drawWidth = Math.max(cellWidth * 2, editor.getVisibleDrawWidth());
    int drawHeight = Math.max(cellHeight * 2, editor.getVisibleDrawHeight());
    int paddingX = Math.max(0, gridSettings.getMarginLeftLines()) * cellWidth;
    int paddingY = Math.max(0, gridSettings.getMarginTopLines()) * cellHeight;
    paddingX = Math.max(paddingX, 2 * cellWidth);
    paddingY = Math.max(paddingY, 2 * cellHeight);

    Rectangle2D.Double visibleBounds = getVisibleContentBounds();
    double visibleWidth = visibleBounds.getWidth();
    double visibleHeight = visibleBounds.getHeight();

    double desiredMinX = visibleWidth + (2 * paddingX) <= drawWidth
                         ? (drawWidth - visibleWidth) / 2.0
                         : paddingX;
    double desiredMinY = visibleHeight + (2 * paddingY) <= drawHeight
                         ? (drawHeight - visibleHeight) / 2.0
                         : paddingY;

    int dx = snapToGrid((int)Math.round(desiredMinX - visibleBounds.getMinX()), cellWidth);
    int dy = snapToGrid((int)Math.round(desiredMinY - visibleBounds.getMinY()), cellHeight);
    if ( dx == 0 && dy == 0 )
    {
      return;
    }

    graph.translate(dx, dy, true);
    changeToOpenGraphGridMode(gridSettings);
  }

  public int getDrawWidth()
  {
    return editor.getWidth() - 2*GraphEditor.DRAW_BUFFER;
  }

  public int getDrawHeight()
  {
    return editor.getHeight() - 2*GraphEditor.DRAW_BUFFER;
  }

  private int snapToGrid(int value, int step)
  {
    if ( step <= 1 )
    {
      return value;
    }
    return (int)Math.round((double)value / (double)step) * step;
  }

  private int floorToGrid(int value, int step)
  {
    return (int)Math.floor((double)value / (double)step) * step;
  }

  private int ceilToGrid(int value, int step)
  {
    return (int)Math.ceil((double)value / (double)step) * step;
  }

  private Rectangle2D.Double getOpenGraphFitBounds(OpenGraphGridSettings settings)
  {
    Graph graph = editor.getGraph();

    if ( graph.getNumNodes() == 0 )
    {
      return new Rectangle2D.Double(0, 0, settings.getCellWidth(), settings.getCellHeight());
    }

    Rectangle2D.Double bounds = graph.getBounds();
    if ( OpenGraphProjectionSupport.syncProjectionModel(editor) )
    {
      graphStructure.ProjectionLayoutResult projectionLayout = graph.getProjectionLayoutResult();
      if ( projectionLayout != null && projectionLayout.sourceBounds != null )
      {
        bounds = new Rectangle2D.Double(projectionLayout.sourceBounds.getX(),
                                        projectionLayout.sourceBounds.getY(),
                                        projectionLayout.sourceBounds.getWidth(),
                                        projectionLayout.sourceBounds.getHeight());
      }
    }

    if ( settings.getFitScope() == OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS &&
         (editor.getGraph().getShowLabels() || editor.getGraph().getShowCoords()) )
    {
      bounds = expandBoundsForNodeLabels(bounds);
    }

    return bounds;
  }

  private Rectangle2D.Double expandBoundsForNodeLabels(Rectangle2D.Double bounds)
  {
    Rectangle2D.Double expanded = new Rectangle2D.Double(bounds.getX(), bounds.getY(),
                                                         bounds.getWidth(), bounds.getHeight());
    if ( !editor.getGraph().getShowLabels() && !editor.getGraph().getShowCoords() )
    {
      return expanded;
    }

    FontMetrics fm = editor.getFontMetrics(editor.getFont());
    Vector nodes = editor.getGraph().getNodes();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      String text = null;
      if ( editor.getGraph().getShowLabels() )
      {
        text = node.getLabel();
      }
      else if ( editor.getGraph().getShowCoords() )
      {
        text = String.valueOf(node.getLocation().intX()) + ", " +
               String.valueOf(node.getLocation().intY());
      }
      if ( text != null && text.length() > 0 )
      {
        double textX = node.getLocation().intX() + Node.RADIUS + 3;
        double textY = node.getLocation().intY() + Node.RADIUS + 2 - fm.getAscent();
        Rectangle2D.Double textBounds = new Rectangle2D.Double(textX, textY,
                                                               fm.stringWidth(text) + 2,
                                                               fm.getHeight());
        Rectangle2D union = expanded.createUnion(textBounds);
        expanded = new Rectangle2D.Double(union.getX(), union.getY(), union.getWidth(), union.getHeight());
      }
    }
    return expanded;
  }
}
