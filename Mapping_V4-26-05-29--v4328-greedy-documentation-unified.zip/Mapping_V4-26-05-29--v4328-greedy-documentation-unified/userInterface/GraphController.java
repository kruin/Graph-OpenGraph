package userInterface;


import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.io.File;
import graphStructure.Graph;
import userInterface.menuAndToolBar.*;

public class GraphController implements InternalFrameListener
{
  private GraphWindow graphWindow;
  private MenuAndToolBar menuAndToolBar;
  private final OpenTreeStructureSupport opnSupport;
  private final GraphFileActions graphFileActions;
  private final GraphWindowCoordinator graphWindowCoordinator;
  private final GraphEditorActions graphEditorActions;
  private final GraphOperationActions graphOperationActions;
  private final GraphSpecialDisplayActions graphSpecialDisplayActions;
  private final OpenGraphActions graphOpenGraphActions;
  private final GraphControllerFrameState frameState;
  private final GraphControllerOptions controllerOptions;
  private boolean isApplication;

  public GraphController(boolean isApplication)
  {
    this.isApplication = isApplication;
    controllerOptions = new GraphControllerOptions();
    GraphControllerOptionsIO.load(controllerOptions);
    graphWindow = new GraphWindow();
    menuAndToolBar = new MenuAndToolBar(this);
    opnSupport = new OpenTreeStructureSupport();
    graphFileActions = new GraphFileActions();
    graphWindowCoordinator = new GraphWindowCoordinator(graphWindow);
    graphEditorActions = new GraphEditorActions(graphWindow, menuAndToolBar);
    graphOperationActions = new GraphOperationActions(graphWindow, graphWindowCoordinator, graphEditorActions);
    graphSpecialDisplayActions = new GraphSpecialDisplayActions(graphWindow, graphWindowCoordinator, graphEditorActions);
    graphOpenGraphActions = new OpenGraphActions(graphWindow, graphWindowCoordinator, graphEditorActions, opnSupport, menuAndToolBar);
    frameState = new GraphControllerFrameState(graphWindow, menuAndToolBar, graphWindowCoordinator, graphOpenGraphActions);
    menuAndToolBar.syncOptionStates();
  }

  public void setDrawOnEmbedding(boolean drawEmbed) { controllerOptions.setDrawOnEmbedding(drawEmbed); }

  public boolean getDrawOnEmbedding() { return controllerOptions.getDrawOnEmbedding(); }

  public void toggleDrawOnEmbedding() { controllerOptions.toggleDrawOnEmbedding(); }

  public void setClearGenerated(boolean clearGen) { controllerOptions.setClearGenerated(clearGen); }

  public boolean getClearGenerated() { return controllerOptions.getClearGenerated(); }

  public void toggleClearGenerated() { controllerOptions.toggleClearGenerated(); }

  public boolean getTestFeaturesEnabled()
  {
    return controllerOptions != null && controllerOptions.getTestFeaturesEnabled();
  }

  public void toggleTestFeatures()
  {
    controllerOptions.toggleTestFeaturesEnabled();
    refreshMenuState();
  }

  public boolean getLoadGraphFromGraphDir()
  {
    return controllerOptions.getLoadGraphFromGraphDir();
  }

  public String getPreferredGraphDirectoryPath()
  {
    return controllerOptions.getPreferredGraphDirectoryPath();
  }

  public void setPreferredGraphDirectoryPath(String preferredGraphDirectoryPath)
  {
    controllerOptions.setPreferredGraphDirectoryPath(preferredGraphDirectoryPath);
    GraphControllerOptionsIO.save(controllerOptions);
    refreshMenuState();
  }

  public boolean getLoadOPNFromOPNDir()
  {
    return controllerOptions.getLoadOPNFromOPNDir();
  }

  public void setLoadOPNFromOPNDir(boolean loadOPNFromOPNDir)
  {
    controllerOptions.setLoadOPNFromOPNDir(loadOPNFromOPNDir);
    GraphControllerOptionsIO.save(controllerOptions);
    refreshMenuState();
  }

  public String getPreferredOPNDirectoryPath()
  {
    return controllerOptions.getPreferredOPNDirectoryPath();
  }

  public void setPreferredOPNDirectoryPath(String preferredOPNDirectoryPath)
  {
    controllerOptions.setPreferredOPNDirectoryPath(preferredOPNDirectoryPath);
    GraphControllerOptionsIO.save(controllerOptions);
    refreshMenuState();
  }

  public void setDefaultGraphDirectory()
  {
    graphFileActions.chooseDefaultGraphDirectory(graphWindow, this);
  }

  public void setLoadGraphFromGraphDir(boolean loadGraphFromGraphDir)
  {
    controllerOptions.setLoadGraphFromGraphDir(loadGraphFromGraphDir);
    GraphControllerOptionsIO.save(controllerOptions);
    refreshMenuState();
  }

  public void toggleLoadGraphFromGraphDir()
  {
    controllerOptions.toggleLoadGraphFromGraphDir();
    GraphControllerOptionsIO.save(controllerOptions);
    refreshMenuState();
  }

  public GraphWindow getGraphWindow() { return graphWindow; }

  public GraphEditorWindow getActiveGraphEditor() { return frameState.getActiveGraphEditorWindow(); }

  public boolean isApplication() { return isApplication; }

  public void updateCursorLocation(Point cursorPoint)
  {
    menuAndToolBar.updateCursorLocation(cursorPoint);
  }

  public JToolBar getToolBar()
  {
    return menuAndToolBar.getToolBar();
  }

  public JMenuBar getMenuBar()
  {
    return menuAndToolBar.getMenuBar();
  }


  public void internalFrameOpened(InternalFrameEvent e)
  {
    frameState.internalFrameOpened(e);
  }

  public void internalFrameClosed(InternalFrameEvent e)
  {
    frameState.internalFrameClosed(e);
  }

  public void internalFrameActivated(InternalFrameEvent e)
  {
    frameState.internalFrameActivated(e);
  }

  public void internalFrameDeactivated(InternalFrameEvent e)
  {
    frameState.internalFrameDeactivated(e);
  }

  public void internalFrameClosing(InternalFrameEvent e)
  {
    frameState.internalFrameClosing(e);
  }

  public void internalFrameDeiconified(InternalFrameEvent e) { }

  public void internalFrameIconified(InternalFrameEvent e) { }

  public MenuAndToolBar getMenuAndToolBar() { return menuAndToolBar; }

  public void showWindow( OpenGraphEdInternalFrame intFrame )
  {
    frameState.showWindow(intFrame);
  }

  public boolean hasUnsavedGraphs()
  {
    return frameState.hasUnsavedGraphs();
  }

  public void nodesSelectedByEditor(int numNodes, int maxNodes)
  {
    frameState.nodesSelectedByEditor(numNodes, maxNodes);
  }

  public void update()
  {
    frameState.update();
  }

  public void refreshMenuState()
  {
    GraphEditorWindow activeEditor = frameState.getActiveGraphEditorWindow();
    if ( activeEditor != null )
    {
      menuAndToolBar.showControls(activeEditor.getGraphEditor());
    }
    else
    {
      menuAndToolBar.hideControls();
    }
  }

  public void newGraph()
  {
    resetOTSCommandState();
    graphWindow.addGraphEditorWindow(this);
  }

  public void loadGraph()
  {
    resetOTSCommandState();
    graphFileActions.loadGraph(graphWindow, this);
  }

  public boolean loadGraphFromPath(String graphPath)
  {
    resetOTSCommandState();
    return graphFileActions.loadGraphFromPath(graphWindow, this, graphPath);
  }

  public void openOPN()
  {
    resetOTSCommandState();
    graphFileActions.loadOPN(graphWindow, this);
  }

  public void saveGraph()
  {
    if ( frameState.getActiveGraphEditorWindow() != null )
    {
      graphFileActions.saveGraph(graphWindow, frameState.getActiveGraphEditorWindow());
    }
  }

  public void closeGraph()
  {
    resetOTSCommandState();
    if ( frameState.getActiveGraphEditorWindow() != null )
    {
      frameState.getActiveGraphEditorWindow().doDefaultCloseAction();
    }
  }

  public void preferences()
  {
    graphWindowCoordinator.showPreferences(this);
  }

  public void help()
  {
    graphWindowCoordinator.showHelp(this);
  }

  public void info()
  {
    graphWindowCoordinator.showInfo(frameState.getActiveGraphEditorWindow());
  }

  public void log()
  {
    graphWindowCoordinator.showLog(frameState.getActiveGraphEditorWindow());
  }

  public void editMode()
  {
    resetOTSCommandState();
    graphEditorActions.changeToEditMode(frameState.getActiveGraphEditorWindow());
  }

  public void gridMode()
  {
    resetOTSCommandState();
    graphEditorActions.changeToGridMode(frameState.getActiveGraphEditorWindow());
  }
  public void openGraphGridMode()
  {
    graphEditorActions.changeToOpenGraphGridMode(frameState.getActiveGraphEditorWindow());
  }

  public void openFunctionalTreeSettings()
  {
    GraphEditorWindow active = frameState.getActiveGraphEditorWindow();
    if ( active != null )
    {
      active.openFunctionalTreeSettingsDialog();
    }
  }
  public void moveMode()
  {
    resetOTSCommandState();
    graphEditorActions.changeToMoveMode(frameState.getActiveGraphEditorWindow());
  }

  public void rotateMode()
  {
    resetOTSCommandState();
    graphEditorActions.changeToRotateMode(frameState.getActiveGraphEditorWindow());
  }

  public void resizeMode()
  {
    resetOTSCommandState();
    graphEditorActions.changeToResizeMode(frameState.getActiveGraphEditorWindow());
  }

  public void toggleUndo()
  {
    graphEditorActions.toggleUndo(frameState.getActiveGraphEditorWindow());
  }

  public void undo()
  {
    resetOTSCommandState();
    graphEditorActions.undo(frameState.getActiveGraphEditorWindow());
  }

  public void redo()
  {
    resetOTSCommandState();
    graphEditorActions.redo(frameState.getActiveGraphEditorWindow());
  }

  public void newUndo()
  {
    graphEditorActions.updateUndo(frameState.getActiveGraphEditorWindow());
  }

  public void unselectAll()
  {
    graphEditorActions.unselectAll(frameState.getActiveGraphEditorWindow());
  }

  public void removeSelected()
  {
    resetOTSCommandState();
    graphEditorActions.removeSelected(frameState.getActiveGraphEditorWindow());
  }

  public void removeAll()
  {
    resetOTSCommandState();
    graphEditorActions.removeAll(frameState.getActiveGraphEditorWindow());
  }

  public void removeGenerated()
  {
    resetOTSCommandState();
    graphEditorActions.removeGenerated(frameState.getActiveGraphEditorWindow());
  }

  public void preserveGenerated()
  {
    resetOTSCommandState();
    graphEditorActions.preserveGenerated(frameState.getActiveGraphEditorWindow());
  }

  public void testConnectivity()
  {
    graphOperationActions.testConnectivity(frameState.getActiveGraphEditorWindow());
  }

  public void testBiconnectivity()
  {
    graphOperationActions.testBiconnectivity(frameState.getActiveGraphEditorWindow());
  }

  public void testPlanarity()
  {
    graphOperationActions.testPlanarity(frameState.getActiveGraphEditorWindow());
  }

  public void createRandom()
  {
    graphOperationActions.createRandom(frameState.getActiveGraphEditorWindow());
  }

  public void embedding()
  {
    graphOperationActions.embedding(frameState.getActiveGraphEditorWindow());
  }

  public void makeConnected()
  {
    graphOperationActions.makeConnected(frameState.getActiveGraphEditorWindow());
  }

  public void makeBiconnected()
  {
    graphOperationActions.makeBiconnected(frameState.getActiveGraphEditorWindow());
  }

  public void makeMaximal()
  {
    graphOperationActions.makeMaximal(frameState.getActiveGraphEditorWindow());
  }

  public void straightLineEmbed()
  {
    graphOperationActions.straightLineEmbed(frameState.getActiveGraphEditorWindow(), controllerOptions.getClearGenerated());
  }

  public void showCoords()
  {
    graphEditorActions.showCoords(frameState.getActiveGraphEditorWindow());
  }

  public void showLabels()
  {
    graphEditorActions.showLabels(frameState.getActiveGraphEditorWindow());
  }

  public void showNothing()
  {
    graphEditorActions.showNothing(frameState.getActiveGraphEditorWindow());
  }

  public void resetDisplay()
  {
    graphEditorActions.resetDisplay(frameState.getActiveGraphEditorWindow());
  }

  public void displayDFS()
  {
    graphEditorActions.displayDFS(frameState.getActiveGraphEditorWindow());
  }

  public void displayBiconnected()
  {
    graphEditorActions.displayBiconnected(frameState.getActiveGraphEditorWindow());
  }

  public void displayST()
  {
    graphOperationActions.displayST(frameState.getActiveGraphEditorWindow());
  }

  public void displayCanonical()
  {
    graphSpecialDisplayActions.displayCanonical(this, frameState.getActiveGraphEditorWindow());
  }

  public void displayNormal()
  {
    graphSpecialDisplayActions.displayNormal(this, frameState.getActiveGraphEditorWindow());
  }

  public void displaySchnyder()
  {
    graphSpecialDisplayActions.displaySchnyder(this, frameState.getActiveGraphEditorWindow());
  }

  public void displayChanTree()
  {
    graphSpecialDisplayActions.displayChanTree(this, frameState.getActiveGraphEditorWindow());
  }


  private void resetOTSCommandState()
  {
    graphOpenGraphActions.clearOPNState(frameState.getActiveGraphEditorWindow());
  }

  public void saveOPN()
  {
    graphOpenGraphActions.saveOPN(frameState.getActiveGraphEditorWindow());
  }

  public void saveOPN(GraphEditorWindow editorWindow)
  {
    graphOpenGraphActions.saveOPN(editorWindow);
  }

  public void launchGreedyGenerator()
  {
    graphOpenGraphActions.launchGreedyGenerator();
  }

  public void configureGreedyGenerator()
  {
    Graph contextGraph = null;
    GraphEditorWindow activeWindow = frameState.getActiveGraphEditorWindow();
    if ( activeWindow != null && activeWindow.getGraphEditor() != null )
    {
      contextGraph = activeWindow.getGraphEditor().getGraph();
    }
    Graph graph = graphOpenGraphActions.showGreedySettingsAndMaybeGenerateGraph(contextGraph);
    displayGreedyGraph(graph);
  }

  public void generateGreedyGraph()
  {
    Graph contextGraph = null;
    GraphEditorWindow activeWindow = frameState.getActiveGraphEditorWindow();
    if ( activeWindow != null && activeWindow.getGraphEditor() != null )
    {
      contextGraph = activeWindow.getGraphEditor().getGraph();
    }
    Graph graph = null;
    if ( contextGraph != null && contextGraph.hasGreedySettingsSpecText() )
    {
      graph = graphOpenGraphActions.generateInternalGreedyPreviewGraphFromSpecText(contextGraph.getGreedySettingsSpecText());
    }
    else
    {
      graph = graphOpenGraphActions.generateInternalGreedyPreviewGraph();
    }
    displayGreedyGraph(graph);
  }

  private void displayGreedyGraph(Graph graph)
  {
    if ( graph == null )
    {
      return;
    }

    GraphEditorWindow editorWindow = graphWindow.addGraphEditorWindow(this, graph);
    if ( editorWindow != null && editorWindow.getGraphEditor() != null )
    {
      applyGeneratedGreedyGrid(editorWindow.getGraphEditor(), graph);
      menuAndToolBar.showControls(editorWindow.getGraphEditor());
      graphWindow.repaint();
    }
  }

  private void applyGeneratedGreedyGrid(GraphEditor graphEditor, Graph graph)
  {
    if ( graphEditor == null || graph == null )
    {
      return;
    }

    OpenGraphGridSettings settings = graphEditor.getOpenGraphGridSettings();
    if ( settings == null )
    {
      settings = new OpenGraphGridSettings();
    }
    else
    {
      settings = settings.copy();
    }

    int cellWidth = graph.getGridColWidth() > 0 ? graph.getGridColWidth() : 20;
    int cellHeight = graph.getGridRowHeight() > 0 ? graph.getGridRowHeight() : 20;

    settings.setGridMode(OpenGraphGridSettings.MODE_FIT_CONTENT);
    settings.setFitScope(OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);
    settings.setCellWidth(cellWidth);
    settings.setCellHeight(cellHeight);
    settings.normalize();

    graphEditor.setOpenGraphGridSettings(settings);
    graphEditor.changeToOpenGraphGridMode(settings);
  }

  public void saveOpenGraphAs()
  {
    GraphEditorWindow editorWindow = frameState.getActiveGraphEditorWindow();
    if ( editorWindow == null )
    {
      JOptionPane.showMessageDialog(graphWindow,
        "Save As requires an open graph window.",
        "Save As",
        JOptionPane.INFORMATION_MESSAGE);
      return;
    }

    Object[] options = new Object[] {
      "Greedy package (.zip)",
      "OPN document (.opn)",
      "Graph only (.graph)",
      "Image only (.gif/.jpg/.jpeg)",
      "Cancel"
    };

    int choice = JOptionPane.showOptionDialog(graphWindow,
      "Choose what to save.\n\n" +
      "Recommended for Greedy restore: Greedy package or OPN document.\n" +
      "Graph only and Image only do not restore Greedy settings.",
      "Greedy Save As",
      JOptionPane.DEFAULT_OPTION,
      JOptionPane.QUESTION_MESSAGE,
      null,
      options,
      options[0]);

    if ( choice == 0 )
    {
      GreedySaveExportSupport.saveGreedyPackage(graphWindow, editorWindow);
    }
    else if ( choice == 1 )
    {
      GreedySaveExportSupport.saveOPNDocument(graphWindow, editorWindow);
    }
    else if ( choice == 2 )
    {
      if ( GreedySaveExportSupport.confirmGraphOnly(graphWindow) )
      {
        graphFileActions.saveGraph(graphWindow, editorWindow);
      }
    }
    else if ( choice == 3 )
    {
      if ( GreedySaveExportSupport.confirmImageOnly(graphWindow) )
      {
        graphFileActions.saveGraphImage(graphWindow, editorWindow);
      }
    }
  }

  public void showGreedyTools()
  {
    Object[] options = new Object[] {
      "Grid Settings / Reapply Grid",
      "External GUI",
      "External Generate + Import",
      "Open Output Folder",
      "Open Preview PNG",
      "Open Report",
      "Open Effective Spec",
      "Open Updated Manual PDF",
      "Cancel"
    };

    int choice = JOptionPane.showOptionDialog(graphWindow,
      "Advanced Greedy tools.\n\nThe normal route is: Greedy > Greedy Generator -> Greedy > Generate Greedy Graph -> fine-tune -> Greedy > Save As.",
      "Greedy Tools",
      JOptionPane.DEFAULT_OPTION,
      JOptionPane.QUESTION_MESSAGE,
      null,
      options,
      options[0]);

    if ( choice == 0 ) openGraphGridMode();
    else if ( choice == 1 ) graphOpenGraphActions.launchGreedyGenerator();
    else if ( choice == 2 ) generateExternalAndImportGreedyOPN();
    else if ( choice == 3 ) graphOpenGraphActions.openGreedyOutputFolder();
    else if ( choice == 4 ) graphOpenGraphActions.openGreedyPreviewPNG();
    else if ( choice == 5 ) graphOpenGraphActions.openGreedyReport();
    else if ( choice == 6 ) graphOpenGraphActions.openGreedyEffectiveSpec();
    else if ( choice == 7 ) graphOpenGraphActions.openGreedyManualPDF();
  }

  public void configureGenerateAndOpenGreedyOPN()
  {
    boolean shouldGenerate = graphOpenGraphActions.configureGreedyGenerator(true);
    if ( shouldGenerate )
    {
      generateAndOpenGreedyOPN();
    }
  }

  public void configureGenerateAndImportGreedyOPN()
  {
    boolean shouldGenerate = graphOpenGraphActions.configureGreedyGenerator(true);
    if ( shouldGenerate )
    {
      generateAndImportGreedyOPN();
    }
  }

  public void configureGenerateAndImportInternalGreedyOPN()
  {
    configureGenerateAndImportGreedyOPN();
  }

  public void generateAndImportInternalGreedyOPN()
  {
    generateAndImportGreedyOPN();
  }

  public void generateAndImportGreedyOPN()
  {
    File opnFile = graphOpenGraphActions.generateInternalGreedyGeneratorDefaultOPN();
    if ( opnFile != null )
    {
      runGreedyImportWorkflow(opnFile);
    }
  }

  public void generateExternalAndImportGreedyOPN()
  {
    File opnFile = graphOpenGraphActions.generateGreedyGeneratorDefaultOPN();
    if ( opnFile != null )
    {
      runGreedyImportWorkflow(opnFile);
    }
  }

  public void generateAndOpenGreedyOPN()
  {
    File opnFile = graphOpenGraphActions.generateInternalGreedyGeneratorDefaultOPN();
    if ( opnFile != null )
    {
      graphFileActions.loadGraphFromPath(graphWindow, this, opnFile.getPath());
    }
  }

  private void runGreedyImportWorkflow(File opnFile)
  {
    boolean keepOpen = true;
    while ( keepOpen )
    {
      int action = graphOpenGraphActions.showGreedyImportWorkflow(opnFile);
      if ( action == OpenGraphActions.GREEDY_IMPORT_ACTION_IMPORT )
      {
        graphFileActions.loadGraphFromPath(graphWindow, this, opnFile.getPath());
        keepOpen = false;
      }
      else if ( action == OpenGraphActions.GREEDY_IMPORT_ACTION_PREVIEW )
      {
        graphOpenGraphActions.openGreedyPreviewPNG();
      }
      else if ( action == OpenGraphActions.GREEDY_IMPORT_ACTION_REPORT )
      {
        graphOpenGraphActions.openGreedyReport();
      }
      else if ( action == OpenGraphActions.GREEDY_IMPORT_ACTION_SPEC )
      {
        graphOpenGraphActions.openGreedyEffectiveSpec();
      }
      else if ( action == OpenGraphActions.GREEDY_IMPORT_ACTION_FOLDER )
      {
        graphOpenGraphActions.openGreedyOutputFolder();
      }
      else
      {
        keepOpen = false;
      }
    }
  }

  public void openGreedyOutputOPN()
  {
    File outputDir = graphOpenGraphActions.getGreedyGeneratorDefaultOutputDirectory();
    graphFileActions.loadOPNFromDirectory(graphWindow,
                                          this,
                                          outputDir,
                                          "Open Greedy Generator OPN");
  }

  public void openGreedyOutputFolder()
  {
    graphOpenGraphActions.openGreedyOutputFolder();
  }

  public void openGreedyPreviewPNG()
  {
    graphOpenGraphActions.openGreedyPreviewPNG();
  }

  public void openGreedyReport()
  {
    graphOpenGraphActions.openGreedyReport();
  }

  public void openGreedyEffectiveSpec()
  {
    graphOpenGraphActions.openGreedyEffectiveSpec();
  }

  public void openGreedyManualPDF()
  {
    graphOpenGraphActions.openGreedyManualPDF();
  }

  public void displayOpenGraphTree()
  {
    graphOpenGraphActions.displayOpenGraphTree(this, frameState.getActiveGraphEditorWindow());
  }

  public void displayOpenGraphTree(GraphEditorWindow editorWindow)
  {
    graphOpenGraphActions.displayOpenGraphTree(this, editorWindow);
  }

  public void openGraphGridMode(GraphEditorWindow editorWindow)
  {
    graphEditorActions.changeToOpenGraphGridMode(editorWindow);
  }

  public void toggleLexicalProjection()
  {
    graphOpenGraphActions.toggleLexicalProjection(frameState.getActiveGraphEditorWindow());
  }

  public void toggleLexicalProjection(GraphEditorWindow editorWindow)
  {
    graphOpenGraphActions.toggleLexicalProjection(editorWindow);
  }

  public void applyLanguageTreeZinstype(String zinstype)
  {
    graphOpenGraphActions.applyLanguageTreeZinstype(frameState.getActiveGraphEditorWindow(), zinstype);
  }

  public void applyLanguageTreeZinstype(GraphEditorWindow editorWindow, String zinstype)
  {
    graphOpenGraphActions.applyLanguageTreeZinstype(editorWindow, zinstype);
  }

  public void applyLanguageTreeVerbClusterOrder(GraphEditorWindow editorWindow, String order)
  {
    graphOpenGraphActions.applyLanguageTreeVerbClusterOrder(editorWindow, order);
  }

  public void applyLanguageTreeVerbClusterOrder(String order)
  {
    graphOpenGraphActions.applyLanguageTreeVerbClusterOrder(frameState.getActiveGraphEditorWindow(), order);
  }

  public void applyOpenGraphStructureType(int structureType)
  {
    graphOpenGraphActions.applyOpenGraphStructureType(frameState.getActiveGraphEditorWindow(), structureType);
  }

  public void applyOpenGraphStructureType(GraphEditorWindow editorWindow, int structureType)
  {
    graphOpenGraphActions.applyOpenGraphStructureType(editorWindow, structureType);
  }

  public void restoreOriginalOpenGraphTree(GraphEditorWindow editorWindow)
  {
    graphOpenGraphActions.restoreOriginalOpenGraphTree(editorWindow);
  }

  public void drawSelectedOpenGraphStructure(GraphEditorWindow editorWindow)
  {
    graphOpenGraphActions.drawSelectedOpenGraphStructure(editorWindow);
  }

  public void drawSelectedOpenGraphStructure()
  {
    graphOpenGraphActions.drawSelectedOpenGraphStructure(frameState.getActiveGraphEditorWindow());
  }

  public void displayMST()
  {
    graphEditorActions.displayMST(frameState.getActiveGraphEditorWindow());
  }

  public void displayDijkstra()
  {
    graphOperationActions.displayDijkstra(this, frameState.getActiveGraphEditorWindow());
  }
}