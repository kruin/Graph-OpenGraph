package userInterface;

import javax.swing.*;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import graphStructure.*;
import userInterface.fileUtils.Utils;

/**
 * Greedy-specific save/export support.
 *
 * The normal Greedy workflow is document-first:
 *   generate -> display/fine-tune -> save/export only when explicitly requested.
 *
 * A plain .graph or image is intentionally graph/image-only.  A Greedy OPN and a
 * Greedy package preserve the embedded Greedy settings so the document can later
 * be restored as a Greedy document.
 */
final class GreedySaveExportSupport
{
  private GreedySaveExportSupport() {}

  static void saveOPNDocument(Component parent, GraphEditorWindow editorWindow)
  {
    Graph graph = graphFrom(editorWindow);
    if ( graph == null )
    {
      message(parent, "No graph is open.", "Save Greedy OPN", JOptionPane.INFORMATION_MESSAGE);
      return;
    }

    if ( !graph.hasGreedySettingsSpecText() )
    {
      int go = JOptionPane.showConfirmDialog(parent,
        "No embedded Greedy settings are attached to this graph.\n\n" +
        "The OPN can still be saved, but Greedy Settings cannot be restored from it.\n\n" +
        "Continue?",
        "OPN Without Greedy Settings",
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.WARNING_MESSAGE);
      if ( go != JOptionPane.OK_OPTION ) return;
    }

    syncGraphGridFromEditorSettings(editorWindow, graph);

    JFileChooser chooser = new JFileChooser(startDirectory(graph));
    chooser.setFileView(new userInterface.fileUtils.GraphFileView());
    chooser.setDialogTitle("Save Greedy OPN Document");
    chooser.setApproveButtonText("Save OPN");
    chooser.setSelectedFile(suggestedFile(editorWindow, graph, Utils.opn));

    int returnVal = chooser.showSaveDialog(parent);
    if ( returnVal != JFileChooser.APPROVE_OPTION ) return;

    try
    {
      File saveFile = prepareSaveFileAndGraph(chooser.getSelectedFile(), graph, Utils.opn).getCanonicalFile();
      if ( !confirmOverwrite(parent, saveFile) ) return;
      writeOPNFile(saveFile, graph);
      graph.setFilePath(saveFile.getPath());
      message(parent,
        "Greedy OPN saved to:\n" + saveFile.getPath() + "\n\n" +
        (graph.hasGreedySettingsSpecText() ?
          "Embedded GREEDY_SETTINGS_YAML was written." :
          "Warning: no Greedy settings were available to embed."),
        "Save Greedy OPN",
        JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      message(parent, "Unable to save Greedy OPN.\n\n" + e.getMessage(),
        "Save Greedy OPN Failed", JOptionPane.ERROR_MESSAGE);
    }
  }

  static void saveGreedyPackage(Component parent, GraphEditorWindow editorWindow)
  {
    Graph graph = graphFrom(editorWindow);
    if ( graph == null )
    {
      message(parent, "No graph is open.", "Save Greedy Package", JOptionPane.INFORMATION_MESSAGE);
      return;
    }

    if ( !graph.hasGreedySettingsSpecText() )
    {
      int go = JOptionPane.showConfirmDialog(parent,
        "No embedded Greedy settings are attached to this graph.\n\n" +
        "A package can still be made, but it will not contain restorable Greedy settings.\n\n" +
        "Continue?",
        "Package Without Greedy Settings",
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.WARNING_MESSAGE);
      if ( go != JOptionPane.OK_OPTION ) return;
    }

    syncGraphGridFromEditorSettings(editorWindow, graph);

    JFileChooser chooser = new JFileChooser(startDirectory(graph));
    chooser.setFileView(new userInterface.fileUtils.GraphFileView());
    chooser.setDialogTitle("Save Greedy Package");
    chooser.setApproveButtonText("Save Greedy Package");
    chooser.setSelectedFile(suggestedFile(editorWindow, graph, "zip"));

    int returnVal = chooser.showSaveDialog(parent);
    if ( returnVal != JFileChooser.APPROVE_OPTION ) return;

    try
    {
      File saveFile = prepareSaveFileAndGraph(chooser.getSelectedFile(), graph, "zip").getCanonicalFile();
      if ( !confirmOverwrite(parent, saveFile) ) return;
      writePackage(saveFile, editorWindow, graph);
      message(parent,
        "Greedy package saved to:\n" + saveFile.getPath() + "\n\n" +
        "Included: .opn, .graph, .svg, .png, spec.yaml, effective_spec.yaml, report, and preview image where available.",
        "Save Greedy Package",
        JOptionPane.INFORMATION_MESSAGE);
    }
    catch ( Exception e )
    {
      e.printStackTrace();
      message(parent, "Unable to save Greedy package.\n\n" + e.getMessage(),
        "Save Greedy Package Failed", JOptionPane.ERROR_MESSAGE);
    }
  }

  static boolean confirmGraphOnly(Component parent)
  {
    return JOptionPane.showConfirmDialog(parent,
      "Graph only saves the visible graph structure as .graph.\n\n" +
      "Greedy settings are not restorable from a plain .graph file.\n" +
      "Use Greedy package or OPN document if you want Greedy restore.",
      "Graph Only: No Greedy Restore",
      JOptionPane.OK_CANCEL_OPTION,
      JOptionPane.WARNING_MESSAGE) == JOptionPane.OK_OPTION;
  }

  static boolean confirmImageOnly(Component parent)
  {
    return JOptionPane.showConfirmDialog(parent,
      "Image only saves a visual image.\n\n" +
      "No graph structure and no Greedy settings are saved.",
      "Image Only: No Restore",
      JOptionPane.OK_CANCEL_OPTION,
      JOptionPane.WARNING_MESSAGE) == JOptionPane.OK_OPTION;
  }

  private static File prepareSaveFileAndGraph(File selectedFile, Graph graph, String extension) throws IOException
  {
    // v4325: the filename tag is an output fact, not an input command.
    // A chooser can be prefilled with a stale gridH20W20 name from the old
    // document path.  Saving must follow the active graph grid instead of
    // letting that stale prefilled name reset the graph back to 20,20.
    File saveFile = OpenGraphGridFileNameSupport.ensureGridTag(selectedFile, graph, extension);
    syncGreedySettingsToGraphGrid(graph);
    return saveFile;
  }

  private static void syncGraphGridFromEditorSettings(GraphEditorWindow editorWindow, Graph graph)
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null || graph == null ) return;
    try
    {
      OpenGraphGridSettings settings = editorWindow.getGraphEditor().getOpenGraphGridSettings();
      if ( settings == null ) return;
      settings = settings.copy();
      settings.normalize();
      int settingsH = settings.getCellHeight();
      int settingsW = settings.getCellWidth();
      int graphH = OpenGraphGridFileNameSupport.normalizedCellHeight(graph);
      int graphW = OpenGraphGridFileNameSupport.normalizedCellWidth(graph);
      if ( settingsH > 0 && settingsW > 0 && (settingsH != graphH || settingsW != graphW) )
      {
        OpenGraphGridFileNameSupport.applyGridCellSize(graph, settingsH, settingsW);
        OpenGraphGridFileNameSupport.snapNodesToGrid(graph);
      }
    }
    catch ( Exception ignored )
    {
      // The graph grid itself remains the fallback.
    }
  }

  private static void syncGreedySettingsToGraphGrid(Graph graph)
  {
    if ( graph == null || !graph.hasGreedySettingsSpecText() ) return;
    int stepX = OpenGraphGridFileNameSupport.normalizedCellWidth(graph);
    int stepY = OpenGraphGridFileNameSupport.normalizedCellHeight(graph);
    int rows = OpenGraphGridFileNameSupport.normalizedRows(graph);
    int cols = OpenGraphGridFileNameSupport.normalizedCols(graph);
    String synced = syncYamlGridValues(graph.getGreedySettingsSpecText(), stepX, stepY, rows, cols);
    graph.setGreedySettingsSpecText(synced);
  }

  private static String syncYamlGridValues(String text, int stepX, int stepY, int rows, int cols)
  {
    if ( text == null || text.trim().length() == 0 ) return text;
    BufferedReader reader = new BufferedReader(new StringReader(text));
    StringWriter sw = new StringWriter();
    PrintWriter out = new PrintWriter(sw);
    boolean inGrid = false;
    boolean sawStepX = false, sawStepY = false, sawHeight = false, sawWidth = false;
    try
    {
      String line;
      while ( (line = reader.readLine()) != null )
      {
        String trimmed = line.trim();
        if ( trimmed.endsWith(":") && !trimmed.startsWith("#") )
        {
          if ( inGrid )
          {
            if ( !sawStepX ) out.println("  step_x: " + stepX);
            if ( !sawStepY ) out.println("  step_y: " + stepY);
            if ( !sawHeight ) out.println("  height: " + rows + "  # rows; updated from current graph");
            if ( !sawWidth ) out.println("  width: " + cols + "   # columns; updated from current graph");
          }
          inGrid = "grid:".equals(trimmed);
          if ( inGrid )
          {
            sawStepX = sawStepY = sawHeight = sawWidth = false;
          }
          out.println(line);
          continue;
        }

        if ( inGrid )
        {
          String key = yamlKey(trimmed);
          if ( "step_x".equals(key) )
          {
            out.println("  step_x: " + stepX);
            sawStepX = true;
            continue;
          }
          if ( "step_y".equals(key) )
          {
            out.println("  step_y: " + stepY);
            sawStepY = true;
            continue;
          }
          if ( "height".equals(key) )
          {
            out.println("  height: " + rows + "  # rows; updated from current graph");
            sawHeight = true;
            continue;
          }
          if ( "width".equals(key) )
          {
            out.println("  width: " + cols + "   # columns; updated from current graph");
            sawWidth = true;
            continue;
          }
        }
        out.println(line);
      }
      if ( inGrid )
      {
        if ( !sawStepX ) out.println("  step_x: " + stepX);
        if ( !sawStepY ) out.println("  step_y: " + stepY);
        if ( !sawHeight ) out.println("  height: " + rows + "  # rows; updated from current graph");
        if ( !sawWidth ) out.println("  width: " + cols + "   # columns; updated from current graph");
      }
    }
    catch ( IOException ignored )
    {
      return text;
    }
    out.close();
    return sw.toString();
  }

  private static String yamlKey(String trimmed)
  {
    if ( trimmed == null ) return "";
    int colon = trimmed.indexOf(':');
    if ( colon <= 0 ) return "";
    return trimmed.substring(0, colon).trim();
  }

  static void writeOPNFile(File file, Graph graph) throws Exception
  {
    PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
    try
    {
      writePipeSafeGraphOPN(writer, graph);
    }
    finally
    {
      writer.close();
    }
  }

  private static void writePackage(File zipFile, GraphEditorWindow editorWindow, Graph graph) throws Exception
  {
    File parent = zipFile.getParentFile();
    if ( parent != null && !parent.exists() && !parent.mkdirs() )
    {
      throw new IOException("Could not create output directory: " + parent.getPath());
    }

    String base = stripExtension(zipFile.getName());
    ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
    try
    {
      addGraphEntry(zip, base + ".graph", graph);
      addOPNEntry(zip, base + ".opn", graph);
      addTextEntry(zip, "spec.yaml", specTextOrNote(graph));
      addTextEntry(zip, "effective_spec.yaml", specTextOrNote(graph));
      addTextEntry(zip, base + "_report.txt", buildReport(graph));
      addTextEntry(zip, "README-GREEDY-PACKAGE.txt", buildReadme(base, graph));
      addSVGEntry(zip, base + ".svg", graph);
      addPNGEntry(zip, editorWindow, base + ".png");
      addPreviewImageEntry(zip, editorWindow, base + "_preview.gif");
    }
    finally
    {
      zip.close();
    }
  }

  private static void addGraphEntry(ZipOutputStream zip, String name, Graph graph) throws IOException
  {
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    graph.saveTo(pw);
    pw.close();
    addTextEntry(zip, name, sw.toString());
  }

  private static void addOPNEntry(ZipOutputStream zip, String name, Graph graph) throws Exception
  {
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    writePipeSafeGraphOPN(pw, graph);
    pw.close();
    addTextEntry(zip, name, sw.toString());
  }

  private static void addSVGEntry(ZipOutputStream zip, String name, Graph graph) throws IOException
  {
    addTextEntry(zip, name, buildCurrentGraphSVG(graph));
  }

  private static void addPNGEntry(ZipOutputStream zip, GraphEditorWindow editorWindow, String name)
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null ) return;
    try
    {
      BufferedImage image = renderEditorImage(editorWindow);
      if ( image == null ) return;
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      ImageIO.write(image, "png", out);
      out.close();
      addBinaryEntry(zip, name, out.toByteArray());
    }
    catch ( Exception ignored )
    {
      // PNG is a convenience export; the package remains valid without it.
    }
  }

  private static void addBinaryEntry(ZipOutputStream zip, String name, byte[] data) throws IOException
  {
    zip.putNextEntry(new ZipEntry(name));
    if ( data != null ) zip.write(data, 0, data.length);
    zip.closeEntry();
  }

  private static BufferedImage renderEditorImage(GraphEditorWindow editorWindow)
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null ) return null;
    GraphEditor editor = editorWindow.getGraphEditor();
    int width = Math.max(1, editor.getWidth());
    int height = Math.max(1, editor.getHeight());
    if ( width < 10 ) width = Math.max(800, editor.getPreferredSize().width);
    if ( height < 10 ) height = Math.max(600, editor.getPreferredSize().height);
    BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    Graphics2D g = image.createGraphics();
    try
    {
      editor.paint(g);
    }
    finally
    {
      g.dispose();
    }
    return image;
  }

  private static void addTextEntry(ZipOutputStream zip, String name, String text) throws IOException
  {
    zip.putNextEntry(new ZipEntry(name));
    byte[] data = (text == null ? "" : text).getBytes("UTF-8");
    zip.write(data, 0, data.length);
    zip.closeEntry();
  }

  private static void addPreviewImageEntry(ZipOutputStream zip, GraphEditorWindow editorWindow, String name)
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null ) return;
    File tmp = null;
    try
    {
      tmp = File.createTempFile("opengraphed-greedy-preview-", ".gif");
      editorWindow.getGraphEditor().saveImage(tmp.getPath());
      if ( tmp.exists() && tmp.length() > 0 )
      {
        zip.putNextEntry(new ZipEntry(name));
        FileInputStream in = new FileInputStream(tmp);
        try
        {
          byte[] buffer = new byte[8192];
          int n;
          while ( (n = in.read(buffer)) > 0 ) zip.write(buffer, 0, n);
        }
        finally
        {
          in.close();
        }
        zip.closeEntry();
      }
    }
    catch ( Exception ignored )
    {
      // Preview is helpful but not required for a valid Greedy package.
    }
    finally
    {
      if ( tmp != null ) tmp.delete();
    }
  }

  private static String buildCurrentGraphSVG(Graph graph)
  {
    if ( graph == null )
    {
      return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1\" height=\"1\" viewBox=\"0 0 1 1\"></svg>\n";
    }

    Vector nodes = graph.getNodes();
    int margin = 40;
    int minX = graph.getGridDisplayMinX();
    int minY = graph.getGridDisplayMinY();
    int maxX = graph.getGridDisplayMaxX();
    int maxY = graph.getGridDisplayMaxY();
    if ( nodes != null )
    {
      for ( int i=0; i<nodes.size(); i++ )
      {
        Node node = (Node)nodes.elementAt(i);
        minX = Math.min(minX, node.getX());
        minY = Math.min(minY, node.getY());
        maxX = Math.max(maxX, node.getX());
        maxY = Math.max(maxY, node.getY());
      }
    }
    int viewMinX = minX - margin;
    int viewMinY = minY - margin;
    int width = Math.max(1, (maxX - minX) + 2 * margin);
    int height = Math.max(1, (maxY - minY) + 2 * margin);

    StringWriter sw = new StringWriter();
    PrintWriter out = new PrintWriter(sw);
    out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    out.println("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + width + "\" height=\"" + height + "\" viewBox=\"" + viewMinX + " " + viewMinY + " " + width + " " + height + "\">");
    out.println("  <metadata>Generated by OpenGraphEd Greedy package. Grid cell height,width: " +
      OpenGraphGridFileNameSupport.normalizedCellHeight(graph) + "," +
      OpenGraphGridFileNameSupport.normalizedCellWidth(graph) + "</metadata>");
    out.println("  <rect x=\"" + viewMinX + "\" y=\"" + viewMinY + "\" width=\"" + width + "\" height=\"" + height + "\" fill=\"white\"/>");

    if ( graph.getDrawGrid() )
    {
      int ox = graph.getGridDisplayMinX();
      int oy = graph.getGridDisplayMinY();
      int rows = graph.getGridDisplayRows();
      int cols = graph.getGridDisplayCols();
      int cellW = Math.max(1, graph.getGridColWidth());
      int cellH = Math.max(1, graph.getGridRowHeight());
      out.println("  <g stroke=\"#d0d0d0\" stroke-width=\"1\">");
      for ( int c=0; c<=cols; c++ )
      {
        int x = ox + c * cellW;
        out.println("    <line x1=\"" + x + "\" y1=\"" + oy + "\" x2=\"" + x + "\" y2=\"" + (oy + rows * cellH) + "\"/>");
      }
      for ( int r=0; r<=rows; r++ )
      {
        int y = oy + r * cellH;
        out.println("    <line x1=\"" + ox + "\" y1=\"" + y + "\" x2=\"" + (ox + cols * cellW) + "\" y2=\"" + y + "\"/>");
      }
      out.println("  </g>");
    }

    out.println("  <g stroke=\"#0000ff\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\">");
    Vector edges = graph.getEdges();
    if ( edges != null )
    {
      for ( int i=0; i<edges.size(); i++ )
      {
        Edge edge = (Edge)edges.elementAt(i);
        Node a = (Node)edge.getStartNode();
        Node b = (Node)edge.getEndNode();
        out.println("    <line x1=\"" + a.getX() + "\" y1=\"" + a.getY() + "\" x2=\"" + b.getX() + "\" y2=\"" + b.getY() + "\"/>");
      }
    }
    out.println("  </g>");

    out.println("  <g font-family=\"Arial, sans-serif\" font-size=\"12\" font-weight=\"bold\">");
    if ( nodes != null )
    {
      for ( int i=0; i<nodes.size(); i++ )
      {
        Node node = (Node)nodes.elementAt(i);
        out.println("    <circle cx=\"" + node.getX() + "\" cy=\"" + node.getY() + "\" r=\"5\" fill=\"#00aa00\" stroke=\"#0000ff\" stroke-width=\"2\"/>");
        String label = xmlEscape(node.getLabel());
        if ( label.length() > 0 ) out.println("    <text x=\"" + (node.getX() + 8) + "\" y=\"" + (node.getY() + 4) + "\" fill=\"#000000\">" + label + "</text>");
      }
    }
    out.println("  </g>");
    out.println("</svg>");
    out.close();
    return sw.toString();
  }

  private static String xmlEscape(String value)
  {
    if ( value == null ) return "";
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
  }

  private static String buildReport(Graph graph)
  {
    StringBuffer b = new StringBuffer();
    b.append("Greedy package report\n");
    b.append("=====================\n\n");
    b.append("Graph label: ").append(graph == null ? "" : graph.getLabel()).append('\n');
    b.append("Grid cell height,width: ")
     .append(OpenGraphGridFileNameSupport.normalizedCellHeight(graph)).append(',')
     .append(OpenGraphGridFileNameSupport.normalizedCellWidth(graph)).append('\n');
    b.append("Grid rows,cols: ")
     .append(OpenGraphGridFileNameSupport.normalizedRows(graph)).append(',')
     .append(OpenGraphGridFileNameSupport.normalizedCols(graph)).append('\n');
    b.append("Nodes: ").append(graph == null ? 0 : graph.getNodes().size()).append('\n');
    b.append("Edges: ").append(graph == null ? 0 : graph.getEdges().size()).append('\n');
    b.append("Embedded Greedy settings: ")
     .append(graph != null && graph.hasGreedySettingsSpecText() ? "yes" : "no").append('\n');
    return b.toString();
  }

  private static String buildReadme(String base, Graph graph)
  {
    return "OpenGraphEd Greedy package\n" +
           "=========================\n\n" +
           "This zip is the restorable Greedy save/export format.\n\n" +
           "Main files:\n" +
           "- " + base + ".opn: OpenGraph document with embedded GREEDY_SETTINGS_YAML.\n" +
           "- " + base + ".graph: visible graph structure only.\n" +
           "- spec.yaml: Greedy settings for reference/import.\n" +
           "- effective_spec.yaml: effective Greedy settings.\n" +
           "- " + base + "_report.txt: package summary.\n" +
           "- " + base + ".svg: scalable visual export of the current graph.\n" +
           "- " + base + ".png: PNG visual export of the current graph.\n" +
           "- " + base + "_preview.gif: legacy visual preview, when available.\n\n" +
           "Use Open Greedy OPN for restore. Plain .graph and image files do not restore Greedy settings.\n";
  }

  private static String specTextOrNote(Graph graph)
  {
    if ( graph != null && graph.hasGreedySettingsSpecText() ) return graph.getGreedySettingsSpecText();
    return "# No embedded Greedy settings were available in this graph.\n";
  }

  private static File suggestedFile(GraphEditorWindow editorWindow, Graph graph, String extension)
  {
    // Use the active grid before constructing the visible proposal.  This makes
    // the chooser show gridH18W22 immediately after the user chose 18,22.
    syncGraphGridFromEditorSettings(editorWindow, graph);

    File base = null;
    if ( graph != null && graph.getFilePath() != null && graph.getFilePath().trim().length() > 0 )
    {
      base = new File(graph.getFilePath().trim());
    }
    if ( base == null )
    {
      String label = graph == null ? "greedy" : graph.getLabel();
      base = new File(System.getProperty("user.dir"), safeFileStem(label) + "." + extension);
    }
    else
    {
      base = new File(base.getParentFile() == null ? new File(System.getProperty("user.dir")) : base.getParentFile(),
        stripExtension(base.getName()) + "." + extension);
    }
    return OpenGraphGridFileNameSupport.ensureGridTag(base, graph, extension);
  }

  private static File startDirectory(Graph graph)
  {
    if ( graph != null && graph.getFilePath() != null && graph.getFilePath().trim().length() > 0 )
    {
      File parent = new File(graph.getFilePath().trim()).getParentFile();
      if ( parent != null && parent.exists() && parent.isDirectory() ) return parent;
    }
    return new File(System.getProperty("user.dir"));
  }

  private static Graph graphFrom(GraphEditorWindow editorWindow)
  {
    if ( editorWindow == null || editorWindow.getGraphEditor() == null ) return null;
    return editorWindow.getGraphEditor().getGraph();
  }

  private static boolean confirmOverwrite(Component parent, File file)
  {
    if ( file == null || !file.exists() ) return true;
    return JOptionPane.showConfirmDialog(parent,
      "Overwrite existing file?\n" + file.getPath(),
      "Overwrite File",
      JOptionPane.YES_NO_OPTION,
      JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
  }

  private static void message(Component parent, String text, String title, int type)
  {
    JOptionPane.showMessageDialog(parent, text, title, type);
  }

  private static String stripExtension(String name)
  {
    if ( name == null || name.trim().length() == 0 ) return "greedy";
    int dot = name.lastIndexOf('.');
    if ( dot <= 0 ) return safeFileStem(name);
    return safeFileStem(name.substring(0, dot));
  }

  private static String safeFileStem(String value)
  {
    if ( value == null || value.trim().length() == 0 ) return "greedy";
    return value.trim().replaceAll("[^A-Za-z0-9._-]+", "_");
  }

  private static void writePipeSafeGraphOPN(PrintWriter writer, Graph graph) throws Exception
  {
    writer.println("OPN_VERSION: 0.3");
    writer.println("STRUCTURE_TYPE: OpenGraphSource");
    writer.println("OPN_SOURCE_MODEL: free-nodes-on-grid");
    writer.println("# OPN pipe-safe drawable view generated by Greedy Save As");
    writer.println("# structure = current visible graph as free source nodes");
    writer.println();
    int rows = OpenGraphGridFileNameSupport.normalizedRows(graph);
    int cols = OpenGraphGridFileNameSupport.normalizedCols(graph);
    int stepX = graph.getGridColWidth() > 0 ? graph.getGridColWidth() : 20;
    int stepY = graph.getGridRowHeight() > 0 ? graph.getGridRowHeight() : 20;

    writer.println("OPN_SOURCE_NOTATION:");
    writer.println("# key | value");
    writer.println("source_model | free-nodes-on-grid");
    writer.println("free_node_definition | label plus source-grid position plus optional edges");
    writer.println("projection_status | none unless later sections add projection metadata");
    writer.println();
    writer.println("GRID:");
    writer.println("# key | value");
    writer.println("rows | " + rows);
    writer.println("cols | " + cols);
    writer.println("cell_height | " + stepY);
    writer.println("cell_width | " + stepX);
    writer.println("height | " + rows + "  # legacy: row count, not cell height");
    writer.println("width | " + cols + "  # legacy: column count, not cell width");
    writer.println("step_x | " + stepX);
    writer.println("step_y | " + stepY);
    writer.println("origin_x | " + graph.getGridOriginX());
    writer.println("origin_y | " + graph.getGridOriginY());
    writer.println("opn_loader_margin | 0");
    writer.println();
    writeEmbeddedGreedySettings(writer, graph);

    writer.println("STRUCTURE_NODES:");
    Vector nodes = graph.getNodes();
    java.util.Map nodeToId = new java.util.HashMap();
    java.util.Map nodeToGridX = new java.util.HashMap();
    java.util.Map nodeToGridY = new java.util.HashMap();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      String id = "n" + i;
      nodeToId.put(node, id);
      int gx = OpenGraphGridFileNameSupport.gridX(graph, node);
      int gy = OpenGraphGridFileNameSupport.gridY(graph, node);
      nodeToGridX.put(node, Integer.valueOf(gx));
      nodeToGridY.put(node, Integer.valueOf(gy));
      writer.println(id + "|" + pipeSafe(node.getLabel()) + "|" + gx + "|" + gy + "|free-source-node");
    }

    writer.println();
    writer.println("STRUCTURE_EDGES:");
    Vector edges = graph.getEdges();
    for ( int i=0; i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      String from = (String)nodeToId.get((Node)edge.getStartNode());
      String to = (String)nodeToId.get((Node)edge.getEndNode());
      if ( from != null && to != null ) writer.println(from + "|" + to);
    }
    writer.println();
    writer.println("FREE_NODES:");
    writer.println("# id | label | source_x | source_y | x_line | y_line | slash_diag | backslash_diag | kind");
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      String id = (String)nodeToId.get(node);
      int gx = ((Integer)nodeToGridX.get(node)).intValue();
      int gy = ((Integer)nodeToGridY.get(node)).intValue();
      writer.println(id + "|" + pipeSafe(node.getLabel()) + "|" + gx + "|" + gy + "|" + gx + "|" + gy + "|" + (gx + gy) + "|" + (gx - gy) + "|free-source-node");
    }
    writer.println();
    writer.println("END_STRUCTURE:");
  }

  private static void writeEmbeddedGreedySettings(PrintWriter writer, Graph graph)
  {
    if ( graph == null || !graph.hasGreedySettingsSpecText() ) return;
    writer.println("GREEDY_SETTINGS_YAML:");
    writer.println("# yaml | line");
    BufferedReader reader = new BufferedReader(new StringReader(graph.getGreedySettingsSpecText()));
    try
    {
      String line;
      while ( (line = reader.readLine()) != null ) writer.println("yaml | " + yamlLineSafe(line));
    }
    catch ( IOException ignored ) {}
    writer.println("END_GREEDY_SETTINGS_YAML:");
    writer.println();
  }

  private static String yamlLineSafe(String value)
  {
    if ( value == null ) return "";
    return value.replace('|', '/').replace('\r', ' ').replace('\n', ' ');
  }

  private static String pipeSafe(String value)
  {
    if ( value == null ) return "";
    return value.replace('|', '/').replace('\r', ' ').replace('\n', ' ').trim();
  }
}
