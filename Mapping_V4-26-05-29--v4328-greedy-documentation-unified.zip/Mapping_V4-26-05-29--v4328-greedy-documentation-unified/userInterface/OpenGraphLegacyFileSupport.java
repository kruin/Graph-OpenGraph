package userInterface;

import javax.swing.*;
import java.awt.Component;
import java.io.File;
import java.io.IOException;

/**
 * Offers a safe cleanup path after saving a legacy file under a new grid-tagged name.
 *
 * Legacy here means: the input filename had no gridH...W... tag.  After a successful
 * save to a grid-tagged filename, the old source file can be renamed to .oldgraph
 * or .oldopn instead of being deleted.
 */
public final class OpenGraphLegacyFileSupport
{
  private OpenGraphLegacyFileSupport() {}

  public static void offerRenameAfterGridSave(Component parent, String sourcePath, File savedFile)
  {
    if ( sourcePath == null || sourcePath.trim().length() == 0 || savedFile == null ) return;

    File sourceFile = new File(sourcePath.trim());
    if ( !sourceFile.exists() || !sourceFile.isFile() ) return;

    try
    {
      sourceFile = sourceFile.getCanonicalFile();
      savedFile = savedFile.getCanonicalFile();
    }
    catch ( IOException ioe )
    {
      return;
    }

    if ( sourceFile.equals(savedFile) ) return;
    if ( OpenGraphGridFileNameSupport.hasGridTag(sourceFile) ) return;
    if ( !OpenGraphGridFileNameSupport.hasGridTag(savedFile) ) return;

    String sourceExt = extension(sourceFile);
    String savedExt = extension(savedFile);
    if ( sourceExt.length() == 0 || !sourceExt.equalsIgnoreCase(savedExt) ) return;
    if ( !sourceExt.equalsIgnoreCase("graph") && !sourceExt.equalsIgnoreCase("opn") ) return;

    File oldFile = uniqueOldFile(sourceFile, sourceExt);
    if ( oldFile == null ) return;

    String action = "Rename old file to " + oldFile.getName();
    Object[] options = new Object[] { "Keep old file", action, "Cancel" };
    int choice = JOptionPane.showOptionDialog(parent,
      "The input file had no grid name.\n\n" +
      "New grid-tagged file was saved as:\n" + savedFile.getPath() + "\n\n" +
      "Old legacy file:\n" + sourceFile.getPath() + "\n\n" +
      "Rename the old file to:\n" + oldFile.getPath() + "\n\n" +
      "This does not delete the old file; it keeps it as a legacy backup.",
      "Legacy file after grid save",
      JOptionPane.DEFAULT_OPTION,
      JOptionPane.QUESTION_MESSAGE,
      null,
      options,
      options[1]);

    if ( choice != 1 ) return;

    boolean renamed = sourceFile.renameTo(oldFile);
    if ( !renamed )
    {
      JOptionPane.showMessageDialog(parent,
        "Could not rename the old legacy file.\n\n" +
        "From:\n" + sourceFile.getPath() + "\n\n" +
        "To:\n" + oldFile.getPath(),
        "Legacy rename failed",
        JOptionPane.ERROR_MESSAGE);
      return;
    }

    JOptionPane.showMessageDialog(parent,
      "Old legacy file renamed to:\n" + oldFile.getPath(),
      "Legacy file renamed",
      JOptionPane.INFORMATION_MESSAGE);
  }

  private static String extension(File file)
  {
    if ( file == null ) return "";
    String name = file.getName();
    if ( name == null ) return "";
    int dot = name.lastIndexOf('.');
    if ( dot < 0 || dot == name.length() - 1 ) return "";
    return name.substring(dot + 1).toLowerCase();
  }

  private static File uniqueOldFile(File sourceFile, String ext)
  {
    if ( sourceFile == null || ext == null ) return null;
    String name = sourceFile.getName();
    int dot = name.lastIndexOf('.');
    String base = dot > 0 ? name.substring(0, dot) : name;
    String oldExt = ext.equalsIgnoreCase("opn") ? ".oldopn" : ".oldgraph";
    File parent = sourceFile.getParentFile();
    File candidate = new File(parent, base + oldExt);
    if ( !candidate.exists() ) return candidate;
    for ( int i=1; i<1000; i++ )
    {
      candidate = new File(parent, base + "_" + i + oldExt);
      if ( !candidate.exists() ) return candidate;
    }
    return null;
  }
}
