package userInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

final class OpenGraphDialogSettingsSupport
{
  private OpenGraphDialogSettingsSupport() {}

  public static OpenGraphDialogSettingsState createDefaultsForType(int structureType)
  {
    OpenGraphDialogSettingsState state = createCommonDefaults();
    state.structureType = structureType;

    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      applyBuiltInLanguageProjectionProfile(state);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      applyBuiltInAnaphorProjectionProfile(state);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      applyBuiltInFrameProjectionProfile(state);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      applyBuiltInFunctionalTreeProjectionProfile(state);
    }
    else
    {
      applyBuiltInSimpleProjectionProfile(state);
    }

    return state;
  }

  public static OpenGraphDialogSettingsState fromProperties(Properties props)
  {
    OpenGraphDialogSettingsState state = createCommonDefaults();

    state.structureType = parseInt(props.getProperty("structure.type"), OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);

    applyBuiltInProjectionProfile(state, state.structureType);
    applyConfiguredProjectionProfile(props, state, state.structureType);
    applyConfiguredLanguageTreeOptions(props, state);

    state.structureOffsetLeft = parseInt(props.getProperty("structure.offset.left"), 2);
    state.structureOffsetRight = 0;
    state.structureOffsetTop = parseInt(props.getProperty("structure.offset.top"), 2);
    state.structureOffsetBottom = 0;

    applyConfiguredProjectionPositions(props, state, state.structureType);

    state.gridColumnWidth = parseInt(props.getProperty("grid.column.width"), 20);
    state.gridRowHeight = parseInt(props.getProperty("grid.row.height"), 20);
    state.gridMarginLeft = parseInt(props.getProperty("grid.margin.left"), 2);
    state.gridMarginRight = parseInt(props.getProperty("grid.margin.right"), 2);
    state.gridMarginTop = parseInt(props.getProperty("grid.margin.top"), 2);
    state.gridMarginBottom = parseInt(props.getProperty("grid.margin.bottom"), 2);

    state.gridMode = parseInt(props.getProperty("grid.mode"), OpenGraphGridSettings.MODE_FIT_CONTENT);
    state.fitScope = parseInt(props.getProperty("grid.fit.scope"),
                              OpenGraphGridSettings.SCOPE_STRUCTURE_PROJECTIONS_AND_LABELS);

    return state;
  }

  public static void applyPostLoadRules(OpenGraphDialogSettingsState state)
  {
    if ( state.structureType < OpenGraphDialog.STRUCTURE_SIMPLE_TREE ||
         state.structureType > OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      state.structureType = OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    }
  }

  public static Properties loadPropertiesIfExists(String path) throws IOException
  {
    File file = new File(path);
    if ( !file.exists() )
    {
      return null;
    }

    Properties props = new Properties();
    try ( FileInputStream in = new FileInputStream(file) )
    {
      props.load(in);
    }
    return props;
  }

  public static void saveProperties(String path, Properties props, String comment) throws IOException
  {
    File file = new File(path);
    File parent = file.getParentFile();
    if ( parent != null && !parent.exists() )
    {
      parent.mkdirs();
    }

    try ( FileOutputStream out = new FileOutputStream(file) )
    {
      props.store(out, comment);
    }
  }

  public static Properties mergeUserProperties(Properties existing, OpenGraphDialogSettingsState state)
  {
    Properties props = new Properties();
    if ( existing != null )
    {
      props.putAll(existing);
    }

    props.setProperty("structure.type", String.valueOf(state.structureType));
    props.setProperty("projections.show", String.valueOf(state.showProjections));
    props.setProperty("projection.left.enabled", String.valueOf(state.leftProjectionEnabled));
    props.setProperty("projection.right.enabled", String.valueOf(state.rightProjectionEnabled));
    props.setProperty("projection.top.enabled", String.valueOf(state.topProjectionEnabled));
    props.setProperty("projection.bottom.enabled", String.valueOf(state.bottomProjectionEnabled));

    props.setProperty("structure.offset.left", String.valueOf(state.structureOffsetLeft));
    props.remove("structure.offset.right");
    props.setProperty("structure.offset.top", String.valueOf(state.structureOffsetTop));
    props.remove("structure.offset.bottom");

    props.setProperty("projection.left.position", String.valueOf(state.leftProjectionPosition));
    props.setProperty("projection.right.position", String.valueOf(state.rightProjectionPosition));
    props.setProperty("projection.top.position", String.valueOf(state.topProjectionPosition));
    props.setProperty("projection.bottom.position", String.valueOf(state.bottomProjectionPosition));

    props.setProperty("projection.left.caption", state.leftProjectionCaption == null ? "LEX" : state.leftProjectionCaption.trim());
    props.setProperty("projection.right.caption", state.rightProjectionCaption == null ? "SYNT" : state.rightProjectionCaption.trim());
    props.setProperty("projection.top.caption", state.topProjectionCaption == null ? "pm" : state.topProjectionCaption.trim());
    props.setProperty("projection.bottom.caption", state.bottomProjectionCaption == null ? "LF" : state.bottomProjectionCaption.trim());

    writeProjectionProfileProperties(props, state);
    writeLanguageTreeOptionProperties(props, state);

    props.setProperty("grid.column.width", String.valueOf(state.gridColumnWidth));
    props.setProperty("grid.row.height", String.valueOf(state.gridRowHeight));
    props.setProperty("grid.mode", String.valueOf(state.gridMode));
    props.setProperty("grid.fit.scope", String.valueOf(state.fitScope));
    props.setProperty("grid.margin.left", String.valueOf(state.gridMarginLeft));
    props.setProperty("grid.margin.right", String.valueOf(state.gridMarginRight));
    props.setProperty("grid.margin.top", String.valueOf(state.gridMarginTop));
    props.setProperty("grid.margin.bottom", String.valueOf(state.gridMarginBottom));

    return props;
  }

  public static String getSettingsHeader(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return "Language Tree / Phrase settings";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      return "Anaphor settings";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      return "Frame settings";
    }
    return "Simple tree settings";
  }

  public static String getSettingsSubHeader(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return "Language Tree / Phrase draws the DS tree and projects lexical material to the LEX axis. Use Frame only for role/function frames.";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      return "Simple uses only the open tree. Grid settings remain available on the separate Grid tab.";
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      return "Anaphor has its own projection profile. Defaults: left LEX, right ANA, top pm, bottom off.";
    }
    return "Frame has its own projection profile. Defaults: left LEX, right ROLE, top FRAME, bottom off.";
  }

  public static void applyConfiguredProjectionProfile(Properties props, OpenGraphDialogSettingsState state, int structureType)
  {
    if ( props == null || state == null )
    {
      return;
    }

    String profile = projectionProfileName(structureType);

    state.showProjections = parseBoolean(firstProfileNonNull(props, profile, "show", "projections.show"), state.showProjections);
    state.leftProjectionEnabled = parseBoolean(firstProfileNonNull(props, profile, "left.enabled", "projection.left.enabled", "projections.left.enabled"), state.leftProjectionEnabled);
    state.rightProjectionEnabled = parseBoolean(firstProfileNonNull(props, profile, "right.enabled", "projection.right.enabled", "projections.right.enabled"), state.rightProjectionEnabled);
    state.topProjectionEnabled = parseBoolean(firstProfileNonNull(props, profile, "top.enabled", "projection.top.enabled", "projections.top.enabled"), state.topProjectionEnabled);
    state.bottomProjectionEnabled = parseBoolean(firstProfileNonNull(props, profile, "bottom.enabled", "projection.bottom.enabled", "projections.bottom.enabled"), state.bottomProjectionEnabled);

    state.leftProjectionCaption = firstProfileNonNull(props, profile, "left.caption", "projection.left.caption", "projection.left.name");
    if ( state.leftProjectionCaption == null ) state.leftProjectionCaption = builtInLeftCaption(structureType);
    state.rightProjectionCaption = firstProfileNonNull(props, profile, "right.caption", "projection.right.caption", "projection.right.name");
    if ( state.rightProjectionCaption == null ) state.rightProjectionCaption = builtInRightCaption(structureType);
    state.topProjectionCaption = firstProfileNonNull(props, profile, "top.caption", "projection.top.caption", "projection.top.name");
    if ( state.topProjectionCaption == null ) state.topProjectionCaption = builtInTopCaption(structureType);
    state.bottomProjectionCaption = firstProfileNonNull(props, profile, "bottom.caption", "projection.bottom.caption", "projection.bottom.name");
    if ( state.bottomProjectionCaption == null ) state.bottomProjectionCaption = builtInBottomCaption(structureType);
  }

  private static void applyConfiguredLanguageTreeOptions(Properties props, OpenGraphDialogSettingsState state)
  {
    if ( state == null )
    {
      return;
    }

    if ( state.structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      String functionalProfile = projectionProfileName(OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE);
      String value = props == null ? null : firstProfileNonNull(props, functionalProfile, "layout.strategy", "functional.layout.strategy");
      state.languageTreeLayoutStrategy = value == null ? OpenGraphProjectionSettings.LAYOUT_ROLE_BOX : normalizeLayoutStrategy(value);
      state.languageTreeVerbClusterOrder = OpenGraphProjectionSettings.VERB_CLUSTER_PV_VD;
      return;
    }

    if ( props == null )
    {
      return;
    }
    String profile = projectionProfileName(OpenGraphDialog.STRUCTURE_LANGUAGE_TREE);
    String value = firstProfileNonNull(props, profile, "verbcluster.order", "language.verbcluster.order");
    state.languageTreeVerbClusterOrder = normalizeVerbClusterOrder(value);

    value = firstProfileNonNull(props, profile, "layout.strategy", "language.layout.strategy");
    state.languageTreeLayoutStrategy = normalizeLayoutStrategy(value);
  }

  private static void applyConfiguredProjectionPositions(Properties props, OpenGraphDialogSettingsState state, int structureType)
  {
    if ( props == null || state == null )
    {
      return;
    }

    String profile = projectionProfileName(structureType);
    state.leftProjectionPosition = parseInt(firstProfileNonNull(props, profile, "left.position", "projection.left.position"), state.leftProjectionPosition);
    state.rightProjectionPosition = parseInt(firstProfileNonNull(props, profile, "right.position", "projection.right.position"), state.rightProjectionPosition);
    state.topProjectionPosition = parseInt(firstProfileNonNull(props, profile, "top.position", "projection.top.position"), state.topProjectionPosition);
    state.bottomProjectionPosition = parseInt(firstProfileNonNull(props, profile, "bottom.position", "projection.bottom.position"), state.bottomProjectionPosition);
  }

  static void applyBuiltInProjectionProfile(OpenGraphDialogSettingsState state, int structureType)
  {
    if ( state == null )
    {
      return;
    }
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      applyBuiltInLanguageProjectionProfile(state);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE )
    {
      applyBuiltInAnaphorProjectionProfile(state);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_FRAME )
    {
      applyBuiltInFrameProjectionProfile(state);
    }
    else if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      applyBuiltInFunctionalTreeProjectionProfile(state);
    }
    else
    {
      applyBuiltInSimpleProjectionProfile(state);
    }
  }

  private static void applyBuiltInSimpleProjectionProfile(OpenGraphDialogSettingsState state)
  {
    state.showProjections = false;
    state.leftProjectionEnabled = false;
    state.rightProjectionEnabled = false;
    state.topProjectionEnabled = false;
    state.bottomProjectionEnabled = false;
    state.leftProjectionCaption = "";
    state.rightProjectionCaption = "";
    state.topProjectionCaption = "";
    state.bottomProjectionCaption = "";
    state.leftProjectionPosition = 2;
    state.rightProjectionPosition = 30;
    state.topProjectionPosition = 2;
    state.bottomProjectionPosition = 30;
  }

  private static void applyBuiltInLanguageProjectionProfile(OpenGraphDialogSettingsState state)
  {
    state.showProjections = true;
    state.leftProjectionEnabled = true;
    state.rightProjectionEnabled = true;
    state.topProjectionEnabled = true;
    state.bottomProjectionEnabled = true;
    state.leftProjectionCaption = "LEX";
    state.rightProjectionCaption = "SYNT";
    state.topProjectionCaption = "pm";
    state.bottomProjectionCaption = "LF";
    state.leftProjectionPosition = 2;
    state.rightProjectionPosition = 30;
    state.topProjectionPosition = 2;
    state.bottomProjectionPosition = 30;
    state.languageTreeLayoutStrategy = OpenGraphProjectionSettings.LAYOUT_PROJECTION_BOX;
  }

  private static void applyBuiltInFrameProjectionProfile(OpenGraphDialogSettingsState state)
  {
    state.showProjections = true;
    state.leftProjectionEnabled = true;
    state.rightProjectionEnabled = true;
    state.topProjectionEnabled = true;
    state.bottomProjectionEnabled = false;
    state.leftProjectionCaption = "LEX";
    state.rightProjectionCaption = "ROLE";
    state.topProjectionCaption = "FRAME";
    state.bottomProjectionCaption = "SEM";
    state.leftProjectionPosition = 2;
    state.rightProjectionPosition = 30;
    state.topProjectionPosition = 2;
    state.bottomProjectionPosition = 30;
  }


  private static void applyBuiltInFunctionalTreeProjectionProfile(OpenGraphDialogSettingsState state)
  {
    state.showProjections = true;
    state.leftProjectionEnabled = true;
    state.rightProjectionEnabled = true;
    state.topProjectionEnabled = true;
    state.bottomProjectionEnabled = false;
    state.leftProjectionCaption = "LEX";
    state.rightProjectionCaption = "ROLE";
    state.topProjectionCaption = "FT";
    state.bottomProjectionCaption = "SEM";
    state.leftProjectionPosition = 2;
    state.rightProjectionPosition = 30;
    state.topProjectionPosition = 2;
    state.bottomProjectionPosition = 30;
    state.languageTreeLayoutStrategy = OpenGraphProjectionSettings.LAYOUT_ROLE_BOX;
  }

  private static void applyBuiltInAnaphorProjectionProfile(OpenGraphDialogSettingsState state)
  {
    state.showProjections = true;
    state.leftProjectionEnabled = true;
    state.rightProjectionEnabled = true;
    state.topProjectionEnabled = true;
    state.bottomProjectionEnabled = false;
    state.leftProjectionCaption = "LEX";
    state.rightProjectionCaption = "ANA";
    state.topProjectionCaption = "pm";
    state.bottomProjectionCaption = "LF";
    state.leftProjectionPosition = 2;
    state.rightProjectionPosition = 32;
    state.topProjectionPosition = 2;
    state.bottomProjectionPosition = 34;
  }

  private static void writeLanguageTreeOptionProperties(Properties props, OpenGraphDialogSettingsState state)
  {
    if ( props == null || state == null || state.structureType != OpenGraphDialog.STRUCTURE_LANGUAGE_TREE )
    {
      return;
    }
    String order = normalizeVerbClusterOrder(state.languageTreeVerbClusterOrder);
    props.setProperty("language.verbcluster.order", order);
    props.setProperty("projection.profile.language.verbcluster.order", order);

    String strategy = normalizeLayoutStrategy(state.languageTreeLayoutStrategy);
    props.setProperty("language.layout.strategy", strategy);
    props.setProperty("projection.profile.language.layout.strategy", strategy);
  }

  private static void writeProjectionProfileProperties(Properties props, OpenGraphDialogSettingsState state)
  {
    if ( props == null || state == null )
    {
      return;
    }
    String prefix = "projection.profile." + projectionProfileName(state.structureType) + ".";
    props.setProperty(prefix + "show", String.valueOf(state.showProjections));
    props.setProperty(prefix + "left.enabled", String.valueOf(state.leftProjectionEnabled));
    props.setProperty(prefix + "right.enabled", String.valueOf(state.rightProjectionEnabled));
    props.setProperty(prefix + "top.enabled", String.valueOf(state.topProjectionEnabled));
    props.setProperty(prefix + "bottom.enabled", String.valueOf(state.bottomProjectionEnabled));
    props.setProperty(prefix + "left.caption", state.leftProjectionCaption == null ? "" : state.leftProjectionCaption.trim());
    props.setProperty(prefix + "right.caption", state.rightProjectionCaption == null ? "" : state.rightProjectionCaption.trim());
    props.setProperty(prefix + "top.caption", state.topProjectionCaption == null ? "" : state.topProjectionCaption.trim());
    props.setProperty(prefix + "bottom.caption", state.bottomProjectionCaption == null ? "" : state.bottomProjectionCaption.trim());
    props.setProperty(prefix + "left.position", String.valueOf(state.leftProjectionPosition));
    props.setProperty(prefix + "right.position", String.valueOf(state.rightProjectionPosition));
    props.setProperty(prefix + "top.position", String.valueOf(state.topProjectionPosition));
    props.setProperty(prefix + "bottom.position", String.valueOf(state.bottomProjectionPosition));
  }

  static String projectionProfileName(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ) return "language";
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "frame";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "functional";
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ) return "anaphor";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "simple";
    return "default";
  }

  private static String firstProfileNonNull(Properties props, String profile, String suffix, String fallbackKey)
  {
    String value = props.getProperty("projection.profile." + profile + "." + suffix);
    if ( value != null ) return value;
    value = props.getProperty("projection.profile.default." + suffix);
    if ( value != null ) return value;
    return fallbackKey == null ? null : props.getProperty(fallbackKey);
  }

  private static String firstProfileNonNull(Properties props, String profile, String suffix, String fallbackKey1, String fallbackKey2)
  {
    String value = firstProfileNonNull(props, profile, suffix, fallbackKey1);
    if ( value != null ) return value;
    return fallbackKey2 == null ? null : props.getProperty(fallbackKey2);
  }

  private static String builtInLeftCaption(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "LEX";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "LEX";
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ) return "LEX";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "";
    return "LEX";
  }

  private static String builtInRightCaption(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "ROLE";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "ROLE";
    if ( structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ) return "ANA";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "";
    return "SYNT";
  }

  private static String builtInTopCaption(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "FRAME";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "FT";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "";
    return "pm";
  }

  private static String builtInBottomCaption(int structureType)
  {
    if ( structureType == OpenGraphDialog.STRUCTURE_FRAME ) return "SEM";
    if ( structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE ) return "SEM";
    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE ) return "";
    return "LF";
  }

  private static String firstNonNull(Properties props, String primaryKey, String fallbackKey)
  {
    String value = props.getProperty(primaryKey);
    if ( value != null )
    {
      return value;
    }
    return props.getProperty(fallbackKey);
  }

  private static OpenGraphDialogSettingsState createCommonDefaults()
  {
    return new OpenGraphDialogSettingsState();
  }

  static String normalizeVerbClusterOrder(String value)
  {
    return OpenGraphProjectionSettings.normalizeLanguageTreeVerbClusterOrder(value);
  }

  static String normalizeLayoutStrategy(String value)
  {
    return OpenGraphProjectionSettings.normalizeLanguageTreeLayoutStrategy(value);
  }

  private static int parseInt(String value, int fallback)
  {
    if ( value == null )
    {
      return fallback;
    }
    try
    {
      return Integer.parseInt(value.trim());
    }
    catch ( NumberFormatException nfe )
    {
      return fallback;
    }
  }

  private static boolean parseBoolean(String value, boolean fallback)
  {
    if ( value == null )
    {
      return fallback;
    }
    return "true".equalsIgnoreCase(value.trim()) || "yes".equalsIgnoreCase(value.trim());
  }
}
