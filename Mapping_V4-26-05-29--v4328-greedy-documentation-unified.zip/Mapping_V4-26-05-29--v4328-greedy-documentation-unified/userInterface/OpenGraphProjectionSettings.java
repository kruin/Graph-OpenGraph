package userInterface;

/**
 * Runtime settings for OpenGraph projection rendering.
 *
 * <p>These are kept separate from the grid settings so the layout logic can
 * decide independently whether the fitted grid should cover only the tree,
 * the tree plus projection bands, or the tree plus projection labels.</p>
 */
public class OpenGraphProjectionSettings
{
  private int structureType;
  private boolean showProjections;
  private boolean leftProjectionEnabled;
  private boolean rightProjectionEnabled;
  private boolean topProjectionEnabled;
  private boolean bottomProjectionEnabled;
  private int leftProjectionPosition;
  private int rightProjectionPosition;
  private int topProjectionPosition;
  private int bottomProjectionPosition;
  private String leftProjectionCaption;
  private String rightProjectionCaption;
  private String topProjectionCaption;
  private String bottomProjectionCaption;
  private String languageTreeZinstype;
  private String languageTreeTopicPreview;
  private String languageTreeVerbClusterOrder;
  private String languageTreeLayoutStrategy;

  public static final String ZINSTYPE_BASIS = "basis";
  public static final String ZINSTYPE_BIJZIN = "bijzin";
  public static final String ZINSTYPE_STELLEND = "stellend";
  public static final String ZINSTYPE_JA_NEE = "ja_nee";
  public static final String ZINSTYPE_WH = "wh";
  public static final String ZINSTYPE_TOPICALISATIE = "topicalisatie";

  public static final String VERB_CLUSTER_PV_VD = "pv_vd";
  public static final String VERB_CLUSTER_VD_PV = "vd_pv";

  public static final String LAYOUT_FREE_D_LITE = "free_d_lite";
  public static final String LAYOUT_NARY_COMPACT_LR = "nary_compact_lr";
  public static final String LAYOUT_PROJECTION_BOX = "projection_box";
  public static final String LAYOUT_ROLE_BOX = "role_box";

  public OpenGraphProjectionSettings()
  {
    resetToDefaults();
  }

  public OpenGraphProjectionSettings(OpenGraphProjectionSettings other)
  {
    if ( other == null )
    {
      resetToDefaults();
    }
    else
    {
      structureType = other.structureType;
      showProjections = other.showProjections;
      leftProjectionEnabled = other.leftProjectionEnabled;
      rightProjectionEnabled = other.rightProjectionEnabled;
      topProjectionEnabled = other.topProjectionEnabled;
      bottomProjectionEnabled = other.bottomProjectionEnabled;
      leftProjectionPosition = other.leftProjectionPosition;
      rightProjectionPosition = other.rightProjectionPosition;
      topProjectionPosition = other.topProjectionPosition;
      bottomProjectionPosition = other.bottomProjectionPosition;
      leftProjectionCaption = other.leftProjectionCaption;
      rightProjectionCaption = other.rightProjectionCaption;
      topProjectionCaption = other.topProjectionCaption;
      bottomProjectionCaption = other.bottomProjectionCaption;
      languageTreeZinstype = other.languageTreeZinstype;
      languageTreeTopicPreview = other.languageTreeTopicPreview;
      languageTreeVerbClusterOrder = other.languageTreeVerbClusterOrder;
      languageTreeLayoutStrategy = other.languageTreeLayoutStrategy;
      normalize();
    }
  }

  public void resetToDefaults()
  {
    structureType = OpenGraphDialog.STRUCTURE_LANGUAGE_TREE;
    showProjections = true;
    leftProjectionEnabled = true;
    rightProjectionEnabled = true;
    topProjectionEnabled = true;
    bottomProjectionEnabled = true;
    leftProjectionPosition = 2;
    rightProjectionPosition = 30;
    topProjectionPosition = 2;
    bottomProjectionPosition = 30;
    leftProjectionCaption = "LEX";
    rightProjectionCaption = "SYNT";
    topProjectionCaption = "pm";
    bottomProjectionCaption = "LF";
    languageTreeZinstype = ZINSTYPE_BASIS;
    languageTreeTopicPreview = "";
    languageTreeVerbClusterOrder = VERB_CLUSTER_PV_VD;
    languageTreeLayoutStrategy = LAYOUT_PROJECTION_BOX;
    normalize();
  }

  public OpenGraphProjectionSettings copy()
  {
    return new OpenGraphProjectionSettings(this);
  }

  public void normalize()
  {
    if ( structureType < OpenGraphDialog.STRUCTURE_SIMPLE_TREE ||
         structureType > OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE )
    {
      structureType = OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE;
    }

    if ( structureType == OpenGraphDialog.STRUCTURE_SIMPLE_TREE )
    {
      showProjections = false;
      leftProjectionEnabled = false;
      rightProjectionEnabled = false;
      topProjectionEnabled = false;
      bottomProjectionEnabled = false;
    }

    leftProjectionCaption = normalizeProjectionCaption(leftProjectionCaption, "LEX");
    rightProjectionCaption = normalizeProjectionCaption(rightProjectionCaption, "SYNT");
    topProjectionCaption = normalizeProjectionCaption(topProjectionCaption, "pm");
    bottomProjectionCaption = normalizeProjectionCaption(bottomProjectionCaption, "LF");

    languageTreeZinstype = normalizeLanguageTreeZinstype(languageTreeZinstype);
    languageTreeVerbClusterOrder = normalizeLanguageTreeVerbClusterOrder(languageTreeVerbClusterOrder);
    languageTreeLayoutStrategy = normalizeLanguageTreeLayoutStrategy(languageTreeLayoutStrategy);
    if ( languageTreeTopicPreview == null )
    {
      languageTreeTopicPreview = "";
    }
    else
    {
      languageTreeTopicPreview = languageTreeTopicPreview.trim();
    }
  }

  public boolean isLexicalProjectionActive()
  {
    return isProjectionCapableStructureType(structureType) && showProjections &&
           (leftProjectionEnabled || rightProjectionEnabled || topProjectionEnabled || bottomProjectionEnabled);
  }

  public static boolean isProjectionCapableStructureType(int structureType)
  {
    return structureType == OpenGraphDialog.STRUCTURE_LANGUAGE_TREE ||
           structureType == OpenGraphDialog.STRUCTURE_ANAPHOR_TREE ||
           structureType == OpenGraphDialog.STRUCTURE_FRAME ||
           structureType == OpenGraphDialog.STRUCTURE_FUNCTIONAL_TREE;
  }

  public int getStructureType() { return structureType; }
  public void setStructureType(int structureType) { this.structureType = structureType; normalize(); }

  public boolean getShowProjections() { return showProjections; }
  public void setShowProjections(boolean showProjections) { this.showProjections = showProjections; normalize(); }

  public boolean getLeftProjectionEnabled() { return leftProjectionEnabled; }
  public void setLeftProjectionEnabled(boolean leftProjectionEnabled) { this.leftProjectionEnabled = leftProjectionEnabled; normalize(); }

  public boolean getRightProjectionEnabled() { return rightProjectionEnabled; }
  public void setRightProjectionEnabled(boolean rightProjectionEnabled) { this.rightProjectionEnabled = rightProjectionEnabled; normalize(); }

  public boolean getTopProjectionEnabled() { return topProjectionEnabled; }
  public void setTopProjectionEnabled(boolean topProjectionEnabled) { this.topProjectionEnabled = topProjectionEnabled; normalize(); }

  public boolean getBottomProjectionEnabled() { return bottomProjectionEnabled; }
  public void setBottomProjectionEnabled(boolean bottomProjectionEnabled) { this.bottomProjectionEnabled = bottomProjectionEnabled; normalize(); }

  public int getLeftProjectionPosition() { return leftProjectionPosition; }
  public void setLeftProjectionPosition(int leftProjectionPosition) { this.leftProjectionPosition = leftProjectionPosition; }

  public int getRightProjectionPosition() { return rightProjectionPosition; }
  public void setRightProjectionPosition(int rightProjectionPosition) { this.rightProjectionPosition = rightProjectionPosition; }

  public int getTopProjectionPosition() { return topProjectionPosition; }
  public void setTopProjectionPosition(int topProjectionPosition) { this.topProjectionPosition = topProjectionPosition; }

  public int getBottomProjectionPosition() { return bottomProjectionPosition; }
  public void setBottomProjectionPosition(int bottomProjectionPosition) { this.bottomProjectionPosition = bottomProjectionPosition; }

  public String getLeftProjectionCaption() { return normalizeProjectionCaption(leftProjectionCaption, "LEX"); }
  public void setLeftProjectionCaption(String caption) { leftProjectionCaption = normalizeProjectionCaption(caption, "LEX"); }

  public String getRightProjectionCaption() { return normalizeProjectionCaption(rightProjectionCaption, "SYNT"); }
  public void setRightProjectionCaption(String caption) { rightProjectionCaption = normalizeProjectionCaption(caption, "SYNT"); }

  public String getTopProjectionCaption() { return normalizeProjectionCaption(topProjectionCaption, "pm"); }
  public void setTopProjectionCaption(String caption) { topProjectionCaption = normalizeProjectionCaption(caption, "pm"); }

  public String getBottomProjectionCaption() { return normalizeProjectionCaption(bottomProjectionCaption, "LF"); }
  public void setBottomProjectionCaption(String caption) { bottomProjectionCaption = normalizeProjectionCaption(caption, "LF"); }

  public String getLanguageTreeZinstype() { return normalizeLanguageTreeZinstype(languageTreeZinstype); }
  public void setLanguageTreeZinstype(String languageTreeZinstype)
  {
    this.languageTreeZinstype = normalizeLanguageTreeZinstype(languageTreeZinstype);
  }

  public String getLanguageTreeTopicPreview() { return languageTreeTopicPreview == null ? "" : languageTreeTopicPreview.trim(); }
  public void setLanguageTreeTopicPreview(String topicPreview)
  {
    languageTreeTopicPreview = topicPreview == null ? "" : topicPreview.trim();
  }

  public String getLanguageTreeVerbClusterOrder()
  {
    return normalizeLanguageTreeVerbClusterOrder(languageTreeVerbClusterOrder);
  }

  public void setLanguageTreeVerbClusterOrder(String order)
  {
    languageTreeVerbClusterOrder = normalizeLanguageTreeVerbClusterOrder(order);
  }


  public String getLanguageTreeLayoutStrategy()
  {
    return normalizeLanguageTreeLayoutStrategy(languageTreeLayoutStrategy);
  }

  public void setLanguageTreeLayoutStrategy(String strategy)
  {
    languageTreeLayoutStrategy = normalizeLanguageTreeLayoutStrategy(strategy);
  }

  public String getLanguageTreeLayoutStrategyDisplayName()
  {
    if ( LAYOUT_NARY_COMPACT_LR.equals(getLanguageTreeLayoutStrategy()) )
    {
      return "n-binair compact LR/RL";
    }
    if ( LAYOUT_PROJECTION_BOX.equals(getLanguageTreeLayoutStrategy()) ) return "projection_box";
    if ( LAYOUT_ROLE_BOX.equals(getLanguageTreeLayoutStrategy()) ) return "role_box";
    return "D-lite";
  }

  public String getLanguageTreeVerbClusterDisplayName()
  {
    if ( VERB_CLUSTER_VD_PV.equals(getLanguageTreeVerbClusterOrder()) )
    {
      return "VD-pv";
    }
    return "pv-VD";
  }

  public String getLanguageTreeZinstypeDisplayName()
  {
    String zinstype = getLanguageTreeZinstype();
    if ( ZINSTYPE_BIJZIN.equals(zinstype) ) return "Bijzin";
    if ( ZINSTYPE_STELLEND.equals(zinstype) ) return "Stellend";
    if ( ZINSTYPE_JA_NEE.equals(zinstype) ) return "Ja/nee-vraag";
    if ( ZINSTYPE_WH.equals(zinstype) ) return "WH-vraag";
    if ( ZINSTYPE_TOPICALISATIE.equals(zinstype) ) return "Topicalisatie";
    return "Basis";
  }

  public String[] getLanguageTreeZinstypeRulePreviewLines()
  {
    String zinstype = getLanguageTreeZinstype();
    if ( ZINSTYPE_BIJZIN.equals(zinstype) )
    {
      return new String[] { "slot0 = C", "slot1 = leeg", "pv blijft in basispositie" };
    }
    if ( ZINSTYPE_STELLEND.equals(zinstype) )
    {
      return new String[] { "slot1 = topic/subject", "pv = direct na slot1", "rest = DS-volgorde" };
    }
    if ( ZINSTYPE_JA_NEE.equals(zinstype) )
    {
      return new String[] { "slot0 = leeg", "slot1 = leeg", "pv = eerste positie" };
    }
    if ( ZINSTYPE_WH.equals(zinstype) )
    {
      return new String[] { "slot1 = WH", "pv = direct na slot1", "rest = DS-volgorde" };
    }
    if ( ZINSTYPE_TOPICALISATIE.equals(zinstype) )
    {
      String topic = getLanguageTreeTopicPreview();
      if ( topic.length() > 0 )
      {
        return new String[] { "slot1 = " + topic, "pv = direct na slot1", "rest = DS-volgorde zonder topic/pv" };
      }
      return new String[] { "slot1 = geselecteerde categoriale knoop", "LEX-label = gebundelde frase", "pv = direct na slot1" };
    }
    return new String[] { "geen verplaatsing", "LEX-as = DS-basisvolgorde" };
  }

  public static String normalizeProjectionCaption(String value, String fallback)
  {
    String result = value == null ? "" : value.trim();
    if ( result.length() == 0 )
    {
      result = fallback == null ? "" : fallback.trim();
    }
    return result;
  }


  public static String normalizeLanguageTreeVerbClusterOrder(String value)
  {
    if ( value == null ) return VERB_CLUSTER_PV_VD;
    String v = value.trim().toLowerCase();
    if ( v.equals("vd_pv") || v.equals("vd-pv") || v.equals("part-pv") ||
         v.equals("part_pv") || v.equals("gebeten heeft") )
    {
      return VERB_CLUSTER_VD_PV;
    }
    return VERB_CLUSTER_PV_VD;
  }

  public static String normalizeLanguageTreeLayoutStrategy(String value)
  {
    if ( value == null ) return LAYOUT_PROJECTION_BOX;
    String v = value.trim().toLowerCase();
    v = v.replace('-', '_').replace(' ', '_');

    if ( v.equals("free") || v.equals("d_lite") || v.equals("free_d_lite") )
    {
      return LAYOUT_FREE_D_LITE;
    }

    if ( v.equals("projection_box") || v.equals("projection_order_box") )
    {
      return LAYOUT_PROJECTION_BOX;
    }

    if ( v.equals("role_box") || v.equals("rolebox") || v.equals("fg_role_box") ||
         v.equals("functional_role_box") || v.equals("rollen_box") )
    {
      return LAYOUT_ROLE_BOX;
    }

    if ( v.equals("compact") || v.equals("lr") || v.equals("compact_lr") ||
         v.equals("nary_compact_lr") || v.equals("n_ary_compact_lr") ||
         v.equals("n_binair") || v.equals("n_binair_compact_lr") ||
         v.equals("nbinair") || v.equals("non_binary") || v.equals("nonbinary") )
    {
      return LAYOUT_NARY_COMPACT_LR;
    }

    return LAYOUT_PROJECTION_BOX;
  }

  public static String normalizeLanguageTreeZinstype(String value)
  {
    if ( value == null ) return ZINSTYPE_BASIS;
    String v = value.trim().toLowerCase();
    if ( v.equals("bijzin") ) return ZINSTYPE_BIJZIN;
    if ( v.equals("stellend") || v.equals("hoofdzin") ) return ZINSTYPE_STELLEND;
    if ( v.equals("ja/nee") || v.equals("ja-nee") || v.equals("janee") || v.equals("ja_nee") ) return ZINSTYPE_JA_NEE;
    if ( v.equals("wh") || v.equals("wh-vraag") || v.equals("vraagwoord") ) return ZINSTYPE_WH;
    if ( v.equals("topicalisatie") || v.equals("topic") ) return ZINSTYPE_TOPICALISATIE;
    return ZINSTYPE_BASIS;
  }
}
