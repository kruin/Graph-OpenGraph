OpenGraph carousel
==================

Deze map wordt gelezen door Tree > OpenGraph.

Bestanden:
- PNG/JPG/JPEG/GIF = screenshot in de carrousel.
- Gelijknamig .txt-bestand = toelichtende tekst bij die screenshot.
- README.txt = deze uitleg.

Volgorde:
- De editor toont bestanden alfabetisch.
- De knoppen Plaats <, Plaats >, Verplaats... en Wissel... slaan de volgorde vast door de carouselmap volledig opnieuw te schrijven met 001-, 002-, 003-, ...
- Daardoor blijft een oude plaats niet als residu achter.
- Het bijbehorende .txt-bestand wordt automatisch mee hernummerd.

Editorfuncties:
- Navigatie: Eerste, <, >, Laatste, Naar...
- Beheer: Screenshot toevoegen, Verwijder, Tekst opslaan, Ververs
- Volgorde: Plaats < / Plaats >, Verplaats..., Wissel...
- Bestand: Export carousel, Import carousel
- Reminder: toont de workflow voor export en handmatige git-update.

Workflow voor een volgende zipversie:
1. Werk de carrousel bij in de app.
2. Klik Export carousel.
3. Bewaar de exportzip. Upload die zip hier mee bij je volgende verzoek, zodat de actuele carrouselstand meegenomen wordt in de volgende zipversie.
4. Git-update blijft handwerk, bijvoorbeeld:
   git add opengraph_carousel
   git commit -m "update opengraph carousel"
   git push

Import:
- Import carousel vervangt de actuele carrouselbestanden door de inhoud van een eerdere exportzip.
- Maak eerst Export carousel als je de huidige stand nog wilt bewaren.

Voorbeeld:
  001-simpele-vertakking-een-level.png
  001-simpele-vertakking-een-level.txt
