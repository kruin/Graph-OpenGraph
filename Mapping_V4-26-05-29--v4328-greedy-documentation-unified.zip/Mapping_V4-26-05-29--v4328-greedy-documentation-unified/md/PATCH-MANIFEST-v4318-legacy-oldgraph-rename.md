# PATCH MANIFEST v4318 — legacy oldgraph rename

## Files changed

- `userInterface/GraphFileActions.java`
- `userInterface/OpenTreeStructureSupport.java`
- `userInterface/OpenGraphLegacyFileSupport.java`
- `build.bat`
- `chatlog/CHANGELOG-v4318.md`
- `md/PATCH-MANIFEST-v4318-legacy-oldgraph-rename.md`

## Behavior

When a legacy input file has no grid tag in its filename and the user saves successfully under a new grid-tagged filename, OpenGraphEd offers to rename the old file instead of deleting it.

Graph files:

```text
name.graph → name.oldgraph
```

OPN files:

```text
name.opn → name.oldopn
```

If the old target name exists, OpenGraphEd proposes a numbered backup filename.

## Safety rule

No legacy file is renamed before the new grid-tagged file has been written successfully.
