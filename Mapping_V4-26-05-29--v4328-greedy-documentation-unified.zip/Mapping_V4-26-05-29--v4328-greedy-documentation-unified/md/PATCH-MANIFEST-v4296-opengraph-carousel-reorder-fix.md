# Patch manifest v4296 - OpenGraph carousel reorder fix

## Bestanden gewijzigd

- `userInterface/GraphEditorWindow.java`
- `build.bat`
- `opengraph_carousel/README.txt`
- `examples/opengraph-carousel/README.txt`
- `chatlog/CHANGELOG-v4296.md`

## Functionele correctie

De carrouselvolgorde wordt niet meer in-place hernoemd. Bij verplaatsen/wisselen wordt de gewenste volgorde eerst naar een tijdelijke map geschreven; daarna worden de oude carouselafbeeldingen verwijderd en wordt de reeks opnieuw opgebouwd.

Hiermee is de fout hersteld waarbij een oude positie zichtbaar kon blijven nadat bijvoorbeeld afbeelding 7 naar positie 2 werd verplaatst.
