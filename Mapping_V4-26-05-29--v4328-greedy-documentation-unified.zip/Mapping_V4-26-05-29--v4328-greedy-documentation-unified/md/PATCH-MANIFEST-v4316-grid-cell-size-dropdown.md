# PATCH MANIFEST v4316 — grid cell size dropdown

## Samenvatting

`Set Grid Size` gebruikt nu voor de gridcelgrootte een dropdown in plaats van een automatisch ingevulde tekstwaarde.

## Reden

De automatisch afgeleide waarde, bijvoorbeeld `32,30`, kwam uit de vensterafmetingen en is niet hetzelfde als de gebruikelijke oude OpenGraphEd-gridcelgrootte. Voor oude `.graph`-bestanden is `20,20` meestal de correcte standaard.

## Gedrag

Bij het tweede `Set Grid Size`-venster:

1. `20,20` staat altijd bovenaan.
2. De huidige gridcelgrootte wordt toegevoegd als die afwijkt.
3. De venster-afgeleide waarde wordt toegevoegd als die afwijkt.

Voorbeeld:

```text
20,20  - oude standaard / legacy default
32,30  - afgeleid uit venster / fitted from window
```

## Bestandsnamen

Outputnamen blijven gebaseerd op de werkelijk ingestelde gridcelgrootte:

```text
naam_gridH20W20.graph
naam_gridH20W20.opn
naam_gridH32W30.graph
naam_gridH32W30.opn
```

## Aangepaste bestanden

```text
userInterface/GraphEditorLayoutSupport.java
build.bat
chatlog/CHANGELOG-v4316.md
md/PATCH-MANIFEST-v4316-grid-cell-size-dropdown.md
```

## Test

```text
javac compile: OK
jar build: OK
```
