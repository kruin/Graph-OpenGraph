# PATCH-MANIFEST v4305 — Greedy language consistency fix

## Samenvatting

Deze patch corrigeert de taalinstelling voor de Greedy Generator-integratie.

## Gewijzigde bestanden

```text
userInterface/GreedyGeneratorSettingsDialog.java
tools/greedy_generator_gui/greedy_generator_gui.py
chatlog/CHANGELOG-v4305.md
md/PATCH-MANIFEST-v4305-greedy-language-fix.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## Functionele wijziging

De taalinstelling `nl/en` is nu consequenter doorgevoerd:

- OpenGraphEd-instellingenvenster wisselt labels, tabs, knoppen, notities en helptekst.
- De dialoog opent in de taal die in `spec.yaml` staat.
- De externe Python-GUI ververst helptekst automatisch bij taalwijziging.
- SVG/PNG-originlabel gebruikt `node 0` bij Engelse output.
- Rapporten en metadata blijven door `output.language` gestuurd.

## Test

```text
javac compile OK
jar build OK
py greedy_generator_gui.py --generate --force-opn spec_english.yaml OK
```
