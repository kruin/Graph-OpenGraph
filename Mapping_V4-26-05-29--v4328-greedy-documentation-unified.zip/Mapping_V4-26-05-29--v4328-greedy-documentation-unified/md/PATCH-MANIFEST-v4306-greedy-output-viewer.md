# PATCH MANIFEST v4306 - Greedy output viewer

## Bestanden gewijzigd

- `userInterface/OpenGraphActions.java`
- `userInterface/GraphController.java`
- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
- `chatlog/CHANGELOG-v4306.md`
- `projectie-master-spec.md`

## Nieuwe menu-acties

```text
OpenGraph → Open Greedy Preview PNG
OpenGraph → Open Greedy Report
OpenGraph → Open Greedy Effective Spec
OpenGraph → Open Greedy Output Folder
OpenGraph → Open Greedy Manual PDF
```

## Status

Deze versie verandert de generatorregels niet. De stap maakt de gegenereerde output inspecteerbaar vanuit OpenGraphEd.
