# PATCH MANIFEST v4300 — Greedy Generator integration

## Samenvatting

OpenGraphEd krijgt een eerste directe koppeling met de Greedy Graph Generator.

## Bestanden

Aangepast:

- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java`
- `userInterface/GraphController.java`
- `userInterface/GraphFileActions.java`
- `userInterface/OpenGraphActions.java`
- `userInterface/OpenGraphEdAppInfo.java`
- `projectie-master-spec.md`
- `md/projectie-master-spec.md`
- `md/CHANGELOG.md`
- `md/INDEX.md`

Toegevoegd:

- `tools/greedy_generator_gui/`
- `sources/pdf/`
- `chatlog/CHANGELOG-v4300.md`
- `md/PATCH-MANIFEST-v4300-greedy-generator-integration.md`

## Gedrag

Nieuw onder menu `OpenGraph`:

```text
Greedy Generator
Open Greedy OPN
```

De generator blijft extern en schrijft `.opn`. OpenGraphEd laadt de `.opn` terug.
