# PATCH MANIFEST v4323 — Greedy package + OPN settings save

## Purpose

Make Greedy save/export explicit and restorable:

- Greedy restore requires either a Greedy package or an OPN document.
- Plain graph/image exports are graph/image-only and warn accordingly.

## Files changed

```text
userInterface/GraphController.java
userInterface/OpenTreeStructureSupport.java
```

## Files added

```text
userInterface/GreedySaveExportSupport.java
chatlog/CHANGELOG-v4323.md
md/PATCH-MANIFEST-v4323-greedy-package-save-opn-settings.md
```

## User-visible workflow

```text
Greedy → Greedy Settings → Genereren
[fine-tune current displayed graph]
Greedy → Save As...
```

Save choices:

```text
Greedy package (.zip)     = full restorable package
OPN document (.opn)       = graph + embedded Greedy settings
Graph only (.graph)       = graph structure only, no Greedy restore
Image only (.gif/.jpg/.jpeg) = visual only, no restore
```

## Restore rule

Use `Open Greedy OPN` for restoring a saved Greedy OPN. The embedded settings are read from `GREEDY_SETTINGS_YAML` and attached to the graph.
