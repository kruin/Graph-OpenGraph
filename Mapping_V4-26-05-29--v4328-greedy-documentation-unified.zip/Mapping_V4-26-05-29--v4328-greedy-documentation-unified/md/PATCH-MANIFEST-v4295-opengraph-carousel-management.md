# PATCH MANIFEST v4295 - OpenGraph carousel management

## Doel
Tree > OpenGraph uitbreiden van een eenvoudige uitlegcarrousel naar een beheerbare carrousel voor lesmateriaal.

## Nieuwe knoppen

Navigatie:
- Eerste
- <
- >
- Laatste
- Naar...

Beheer:
- Screenshot toevoegen
- Verwijder
- Tekst opslaan
- Ververs

Volgorde:
- Plaats <
- Plaats >
- Verplaats...
- Wissel...

## Volgorde op schijf
De volgorde wordt niet alleen intern onthouden maar op schijf vastgelegd. Bij verplaatsen of wisselen worden image/caption-paren hernoemd naar:

```text
001-naam.png
001-naam.txt
002-naam.png
002-naam.txt
```

Bestaande prefixes `01-` en `001-` worden bij hernummeren herkend en vervangen.

## Bestanden
- `userInterface/GraphEditorWindow.java`
- `opengraph_carousel/README.txt`
- `examples/opengraph-carousel/README.txt`
