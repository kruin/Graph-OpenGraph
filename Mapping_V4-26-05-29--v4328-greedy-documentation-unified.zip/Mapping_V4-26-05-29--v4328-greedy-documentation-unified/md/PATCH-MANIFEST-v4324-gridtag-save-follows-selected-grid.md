# PATCH MANIFEST v4324 — gridtag save follows selected grid

## Doel

Zorgen dat Save As-outputnamen de gekozen/actuele gridcelgrootte volgen en niet terugvallen op een oude `gridH20W20`-tag.

## Aangepaste bestanden

```text
userInterface/OpenGraphGridFileNameSupport.java
userInterface/GreedySaveExportSupport.java
userInterface/GraphFileActions.java
chatlog/CHANGELOG-v4324.md
md/PATCH-MANIFEST-v4324-gridtag-save-follows-selected-grid.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## Technische wijziging

### 1. Save-selectie bewaart expliciete gridtag

Nieuwe helper:

```text
OpenGraphGridFileNameSupport.ensureGridTagForSaveSelection(...)
```

Als de gebruiker in de save chooser zelf een naam met `gridH...W...` kiest, wordt die tag niet vervangen.

### 2. Embedded Greedy YAML volgt actuele graph

Voor Greedy OPN en Greedy package wordt de embedded YAML voor het opslaan gesynchroniseerd met de graph-gridcel:

```yaml
grid:
  step_x: <cell_width>
  step_y: <cell_height>
  height: <rows>
  width: <cols>
```

### 3. Plain graph/image gebruikt dezelfde save-regel

Ook Graph only en Image only gebruiken de save-selectievariant, zodat een expliciet gekozen gridtag niet wordt overschreven.

## Verwachte test

1. Genereer Greedy graph.
2. Kies gridcel `14,20`.
3. Kies `Greedy -> Save As...`.
4. Kies OPN of Greedy package.
5. De voorgestelde/eindnaam moet `gridH14W20` bevatten.
6. Bij OPN moet `GREEDY_SETTINGS_YAML` `step_y: 14` en `step_x: 20` bevatten.
