# PATCH MANIFEST v4310 — OPN vrije knoop bronnotatie

## Bestanden geraakt

```text
graphStructure/Graph.java
userInterface/GraphFileActions.java
userInterface/GraphEditorInfoSupport.java
userInterface/GreedyGeneratorSettingsDialog.java
userInterface/GreedyInternalGenerator.java
userInterface/OpenTreeStructureSupport.java
tools/greedy_generator_gui/greedy_generator_gui.py
md/OPN-BRONNOTATIE-VRIJE-KNOOP-v4310.md
chatlog/CHANGELOG-v4310.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## Kern

OPN v0.3 legt vrije knopen expliciet vast als bronnotatie:

```text
OPN_SOURCE_MODEL: free-nodes-on-grid
FREE_NODES:
GROWTH_ORDER:
```

`STRUCTURE_NODES` blijft de compatibele tekenlaag voor de bestaande loader.
