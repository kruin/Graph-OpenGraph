# PATCH MANIFEST v4317 — grid legacy option toggle

## Doel

Gebruiker kan de legacy-keuze `20,20` verwijderen uit het gridcelkeuzevenster.

## Aangepaste bestanden

- `userInterface/GraphEditorLayoutSupport.java`
- `build.bat`
- `chatlog/CHANGELOG-v4317.md`
- `md/PATCH-MANIFEST-v4317-grid-legacy-option-toggle.md`

## Functioneel gedrag

`Set Grid Size` toont in de tweede stap een dropdown met een checkbox:

```text
Toon legacy 20,20 optie
```

Uitgeschakeld betekent: de vaste legacy-keuze `20,20 - oude standaard / legacy default` wordt uit de dropdown gehaald. De instelling wordt bewaard via Java Preferences en kan later weer aangezet worden door dezelfde checkbox opnieuw in te schakelen.

## Status

- Compile OK.
- Jar build OK.
