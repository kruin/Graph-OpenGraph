# PATCH MANIFEST v4307 — Greedy importworkflow

## Samenvatting

v4307 voegt een expliciete OpenGraphEd-importworkflow toe voor gegenereerde Greedy-resultaten.

In eerdere versies kon de generator een `.opn` maken en direct laden. Dat blijft bestaan. Nieuw is dat de gebruiker na genereren eerst een importdialoog krijgt, waarin preview, rapport en effective spec bekeken kunnen worden voordat de `.opn` daadwerkelijk wordt geïmporteerd.

## Menu

Toegevoegd onder **OpenGraph**:

```text
Settings + Generate + Import Greedy OPN
Generate + Import Greedy OPN
```

Bestaande directe opties blijven behouden:

```text
Settings + Generate + Load Greedy OPN
Generate + Load Greedy OPN
```

## Importworkflow

De nieuwe workflow:

```text
Generate -> Result dialog -> Inspect or Import
```

De result dialog biedt:

```text
Import OPN
Preview PNG
Report
Effective Spec
Output Folder
Cancel
```

## Reden

Hiermee wordt Greedy-output behandeld als een echte OpenGraphEd-importstap:

- de generator produceert een bronresultaat;
- de gebruiker kan het resultaat inspecteren;
- de `.opn` wordt pas geladen wanneer de gebruiker expliciet importeert.

## Gewijzigde bestanden

```text
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
userInterface/GraphController.java
userInterface/OpenGraphActions.java
build.bat
```

## Build/test

```text
compile OK
jar OK
headless generator OK
```
