# PATCH MANIFEST v4313 — gridnaam-alert bij input

## Doel

Bij alle input moet zichtbaar zijn of een bestand al voldoet aan de nieuwe gridnaamconventie. Een bestaand bestand zonder `gridH...W...` in de naam mag nog geopend worden, maar de gebruiker moet expliciet gewaarschuwd worden.

## Conventie

```text
<naam>_gridH<hoogte>W<breedte>.<extensie>
```

Voorbeelden:

```text
boom_gridH24W30.graph
voorbeeld_gridH45W45.opn
```

## Gedrag

Bij laden van `.graph` of `.opn`:

1. OpenGraphEd controleert de bestandsnaam.
2. Als `gridH<hoogte>W<breedte>` ontbreekt, verschijnt een waarschuwing.
3. Het bestand wordt toch geladen.
4. Bij opnieuw opslaan wordt de gridtag automatisch aan de outputnaam toegevoegd.

## Gewijzigde bestanden

- `userInterface/GraphFileActions.java`
- `build.bat`
- `chatlog/CHANGELOG-v4313.md`
- `md/PATCH-MANIFEST-v4313-gridname-input-alert.md`
- `md/projectie-master-spec.md`

## Teststatus

- Java compile: OK
- JAR build: OK
