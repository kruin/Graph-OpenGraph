# PATCH MANIFEST v4304 — Greedy menu blank-method fix

## Context

v4303 fixed the comma-related Greedy menu descriptor crash, but its stricter reflection check also rejected an existing placeholder menu item in the Windows menu.

Problem descriptor:

```text
S,Windows,None,null,No Windows Are Open, ,true,1, 
```

The final method field is intentionally blank. The menu item is used as a disabled/placeholder entry when no graph windows are open.

## Modified files

```text
userInterface/menuAndToolBar/MenuAndToolBarBuildSupport.java
chatlog/CHANGELOG-v4304.md
md/PATCH-MANIFEST-v4304-greedy-menu-blank-method-fix.md
projectie-master-spec.md
md/projectie-master-spec.md
```

## Technical fix

The menu builder now does this:

```java
String methodName = tok.nextToken().trim();
if ( methodName.length() > 0 )
{
  method = GraphController.class.getDeclaredMethod(methodName);
}
```

So:

- blank method field → allowed, stored as `null`;
- real non-empty method field → checked;
- missing real method → clear `IllegalArgumentException`.

## Expected result

`run.bat` should start OpenGraphEd normally again.
