# PATCH MANIFEST v4308 — Greedy internal Java engine

## Toegevoegd

- `userInterface/GreedyInternalGenerator.java`
- Menu-items onder `OpenGraph`:
  - `Settings + Generate Internal + Import Greedy OPN`
  - `Generate Internal + Import Greedy OPN`
- `GraphController` routes voor interne generatie.
- `OpenGraphActions.generateInternalGreedyGeneratorDefaultOPN()`.

## Gedrag

De interne Java-route leest dezelfde `spec.yaml` als de externe generator en schrijft output in dezelfde outputmap. `.opn` wordt altijd geforceerd geschreven voor import.

## Output

- `.opn`
- `.graph` indien gekozen
- `.svg` indien gekozen
- `.png` indien gekozen
- `_report.txt` indien gekozen
- `_effective_spec.yaml` indien gekozen
- `last_generated.txt`

## Reden

Deze stap maakt de Greedy-generator minder afhankelijk van externe Python-uitvoering en bereidt volledige integratie in OpenGraphEd voor.
