# PATCH MANIFEST v4327 — Greedy package PNG/SVG + menu cleanup

## Doel

- Greedy package compleet maken met `.svg` en `.png`.
- `Greedy Settings` in het Greedy-menu hernoemen naar `Greedy Generator`.
- `Grid Settings` uit het hoofdmenu halen omdat de gridcel nu primair via de generator/gridtab en documentinstellingen loopt.

## Gewijzigde Java-bestanden

```text
userInterface/GreedySaveExportSupport.java
userInterface/GraphController.java
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
```

## Functioneel gedrag

### Greedy package

`Greedy -> Save As... -> Greedy package (.zip)` schrijft nu:

```text
<base>.opn
<base>.graph
<base>.svg
<base>.png
spec.yaml
effective_spec.yaml
<base>_report.txt
README-GREEDY-PACKAGE.txt
<base>_preview.gif   # indien beschikbaar
```

### Menu

Hoofdmenu `Greedy`:

```text
Greedy Generator
Generate Greedy Graph
Open Greedy OPN
Save As...
Greedy Tools...
```

`Grid Settings / Reapply Grid` staat nu onder `Greedy Tools...`.

## Test

- `javac`: OK.
- `jar`: OK.
