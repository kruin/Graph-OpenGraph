# PATCH-MANIFEST v4322 — Greedy generate zonder YAML, OPN bewaart instellingen

## Doel

De Greedy-workflow is document-first gemaakt binnen het menu **Greedy**.

Genereren mag geen verplichte tussenstap met `spec.yaml` meer zijn. De gebruiker moet eerst de graph zien, daarna fine-tunen, en pas daarna expliciet opslaan.

## Gedragswijziging

### Greedy Settings

- De knop `Spec opslaan` is verwijderd uit de hoofdworkflow.
- De knop `Genereren` schrijft geen `tools/greedy_generator_gui/spec.yaml` meer.
- `Genereren` leest de waarden direct uit het dialoogvenster.
- Daarna wordt de graph intern gegenereerd en direct afgebeeld in OpenGraphEd.
- Er wordt bij genereren geen `.yaml`, `.opn`, `.graph`, `.svg` of `.png` geschreven.

### Save OPN

- Als de graph uit Greedy-instellingen is gegenereerd, draagt de graph de gebruikte instellingen intern mee.
- Bij `Greedy → Save As... → OPN (.opn)` worden die instellingen in de OPN opgenomen als `GREEDY_SETTINGS_YAML`.
- Daarmee wordt de OPN het leidende documentformaat voor een opgeslagen Greedy-resultaat.

### Open Greedy OPN

- Bij het openen van een Greedy-OPN met `GREEDY_SETTINGS_YAML` worden de embedded instellingen weer op de geladen graph gezet.
- Als daarna `Greedy Settings` wordt geopend, gebruikt de dialoog de instellingen uit het actieve document, niet blind de losse `spec.yaml`.

## Aangepaste bestanden

- `userInterface/GreedyGeneratorSettingsDialog.java`
- `userInterface/GreedyInternalGenerator.java`
- `userInterface/OpenGraphActions.java`
- `userInterface/GraphController.java`
- `userInterface/OpenTreeStructureSupport.java`
- `userInterface/GraphFileActions.java`
- `graphStructure/Graph.java`

## Test

- Java compile: OK.
- JAR build: OK.
- Interne Greedy generatie vanuit in-memory spectekst: OK.
- Generated graph bevat embedded Greedy settings: OK.

## Verwachte gebruikersroute

```text
Greedy → Greedy Settings → Genereren
[fine-tune in OpenGraphEd]
Greedy → Save As... → OPN (.opn)
```

Geen YAML-tussenbestand is nodig.
