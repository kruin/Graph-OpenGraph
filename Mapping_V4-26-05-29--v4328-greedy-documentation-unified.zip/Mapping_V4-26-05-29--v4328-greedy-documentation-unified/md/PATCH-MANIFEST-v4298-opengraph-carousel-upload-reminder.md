# PATCH MANIFEST v4.29.8 — OpenGraph carousel upload reminder

## Doel

De carrousel-reminder vermeldt nu expliciet dat de exportzip hier moet worden meegeüpload bij het volgende verzoek.

## Gewijzigd

- `userInterface/GraphEditorWindow.java`
  - korte reminderregel uitgebreid;
  - `Reminder`-knoptekst uitgebreid;
  - statusmelding na carrouselwijziging uitgebreid;
  - melding na `Export carousel` uitgebreid;
  - standaardintro voor OpenGraph-carrousel uitgebreid.
- `opengraph_carousel/README.txt`
- `examples/opengraph-carousel/README.txt`
- `chatlog/CHANGELOG-v4298.md`
- `md/CHANGELOG.md`

## Remindertekst

```text
Upload die zip hier mee bij je volgende verzoek.
```

## Build

Compile-check: OK, alleen bestaande Java-waarschuwingen.
