# PATCH MANIFEST v4315 — gridcelgrootte in bestandsnaam

## Doel

Herstel de betekenis van de gridtag in outputnamen. `gridH...W...` verwijst voortaan naar de ingestelde gridcelgrootte: hoogte,breedte. Het verwijst niet naar rijen,kolommen.

## Gewijzigde bronbestanden

- `userInterface/OpenGraphGridFileNameSupport.java`
- `userInterface/GraphFileActions.java`
- `userInterface/GraphEditorLayoutSupport.java`
- `userInterface/OpenTreeStructureSupport.java`
- `userInterface/GreedyInternalGenerator.java`
- `userInterface/GreedyGeneratorSettingsDialog.java`
- `tools/greedy_generator_gui/greedy_generator_gui.py`
- `build.bat`

## Nieuwe conventie

```text
naam_gridH<celhoogte>W<celbreedte>.graph
naam_gridH<celhoogte>W<celbreedte>.opn
```

Voor oude standaardbestanden is dat meestal:

```text
gridH20W20
```

## Belangrijk onderscheid

```text
rows,cols        = aantal gridlijnen / tekenveld-dimensie
cell_height,width = afstand tussen gridknooppunten
```

Alleen `cell_height,width` hoort in de outputnaam.

## OPN GRID-sectie

Nieuwe OPN-output bevat:

```text
GRID:
rows | ...
cols | ...
cell_height | ...
cell_width | ...
height | ...  # legacy: row count, not cell height
width | ...   # legacy: column count, not cell width
step_x | ...
step_y | ...
```
