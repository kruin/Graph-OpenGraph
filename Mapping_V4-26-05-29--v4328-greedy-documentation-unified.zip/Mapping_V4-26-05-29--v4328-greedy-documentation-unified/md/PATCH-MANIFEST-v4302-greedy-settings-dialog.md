# PATCH MANIFEST v4302 — Greedy Settings inside OpenGraphEd

## Samenvatting

v4302 voegt een ingebouwde OpenGraphEd-dialoog toe voor de Greedy Generator. De gebruiker hoeft voor eenvoudige instellingen niet meer eerst de externe Python/Tkinter-GUI te openen of `spec.yaml` handmatig te bewerken.

## Nieuwe menu-items

```text
OpenGraph > Greedy Settings
OpenGraph > Settings + Generate + Load Greedy OPN
```

## Gewijzigde Java-bestanden

```text
userInterface/GraphController.java
userInterface/OpenGraphActions.java
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
```

## Nieuw Java-bestand

```text
userInterface/GreedyGeneratorSettingsDialog.java
```

## Gedrag

### Greedy Settings

Opent een Java/Swing-dialoog waarmee `tools/greedy_generator_gui/spec.yaml` wordt gelezen en herschreven.

### Settings + Generate + Load Greedy OPN

Opent dezelfde dialoog. Na opslaan wordt de bestaande headless generatorroute gebruikt:

```text
tools/greedy_generator_gui/generate_default_opn.bat
```

Daarna wordt het laatst gegenereerde `.opn`-bestand direct in OpenGraphEd geladen.

## Belangrijk ontwerpbesluit

De Python-generator blijft voorlopig de bron voor de greedy-kern. OpenGraphEd krijgt nu wel een eigen instellingenvenster. Dit is dus een tussenvorm tussen:

```text
fase 1: externe generator starten
fase 2: instellingen in OpenGraphEd
fase 3: greedy-kern volledig naar Java porten
```

## Teststatus

- Compile OK.
- Jar OK.
- Headless generator OK.
- Kliktest in Windows nodig.
