# PATCH MANIFEST v4311 — grid dimensions in names and input

## Samenvatting

v4311 maakt de grid-dimensies expliciet en reproduceerbaar:

- outputnamen bevatten altijd `gridH<height>W<width>`;
- spec input kan `grid.height` en `grid.width` bevatten;
- OPN output bevat een `GRID:`-sectie;
- OPN import leest de `GRID:`-sectie en gebruikt die voor de editorgrid.

## Aangepaste bestanden

- `userInterface/GreedyInternalGenerator.java`
- `userInterface/GreedyGeneratorSettingsDialog.java`
- `userInterface/GraphFileActions.java`
- `tools/greedy_generator_gui/greedy_generator_gui.py`
- `tools/greedy_generator_gui/spec*.yaml`
- `build.bat`
- `projectie-master-spec.md`
- `md/projectie-master-spec.md`
- `chatlog/CHANGELOG-v4311.md`

## Nieuwe specvelden

```yaml
grid:
  height: 0
  width: 0
```

Betekenis:

- `height`: aantal gridrijen;
- `width`: aantal gridkolommen;
- `0`: automatisch afleiden uit `graph.max` en `grid.margin`.

## Outputnaam

Ook bij `output.naming: short` wordt de gridtag toegevoegd:

```text
<base>_gridH45W45.opn
```

Bij `output.naming: full` blijft de volledige instellingennaam behouden en wordt de gridtag expliciet opgenomen.
