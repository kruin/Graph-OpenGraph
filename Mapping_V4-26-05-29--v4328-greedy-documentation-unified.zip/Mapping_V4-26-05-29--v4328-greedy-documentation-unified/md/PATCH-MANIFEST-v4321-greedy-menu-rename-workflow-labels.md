# PATCH MANIFEST v4321 — Greedy menu rename + workflow labels

## Basis

Gebaseerd op v4320.

## Aangepaste bestanden

- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/GreedyGeneratorSettingsDialog.java`
- `userInterface/OpenGraphActions.java`
- `userInterface/GraphController.java`
- `build.bat`
- `projectie-master-spec.md`
- `md/projectie-master-spec.md`
- `chatlog/CHANGELOG-v4321.md`

## Functionele wijziging

Het voormalige menu `OpenGraph` is hernoemd naar `Greedy`. De instructie `eerst afbeelden, fine-tunen, pas daarna opslaan` is daarmee expliciet beperkt tot de Greedy-generatorworkflow. De algemene OpenGraphEd-app krijgt geen nieuw startgedrag.

## UI-wijzigingen

Hoofdmenu:

```text
Greedy
  Greedy Settings
  Generate Greedy Graph
  Open Greedy OPN
  Grid Settings
  Save As...
  Greedy Tools...
```

Greedy-instellingen:

```text
Spec opslaan
Genereren
Annuleren
```

Engels:

```text
Save Spec
Generate
Cancel
```

## Test

- `javac`: OK.
- `jar`: OK.
- Menu descriptor-tokencontrole: OK.
