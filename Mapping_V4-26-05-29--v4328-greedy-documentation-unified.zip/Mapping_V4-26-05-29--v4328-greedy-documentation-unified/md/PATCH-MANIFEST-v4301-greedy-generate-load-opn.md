# PATCH MANIFEST v4301 — Greedy Generate + Load OPN

## Samenvatting

v4301 maakt van de eerste Greedy-integratie een directe workflow:

```text
OpenGraph > Generate + Load Greedy OPN
```

De gebruiker hoeft na het instellen van `spec.yaml` niet meer handmatig in de outputmap naar de `.opn` te zoeken.

## Gewijzigde Java-bestanden

```text
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
userInterface/GraphController.java
userInterface/OpenGraphActions.java
```

## Gewijzigde generatorbestanden

```text
tools/greedy_generator_gui/greedy_generator_gui.py
tools/greedy_generator_gui/generate_default_opn.bat
tools/greedy_generator_gui/generate_from_spec.bat
tools/greedy_generator_gui/README.md
tools/greedy_generator_gui/HANDLEIDING_GUI.md
```

## Nieuwe workflow

1. Pas `tools/greedy_generator_gui/spec.yaml` aan, eventueel via de GUI.
2. Kies in OpenGraphEd:

```text
OpenGraph > Generate + Load Greedy OPN
```

3. OpenGraphEd genereert en laadt de `.opn`.

## Status

- Fase 1b-integratie.
- Greedy-kern blijft Python.
- OpenGraphEd gebruikt `.opn` als brugformaat.
- Volledige Java-port blijft een latere stap.
