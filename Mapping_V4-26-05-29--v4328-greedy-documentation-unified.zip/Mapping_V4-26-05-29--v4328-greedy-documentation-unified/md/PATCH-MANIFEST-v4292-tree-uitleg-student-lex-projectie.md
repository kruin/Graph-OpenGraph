# PATCH MANIFEST v4292 — Tree Uitleg: studentversie, LEX-projectie

## Doel

De Tree-knop **Uitleg** inhoudelijk aanpassen voor taalkundige studenten.
Niet primair technisch uitleggen, maar vertrekken vanuit de klassieke syntactische boom:
waarom staan woorden onderaan, hoe wordt woordvolgorde gereconstrueerd, en hoe verschilt dat van OpenGraph?

## Functionele wijziging

Geen wijziging in de layout-engine of boomtekening.
Alleen de inhoud van de Uitleg-tekst is aangepast.

## Inhoudelijke kern

- De traditionele boom plaatst woorden onderaan als notatieconventie, niet omdat daar een inhoudelijke "zwaartekracht" werkt.
- De traditionele boom bouwt vertakkingen en gebruikt in varianten vaak transformaties om de uiting/woordvolgorde te reconstrueren.
- In oude notatie is `S-NP,VP` iets anders dan `S-VP,NP`; de volgorde zit direct in de lokale vertakking.
- OpenGraph bewaart een vrijere bronnotatie met knopen en takken.
- De vrije knopen creëren ruimte voor verschillende projecties rond dezelfde bronstructuur.
- De LEX-projectie toont de lexicale uitingsvolgorde; bij goede verdeling van taklengte/projectieslots kan die dezelfde volgorde opleveren als de klassieke boomnotatie.
- LEX-regels functioneren als alternatief voor transformaties: de boom hoeft niet te worden herschreven om woordvolgorde te tonen.

## Aangeraakt bestand

- `userInterface/GraphEditorWindow.java`

## Test

Compile-check: OK, met alleen de bekende Java-waarschuwing.
