# PATCH MANIFEST v4303 - Greedy menu descriptor fix

## Based on

- v4302 Greedy Settings dialog package.

## Files changed

- `userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java`
- `userInterface/menuAndToolBar/MenuAndToolBarBuildSupport.java`
- `build.bat`
- `chatlog/CHANGELOG-v4303.md`
- `md/PATCH-MANIFEST-v4303-greedy-menu-descriptor-fix.md`

## Problem

v4302 failed at startup with:

```text
NullPointerException: Cannot invoke "MenuAndToolBarAction.isCompound()" because "<parameter5>" is null
```

## Cause

The menu action catalogue uses comma-separated records. The new v4302 descriptor for:

```text
Settings + Generate + Load Greedy OPN
```

contained commas in its description field. That changed the token count and caused `createMenuAndToolbarAction` to return `null`.

## Fix

- Replaced the comma-containing description with a comma-free description.
- Added a null guard in the menu builder.
- Added a missing-method guard for reflected `GraphController` menu action methods.

## Intended result

OpenGraphEd starts normally again, and all Greedy menu entries remain available.
