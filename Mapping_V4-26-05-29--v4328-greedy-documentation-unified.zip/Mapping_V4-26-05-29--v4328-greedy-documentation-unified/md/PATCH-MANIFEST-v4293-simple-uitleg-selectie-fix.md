# PATCH MANIFEST v4293 — Simple Uitleg selectie-fix

## Doel

Corrigeren dat **Uitleg** bij **Tree = Simple** nog de uitleg van **origineel** toont.

## Kern

Simple is een boomtype zonder aparte projectielaag. Daardoor mag de headerlogica Simple niet terugvertalen naar origineel wanneer de uitleg wordt opgevraagd.

## Aanpassing

`GraphEditorWindow` houdt `lastExplicitTreeTypeSelection` bij. De Uitleg-knop gebruikt die expliciete keuze wanneer Simple geselecteerd is.

## Test

- Compile-check: `javac` op alle `.java`-bronnen.
- Verwachte UI-test: kies Tree → Simple, klik Uitleg. De titel en tekst moeten **Simple** tonen, niet **origineel**.
