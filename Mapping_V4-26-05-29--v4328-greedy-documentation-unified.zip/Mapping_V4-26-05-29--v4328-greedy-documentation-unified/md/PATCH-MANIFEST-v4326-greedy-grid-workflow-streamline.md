# PATCH MANIFEST v4326 — Greedy grid workflow streamline

## Scope

This patch corrects the Greedy workflow only. It does not change general OpenGraphEd startup behavior.

## Problem

After `Greedy Settings -> Genereren`, OpenGraphEd opened the generic OpenGraphGrid dialog. That dialog used saved/default grid values such as `20,20`, not necessarily the grid cell size from the Greedy settings that generated the graph. This made the workflow confusing and caused stale `gridH20W20` filename proposals.

## Solution

1. Display Greedy results directly in a new editor window.
2. Do not open the OpenGraphGrid dialog automatically after generation.
3. Synchronize the editor's OpenGraphGrid settings from the generated graph cell size.
4. Make `Save + Apply` in the OpenGraphGrid dialog both persist and apply settings to the current drawing.
5. Keep Save As proposals based on the active graph grid.

## Expected workflow

```text
Greedy -> Greedy Settings -> Genereren
[graph appears directly]
Greedy -> Grid Settings   # optional fine-tune
Greedy -> Save As...
```

## Grid naming rule

The output grid tag remains:

```text
gridH<row-height>W<column-width>
```

Example:

```text
step_y = 19, step_x = 21  ->  gridH19W21
row height = 17, column width = 23  ->  gridH17W23
```
