# PATCH MANIFEST v4328 — Greedy documentation unified

## Doel

Deze patch trekt de nieuwe Greedy-aanpak consequent door in menu’s, vensterteksten en documentatie.

## Centrale workflow

```text
Greedy > Greedy Generator > Genereren
fine-tune in OpenGraphEd
Greedy > Save As...
```

## Gedragslijn

- `Genereren` toont de graph direct in OpenGraphEd.
- `Genereren` schrijft geen YAML, OPN, GRAPH, SVG of PNG.
- Fine-tune gebeurt in het actieve document.
- Save/export gebeurt pas via `Greedy > Save As...`.
- Greedy package en OPN document bewaren restore-informatie.
- Graph only en Image only bewaren geen Greedy restore.

## Aangepast

### Java/menu

- Menu-descripties onder `Greedy` herschreven naar document-first workflow.
- `Greedy Generator` uitgelegd als instellingen + direct tonen, niet als opslagactie.
- `Save As...` uitgelegd als export van het huidige document.
- `Greedy Tools...` uitgelegd als fallback/inspectie.
- `Greedy Generator`-venster: tabs, notes en helptekst herschreven.
- `Output`-tab hernoemd naar `Opslaan/Export` / `Save/Export`.

### Documentatie

- `tools/greedy_generator_gui/README.md` herschreven.
- `tools/greedy_generator_gui/HANDLEIDING_GUI.md` herschreven.
- `GREEDY_GENERATOR_UITLEG_NL.pdf` opnieuw gemaakt.
- `GREEDY_GENERATOR_EXPLANATION_EN.pdf` opnieuw gemaakt.
- PDF-kopieën onder `sources/pdf/` bijgewerkt.
- `projectie-master-spec.md` bijgewerkt met Greedy Generator workflow v4328.

### Externe GUI

- Helptekst in `greedy_generator_gui.py` verduidelijkt:
  - normale OpenGraphEd-route is document-first;
  - externe Python-GUI blijft fallback/reference en kan zelfstandig bestanden schrijven.

## Test

- `javac` compile: OK.
- JAR build: OK.
- PDF-rendercontrole eerste pagina NL/EN: OK.
