# PATCH MANIFEST v4325 — gridtag save uses active grid

## Problem

After choosing a non-20,20 grid, Greedy Save As could still propose `gridH20W20`.
The chooser prefilled a stale filename from the previous document path, and save handling could interpret that stale tag as intentional.

## Solution

- Save proposals sync from the active editor grid before the chooser is shown.
- Save finalization always rewrites the grid tag from the current graph grid.
- Manual Grid Size updates both the Graph grid and the OpenGraphGrid settings cache.

## Changed files

- `userInterface/GreedySaveExportSupport.java`
- `userInterface/GraphEditorLayoutSupport.java`
