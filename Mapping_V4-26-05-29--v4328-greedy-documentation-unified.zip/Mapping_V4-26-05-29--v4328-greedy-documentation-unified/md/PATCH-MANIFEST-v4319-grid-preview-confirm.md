# PATCH MANIFEST v4319 — grid preview confirm

## Samenvatting

Deze patch voegt een visuele bevestigingsstap toe aan `Set Grid Size`.

Na keuze van een gridcelgrootte in de dropdown wordt het gekozen grid eerst getoond in de editor. Daarna bevestigt de gebruiker met `OK` of annuleert de keuze.

## Functioneel gedrag

1. Gebruiker kiest rijen,kolommen.
2. Gebruiker kiest gridcel hoogte,breedte, bijvoorbeeld `20,20`.
3. OpenGraphEd toont dat grid tijdelijk.
4. Dialoog vraagt bevestiging met `OK?`.
5. Bij OK wordt het grid definitief toegepast.
6. Bij Cancel wordt de vorige gridstatus hersteld.

## Relevantie

De legacy-optie `20,20` blijft nuttig voor oude `.graph`-bestanden, maar de gebruiker ziet nu eerst wat die keuze visueel betekent.

## Gewijzigde bronbestanden

- `userInterface/GraphEditorLayoutSupport.java`

## Buildstatus

- `javac`: OK.
- `OpenGraphEd.jar`: gebouwd.
