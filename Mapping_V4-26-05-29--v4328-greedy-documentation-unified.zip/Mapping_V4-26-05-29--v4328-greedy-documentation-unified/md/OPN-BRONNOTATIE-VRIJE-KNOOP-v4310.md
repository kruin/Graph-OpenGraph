# OPN-bronnotatie en vrije knopen — v4310

## Doel

v4310 werkt de OPN-bronnotatie verder uit. De centrale afspraak is:

```text
OPN begint met vrije knopen.
```

Een vrije knoop is geen klassieke boomknoop die al vastligt als links/rechts/onder/boven. Een vrije knoop is eerst:

```text
label + gridpositie + optionele verbindingen + optionele metadata
```

Boomlagen, projecties en taalinterpretaties zijn afgeleide lagen bovenop deze bron.

## Waarom dit belangrijk is

In traditionele boomnotatie zit veel informatie direct in de verticale boomvorm. Woorden hangen vaak onderaan en de lokale vertakking suggereert meteen een volgorde. OpenGraphEd wil juist de bronnotatie vrijer houden:

```text
vrije bronknopen → plaatsingsregels/projecties → afgeleide weergaven
```

Daarom moet OPN zichtbaar maken wat de bron is voordat LEX, SYN, LF of andere projecties worden toegepast.

## OPN v0.3

De Greedy-generator en Save OPN schrijven nu explicieter dat de bron uit vrije knopen bestaat.

Belangrijke regels:

```text
OPN_VERSION: 0.3
OPN_SOURCE_MODEL: free-nodes-on-grid
```

Daarnaast bevat een Greedy-OPN nu:

```text
OPN_SOURCE_NOTATION:
STRUCTURE_NODES:
STRUCTURE_EDGES:
FREE_NODES:
GROWTH_ORDER:
CONSTRAINTS:
END_STRUCTURE:
```

## STRUCTURE_NODES

`STRUCTURE_NODES` blijft de eenvoudige tekenlaag die de bestaande OPN-loader al begrijpt:

```text
id | label | x | y | kind
```

Voorbeeld:

```text
n000 | 0 | 20 | 20 | free-start-node
n001 | 1 | 19 | 18 | free-greedy-node
```

De `x` en `y` zijn bron-gridcoördinaten. OpenGraphEd voegt bij het laden zijn eigen marge toe en zet de knopen op gridlijnen.

## FREE_NODES

`FREE_NODES` is de nieuwe expliciete bronuitleg. Hier staat per knoop waarom het een vrije gridknoop is:

```text
id | label | model_x | model_y | source_x | source_y | x_line | y_line | slash_diag | backslash_diag | order | kind
```

Voorbeeld:

```text
n004 | 4 | 2 | -3 | 22 | 17 | 2 | -3 | -1 | 5 | 4 | generated-free-node
```

Betekenis:

| veld | betekenis |
|---|---|
| `model_x`, `model_y` | positie t.o.v. knoop 0 |
| `source_x`, `source_y` | verschoven bronpositie voor OPN: `model + MAX` |
| `x_line` | gebruikte verticale gridlijn |
| `y_line` | gebruikte horizontale gridlijn |
| `slash_diag` | `/`-diagonaal: `x + y` |
| `backslash_diag` | `\`-diagonaal: `x - y` |
| `order` | volgorde van acceptatie in de groei |
| `kind` | soort vrije knoop |

## GROWTH_ORDER

`GROWTH_ORDER` beschrijft de volgorde waarin de greedy-generator de knopen heeft geaccepteerd.

```text
order | node_id | previous | incoming_vector | accepted_as
```

Voorbeeld:

```text
7 | n007 | n006 | 3,-2 | first-valid-candidate
```

Dat betekent: knoop `n007` is na `n006` geplaatst met vector `(3,-2)` en was de eerste kandidaat die aan alle regels voldeed.

## Vrijheid

Een plaats is vrij als zij alle actieve regels respecteert. Basisregels:

```text
x uniek
y uniek
lijn kruist/raakt geen oudere lijn
geen oudere knoop op de nieuwe lijn
binnen MAX
```

Optioneel:

```text
diagonal_free = slash      → x+y uniek
diagonal_free = backslash  → x-y uniek
diagonal_free = both       → x+y en x-y uniek
```

## Wat is nog niet gedaan

v4310 maakt de OPN-bronnotatie explicieter, maar maakt Greedy nog niet tot volledig nieuw OpenGraphEd-structure-type. Dat is een latere stap.

Voor nu geldt:

```text
OPN bevat rijkere bronmetadata.
OpenGraphEd laadt de tekenbare STRUCTURE_NODES/EDGES.
Info-venster toont dat vrije-bronnotatie aanwezig is.
```
