# PATCH MANIFEST v4320 — Greedy display first, save later

## Doel

De OpenGraph-route is vereenvoudigd: eerst afbeelden in OpenGraphEd, daarna handmatig finetunen, en pas daarna opslaan in het door de gebruiker gekozen formaat.

## Belangrijkste wijziging

De normale Greedy-route is nu:

```text
OpenGraph -> Greedy Settings
OpenGraph -> Generate Greedy Graph
[fine-tune in OpenGraphEd]
OpenGraph -> Save As...
```

`Generate Greedy Graph` maakt geen importbestand dat daarna opnieuw geladen wordt. De interne Java-engine bouwt een `Graph` direct in geheugen en opent die als editorvenster.

## Menu vereenvoudigd

Het OpenGraph-menu bevat nu alleen de hoofdacties:

```text
Greedy Settings
Generate Greedy Graph
Grid Settings
FT Settings
Toggle Projections
Save As...
Greedy Tools...
```

De eerdere losse inspectie- en importopties zijn verplaatst naar `Greedy Tools...`.

## Save As

`OpenGraph -> Save As...` laat de gebruiker kiezen:

```text
Graph (.graph)
OPN (.opn)
Image (.gif/.jpg/.jpeg)
```

De huidige zichtbare/fijngestelde graph wordt opgeslagen. Er is geen reloadstap.

## Greedy Tools

`Greedy Tools...` bevat de geavanceerde/fallback-acties:

```text
External GUI
Generate External + Import
Open Output Folder
Open Preview PNG
Open Report
Open Effective Spec
Open Manual PDF
```

## Techniek

Aangepaste bestanden:

```text
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/GraphController.java
userInterface/OpenGraphActions.java
userInterface/GreedyInternalGenerator.java
userInterface/GraphFileActions.java
build.bat
```

## Test

- Java compile: OK.
- JAR build: OK.
- Interne Greedy preview-test: OK (`nodes=31`, `rows=45`, `cols=45`, `cell=20,20`).
