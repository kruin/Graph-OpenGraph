# PATCH MANIFEST v4309 — Greedy internal primary

## Doel

De Greedy-integratie is na succesvolle test van beide routes opgeschoond:

```text
interne Java-engine = standaardroute
externe Python-generator = GUI/fallback/debugroute
```

## Aangeraakte bestanden

```text
userInterface/menuAndToolBar/MenuAndToolBarControlCatalog.java
userInterface/menuAndToolBar/MenuAndToolBarStateSupport.java
userInterface/GraphController.java
chatlog/CHANGELOG-v4309.md
md/PATCH-MANIFEST-v4309-greedy-internal-primary.md
projectie-master-spec.md
```

## Menu-aanpassing

Verwijderd uit menu:

```text
Settings + Generate Internal + Import Greedy OPN
Generate Internal + Import Greedy OPN
Settings + Generate + Load Greedy OPN
Generate + Load Greedy OPN
```

Toegevoegd / behouden:

```text
Settings + Generate + Import Greedy OPN  -> interne Java-engine
Generate + Import Greedy OPN             -> interne Java-engine
Greedy Generator GUI                     -> externe GUI
Generate External + Import Greedy OPN    -> externe Python-generator
```

## Compatibiliteit

De oude Java-methodes voor de interne route blijven bestaan als alias, zodat oudere verwijzingen niet breken.

## Testadvies

1. `run`
2. `OpenGraph -> Greedy Settings`
3. `OpenGraph -> Generate + Import Greedy OPN`
4. importdialoog: Preview PNG, Report, Effective Spec, Import OPN
5. optioneel: `OpenGraph -> Generate External + Import Greedy OPN`
