# PATCH MANIFEST v4294 — OpenGraph carousel

## Summary
This patch adds a new Tree option **OpenGraph** between **origineel** and **Simple**. It shows a screenshot carousel in the editor area. The carousel is intended as a student-facing explanation layer for the OpenGraph notation: free nodes, simple branch variants, and first projections.

## UI changes
Tree order:

```text
origineel - OpenGraph - Simple - Language - Functional - Frame - Anaphor
```

OpenGraph mode:
- replaces the graph editor view with a carousel panel;
- does not draw or transform the current graph;
- keeps the current `.graph` editor state available via **origineel** and the normal Back/Undo history.

Carousel buttons:
- previous
- next
- screenshot toevoegen
- tekst opslaan
- ververs

## Carousel file format
The carousel reads screenshots from:

```text
opengraph_carousel/
```

Fallback example folder:

```text
examples/opengraph-carousel/
```

Each image may have a same-basename text file:

```text
01-simpele-vertakking-een-level.png
01-simpele-vertakking-een-level.txt
```

Supported image extensions:

```text
.png .jpg .jpeg .gif
```

## Included seed screenshots
Initial screenshots supplied in the chat are included as numbered slides. The first captions focus on:
- simple branching, one level;
- left/right branch variants;
- old notation `S-NP,VP` versus `S-VP,NP`;
- projectie naar links as bare line with copied nodes;
- projection space around a source tree.

## Source files changed
- `userInterface/GraphEditorWindow.java`
- `userInterface/modes/EditListenerPopupSupport.java`

## Compatibility
No new external libraries.
