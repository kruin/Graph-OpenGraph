# PATCH MANIFEST v4312 — algemene gridnamen en gridinput

## Doel

De grid-dimensies gelden niet alleen voor Greedy-output, maar voor alle OpenGraphEd-output.

Conventie:

```text
gridH<hoogte>W<breedte>
```

waarbij:

- `hoogte` = aantal gridrijen;
- `breedte` = aantal gridkolommen.

## Aangepast

### Bestandnamen

Gridtags worden nu algemeen toegevoegd aan outputnamen voor:

- `.graph` via File → Save Graph;
- `.gif/.jpg/.jpeg` via image save;
- `.opn` via OpenGraph → Save OPN;
- Greedy-output blijft dezelfde conventie gebruiken.

Voorbeeld:

```text
OPN_graph_gridH45W45.opn
untitled_gridH45W45.graph
voorbeeld_gridH45W45.jpg
```

### Input

Bij laden wordt een gridtag uit de bestandsnaam gelezen:

```text
*_gridH45W45.graph
*_gridH45W45.opn
```

Als de tag aanwezig is, wordt de editorgrid daarop gezet en worden de knopen op het dichtstbijzijnde gridknooppunt geplaatst.

### OPN

`Save OPN` schrijft nu ook een algemene `GRID:`-sectie:

```text
GRID:
height | 45
width | 45
step_x | 20
step_y | 20
origin_x | 0
origin_y | 0
opn_loader_margin | 0
```

De OPN-loader leest nu `opn_loader_margin`. Greedy gebruikt nog steeds marge `2`; gewone OpenGraphEd-OPN gebruikt marge `0`, zodat een save/load-ronde dezelfde gridposities bewaart.

## Gewijzigde bestanden

- `userInterface/OpenGraphGridFileNameSupport.java` nieuw
- `userInterface/GraphFileActions.java`
- `userInterface/OpenTreeStructureSupport.java`
- `md/projectie-master-spec.md`
- `chatlog/CHANGELOG-v4312.md`

## Teststatus

- Java compile: OK
- JAR build: OK
- algemene gridtag-helper: toegevoegd
- `.graph` savepad: gridtag toegevoegd
- image savepad: gridtag toegevoegd
- `.opn` savepad: gridtag toegevoegd
- OPN `GRID:`-sectie voor gewone Save OPN: toegevoegd
