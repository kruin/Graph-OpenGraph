# PATCH-MANIFEST v4.28.9 — Tree origineel en Uitleg

## Doel

De Tree-keuze in de OpenGraphEd-header uitbreiden met:

1. `origineel` als eerste optie.
2. Een knop `Uitleg` die het actuele Tree-type uitlegt.

## Functioneel gedrag

### origineel

- Staat als eerste optie in de Tree-keuzelijst.
- Herlaadt de oorspronkelijke `.graph` van schijf.
- Verwijdert het huidige OpenGraph-drawresultaat uit het editorvenster.
- Tekent zelf geen nieuwe layout.
- Zet de header terug naar de bronstatus.

### Uitleg

Toont een korte uitleg voor:

- origineel
- Simple
- Language
- Functional
- Frame
- Anaphor

## Technische wijziging

- `GraphEditorWindow`:
  - extra Tree-item `origineel` met interne waarde `0`;
  - extra knop `Uitleg` naast de Tree-keuze;
  - selectie-update toont `origineel` wanneer geen OpenGraph-projectiecontext actief is.
- `GraphController`:
  - delegatie toegevoegd: `restoreOriginalOpenGraphTree(...)`.
- `OpenGraphActions`:
  - nieuw herstelpad dat het `.graph`-bestand opnieuw laadt en tijdelijke OPN/OpenGraph-status opruimt.

## Build-test

Compileert met alleen de bestaande Java-waarschuwing over `new Integer(...)`.
