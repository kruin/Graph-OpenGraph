# PATCH MANIFEST v4314 — input gridnaam + save-voorstel

## Probleem

Bij laden van een oud bestand zonder gridnaam verscheen wel een waarschuwing, maar daarna stelde `Save Current Graph to File` nog steeds `untitled.graph` in de projectroot voor. Dat verbreekt de bedoeling van de gridnaamconventie: de gebruiker moet direct kunnen zien welke nieuwe naam bij het geopende inputbestand hoort.

Voorbeeldsituatie:

```text
input: C:\greedy4313\examples\graph\lextest.graph
fout save-voorstel: untitled.graph
gewenst voorstel: C:\greedy4313\examples\graph\lextest_gridH18W32.graph
```

## Oplossing

### 1. Alert uitgebreid

De waarschuwing bij input zonder gridnaam toont nu:

```text
Input file:
<volledig pad>

Detected file grid height,width: <hoogte>,<breedte>
Detected grid tag: gridH<hoogte>W<breedte>
Grid cell height,width: <celhoogte>,<celbreedte>
Note: most old .graph files use grid cell 20,20.

Suggested new name, in the same directory:
<zelfde map>/<oude naam>_gridH<hoogte>W<breedte>.<ext>
```

### 2. Save-voorstel uit bronbestand

`File → Save Graph` gebruikt nu:

1. het actuele `Graph.filePath`, indien aanwezig;
2. dezelfde map als de inputfile;
3. dezelfde basisnaam als de inputfile;
4. automatisch `gridH<hoogte>W<breedte>`.

Nieuwe graph zonder bronbestand blijft `untitled_gridH...W....graph` gebruiken.

### 3. Snappen naar grid

Na laden worden knopen altijd naar het actieve grid gesnapt.

- Met gridnaam: eerst grid uit bestandsnaam toepassen.
- Zonder gridnaam: file-grid gebruiken en alert tonen.

## Gewijzigde bestanden

```text
userInterface/GraphFileActions.java
build.bat
chatlog/CHANGELOG-v4314.md
md/PATCH-MANIFEST-v4314-input-gridname-save-proposal.md
```

## Testcase

```text
Open: examples/graph/lextest.graph
Alert: voorstel lextest_gridH18W32.graph
Save Graph: chooser opent in examples/graph en selecteert lextest_gridH18W32.graph
```
