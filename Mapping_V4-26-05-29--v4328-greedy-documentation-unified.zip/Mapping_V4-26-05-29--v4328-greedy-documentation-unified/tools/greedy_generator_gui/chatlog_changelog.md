# Changelog

- GUI toegevoegd met tabbladen Basis, Grid, Greedy, Output en Spec.
- Preview-canvas toegevoegd.
- Output .graph/.svg/.png/rapport/effective spec via knop.
- Volledig max-grid zichtbaar; knoop 0 centraal.

- v2.1: instelling `constraints.diagonal_free` toegevoegd: none/slash/backslash/both.
- v2.1: GUI-tab Greedy uitgebreid met DIAGONAL_FREE.
- v2.1: rapport, preview en metadata tonen diagonale vrijheid.

- v2.2: `.opn` toegevoegd als outputformaat.
- v2.2: `diagonal_free` wordt meegeschreven in OPN metadata.
- v2.2: GUI Output-tab uitgebreid met `.opn`.
