@echo off
setlocal

REM Headless generatie met opgegeven spec.
REM Gebruik: generate_from_spec.bat mijn_spec.yaml

if "%~1"=="" (
  echo FOUT: geef een specbestand op.
  echo Voorbeeld: generate_from_spec.bat spec.yaml
  exit /b 1
)

if not exist "%~1" (
  echo FOUT: specbestand niet gevonden: %~1
  exit /b 1
)

py -m pip install --quiet pyyaml pillow
py greedy_generator_gui.py --generate --force-opn "%~1"
exit /b %ERRORLEVEL%
