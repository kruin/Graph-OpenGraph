@echo off
setlocal

REM Headless generatie voor OpenGraphEd.
REM Leest spec.yaml, schrijft output\*.opn en output\last_generated.txt.

if not exist spec.yaml (
  echo FOUT: spec.yaml niet gevonden naast generate_default_opn.bat.
  exit /b 1
)

py -m pip install --quiet pyyaml pillow
py greedy_generator_gui.py --generate --force-opn spec.yaml
exit /b %ERRORLEVEL%
