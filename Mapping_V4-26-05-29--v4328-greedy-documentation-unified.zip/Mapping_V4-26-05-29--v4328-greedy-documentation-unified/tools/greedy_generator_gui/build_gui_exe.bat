@echo off
setlocal

REM Bouw Windows exe:
REM   dist\GreedyGraphGUI.exe

py -m pip install --upgrade pyinstaller pyyaml pillow
py -m PyInstaller --onefile --windowed --name GreedyGraphGUI greedy_generator_gui.py

echo.
echo Klaar indien geen fouten.
echo Exe:
echo dist\GreedyGraphGUI.exe
pause
