# Greedy Generator - OpenGraphEd workflow

## Kern

De Greedy Generator in het menu **Greedy** werkt document-eerst:

```text
Greedy > Greedy Generator > Genereren
fine-tune in OpenGraphEd
Greedy > Save As...
```

**Genereren schrijft geen bestanden.** De graph wordt direct in OpenGraphEd getoond. Daarna kan de gebruiker grid, labels, knopen, projecties of layout aanpassen. Pas bij **Save As...** wordt er bewaard of geëxporteerd.

## Menu Greedy

| menu-item | betekenis |
|---|---|
| `Greedy Generator` | instellingen kiezen en direct een graph tonen; geen YAML/OPN/GRAPH-output |
| `Generate Greedy Graph` | opnieuw genereren vanuit de huidige documentinstellingen |
| `Open Greedy OPN` | eerder opgeslagen herstelbare Greedy-OPN openen, inclusief embedded instellingen |
| `Save As...` | huidige zichtbare/fijngestelde document bewaren of exporteren |
| `Greedy Tools...` | fallback, externe Python-GUI en inspectiehulpmiddelen |

## Save As

| keuze | inhoud | Greedy restore |
|---|---|---:|
| `Greedy package (.zip)` | `.opn`, `.graph`, `spec.yaml`, `effective_spec.yaml`, report, `.svg`, `.png`, README waar beschikbaar | ja |
| `OPN document (.opn)` | graph + embedded `GREEDY_SETTINGS_YAML` | ja |
| `Graph only (.graph)` | alleen graphstructuur | nee |
| `Image only (.gif/.jpg/.jpeg)` | alleen afbeelding | nee |

Gebruik **Greedy package** voor archief en overdracht. Gebruik **OPN document** voor een compact herstelbaar Greedy-document.

## Grid en bestandsnamen

De actieve gridcel bepaalt de gridtag in outputnamen:

```text
gridH<rijhoogte>W<kolombreedte>
```

Dus:

```text
Gridstap Y = 19
Gridstap X = 21
-> space3_gridH19W21.opn
```

## YAML

YAML is geen verplicht tussentijds werkbestand meer.

- `Genereren` schrijft geen `spec.yaml`.
- Een Greedy package bevat wel een YAML/spec als exportinformatie.
- Een OPN document bevat de instellingen embedded als `GREEDY_SETTINGS_YAML`.

## Externe Python-GUI

De externe GUI in deze map blijft bestaan als fallback/reference-tool. Die kan nog zelfstandig `.graph`, `.opn`, `.svg`, `.png`, reports en specs schrijven. Vanuit OpenGraphEd staat die onder:

```text
Greedy > Greedy Tools... > External GUI
```

Voor de normale OpenGraphEd-route is de externe GUI niet nodig.
