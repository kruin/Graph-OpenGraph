@echo off
setlocal

REM Greedy Graph Generator GUI
REM Start de grafische interface.

py -m pip install --quiet pyyaml pillow

py greedy_generator_gui.py

pause
