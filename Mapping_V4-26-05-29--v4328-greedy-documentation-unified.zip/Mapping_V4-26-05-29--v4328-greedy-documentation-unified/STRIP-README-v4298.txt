Mapping V4 v4.29.8 - source strip

Wijziging:
- OpenGraph-carousel reminder noemt nu expliciet:
  Upload die zip hier mee bij je volgende verzoek.
- Dit staat in de korte reminderregel, de Reminder-knop, de exportmelding en de README's.

Build:
- Gebruik build.bat op Windows.
- Source-only zip: geen out/, dist/, .class of .jar.
