OpenGraphEd v4.28.3 source-strip

Inhoud:
- Java-bronbestanden (*.java)
- config/, examples/, help/, images/, md/, tools/
- batch-scripts voor build/run

Verwijderd uit deze strip:
- *.class
- out/
- dist/
- .build-tmp/
- ingebouwde jar-bestanden

Gebruik:
1. Pak deze zip uit in een schone map.
2. Draai build.bat.
3. Start met START-OpenGraphEd.bat of OpenGraphEd.bat.

Basis: Mapping_V4-26-05-20--v4281-frame-draw-no-jump.zip


BUILD FIX v4282:
- build.bat now quotes every Java source path in the javac @argfile.
- This fixes builds from folders whose path contains spaces, e.g. C:\V42682 strip test.


BUILD FIX v4283:
- build.bat no longer writes absolute Windows paths to the javac @argfile.
- Source paths are written as relative paths with forward slashes.
- This fixes javac interpreting backslashes in @argfiles as escape characters, e.g. C:\dir\File.java becoming C:dirFile.java.
