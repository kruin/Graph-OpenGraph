Mapping V4 v4.28.8 source strip

Patch: tree minimum child branches validation.

Rule:
- Een node mag 0 kindtakken hebben: eindknoop.
- Als een node kindtakken heeft, dan is het minimum 2.
- Een node met precies 1 kindtak wordt geweigerd vóór layout.
- Richting van de tak is hierbij irrelevant.

Build:
- Run build.bat from the project directory.
- Paths with spaces are supported.
