Source strip v4297
==================

Variant: OpenGraph carousel export/import + reminder.

Niet meegeleverd in deze source strip:
- .class
- out/
- dist/
- .build-tmp/
- .jar

Nieuw in v4297:
- Tree > OpenGraph bevat Export carousel.
- Tree > OpenGraph bevat Import carousel.
- Tree > OpenGraph bevat Reminder voor carrouselexport en handmatige git-update.
- README's voor de carrouselworkflow zijn bijgewerkt.
