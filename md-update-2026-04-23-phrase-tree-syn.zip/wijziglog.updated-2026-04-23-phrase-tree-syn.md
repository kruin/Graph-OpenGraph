# wijziglog-2026-04-23-phrase-tree-syn

## Overzicht
Deze set actualiseert de markdownbestanden na drie inhoudelijke beslissingen:
- **language tree** wordt voortaan **phrase tree**
- latere `.opn`-typen blijven niet beperkt tot phrase trees; een eerste voorzien vervolgtype is **Meta**
- **SYN slice 1** op statische phrase trees geldt nu als werkend afgerond voor de huidige fase

## Kernpunten
- terminologie in specs en implementatieplan verschuift van *language tree* naar **phrase tree**
- de eerste SYN-slice blijft beperkt tot een **statische phrase tree**
- zichtbare SYN-labels zijn tijdelijk **neutraal** gemaakt; definitieve JAN-upper/lowercase-notatie is nog niet vastgelegd
- huidige minimale werkset voor `synCategoryLabels` is: `{S, NP, VP}`
- L2 blijft buiten deze eerste statische SYN-slice
- later kunnen naast phrase-tree-OPN’s ook andere OPN-typen bestaan, waaronder **Meta**

## Bestanden

### 1. `projectie-master-spec.updated-2026-04-23-phrase-tree-syn.md`
Wijzigingen:
- terminologie aangepast van **language tree** naar **phrase tree**
- notitie toegevoegd over latere OPN-typen, waaronder **Meta**
- statussectie toegevoegd: **SYN slice 1** afgerond
- open SYN-punten expliciet samengevat

### 2. `projection-layout-implementation-plan.updated-2026-04-23-phrase-tree-syn.md`
Wijzigingen:
- terminologie aangepast naar **phrase tree**
- statusupdate aangevuld met huidige SYN-stand
- minimale werkset voor `synCategoryLabels` genoteerd als `{S, NP, VP}`

### 3. `projectielayout-en-gridgedrag.updated-2026-04-23-phrase-tree-syn.md`
Wijzigingen:
- terminologienotitie toegevoegd: **phrase tree**
- statusnotitie toegevoegd voor neutrale zichtbare SYN-labels

### 4. `l2-growth-spec-v0.2.updated-2026-04-23-phrase-tree.md`
Wijzigingen:
- terminologie verduidelijkt naar **phrase tree**
- afbakening toegevoegd dat latere OPN-typen, waaronder **Meta**, buiten deze L2-specificatie vallen

## Uitvoer
Doel van deze set is om de documentatie weer in lijn te brengen met:
- de actuele UI- en codebenaming **phrase tree**
- de huidige afgeronde status van **SYN slice 1**
- de projectlijn waarin later meerdere `.opn`-typen naast elkaar kunnen bestaan
