# projectie-master-spec

## Doel
Dit is het centrale, duurzame specificatiebestand voor het project **Projectie**.

Doel van dit bestand:
- de inhoudelijke afspraken centraal bewaren
- de actuele werktermen en structuurtypes vastleggen
- een brug vormen tussen chat-afspraken en projectbestanden
- bij toekomstige projectzips steeds meegeleverd worden

---

## 1. Kernmapping

| Richting | Label | Betekenis | Status |
|---|---|---|---|
| W / west | **LEX** | lexicale projectie | actief |
| O / oost | **SYN** | syntactische projectie | actief |
| Z / zuid | **LOG** | logische projectie (`log`, `LF`) | actief |
| N / noord | **PM** | nog te bepalen | open |

### Compacte interne notatie
```text
W = LEX
O = SYN
Z = LOG
N = PM
```

---

## 2. Deelname per projectie

### 2.1 LEX
**Omschrijving**
- phrase tree / lexicale projectie

**Deelnameregel**
- alleen **eindknopen** doen mee

**Open preciseringen**
- formele definitie van `eindknoop`
- behandeling van leestekens, lege knopen, samengestelde woorden

### 2.2 SYN
**Omschrijving**
- syntactische projectie
- rechts ook gebruikt als **syntactische notatieprojectie** in JAN-vorm

**Deelnameregel**
- voor de huidige rechterprojectie doen alleen **vertakkende categorieknooppunten** mee

**Labelregel**
- de labelinhoud wordt **berekend**
- bron is de **geordende lijst dochtercategorieën** van de vertakkende knoop
- de volgorde is **links-naar-rechts**
- de weergave volgt de geldende **JAN-hoofd-/kleinschriftconventie**

**Voorlopige categorieën**
- `S`
- `NP`
- `VP`
- `Det`

**Open preciseringen**
- formele definitie van `catknoop`
- uitbreiding van de categorielijst
- status van tussenknopen / hulpknopen
- exacte formatteringsregel van de JAN-notatie bij meer dan twee dochters

### 2.3 LOG
**Omschrijving**
- logische projectie
- `log` / `LF`

**Deelnameregel**
- alleen **logische categorieën** doen mee

**Voorlopige categorieën**
- `V = Verb`
- `S = Subject`
- `O = Object`

**Open preciseringen**
- uitbreiding van de logische categorielijst
- relatie tussen syntactische en logische labels
- status van adjuncten en operatoren

### 2.4 N / PM
**Omschrijving**
- nog te bepalen

**Status**
- open werkpunt

**Mogelijke richtingen**
- morfologische projectie
- semantische projectie
- pragmatische projectie
- informatiestructurele projectie

**Vooruitblik op OPN-typen**
- naast phrase tree wordt later ten minste ook **Meta** als afzonderlijk OPN-type voorzien

---

## 3. Structuurtype

### 3.1 Overzicht

| Type | Naam | Korte omschrijving | Status |
|---|---|---|---|
| D | **demo** | handmatig getekende boomstructuur | actief |
| L | **phrase tree** | constituent-/frasenboom met projecties LEX-SYN-LOG | actief |
| R | **rest** | groeiende structuur volgens plaatsingsregels | voorlopig / open |

### 3.2 Type D = demo
**Omschrijving**
- eenvoudige, handmatig getekende boomstructuur
- eerdere naam: `Type D simple`
- werknaam voortaan: **type demo**

**Input**
- een door de gebruiker getekende structuur (zeg: boom)

**Verwerking**
- de app zet deze om naar **opentree**
- projecties zijn beschikbaar via **toggle**

**Open punten**
- exacte definitie van de omzetting naar opentree
- precieze rol van projectietoggle bij type D

### 3.3 Type L = phrase tree
**Omschrijving**
- phrase tree
- constituent-/frasenboom
- heeft drie projecties:
  - **LEX**
  - **SYN**
  - **LOG**

**Subtype L1: getekende boom met labels**
- input is een getekende boom
- knooplabels zijn ingevuld
- ombouw gebeurt via de app
- richting: **bottom-up**, recursief
- referentie: bestaande code

**Subtype L2: groeiende boom**
- dit is expliciet een **tree / boomstructuur**
- de boom bestaat **niet vooraf**
- de boom ontstaat **stap voor stap tijdens invoer**
- het bepalende kenmerk is **groei**, niet recursie
- de invoer in **LEX-volgorde** stuurt de groei van de structuur

**Formeel kernidee**
Per volgend token uit de lineaire invoer gebeurt:

1. neem volgend token
2. zoek de **eerste open plek**
3. plaats het token op die plek
4. update structuur en open plekken

Formeel:

```text
for token in input:
    slot = first_open_slot(token)
    place(token, slot)
    update_state()
```

**Basisbegrippen**
- `GrowthState`: de huidige partiële structuur
- `OpenSlot`: een open plek waar een element geplaatst kan worden
- `slotType`: type open plek, voorlopig met vaste v0-set

**Minimale L2-v0-slottypes**
- `LEX_LEFT_EDGE`
- `VERB_FINITE`
- `DET_SLOT`
- `NOUN_SLOT`
- `VERB_PARTICIPLE`

**Selectieregel**
- een token wordt geplaatst op de **eerste open slot** waarvoor de constraints gelden
- in v0 zijn die constraints nog impliciet / hardcoded per `slotType`

**Belangrijk onderscheid t.o.v. L1**
L2 is geen afgeleide van een bestaande boom:
- geen recursieve tekenprocedure
- geen volledige structuur vooraf
- geen top-down expander van een vast schema

Maar wel:
- incrementele groei
- gestuurd door invoer
- gestuurd door geordende open slots

**Relatie met projecties**
Na voltooiing van de groei:
- **LEX** werkt op eindknopen
- **LOG** werkt op vertakkende knopen

Projecties:
- beïnvloeden de structuur niet
- worden achteraf toegevoegd
- volgen de bestaande layoutregels

**Referentie**
- formele v0-specificatie staat in: `l2-growth-spec-v0.2.md`

**Open punten**
- formele definitie van L1-ombouw
- verdere formalisering van constraints per slot
- dynamische slotcreatie
- meerdere zinstypen
- relatie tussen L1 en L2: zelfde doelformaat of niet?

### 3.4 Type R = rest
**Omschrijving**
- restcategorie / nog nader te bepalen
- `R` kan een **tree** zijn, maar ook een **andere structuur**
- `R` kan zowel **groeiend** als **getekend** zijn

**Huidige werkdefinitie**
- `R` is voorlopig een verzameltype voor structuren die niet netjes onder `D` of `L` vallen
- de precieze afbakening is nog open

**Voorlopige subtypen**
- **R1** = tree, getekend
- **R2** = tree, groeiend
- **R3** = niet-tree, getekend
- **R4** = niet-tree, groeiend

**Belangrijk onderscheid t.o.v. L2**
- **L2** is altijd een **phrase tree / boom**
- bij **L2** is **groei** het bepalende kenmerk
- **R** hoeft geen boom te zijn
- **R** kan zowel een groeiende als een getekende structuur zijn
- **R2** is een groeiende tree binnen restcategorie `R`, niet automatisch een phrase tree

**Open punten**
- precieze formele definitie van `R`
- of `R` werkelijk een resttype blijft of later wordt opgesplitst
- welke niet-boomstructuren hieronder vallen
- welke groeiregels of omzetregels voor `R` gelden

---

## 4. Terminologie

### Werktermen
- **eindknoop**: terminale knoop in de boomstructuur; exacte definitie nog vast te leggen
- **catknoop**: knoop die een syntactische categorie draagt; exacte definitie nog vast te leggen
- **logische categorie**: knoop of label op logisch niveau; exacte definitie nog vast te leggen
- **GrowthState**: de huidige partiële L2-structuur met ten minste een root en een geordende lijst open slots
- **OpenSlot**: een nog onbezette plaats in de groeiende L2-boom waarop een token geplaatst kan worden
- **slotType**: het type open plek dat bepaalt welke plaatsingsregel voorlopig van toepassing is

---

## 5. Projectieregels

### Algemene regel
Elke projectie selecteert alleen de knopen die volgens haar eigen deelnameregel zijn toegestaan.

### Huidige stand
- **LEX** selecteert eindknopen
- **SYN** selecteert vertakkende categorieknooppunten en berekent labels uit geordende dochtercategorieën
- **LOG** selecteert logische categorieën
- **N** nog niet vastgelegd

---

## 6. Projectielayout en gridgedrag

### 6.1 Doel
Deze sectie legt vast hoe projectieknopen en projectielabels worden geplaatst ten opzichte van de bronstructuur en het grid.

### 6.2 Hoofdregel
Het **grid blijft onveranderd** wanneer projecties worden toegevoegd.

Dat betekent:
- projectieknopen vergroten het grid niet
- projectielabels vergroten het grid niet
- de bronstructuur bepaalt de gridgrenzen
- extra ruimte voor projectieknopen en projectielabels komt uit **render-/margeruimte**, niet uit gridvergroting

### 6.3 Scheiding tussen grid en rendering
Er wordt onderscheid gemaakt tussen:

#### 1. Structuurgrid
- bedoeld voor de bronstructuur
- bepaalt de vaste gridafmetingen

#### 2. Renderruimte
- extra tekenruimte buiten het grid
- bedoeld voor projectieknopen en projectielabels
- mag automatisch meegroeien zonder wijziging van het grid zelf

### 6.4 Huidige projecties in layout
#### LEX
- standaardrichting: **links**
- grijpt aan op: **eindknopen**
- labelbron: label van de bronknoop
- huidige transfermodus: **copy**

#### LOG
- standaardrichting: **onder**
- grijpt aan op: **vertakkende knopen / P-knooppunten**
- labelbron: label van de bronknoop
- huidige transfermodus: **copy**
- in de **eerste implementatieslice** alleen te gebruiken wanneer de logische labelinhoud al expliciet op de bronstructuur aanwezig is
- automatische afleiding van logische rollen valt buiten die eerste slice

#### SYN
- standaardrichting: **rechts**
- grijpt aan op: **vertakkende categorieknooppunten**
- labelinhoud wordt **berekend**
- labelbron: **geordende dochtercategorieën van de bronknoop**
- huidige transfermodus: **computed**
- notatie volgt de **JAN-hoofd-/kleinschriftconventie**

### 6.5 Richtingen
Voor alle projecties moet configuratie mogelijk zijn voor vier richtingen:
- links
- rechts
- boven
- onder

### 6.6 Labelregels per richting
#### Links
- label staat **outwards**
- het label sluit aan op de **linker gridrand**
- tekst blijft voorlopig horizontaal

#### Rechts
- label staat **outwards**
- het label sluit aan op de **rechter gridrand**
- tekst blijft voorlopig horizontaal

#### Boven
- label staat **outwards**
- het label sluit aan op de **bovenste gridrand**
- tekstoriëntatie is later configureerbaar

#### Onder
- label staat **outwards**
- het label sluit aan op de **onderste gridrand**
- labeltekst loopt **naar beneden**, dus niet horizontaal

### 6.7 Projectieknooppunten
- projectieknooppunten zijn zichtbaar
- projectieknooppunten mogen buiten het bron-grid liggen
- projectieknooppunten worden via een projectielijn verbonden met hun bronknoop
- projectieknooppunten veranderen de gridgrootte niet

### 6.8 Labeltransfer
Per projectie moet configureerbaar zijn:
- **copy**
- **move**
- later eventueel: **computed**

Huidige default:
- LEX: `copy`
- LOG: `copy`
- SYN: `computed`

### 6.9 Reserve voor latere uitbreiding
Later moet ondersteuning mogelijk zijn voor:
- berekende SYN-projectie
- labelmaat-gevoelige render margins
- verschillende offsets per projectie
- verschillende offsets per richting
- eventuele grid-aanpassing als afzonderlijke, expliciet instelbare modus

---

## 7. Concrete app-config keys voor projectielayout

Deze sectie zet de projectieregels om in concrete app-config keys, aansluitend op de bestaande projectiespecificatie en de vastgelegde regels voor projectielayout en gridgedrag.

### 7.1 YAML-config
```yaml
projection_layout:
  grid:
    resize_mode: fixed
    include_source_structure_in_bounds: true
    include_projection_nodes_in_bounds: false
    include_projection_labels_in_bounds: false

  render_margin:
    enabled: true
    mode: auto
    include_projection_nodes: true
    include_projection_labels: true

  projections:
    lex:
      enabled: true
      direction: left
      attach_to: terminal_node
      label_transfer: copy
      label_source: source_node_label

    log:
      enabled: true
      direction: down
      attach_to: branching_node
      label_transfer: copy
      label_source: source_node_label

    syn:
      enabled: false
      direction: right
      attach_to: branching_node
      label_transfer: computed
      label_source: ordered_child_categories

  directions:
    left:
      axis: horizontal
      sign: negative
      node_side: outside_grid
      label_anchor: grid_outward
      text_orientation: horizontal

    right:
      axis: horizontal
      sign: positive
      node_side: outside_grid
      label_anchor: grid_outward
      text_orientation: horizontal

    up:
      axis: vertical
      sign: negative
      node_side: outside_grid
      label_anchor: grid_outward
      text_orientation: upward

    down:
      axis: vertical
      sign: positive
      node_side: outside_grid
      label_anchor: grid_outward
      text_orientation: downward

  nodes:
    visible: true
    use_grid_alignment: true
    allow_outside_source_grid: true
    affect_grid_resize: false

  edges:
    draw_projection_edge: true
    projection_edge_style: straight
    projection_edge_direction: source_to_projection

  labels:
    source:
      keep_visible_when_transfer_is_copy: true
      keep_visible_when_transfer_is_move: false

    projection:
      enabled: true
      affect_grid_resize: false
      may_extend_outside_grid: true

    left:
      anchor_rule: touches_left_grid_edge_outward
      alignment_rule: label_box_right_touches_grid

    right:
      anchor_rule: touches_right_grid_edge_outward
      alignment_rule: label_box_left_touches_grid

    up:
      anchor_rule: touches_top_grid_edge_outward
      alignment_rule: label_box_bottom_touches_grid

    down:
      anchor_rule: touches_bottom_grid_edge_outward
      alignment_rule: label_box_top_touches_grid

  spacing:
    projection_offset_in_grid_units: 1
    label_gap_from_projection_node_in_grid_units: 0
    reserve_for_future_label_metrics: true
```

### 7.2 Korte toelichting per blok

#### `projection_layout.grid`
Regelt wat wel en niet meetelt voor de gridgrenzen. De hoofdregel blijft dat het grid niet automatisch meegroeit door projectieknopen of projectielabels.

#### `projection_layout.render_margin`
Regelt extra tekenspatie buiten het grid. Deze ruimte mag meegroeien zonder wijziging van het structuurgrid.

#### `projection_layout.projections`
Bevat projectiespecifieke defaults:
- `lex`: links, op eindknopen, labeltransfer via `copy`
- `log`: onder, op vertakkende knopen, labeltransfer via `copy`
- `syn`: nog niet actief; rechts op vertakkende categorieknooppunten, met berekende labels uit geordende dochtercategorieën

#### `projection_layout.directions`
Legt richtingseigenschappen vast voor alle vier richtingen:
- as
- tekenrichting
- positie buiten het grid
- labelankering
- tekstoriëntatie

#### `projection_layout.nodes`
Regelt zichtbaarheid en plaatsing van projectieknooppunten.

#### `projection_layout.edges`
Regelt de projectielijn tussen bronknoop en projectieknoop.

#### `projection_layout.labels`
Scheidt bronlabels van projectielabels en bevat de per-richting anker- en uitlijnregels.

#### `projection_layout.spacing`
Bevat elementaire afstandsregels en reserve voor latere labelmetriek.

### 7.3 Directe implementatiedoelen
1. Lees `projection_layout.grid.resize_mode` uit vóór elke herberekening van gridgrenzen.
2. Behandel `render_margin` apart van structurele gridberekening.
3. Laat LEX standaard op eindknopen werken en LOG standaard op vertakkende knopen.
4. Laat SYN rechts op vertakkende categorieknooppunten kunnen werken met `computed` labels uit geordende dochtercategorieën.
5. Laat labelplaatsing per richting verlopen via `label_anchor` en `text_orientation`.
6. Gebruik `label_transfer` als schakelaar tussen `copy`, `move` en `computed`.

### 7.4 Opmerking voor latere uitbreiding
Bij invoering van SYN hoeft de key-structuur niet te veranderen. Alleen de berekeningslogica achter:
- `attach_to: branching_node`
- `label_transfer: computed`
- `label_source: ordered_child_categories`

moet dan worden ingevuld, inclusief de formattering volgens de JAN-hoofd-/kleinschriftconventie.


### 7.5 Eerste implementatieslice

De eerste werkende verticale doorsnede richt zich op een **bestaande getekende boom** (`type D` / `L1`) en **nog niet** op L2-groei.

Prioriteitsvolgorde:
- eerst **projectiemodel** in `Graph`
- daarna **layout** met scheiding tussen `sourceBounds` en `renderBounds`
- daarna **rendering**
- pas daarna **opslag**, **undo/redo** en verdere UI-verfijning

In deze eerste slice geldt:
- **LEX links** is actief op eindknopen
- **SYN rechts** is actief als **computed** JAN-notatie op vertakkende categorieknooppunten
- **LOG onder** blijft beperkt tot gevallen waarin logische labelinhoud al expliciet beschikbaar is
- automatische afleiding van logische rollen valt buiten deze slice
- **L2-groei** valt buiten deze eerste slice en wordt pas later gekoppeld aan projectiegeneratie


---

## 8. Bestandsformaten

### 8.1 `.graph`
- bedoeld als **kale, JGraphEd-compatibele snapshot**
- bewaart de actuele zichtbare graaf:
  - nodes
  - edges
  - posities
  - labels
  - kleuren
  - gridinstellingen
- bevat **geen verplichte OpenSpec-semantiek**
- projecties mogen hierin alleen voorkomen voor zover ze als gewone zichtbare graph-entiteiten zijn uitgewerkt

### 8.2 `.opn`
- bedoeld als **rijker OpenSpec-formaat**
- extensie **`opn`** staat voor **open**
- de naam is bewust neutraler dan `ots`, omdat het formaat later ook andere structuren dan bomen moet kunnen dragen
- bewaart minimaal:
  - documentmetadata
  - projection layout config
  - projection specs
  - projection entries
- moet op termijn reconstructie van de OpenGraph/Open-structuur ondersteunen

### 8.3 Huidige werkafspraak
- **Save Graph** schrijft `.graph`
- **Save OPN** schrijft `.opn`
- `.graph` en `.opn` hebben dus bewust **verschillende semantiek**

---

## 9. Implementatievragen

Nog uit te werken:
- hoe projecties intern worden opgeslagen
- hoe projecties gelabeld worden in UI
- hoe projecties getoond worden links / rechts / onder / boven
- hoe projecties zich gedragen bij undo/redo
- hoe projecties meegaan in export en import
- hoe projecties omgaan met ontbrekende labels
- hoe `render_margin` en `grid.resize_mode` technisch van elkaar gescheiden blijven in layoutberekening
- hoe richting-specifieke tekstoriëntatie exact wordt gemodelleerd, vooral voor **onder** en later **boven**
- hoe de JAN-hoofd-/kleinschriftconventie voor SYN technisch wordt geformatteerd
- hoe geordende dochtercategorieën robuust uit de bestaande boomorde worden afgeleid voor SYN
- hoe `GrowthState`, `OpenSlot` en `slotType` intern worden gemodelleerd voor L2
- hoe open slots geordend en geüpdatet worden tijdens L2-groei
- hoe L2-groei wordt gekoppeld aan projectiegeneratie ná voltooiing van de structuur

---

## 10. Beslispunten

Open:
- invulling van **N / noord**
- formele definitie van `eindknoop`
- formele definitie van `catknoop`
- formele definitie van logische categorie
- definitieve lijst SYN-categorieën
- definitieve lijst LOG-categorieën
- exacte semantiek van `move` versus `copy` bij labeltransfer in de UI
- precieze JAN-hoofd-/kleinschriftconventie voor SYN-notatie
- gedrag van SYN-notatie bij meer dan twee dochters

---


## 10A. Status SYN slice 1

De huidige statische SYN-slice op phrase trees geldt als **werkend afgerond** voor de eerste verticale doorsnede.

Bereikt in deze slice:
- SYN staat **rechts**
- SYN grijpt aan op een **beperkte, expliciete categorieverzameling**
- de zichtbare SYN-labels worden **neutraal** weergegeven, dus zonder geforceerde upper/lowercase-notatie
- toggle en undo/redo zijn getest in de actuele codebasis

Huidige minimale werkset voor SYN-broncategorieën:
- `S`
- `NP`
- `VP`

Nog open voor latere SYN-fases:
- formele definitie van `catknoop`
- definitieve `synCategoryLabels`
- gedrag bij meer dan twee dochters
- eventuele definitieve JAN-notatie
- koppeling van SYN aan L2-frames in plaats van alleen statische bomen

## 11. Wijziglog

- **2026-04-23**: terminologie aangepast van **language tree** naar **phrase tree**; vooruitblik toegevoegd dat later ten minste ook **Meta** als apart OPN-type wordt voorzien.
- **2026-04-23**: **SYN slice 1** op statische phrase trees gemarkeerd als werkend afgerond; zichtbare SYN-labels tijdelijk neutraal gemaakt zonder upper/lowercase-notatie.

- **2026-04-21**: bestandsformaat aangescherpt: `.ots` verlaten ten gunste van `.opn` als neutraler OpenSpec-formaat; `.graph` blijft kale JGraphEd-compatibele snapshot, `.opn` wordt rijke specslaag.
- **2026-04-18**: implementatievolgorde aangescherpt: eerste werkende slice richt zich op statische bomen (`type D` / `L1`) met **LEX links** en **SYN rechts**, met scheiding tussen `sourceBounds` en `renderBounds`; **L2** en automatische LOG-afleiding later.
- **2026-04-18**: SYN aangescherpt als rechter syntactische notatieprojectie; labelbron gewijzigd van knoopnaam naar geordende dochtercategorieën, met `computed` labeltransfer en JAN-hoofd-/kleinschriftconventie.
- **2026-04-18**: L2 formeel aangescherpt als groeiende boom via geordende open slots en plaatsing op de eerste geldige open plek; verwijzing toegevoegd naar `l2-growth-spec-v0.2.md`.
- **2026-04-14**: eerste vastlegging van W/O/Z/N en deelnameregels voor LEX, SYN en LOG.
- **2026-04-14**: document herwerkt naar vaste specificatiestructuur met kernmapping, regels, terminologie, implementatievragen en beslispunten.
- **2026-04-14**: structuurtype toegevoegd met types D = demo, L = language tree (later: phrase tree) en R = rest, inclusief invoer- en groeiregels in voorlopige vorm.
- **2026-04-14**: onderscheid aangescherpt tussen L2 en R: L2 is altijd een groeiende boom; bij R is nog open of het een boom of andere structuur is, en of die groeiend of getekend is.
- **2026-04-14**: voorlopige subtype-indeling voor R toegevoegd: R1 tree-getekend, R2 tree-groeiend, R3 niet-tree-getekend, R4 niet-tree-groeiend.
- **2026-04-16**: L2-open-punten opgeschoond; dubbele regels verwijderd.
- **2026-04-17**: sectie **Projectielayout en gridgedrag** toegevoegd aan de master-spec; hoofdregel vastgelegd dat projecties het structuurgrid niet vergroten.
- **2026-04-17**: sectie **Concrete app-config keys voor projectielayout** toegevoegd, inclusief YAML-voorstel, richtingregels en implementatiedoelen.
