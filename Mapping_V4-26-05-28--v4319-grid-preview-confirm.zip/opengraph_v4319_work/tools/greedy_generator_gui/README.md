# Greedy Graph Generator GUI

## Start

Dubbelklik:

```bat
start_gui.bat
```

De GUI opent met tabbladen:

- Basis
- Grid
- Greedy
- Output
- Spec

## Wat doet de GUI?

De GUI maakt direct:

- `.graph`
- `.svg`
- `.png`
- `_report.txt`
- `_effective_spec.yaml`

## Belangrijk

De output toont het volledige max-grid.  
Knoop 0 staat centraal.  
Alle knopen liggen exact op gridlijnen.

## Exe bouwen

Dubbelklik:

```bat
build_gui_exe.bat
```

Daarna staat de exe in:

```text
dist\GreedyGraphGUI.exe
```


## Nieuw in v2.1: diagonale vrijheid

Extra instelling in de GUI en in `spec.yaml`:

```yaml
constraints:
  diagonal_free: none
```

Mogelijke waarden:

| waarde | betekenis |
|---|---|
| `none` | geen diagonale vrijheidsregel |
| `slash` | `/`-diagonalen moeten vrij zijn: `x + y` uniek |
| `backslash` | `\`-diagonalen moeten vrij zijn: `x - y` uniek |
| `both` | beide diagonale richtingen moeten vrij zijn |

Deze regel komt bovenop de bestaande unieke x- en y-regels.


## Voorbeeldspecs voor diagonale vrijheid

Meegeleverd:

| bestand | betekenis |
|---|---|
| `spec_diagonal_slash.yaml` | `/`-diagonalen vrij houden |
| `spec_diagonal_backslash.yaml` | `\`-diagonalen vrij houden |
| `spec_diagonal_both_max30.yaml` | beide diagonale richtingen vrij houden, met ruimer `MAX=30` |

Start een specifieke spec via:

```bat
py greedy_generator_gui.py
```

en laad de spec in het tabblad **Spec**, of pas `spec.yaml` handmatig aan.


## Nieuw in v2.2: OPN-output

De GUI kan nu ook `.opn` schrijven. Zet in de GUI bij **Output** het vakje `.opn` aan, of gebruik in de spec:

```yaml
output:
  formats: [graph, svg, png, opn]
```

### Wat staat er in de OPN?

De generator schrijft een pipe-safe OPN met:

```text
STRUCTURE_NODES:
node-id | label | x | y | kind

STRUCTURE_EDGES:
from | to
```

De OPN bevat ook metadata/commentaar over:

- `max`
- `count`
- `style`
- `rule`
- `diagonal_free`

### Belangrijk verschil tussen `.graph` en `.opn`

De `.graph` bevat de directe OpenGraphEd-coördinaten.

De `.opn` bevat bron-gridcoördinaten:

```text
opn_x = model_x + MAX
opn_y = model_y + MAX
```

Bij het laden van OPN voegt OpenGraphEd zelf zijn vaste OPN-marge toe en gebruikt een gridcel van 20. Daardoor blijven de knopen exact op gridlijnen.

### Diagonal in OPN

`diagonal_free` wordt in de OPN expliciet meegeschreven als metadata. De OPN-plaatsing zelf is al volgens die regel berekend. Het `.opn`-bestand bevat dus zowel het resultaat als een leesbare vermelding van de gebruikte diagonale vrijheidsregel.


## v2.3: uitgebreide uitleg en taalinstelling

Toegevoegd:

- PDF-handleiding Nederlands: `GREEDY_GENERATOR_UITLEG_NL.pdf`
- PDF manual English: `GREEDY_GENERATOR_EXPLANATION_EN.pdf`
- GUI-tab `Uitleg/Help` met uitleg in Nederlands of Engels
- Instelling `output.language` in de spec
- GUI-keuze `Taal / Language` op het tabblad Basis

Voor Engelse output:

```yaml
output:
  language: en
```

Dit beinvloedt rapport, metadata in SVG/PNG en de Help-tab in de GUI.

## v4301: headless generation from OpenGraphEd

OpenGraphEd can now call the generator without opening the GUI.
The script used for that is:

```bat
generate_default_opn.bat
```

It reads `spec.yaml`, writes output into `output\`, and creates:

```text
output\last_generated.txt
```

OpenGraphEd menu item:

```text
OpenGraph > Generate + Load Greedy OPN
```

runs this headless generation and loads the resulting `.opn` directly.

## v4311: gridhoogte en gridbreedte in outputnamen

Elke outputnaam bevat nu de zichtbare griddimensies:

```text
<base>_gridH20W20.opn
<base>_gridH20W20.graph
<base>_gridH20W20.svg
<base>_gridH20W20.png
```

In `spec.yaml` kun je de gridhoogte en gridbreedte expliciet instellen:

```yaml
grid:
  height: 0
  width: 0
```

`0` betekent: automatisch afleiden uit `graph.max` en `grid.margin`.

OPN-bestanden bevatten nu ook een `GRID:`-sectie. OpenGraphEd leest die bij import, zodat de knopen direct op de bedoelde gridknooppunten vallen.
