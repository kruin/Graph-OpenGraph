package userInterface;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import graphStructure.*;
import userInterface.fileUtils.Utils;
import java.util.Vector;

final class OpenTreeStructureSupport
{
  private boolean resultAvailable;
  private GraphEditorWindow resultWindow;
  private Graph resultGraph;

  public void clear()
  {
    resultAvailable = false;
    resultWindow = null;
    resultGraph = null;
  }

  public boolean isSaveAvailableFor(GraphEditorWindow activeWindow)
  {
    return resultAvailable &&
           activeWindow != null &&
           activeWindow == resultWindow &&
           resultGraph != null;
  }

  public void rememberResult(GraphEditorWindow window, Graph drawnGraph) throws Exception
  {
    resultAvailable = true;
    resultWindow = window;
    resultGraph = cloneGraph(drawnGraph);
  }

  public void saveResult(Component parent, Graph sourceGraph) throws Exception
  {
    String suggestedPath = buildSuggestedPath(sourceGraph);
    JFileChooser chooser = createSaveChooser(suggestedPath);

    int returnVal = chooser.showSaveDialog(parent);
    if ( returnVal != JFileChooser.APPROVE_OPTION )
    {
      return;
    }

    File saveFile = ensureOPNExtension(chooser.getSelectedFile());
    saveFile = OpenGraphGridFileNameSupport.ensureGridTag(saveFile, resultGraph, Utils.opn);
    String savePath = saveFile.getCanonicalPath();
    if ( !confirmOverwriteIfNeeded(parent, savePath) )
    {
      return;
    }

    PrintWriter writer = new PrintWriter(new FileWriter(savePath));
    writeMiniOPN(writer, resultGraph, sourceGraph);
    writer.close();

    JOptionPane.showMessageDialog(parent,
                                  "Open format saved to:\n" + savePath,
                                  "Save OPN",
                                  JOptionPane.INFORMATION_MESSAGE);
  }


  private void writeMiniOPN(PrintWriter writer, Graph graph, Graph sourceGraph) throws Exception
  {
    if ( writer == null )
    {
      return;
    }

    ProjectionLayoutConfig config = graph == null ? new ProjectionLayoutConfig() : graph.getProjectionLayoutConfig();
    Vector links = graph == null ? new Vector() : graph.getProjectionLinks();

    writer.println("OPN_VERSION=0.1");
    writer.println("FORMAT=OpenSpec");
    writer.println();

    writer.println("[DOCUMENT]");
    writer.println("STRUCTURE_TYPE=" + detectStructureType(graph));
    writer.println("ROOT_GRAPH_LABEL=" + safeValue(graph == null ? null : graph.getLabel()));
    writer.println("SOURCE_FILE_OPTIONAL=" + safeValue(tryGetGraphFilePath(sourceGraph)));
    writer.println();

    writer.println("[PROJECTION_LAYOUT]");
    writer.println("GRID_RESIZE_MODE=" + enumName(config.gridResizeMode));
    writer.println("INCLUDE_SOURCE_STRUCTURE_IN_BOUNDS=" + config.includeSourceStructureInBounds);
    writer.println("INCLUDE_PROJECTION_NODES_IN_BOUNDS=" + config.includeProjectionNodesInBounds);
    writer.println("INCLUDE_PROJECTION_LABELS_IN_BOUNDS=" + config.includeProjectionLabelsInBounds);
    writer.println("RENDER_MARGIN_ENABLED=" + config.renderMarginEnabled);
    writer.println("RENDER_MARGIN_INCLUDE_PROJECTION_NODES=" + config.renderMarginIncludeProjectionNodes);
    writer.println("RENDER_MARGIN_INCLUDE_PROJECTION_LABELS=" + config.renderMarginIncludeProjectionLabels);
    writer.println("PROJECTION_OFFSET_IN_GRID_UNITS=" + config.projectionOffsetInGridUnits);
    writer.println("LABEL_GAP_FROM_PROJECTION_NODE_IN_GRID_UNITS=" + config.labelGapFromProjectionNodeInGridUnits);
    writer.println();

    writeProjectionSpec(writer, "LEX", config.lex);
    writeProjectionSpec(writer, "SYN", config.syn);
    writeProjectionSpec(writer, "LOG", config.log);

    writer.println("[PROJECTIONS]");
    writer.println("COUNT=" + links.size());
    for ( int i=0; i<links.size(); i++ )
    {
      ProjectionLink link = (ProjectionLink)links.elementAt(i);
      writeProjectionEntry(writer, i, link, graph);
    }
  }

  private void writeProjectionSpec(PrintWriter writer, String name, ProjectionSpec spec)
  {
    ProjectionSpec resolved = spec == null ? new ProjectionSpec() : spec;
    writer.println("[PROJECTION_SPEC " + name + "]");
    writer.println("ENABLED=" + resolved.enabled);
    writer.println("DIRECTION=" + enumName(resolved.direction));
    writer.println("ATTACH_TO=" + enumName(resolved.attachTo));
    writer.println("LABEL_TRANSFER=" + enumName(resolved.labelTransfer));
    writer.println("LABEL_SOURCE=" + safeValue(resolved.labelSource));
    writer.println();
  }

  private void writeProjectionEntry(PrintWriter writer, int index, ProjectionLink link, Graph graph)
  {
    if ( link == null )
    {
      return;
    }

    ProjectionNodeData nodeData = link.projectionNodeData;
    ProjectedLabel projectedLabel = link.projectedLabel;

    writer.println("PROJECTION_" + index + "_TYPE=" + enumName(link.projectionType));
    writer.println("PROJECTION_" + index + "_SOURCE_NODE_ID=" + nodeId(link.sourceNode));
    writer.println("PROJECTION_" + index + "_PROJECTION_NODE_ID=" + projectionNodeId(index, link.projectionNode));
    writer.println("PROJECTION_" + index + "_DIRECTION=" + enumName(nodeData == null ? null : nodeData.direction));
    writer.println("PROJECTION_" + index + "_LABEL_TRANSFER=" + enumName(projectedLabel == null ? null : projectedLabel.mode));
    writer.println("PROJECTION_" + index + "_PROJECTED_LABEL=" + safeValue(nodeData == null ? null : nodeData.projectedLabel));
    writer.println("PROJECTION_" + index + "_SOURCE_LABEL=" + safeValue(link.sourceNode == null ? null : link.sourceNode.getLabel()));
    writer.println();
  }

  private String nodeId(Node node)
  {
    if ( node == null )
    {
      return "";
    }
    return String.valueOf(node.getIndex());
  }

  private String projectionNodeId(int index, Node node)
  {
    if ( node == null )
    {
      return "P" + index;
    }
    return "P" + index + "@" + node.getLocation().intX() + "," + node.getLocation().intY();
  }

  private String enumName(Enum value)
  {
    return value == null ? "" : value.name();
  }

  private String safeValue(String value)
  {
    if ( value == null )
    {
      return "";
    }
    return value.replace('\r', ' ').replace('\n', ' ').trim();
  }

  private String detectStructureType(Graph graph)
  {
    if ( graph == null )
    {
      return "D";
    }
    Vector links = graph.getProjectionLinks();
    return links != null && links.size() > 0 ? "L1" : "D";
  }

  private String buildSuggestedPath(Graph sourceGraph) throws Exception
  {
    String sourcePath = tryGetGraphFilePath(sourceGraph);
    File baseFile;
    if ( sourcePath != null && sourcePath.length() > 0 )
    {
      baseFile = new File(deriveOPNPath(sourcePath));
    }
    else
    {
      baseFile = new File(System.getProperty("user.dir"), "OPN_graph.opn");
    }
    return OpenGraphGridFileNameSupport.ensureGridTag(baseFile, sourceGraph, Utils.opn).getCanonicalPath();
  }

  private JFileChooser createSaveChooser(String suggestedPath)
  {
    JFileChooser chooser = new JFileChooser();
    File suggestedFile = new File(suggestedPath);
    File parentDir = suggestedFile.getParentFile();
    if ( parentDir != null && parentDir.exists() )
    {
      chooser.setCurrentDirectory(parentDir);
    }
    else
    {
      chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
    }
    chooser.setSelectedFile(ensureOPNName(new File(suggestedFile.getName())));
    userInterface.fileUtils.OPNFilter opnFilter = new userInterface.fileUtils.OPNFilter();
    chooser.addChoosableFileFilter(opnFilter);
    chooser.setFileFilter(opnFilter);
    chooser.setAcceptAllFileFilterUsed(false);
    chooser.setDialogTitle("Save OPN");
    chooser.setApproveButtonText("Save OPN");
    chooser.setApproveButtonToolTipText("OPN = Open open format");

    JPanel accessory = new JPanel(new BorderLayout());
    accessory.add(new JLabel("<html><b>OPN</b> = Open format<br>Suggested result name starts with <b>OPN_</b> and ends with <b>.opn</b>.</html>"),
                  BorderLayout.NORTH);
    chooser.setAccessory(accessory);
    return chooser;
  }


  private File ensureOPNName(File selectedFile)
  {
    if ( selectedFile == null )
    {
      return new File("untitled.opn");
    }
    String name = selectedFile.getName();
    if ( name == null || name.trim().length() == 0 )
    {
      return new File("untitled.opn");
    }
    if ( name.toLowerCase().endsWith(".opn") )
    {
      return selectedFile;
    }
    return new File(selectedFile.getParentFile() == null ? "" : selectedFile.getParentFile().getPath(), name + ".opn");
  }

  private File ensureOPNExtension(File selectedFile) throws IOException
  {
    File named = ensureOPNName(selectedFile);
    return named.getCanonicalFile();
  }

  private boolean confirmOverwriteIfNeeded(Component parent, String savePath)
  {
    File aFile = new File(savePath);
    if ( aFile.exists() )
    {
      int returnInt = JOptionPane.showConfirmDialog(parent,
                        "Do you wish to Overwrite the file " + savePath + "?",
                        "File Already Exists",
                        JOptionPane.YES_NO_OPTION);
      return returnInt == JOptionPane.YES_OPTION;
    }
    return true;
  }

  private String deriveOPNPath(String sourcePath)
  {
    File sourceFile = new File(sourcePath);
    String name = sourceFile.getName();
    File parent = sourceFile.getParentFile();

    int dot = name.lastIndexOf('.');
    if ( dot > 0 )
    {
      name = name.substring(0, dot);
    }
    if ( !name.startsWith("OPN_") )
    {
      name = "OPN_" + name;
    }
    name = name + ".opn";

    if ( parent != null )
    {
      return new File(parent, name).getPath();
    }
    return name;
  }

  private String tryGetGraphFilePath(Graph graph)
  {
    try
    {
      java.lang.reflect.Method method = graph.getClass().getMethod("getFilePath", new Class[0]);
      Object value = method.invoke(graph, new Object[0]);
      if ( value instanceof String )
      {
        return (String)value;
      }
    }
    catch ( Exception e )
    {
    }
    return null;
  }

  private Graph cloneGraph(Graph sourceGraph) throws Exception
  {
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    sourceGraph.saveTo(pw);
    pw.close();

    BufferedReader reader = new BufferedReader(new StringReader(sw.toString()));
    Graph cloned = Graph.loadFrom(reader);
    reader.close();
    return cloned;
  }

  public void saveCurrentGraph(Component parent, Graph currentGraph) throws Exception
  {
    if ( currentGraph == null )
    {
      throw new Exception("No graph is open.");
    }

    String suggestedPath = buildSuggestedPath(currentGraph);
    JFileChooser chooser = createSaveChooser(suggestedPath);
    int returnVal = chooser.showSaveDialog(parent);
    if ( returnVal != JFileChooser.APPROVE_OPTION )
    {
      return;
    }

    File saveFile = ensureOPNExtension(chooser.getSelectedFile());
    saveFile = OpenGraphGridFileNameSupport.ensureGridTag(saveFile, currentGraph, Utils.opn);
    String savePath = saveFile.getCanonicalPath();
    if ( !confirmOverwriteIfNeeded(parent, savePath) )
    {
      return;
    }

    String sourcePath = tryGetGraphFilePath(currentGraph);
    if ( sourcePath != null && sourcePath.toLowerCase().endsWith(".opn") && new File(sourcePath).exists() )
    {
      copyTextFile(sourcePath, savePath);
    }
    else
    {
      PrintWriter writer = new PrintWriter(new FileWriter(savePath));
      writePipeSafeGraphOPN(writer, currentGraph);
      writer.close();
    }

    currentGraph.setFilePath(new File(savePath).getCanonicalPath());
    OpenGraphLegacyFileSupport.offerRenameAfterGridSave(parent, sourcePath, new File(savePath));

    JOptionPane.showMessageDialog(parent,
                                  "Open format saved to:\n" + savePath,
                                  "Save OPN",
                                  JOptionPane.INFORMATION_MESSAGE);
  }

  private void copyTextFile(String sourcePath, String savePath) throws Exception
  {
    BufferedReader reader = new BufferedReader(new FileReader(sourcePath));
    StringBuffer buffer = new StringBuffer();
    try
    {
      String line;
      while ( (line = reader.readLine()) != null )
      {
        buffer.append(line).append(System.getProperty("line.separator"));
      }
    }
    finally
    {
      reader.close();
    }

    PrintWriter writer = new PrintWriter(new FileWriter(savePath));
    try
    {
      writer.print(buffer.toString());
    }
    finally
    {
      writer.close();
    }
  }

  private void writePipeSafeGraphOPN(PrintWriter writer, Graph graph) throws Exception
  {
    writer.println("OPN_VERSION: 0.3");
    writer.println("STRUCTURE_TYPE: OpenGraphSource");
    writer.println("OPN_SOURCE_MODEL: free-nodes-on-grid");
    writer.println("# OPN pipe-safe drawable view generated by Save OPN");
    writer.println("# structure = current visible graph as free source nodes");
    writer.println();
    int rows = OpenGraphGridFileNameSupport.normalizedRows(graph);
    int cols = OpenGraphGridFileNameSupport.normalizedCols(graph);
    int stepX = graph.getGridColWidth() > 0 ? graph.getGridColWidth() : 20;
    int stepY = graph.getGridRowHeight() > 0 ? graph.getGridRowHeight() : 20;

    writer.println("OPN_SOURCE_NOTATION:");
    writer.println("# key | value");
    writer.println("source_model | free-nodes-on-grid");
    writer.println("free_node_definition | label plus source-grid position plus optional edges");
    writer.println("projection_status | none unless later sections add projection metadata");
    writer.println();
    writer.println("GRID:");
    writer.println("# key | value");
    writer.println("rows | " + rows);
    writer.println("cols | " + cols);
    writer.println("cell_height | " + stepY);
    writer.println("cell_width | " + stepX);
    writer.println("height | " + rows + "  # legacy: row count, not cell height");
    writer.println("width | " + cols + "  # legacy: column count, not cell width");
    writer.println("step_x | " + stepX);
    writer.println("step_y | " + stepY);
    writer.println("origin_x | " + graph.getGridOriginX());
    writer.println("origin_y | " + graph.getGridOriginY());
    writer.println("opn_loader_margin | 0");
    writer.println();
    writer.println("STRUCTURE_NODES:");

    java.util.Vector nodes = graph.getNodes();
    java.util.Map nodeToId = new java.util.HashMap();
    java.util.Map nodeToGridX = new java.util.HashMap();
    java.util.Map nodeToGridY = new java.util.HashMap();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      String id = "n" + i;
      nodeToId.put(node, id);
      int gx = OpenGraphGridFileNameSupport.gridX(graph, node);
      int gy = OpenGraphGridFileNameSupport.gridY(graph, node);
      nodeToGridX.put(node, Integer.valueOf(gx));
      nodeToGridY.put(node, Integer.valueOf(gy));
      writer.println(id + "|" + pipeSafe(node.getLabel()) + "|" + gx + "|" + gy + "|free-source-node");
    }

    writer.println();
    writer.println("STRUCTURE_EDGES:");
    java.util.Vector edges = graph.getEdges();
    for ( int i=0; i<edges.size(); i++ )
    {
      Edge edge = (Edge)edges.elementAt(i);
      String from = (String)nodeToId.get((Node)edge.getStartNode());
      String to = (String)nodeToId.get((Node)edge.getEndNode());
      if ( from != null && to != null )
      {
        writer.println(from + "|" + to);
      }
    }
    writer.println();
    writer.println("FREE_NODES:");
    writer.println("# id | label | source_x | source_y | x_line | y_line | slash_diag | backslash_diag | kind");
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      String id = (String)nodeToId.get(node);
      int gx = ((Integer)nodeToGridX.get(node)).intValue();
      int gy = ((Integer)nodeToGridY.get(node)).intValue();
      writer.println(id + "|" + pipeSafe(node.getLabel()) + "|" + gx + "|" + gy + "|" + gx + "|" + gy + "|" + (gx + gy) + "|" + (gx - gy) + "|free-source-node");
    }
    writer.println();
    writer.println("END_STRUCTURE:");
  }

  private String pipeSafe(String value)
  {
    if ( value == null ) return "";
    return value.replace('|', '/').replace('\r', ' ').replace('\n', ' ').trim();
  }
}
