package userInterface;

import java.io.File;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import graphStructure.*;

/**
 * Shared support for grid-aware file names and deterministic grid import.
 *
 * Convention: every OpenGraphEd output file name should contain
 *   gridH<cell-height>W<cell-width>
 * where height/width mean the grid cell size, not the number of rows/columns.
 * Example: name_gridH20W20.graph means row height 20 and column width 20.
 */
final class OpenGraphGridFileNameSupport
{
  private static final Pattern GRID_TAG = Pattern.compile("(?i)(?:^|[_-])gridH(\\d+)W(\\d+)(?=$|[_.-])");
  private static final int DEFAULT_CELL_HEIGHT = 20;
  private static final int DEFAULT_CELL_WIDTH = 20;

  private OpenGraphGridFileNameSupport() {}

  /** File-name tag: grid cell height,width. */
  static String gridTag(Graph graph)
  {
    int cellHeight = normalizedCellHeight(graph);
    int cellWidth = normalizedCellWidth(graph);
    return "gridH" + cellHeight + "W" + cellWidth;
  }

  static int normalizedCellHeight(Graph graph)
  {
    if ( graph == null ) return DEFAULT_CELL_HEIGHT;
    int cellHeight = graph.getGridRowHeight();
    return cellHeight > 0 ? cellHeight : DEFAULT_CELL_HEIGHT;
  }

  static int normalizedCellWidth(Graph graph)
  {
    if ( graph == null ) return DEFAULT_CELL_WIDTH;
    int cellWidth = graph.getGridColWidth();
    return cellWidth > 0 ? cellWidth : DEFAULT_CELL_WIDTH;
  }

  /** Drawable row count. This is not the filename grid tag. */
  static int normalizedRows(Graph graph)
  {
    if ( graph == null ) return 0;
    int rows = graph.getGridRows();
    if ( rows > 0 ) return rows;
    return inferRowsFromNodes(graph, normalizedCellHeight(graph));
  }

  /** Drawable column count. This is not the filename grid tag. */
  static int normalizedCols(Graph graph)
  {
    if ( graph == null ) return 0;
    int cols = graph.getGridCols();
    if ( cols > 0 ) return cols;
    return inferColsFromNodes(graph, normalizedCellWidth(graph));
  }

  static String ensureGridTagPath(String path, Graph graph, String defaultExtension)
  {
    if ( path == null || path.trim().length() == 0 ) return path;
    File file = new File(path);
    File tagged = ensureGridTag(file, graph, defaultExtension);
    return tagged.getPath();
  }

  static File ensureGridTag(File file, Graph graph, String defaultExtension)
  {
    if ( file == null ) return null;
    String name = file.getName();
    String ext = extension(name);
    String stem = stem(name);
    if ( ext.length() == 0 && defaultExtension != null && defaultExtension.trim().length() > 0 )
    {
      ext = defaultExtension.trim();
      if ( ext.startsWith(".") ) ext = ext.substring(1);
    }

    String tag = gridTag(graph);
    String taggedStem = replaceOrAppendGridTag(stem, tag);
    String taggedName = taggedStem + (ext.length() == 0 ? "" : "." + ext);
    File parent = file.getParentFile();
    return parent == null ? new File(taggedName) : new File(parent, taggedName);
  }

  /** Returns {cellHeight, cellWidth}. */
  static int[] parseGridTag(File file)
  {
    if ( file == null ) return null;
    return parseGridTag(file.getName());
  }

  /** Returns {cellHeight, cellWidth}. */
  static int[] parseGridTag(String name)
  {
    if ( name == null ) return null;
    Matcher matcher = GRID_TAG.matcher(name);
    int[] found = null;
    while ( matcher.find() )
    {
      try
      {
        int cellHeight = Integer.parseInt(matcher.group(1));
        int cellWidth = Integer.parseInt(matcher.group(2));
        if ( cellHeight > 0 && cellWidth > 0 ) found = new int[] { cellHeight, cellWidth };
      }
      catch ( NumberFormatException nfe )
      {
        // Ignore malformed grid tag.
      }
    }
    return found;
  }

  static boolean hasGridTag(File file)
  {
    return parseGridTag(file) != null;
  }

  /**
   * Applies a filename tag as cell height,width. Row/column count is kept from
   * the loaded file where available, and enlarged only when nodes need it.
   */
  static boolean applyGridTagFromFileName(Graph graph, File file)
  {
    int[] cell = parseGridTag(file);
    if ( graph == null || cell == null ) return false;
    applyGridCellSize(graph, cell[0], cell[1]);
    return true;
  }

  static void applyGridCellSize(Graph graph, int cellHeight, int cellWidth)
  {
    if ( graph == null || cellHeight <= 0 || cellWidth <= 0 ) return;
    int requiredRows = Math.max(normalizedRows(graph), inferRowsFromNodes(graph, cellHeight));
    int requiredCols = Math.max(normalizedCols(graph), inferColsFromNodes(graph, cellWidth));
    graph.setGrid(requiredRows, cellHeight, requiredCols, cellWidth, false);
  }

  /** Backward-compatible helper name used by older patch code: now means cell size. */
  static void applyGridDimensions(Graph graph, int cellHeight, int cellWidth)
  {
    applyGridCellSize(graph, cellHeight, cellWidth);
  }

  static void snapNodesToGrid(Graph graph)
  {
    if ( graph == null || graph.getGridRows() <= 0 || graph.getGridCols() <= 0 ) return;
    Vector nodes = graph.getNodes();
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      Location snapped = graph.getClosestGridLocation(node.getLocation());
      if ( snapped != null ) node.setLocation(snapped);
    }
  }

  static int gridX(Graph graph, Node node)
  {
    if ( graph == null || node == null ) return 0;
    int colWidth = Math.max(1, graph.getGridColWidth());
    return Math.max(0, (int)Math.round((node.getLocation().doubleX() - graph.getGridOriginX()) / (double)colWidth));
  }

  static int gridY(Graph graph, Node node)
  {
    if ( graph == null || node == null ) return 0;
    int rowHeight = Math.max(1, graph.getGridRowHeight());
    return Math.max(0, (int)Math.round((node.getLocation().doubleY() - graph.getGridOriginY()) / (double)rowHeight));
  }

  static String replaceOrAppendGridTag(String stem, String tag)
  {
    if ( stem == null || stem.length() == 0 ) stem = "untitled";
    if ( tag == null || tag.length() == 0 ) return stem;
    Matcher matcher = GRID_TAG.matcher(stem);
    if ( matcher.find() )
    {
      return matcher.replaceAll("_" + tag);
    }
    return stem + "_" + tag;
  }

  private static String extension(String name)
  {
    if ( name == null ) return "";
    int dot = name.lastIndexOf('.');
    if ( dot < 0 || dot == name.length()-1 ) return "";
    return name.substring(dot+1);
  }

  private static String stem(String name)
  {
    if ( name == null || name.length() == 0 ) return "untitled";
    int dot = name.lastIndexOf('.');
    if ( dot <= 0 ) return name;
    return name.substring(0, dot);
  }

  private static int inferRowsFromNodes(Graph graph, int rowHeight)
  {
    if ( graph == null ) return 0;
    Vector nodes = graph.getNodes();
    int max = 0;
    int cell = Math.max(1, rowHeight);
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      int y = Math.max(0, (int)Math.round((node.getLocation().doubleY() - graph.getGridOriginY()) / (double)cell));
      if ( y > max ) max = y;
    }
    return Math.max(2, max + 1);
  }

  private static int inferColsFromNodes(Graph graph, int colWidth)
  {
    if ( graph == null ) return 0;
    Vector nodes = graph.getNodes();
    int max = 0;
    int cell = Math.max(1, colWidth);
    for ( int i=0; i<nodes.size(); i++ )
    {
      Node node = (Node)nodes.elementAt(i);
      int x = Math.max(0, (int)Math.round((node.getLocation().doubleX() - graph.getGridOriginX()) / (double)cell));
      if ( x > max ) max = x;
    }
    return Math.max(2, max + 1);
  }
}
